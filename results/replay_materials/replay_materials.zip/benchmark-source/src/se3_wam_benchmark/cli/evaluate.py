from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from dataclasses import asdict
from pathlib import Path
from typing import cast

from se3_wam_benchmark.evaluation.policy import _load_policy_factory
from se3_wam_benchmark.evaluation.suite import evaluate


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="se3-wam-evaluate")
    parser.add_argument("--suite", required=True, type=Path)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument("--wall-control-period-s", type=float)
    parser.add_argument(
        "--execution-translation-limit-m", type=float, choices=(0.05, 0.10), default=0.05
    )
    parser.add_argument("--output", required=True, type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    arguments = _parser().parse_args(argv)
    output: Path = arguments.output
    if not output.parent.is_dir():
        raise FileNotFoundError(output.parent)
    if output.exists():
        raise FileExistsError(output)
    policy = _load_policy_factory(arguments.policy)
    summary = evaluate(
        policy,
        arguments.suite,
        shard_index=arguments.shard_index,
        shard_count=arguments.shard_count,
        wall_control_period_s=arguments.wall_control_period_s,
        execution_translation_limit_m=arguments.execution_translation_limit_m,
    )
    payload = json.dumps(
        cast(object, asdict(summary)),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(payload + "\n")


__all__ = ["main"]
