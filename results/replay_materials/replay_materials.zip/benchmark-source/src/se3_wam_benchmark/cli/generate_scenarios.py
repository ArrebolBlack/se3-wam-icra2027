from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    OOD_FACTORS,
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    _scenario_id,
    write_manifest,
)
from se3_wam_benchmark.tasks.registry import load_task


def _non_negative_integer(value: str) -> int:
    result = int(value)
    if result < 0:
        raise argparse.ArgumentTypeError("must be a non-negative integer")
    return result


def _positive_integer(value: str) -> int:
    result = int(value)
    if result <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="se3-wam-generate-scenarios")
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--recipe", required=True, type=Path)
    parser.add_argument(
        "--partition",
        required=True,
        choices=("train", "validation", "test_id", "ood", "stress"),
    )
    parser.add_argument("--factor", choices=tuple(sorted(OOD_FACTORS)))
    parser.add_argument("--recipe-name", required=True)
    parser.add_argument("--seed", required=True, type=_non_negative_integer)
    parser.add_argument("--count", required=True, type=_positive_integer)
    parser.add_argument("--output", required=True, type=Path)
    return parser


def _generate_manifest(
    *,
    task_id: str,
    recipe: Path,
    partition: Partition,
    factor: str | None,
    recipe_name: str,
    seed: int,
    count: int,
    output: Path,
) -> None:
    if partition == "ood":
        if factor not in OOD_FACTORS:
            raise ValueError("OOD generation requires one known factor")
    elif factor is not None:
        raise ValueError("factor is only valid for OOD generation")
    if not output.parent.is_dir():
        raise FileNotFoundError(output.parent)
    if output.exists():
        raise FileExistsError(output)
    task = load_task(task_id)
    rows: list[ScenarioManifestRow] = []
    for local_ordinal in range(count):
        source_seed = seed + local_ordinal
        rows.append(
            ScenarioManifestRow(
                schema_version=1,
                protocol_version="v1",
                scenario_id=_scenario_id(task_id, partition, factor, local_ordinal),
                task_id=task_id,
                partition=partition,
                factor=factor,
                source_seed=source_seed,
                scenario=generate_scenario(
                    task,
                    recipe,
                    source_seed,
                    partition=partition,
                    factor=factor,
                    recipe_name=recipe_name,
                ),
            )
        )
    write_manifest(ScenarioManifest(tuple(rows)), output)


def main(argv: Sequence[str] | None = None) -> None:
    arguments = _parser().parse_args(argv)
    _generate_manifest(
        task_id=arguments.task_id,
        recipe=arguments.recipe,
        partition=cast(Partition, arguments.partition),
        factor=arguments.factor,
        recipe_name=arguments.recipe_name,
        seed=arguments.seed,
        count=arguments.count,
        output=arguments.output,
    )


__all__ = ["main"]
