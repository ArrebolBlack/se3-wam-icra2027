from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

from se3_wam_benchmark.evaluation.policy import _load_policy_factory
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios.manifest import load_manifest
from se3_wam_benchmark.tasks.registry import load_task


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="se3-wam-record")
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument(
        "--policy", required=True, help="module:factory or the built-in offline native-oracle"
    )
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument(
        "--execution-translation-limit-m", type=float, choices=(0.05, 0.10), default=0.05
    )
    parser.add_argument("--output", required=True, type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    arguments = _parser().parse_args(argv)
    output: Path = arguments.output
    if not output.is_dir():
        raise ValueError("recording output must be an existing directory")
    manifest = load_manifest(arguments.manifest)
    shard = manifest.shard(arguments.shard_index, arguments.shard_count)
    native_oracle = arguments.policy == "native-oracle"
    policy = None if native_oracle else _load_policy_factory(arguments.policy)
    for row in shard:
        _rollout_episode(
            load_task(row.task_id),
            row.scenario,
            policy,
            scenario_id=row.scenario_id,
            partition=row.partition,
            factor=row.factor,
            repeat_index=0,
            record_directory=output,
            execution_translation_limit_m=arguments.execution_translation_limit_m,
            _native_oracle=native_oracle,
        )


__all__ = ["main"]
