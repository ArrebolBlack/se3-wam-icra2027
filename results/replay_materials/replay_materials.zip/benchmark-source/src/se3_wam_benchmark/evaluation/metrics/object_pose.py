"""Explicit offline symmetry-aware object-pose diagnostics."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
import numpy.typing as npt

_SymmetryKind = Literal[
    "identity",
    "finite",
    "axial_directed",
    "axial_bidirectional",
    "spherical",
]


@dataclass(frozen=True, slots=True)
class _ObjectPoseMetrics:
    pose_translation_ade_m: float | None
    pose_rotation_ade_rad: float | None
    pose_translation_fde_m: float | None
    pose_rotation_fde_rad: float | None
    valid_count: int

    @property
    def se3_pose_ade(self) -> tuple[float, float] | None:
        if self.pose_translation_ade_m is None or self.pose_rotation_ade_rad is None:
            return None
        return self.pose_translation_ade_m, self.pose_rotation_ade_rad

    @property
    def se3_pose_fde(self) -> tuple[float, float] | None:
        if self.pose_translation_fde_m is None or self.pose_rotation_fde_rad is None:
            return None
        return self.pose_translation_fde_m, self.pose_rotation_fde_rad


def _quaternion_xyzw_to_matrix(
    quaternion_xyzw: npt.NDArray[np.float64],
) -> npt.NDArray[np.float64]:
    x, y, z, w = quaternion_xyzw
    return np.array(
        (
            (1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)),
            (2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)),
            (2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)),
        ),
        dtype=np.float64,
    )


def _rotation_angle(first: npt.NDArray[np.float64], second: npt.NDArray[np.float64]) -> float:
    cosine = float((np.trace(first.T @ second) - 1.0) / 2.0)
    return math.acos(float(np.clip(cosine, -1.0, 1.0)))


def _proper_rotations(
    value: npt.NDArray[np.float64] | None,
) -> npt.NDArray[np.float64]:
    if (
        not isinstance(value, np.ndarray)
        or value.dtype != np.float64
        or value.ndim != 3
        or value.shape[0] == 0
        or value.shape[1:] != (3, 3)
        or not np.isfinite(value).all()
    ):
        raise ValueError("finite_symmetry_rotations must be a finite float64[S,3,3] array")
    gram = np.swapaxes(value, 1, 2) @ value
    if not np.allclose(gram, np.eye(3), rtol=0.0, atol=1e-8) or not np.allclose(
        np.linalg.det(value), 1.0, rtol=0.0, atol=1e-8
    ):
        raise ValueError("finite_symmetry_rotations must contain proper rotations")
    return value


def _unit_axis(value: npt.NDArray[np.float64] | None) -> npt.NDArray[np.float64]:
    if (
        not isinstance(value, np.ndarray)
        or value.dtype != np.float64
        or value.shape != (3,)
        or not np.isfinite(value).all()
        or not math.isclose(float(np.linalg.norm(value)), 1.0, rel_tol=0.0, abs_tol=1e-8)
    ):
        raise ValueError("symmetry_axis_local must be a finite unit float64[3] array")
    return value


def _rotation_error(
    predicted: npt.NDArray[np.float64],
    truth: npt.NDArray[np.float64],
    *,
    symmetry: _SymmetryKind,
    finite_symmetry_rotations: npt.NDArray[np.float64] | None,
    symmetry_axis_local: npt.NDArray[np.float64] | None,
) -> float:
    """Compute one error using symmetry inputs validated by the metrics entry point."""
    if symmetry == "spherical":
        return 0.0
    if symmetry == "identity":
        return _rotation_angle(predicted, truth)
    if symmetry == "finite":
        assert finite_symmetry_rotations is not None
        return min(
            _rotation_angle(predicted, truth @ member) for member in finite_symmetry_rotations
        )
    assert symmetry_axis_local is not None
    cosine = float(np.dot(predicted @ symmetry_axis_local, truth @ symmetry_axis_local))
    if symmetry == "axial_bidirectional":
        cosine = abs(cosine)
    return math.acos(float(np.clip(cosine, -1.0, 1.0)))


def _offline_object_pose_metrics(
    prediction_world: npt.NDArray[np.float64],
    ground_truth_world: npt.NDArray[np.float64],
    valid: npt.NDArray[np.bool_],
    *,
    symmetry: _SymmetryKind,
    finite_symmetry_rotations: npt.NDArray[np.float64] | None = None,
    symmetry_axis_local: npt.NDArray[np.float64] | None = None,
) -> _ObjectPoseMetrics:
    if (
        not isinstance(prediction_world, np.ndarray)
        or prediction_world.dtype != np.float64
        or prediction_world.ndim != 2
        or prediction_world.shape[0] == 0
        or prediction_world.shape[1] != 7
    ):
        raise ValueError("prediction_world must be a non-empty float64[F,7] array")
    if (
        not isinstance(ground_truth_world, np.ndarray)
        or ground_truth_world.dtype != np.float64
        or ground_truth_world.shape != prediction_world.shape
    ):
        raise ValueError("ground_truth_world must match prediction_world as float64[F,7]")
    if (
        not isinstance(valid, np.ndarray)
        or valid.dtype != np.bool_
        or valid.shape != (prediction_world.shape[0],)
    ):
        raise ValueError("valid must be bool[F]")
    if not np.isfinite(prediction_world).all() or not np.isfinite(ground_truth_world).all():
        raise ValueError("pose prediction and ground truth must be finite")
    if symmetry not in (
        "identity",
        "finite",
        "axial_directed",
        "axial_bidirectional",
        "spherical",
    ):
        raise ValueError("unknown object-pose symmetry")
    if symmetry == "finite":
        finite_symmetry_rotations = _proper_rotations(finite_symmetry_rotations)
    elif finite_symmetry_rotations is not None:
        raise ValueError("finite_symmetry_rotations is only valid for finite symmetry")
    if symmetry in ("axial_directed", "axial_bidirectional"):
        symmetry_axis_local = _unit_axis(symmetry_axis_local)
    elif symmetry_axis_local is not None:
        raise ValueError("symmetry_axis_local is only valid for axial symmetry")

    predicted_quaternion = prediction_world[:, 3:]
    truth_quaternion = ground_truth_world[:, 3:]
    for name, quaternion in (
        ("prediction_world", predicted_quaternion),
        ("ground_truth_world", truth_quaternion),
    ):
        if not np.allclose(np.linalg.norm(quaternion, axis=1), 1.0, rtol=0.0, atol=1e-8):
            raise ValueError(f"{name} quaternions must be unit length")

    indices = np.flatnonzero(valid)
    if len(indices) == 0:
        return _ObjectPoseMetrics(None, None, None, None, 0)
    translation_errors = np.linalg.norm(
        prediction_world[indices, :3] - ground_truth_world[indices, :3], axis=1
    )
    rotation_errors = np.asarray(
        [
            _rotation_error(
                _quaternion_xyzw_to_matrix(predicted_quaternion[index]),
                _quaternion_xyzw_to_matrix(truth_quaternion[index]),
                symmetry=symmetry,
                finite_symmetry_rotations=finite_symmetry_rotations,
                symmetry_axis_local=symmetry_axis_local,
            )
            for index in indices
        ],
        dtype=np.float64,
    )
    final_valid = bool(valid[-1])
    return _ObjectPoseMetrics(
        pose_translation_ade_m=float(np.mean(translation_errors)),
        pose_rotation_ade_rad=float(np.mean(rotation_errors)),
        pose_translation_fde_m=float(translation_errors[-1]) if final_valid else None,
        pose_rotation_fde_rad=float(rotation_errors[-1]) if final_valid else None,
        valid_count=len(indices),
    )


__all__: list[str] = []
