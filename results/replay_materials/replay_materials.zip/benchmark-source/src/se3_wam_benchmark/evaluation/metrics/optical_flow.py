"""Explicit offline 2D optical-flow diagnostics."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt


@dataclass(frozen=True, slots=True)
class _OpticalFlowMetrics:
    epe2d_valid_px: float | None
    epe2d_visible_px: float | None
    epe2d_occluded_px: float | None
    epe2d_out_of_frame_px: float | None
    valid_count: int
    visible_count: int
    occluded_count: int
    out_of_frame_count: int


def _mean_epe(
    error: npt.NDArray[np.float64], mask: npt.NDArray[np.bool_]
) -> tuple[float | None, int]:
    count = int(np.count_nonzero(mask))
    return float(np.mean(error[mask])) if count else None, count


def _offline_optical_flow_metrics(
    prediction_2d_px: npt.NDArray[np.float32],
    ground_truth_2d_px: npt.NDArray[np.float32],
    flow_valid: npt.NDArray[np.bool_],
    flow_future_visible: npt.NDArray[np.bool_],
) -> _OpticalFlowMetrics:
    if (
        not isinstance(prediction_2d_px, np.ndarray)
        or prediction_2d_px.dtype != np.float32
        or prediction_2d_px.ndim != 5
        or prediction_2d_px.shape[-1] != 2
        or any(size <= 0 for size in prediction_2d_px.shape[:-1])
    ):
        raise ValueError("prediction_2d_px must be a non-empty float32[N,V,H,W,2] array")
    if (
        not isinstance(ground_truth_2d_px, np.ndarray)
        or ground_truth_2d_px.dtype != np.float32
        or ground_truth_2d_px.shape != prediction_2d_px.shape
    ):
        raise ValueError("ground_truth_2d_px must match prediction_2d_px as float32[N,V,H,W,2]")
    mask_shape = prediction_2d_px.shape[:-1]
    if (
        not isinstance(flow_valid, np.ndarray)
        or flow_valid.dtype != np.bool_
        or flow_valid.shape != mask_shape
    ):
        raise ValueError("flow_valid must be bool[N,V,H,W]")
    if (
        not isinstance(flow_future_visible, np.ndarray)
        or flow_future_visible.dtype != np.bool_
        or flow_future_visible.shape != mask_shape
    ):
        raise ValueError("flow_future_visible must be bool[N,V,H,W]")
    if not np.isfinite(prediction_2d_px).all() or not np.isfinite(ground_truth_2d_px).all():
        raise ValueError("predicted and ground-truth flow must be finite")
    if np.any(ground_truth_2d_px[~flow_valid] != 0.0):
        raise ValueError("invalid ground-truth flow values must be zero")
    if np.any(flow_future_visible & ~flow_valid):
        raise ValueError("flow_future_visible must be a subset of flow_valid")

    _, _, height, width, _ = prediction_2d_px.shape
    pixel_u, pixel_v = np.meshgrid(
        np.arange(width, dtype=np.float64),
        np.arange(height, dtype=np.float64),
    )
    target_u = pixel_u[None, None, ...] + ground_truth_2d_px[..., 0]
    target_v = pixel_v[None, None, ...] + ground_truth_2d_px[..., 1]
    in_frame = (
        (target_u >= 0.0) & (target_u <= width - 1) & (target_v >= 0.0) & (target_v <= height - 1)
    )
    if np.any(flow_future_visible & ~in_frame):
        raise ValueError("future-visible flow must have an in-frame continuous target coordinate")
    error = np.linalg.norm(
        prediction_2d_px.astype(np.float64) - ground_truth_2d_px.astype(np.float64),
        axis=-1,
    )
    visible = flow_valid & flow_future_visible
    occluded = flow_valid & in_frame & ~flow_future_visible
    out_of_frame = flow_valid & ~in_frame
    valid_metric, valid_count = _mean_epe(error, flow_valid)
    visible_metric, visible_count = _mean_epe(error, visible)
    occluded_metric, occluded_count = _mean_epe(error, occluded)
    out_of_frame_metric, out_of_frame_count = _mean_epe(error, out_of_frame)
    return _OpticalFlowMetrics(
        epe2d_valid_px=valid_metric,
        epe2d_visible_px=visible_metric,
        epe2d_occluded_px=occluded_metric,
        epe2d_out_of_frame_px=out_of_frame_metric,
        valid_count=valid_count,
        visible_count=visible_count,
        occluded_count=occluded_count,
        out_of_frame_count=out_of_frame_count,
    )


__all__: list[str] = []
