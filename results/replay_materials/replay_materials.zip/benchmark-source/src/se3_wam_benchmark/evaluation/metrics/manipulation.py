"""Pure single-episode manipulation metrics from an already aligned trace."""

from __future__ import annotations

from typing import Final

from se3_wam_benchmark.evaluation.result import (
    EpisodeTrace,
    FailureClass,
    ManipulationMetrics,
    StageName,
    failure_class_for,
)

_CAPTURE_STAGES: Final[tuple[StageName, ...]] = (
    "approach",
    "fingerpad_contact",
    "bilateral_hold",
    "clearance",
    "stable_dwell",
)
_PLACEMENT_STAGES: Final[tuple[StageName, ...]] = (
    "goal_approach",
    "full_containment",
    "release",
    "low_relative_motion",
    "stable_dwell",
)
_PHASE_STAGES: Final[tuple[StageName, ...]] = (
    "phase_alignment",
    "loop_entry",
    "path_progress_0_60",
    "terminal_arrival",
)
_FULL_ROTATING_STAGES: Final[tuple[StageName, ...]] = (
    "wand_acquisition",
    *_PHASE_STAGES,
    "wire_exit",
    "wand_release",
)
_REPLANNING_STAGES: Final[tuple[StageName, ...]] = (
    "valid_selected_impact",
    *_CAPTURE_STAGES,
)
_CAPTURE_TASK_IDS: Final[frozenset[str]] = frozenset(
    {
        "grasp",
        "t1_belt",
        "t1_xyz",
        "t1_so3",
        "t1_occ",
        "t4_sphere",
        "t4_sphere_tabletop",
        "t4_slider",
        "t4_can",
    }
)


def _stage_names_for_task(task_id: str) -> tuple[StageName, ...]:
    if task_id == "t2_trans" or task_id == "t2_se3":
        return _PLACEMENT_STAGES
    if task_id == "t3_phase":
        return _PHASE_STAGES
    if task_id == "t3_full":
        return _FULL_ROTATING_STAGES
    if task_id == "t5_replan":
        return _REPLANNING_STAGES
    if task_id in _CAPTURE_TASK_IDS:
        return _CAPTURE_STAGES
    raise ValueError(f"task completion stages are not defined for task: {task_id}")


def _failure_class(trace: EpisodeTrace) -> FailureClass | None:
    if trace.success:
        return None
    if trace.failure_code is None:
        raise ValueError("failed EpisodeTrace requires one failure code")
    return failure_class_for(trace.failure_code)


def _task_completion(trace: EpisodeTrace) -> float:
    expected = _stage_names_for_task(trace.task_id)
    for step in trace.steps:
        actual = tuple(stage.stage_name for stage in step.stage_progress)
        if actual != expected:
            raise ValueError("stage_progress does not match the frozen task stage sequence")
    final = trace.steps[-1].stage_progress
    completed = 0
    active_progress = 0.0
    for stage in final:
        if stage.completed:
            completed += 1
        else:
            active_progress = stage.progress
            break
    value = (completed + active_progress) / len(expected)
    if trace.success and value != 1.0:
        raise ValueError("successful EpisodeTrace must complete every task stage")
    if not trace.success and value == 1.0:
        raise ValueError("failed EpisodeTrace cannot complete every task stage")
    return value


def _manipulation_metrics(trace: EpisodeTrace) -> ManipulationMetrics:
    failure_class = _failure_class(trace)
    return ManipulationMetrics(
        success_rate=1.0 if trace.success else 0.0,
        task_completion=_task_completion(trace),
        completion_time_s=trace.elapsed_s if trace.success else None,
        safety_failure_rate=1.0 if failure_class == "safety" else 0.0,
    )


__all__: list[str] = []
