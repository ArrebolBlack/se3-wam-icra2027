from __future__ import annotations

import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from statistics import NormalDist
from typing import Literal, TypeVar, cast

import numpy as np
import numpy.typing as npt
import yaml

from se3_wam_benchmark.control.action import (
    ActionMode,
    ActionRepresentation,
    _validate_execution_translation_limit,
)
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy
from se3_wam_benchmark.evaluation.result import (
    FAILURE_CODES,
    AggregateMetrics,
    EpisodeResult,
    EvaluationGroup,
    EvaluationGroupKey,
    EvaluationSummary,
    FailureCode,
    FailureRate,
    MetricEstimate,
    PairedDifferenceMetrics,
)
from se3_wam_benchmark.evaluation.rollout import (
    _rollout_episode,
    _validated_wall_control_period_s,
)
from se3_wam_benchmark.scenarios.manifest import (
    OOD_FACTORS,
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
)
from se3_wam_benchmark.tasks.registry import TASK_IDS, load_task, load_yaml_strict

GROUP_FIELDS = (
    "task_id",
    "partition",
    "factor",
    "action_mode",
    "action_representation",
    "observation_profile",
)

_BOOTSTRAP_SAMPLES = 10_000
_BOOTSTRAP_SEED = 0
_WILSON_Z_95 = NormalDist().inv_cdf(0.975)
_ObservationProfile = Literal["agentview", "agentview_wrist"]


def _is_formal_v1_suite_id(suite_id: str) -> bool:
    if suite_id in {"validation", "test_id", "stress", "benchmark_v1"}:
        return True
    return suite_id.startswith("ood_") and suite_id.removeprefix("ood_") in OOD_FACTORS


@dataclass(frozen=True, slots=True)
class SuiteMember:
    manifest: Path
    task_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.manifest, Path):
            raise ValueError("Suite member manifest must be a Path")
        if not isinstance(self.task_ids, tuple) or not self.task_ids:
            raise ValueError("Suite member task_ids must be a non-empty tuple")
        if any(task_id not in TASK_IDS for task_id in self.task_ids):
            raise ValueError("Suite member contains an unknown task_id")
        if len(self.task_ids) != len(set(self.task_ids)):
            raise ValueError("Suite member task_ids must be unique")
        order = {task_id: index for index, task_id in enumerate(TASK_IDS)}
        if tuple(sorted(self.task_ids, key=order.__getitem__)) != self.task_ids:
            raise ValueError("Suite member task_ids must follow registry order")


@dataclass(frozen=True, slots=True)
class SuiteSpec:
    suite_id: str
    protocol_version: str
    repeats: int
    members: tuple[SuiteMember, ...]
    group_by: tuple[str, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.suite_id, str) or not self.suite_id:
            raise ValueError("suite_id must be non-empty")
        if self.protocol_version != "v1":
            raise ValueError("Suite protocol_version must be v1")
        if isinstance(self.repeats, bool) or not isinstance(self.repeats, int) or self.repeats <= 0:
            raise ValueError("repeats must be a positive integer")
        if _is_formal_v1_suite_id(self.suite_id) and self.repeats != 1:
            raise ValueError("formal v1 Suites require repeats=1")
        if (
            not isinstance(self.members, tuple)
            or not self.members
            or not all(isinstance(member, SuiteMember) for member in self.members)
        ):
            raise ValueError("members must be a non-empty SuiteMember tuple")
        manifests = tuple(member.manifest for member in self.members)
        if len(manifests) != len(set(manifests)):
            raise ValueError("Suite member manifests must be unique")
        if self.group_by != GROUP_FIELDS:
            raise ValueError("group_by must equal the frozen field sequence")


@dataclass(frozen=True, slots=True)
class _SuiteJob:
    row: ScenarioManifestRow
    repeat_index: int


@dataclass(frozen=True, slots=True)
class _EvaluatedEpisode:
    result: EpisodeResult
    source_seed: int


@dataclass(frozen=True, slots=True)
class _ScenarioMetrics:
    scenario_id: str
    task_id: str
    partition: Partition
    factor: str | None
    action_mode: ActionMode
    action_representation: ActionRepresentation
    observation_profile: _ObservationProfile
    source_seed: int
    n_total: int
    n_success: int
    n_failure: int
    completion_time_n_valid: int
    success_rate: float
    task_completion: float
    completion_time_s: float | None
    safety_failure_rate: float
    failure_rates: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class _PairedScenarioMetrics:
    scenario_id: str
    task_id: str
    factor: str
    action_mode: ActionMode
    action_representation: ActionRepresentation
    observation_profile: _ObservationProfile
    source_seed: int
    n_total: int
    completion_time_n_valid: int
    success_rate: float
    task_completion: float
    completion_time_s: float | None
    safety_failure_rate: float
    failure_rates: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class _EstimateObservation:
    task_id: str
    source_seed: int
    value: float


_Scenario = TypeVar("_Scenario", _ScenarioMetrics, _PairedScenarioMetrics)
_GroupTuple = tuple[
    str,
    Partition,
    str | None,
    ActionMode,
    ActionRepresentation,
    _ObservationProfile,
]
_MacroTuple = tuple[
    Partition,
    str | None,
    ActionMode,
    ActionRepresentation,
    _ObservationProfile,
]
_PairTuple = tuple[
    str,
    int,
    ActionMode,
    ActionRepresentation,
    _ObservationProfile,
    int,
]
_KnownPairTuple = tuple[
    str,
    int,
    ActionMode,
    _ObservationProfile,
    int,
]
_ShardTuple = tuple[
    str,
    str,
    int,
    ActionMode,
    _ObservationProfile,
]


def _exact(value: Mapping[str, object], fields: set[str], name: str) -> None:
    missing = fields - value.keys()
    unknown = value.keys() - fields
    if missing:
        raise ValueError(f"{name} missing fields: {sorted(missing)}")
    if unknown:
        raise ValueError(f"{name} unknown fields: {sorted(unknown)}")


def load_suite(path: str | Path) -> SuiteSpec:
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    try:
        data = load_yaml_strict(source)
        _exact(
            data,
            {"schema_version", "suite_id", "protocol_version", "repeats", "members", "report"},
            "suite",
        )
        if (
            isinstance(data["schema_version"], bool)
            or not isinstance(data["schema_version"], int)
            or data["schema_version"] != 1
            or data["protocol_version"] != "v1"
        ):
            raise ValueError("Suite requires schema_version 1 and protocol_version v1")
        suite_id = data["suite_id"]
        if not isinstance(suite_id, str) or suite_id != source.stem:
            raise ValueError("suite_id must match the Suite filename")
        repeats = data["repeats"]
        if isinstance(repeats, bool) or not isinstance(repeats, int) or repeats <= 0:
            raise ValueError("repeats must be a positive integer")
        raw_members = data["members"]
        if not isinstance(raw_members, list) or not raw_members:
            raise ValueError("members must be a non-empty list")
        members: list[SuiteMember] = []
        for raw_member in raw_members:
            if not isinstance(raw_member, Mapping):
                raise ValueError("Suite member must be a mapping")
            _exact(raw_member, {"manifest", "task_ids"}, "Suite member")
            manifest = raw_member["manifest"]
            task_ids = raw_member["task_ids"]
            if not isinstance(manifest, str) or not isinstance(task_ids, list) or not task_ids:
                raise ValueError("Suite member requires manifest and explicit task_ids")
            if not all(isinstance(task_id, str) for task_id in task_ids):
                raise ValueError("Suite task_ids must be strings")
            members.append(SuiteMember((source.parent / manifest).resolve(), tuple(task_ids)))
        report = data["report"]
        if not isinstance(report, Mapping):
            raise ValueError("report must be a mapping")
        _exact(report, {"group_by"}, "report")
        group_by = report["group_by"]
        if not isinstance(group_by, list) or tuple(group_by) != GROUP_FIELDS:
            raise ValueError("group_by must equal the frozen field sequence")
        result = SuiteSpec(suite_id, "v1", repeats, tuple(members), GROUP_FIELDS)
        for member in result.members:
            if not member.manifest.is_file():
                raise FileNotFoundError(member.manifest)
        return result
    except (ValueError, yaml.YAMLError) as exc:
        if str(source) not in getattr(exc, "__notes__", ()):
            exc.add_note(str(source))
        raise


def _member_rows(
    member: SuiteMember, manifest: ScenarioManifest
) -> tuple[ScenarioManifestRow, ...]:
    rows = tuple(row for row in manifest if row.task_id in member.task_ids)
    present = {row.task_id for row in rows}
    missing = tuple(task_id for task_id in member.task_ids if task_id not in present)
    if missing:
        raise ValueError(
            f"Suite member {member.manifest} has no rows for declared task_ids: {list(missing)}"
        )
    return rows


def _load_declared_jobs(
    suite: SuiteSpec,
) -> tuple[tuple[_SuiteJob, ...], tuple[ScenarioManifest, ...]]:
    jobs: list[_SuiteJob] = []
    manifests: list[ScenarioManifest] = []
    for member in suite.members:
        manifest = load_manifest(member.manifest)
        manifests.append(manifest)
        for row in _member_rows(member, manifest):
            for repeat_index in range(suite.repeats):
                jobs.append(_SuiteJob(row, repeat_index))
    _validate_static_job_identities(jobs)
    return tuple(jobs), tuple(manifests)


def _validate_static_job_identities(jobs: Sequence[_SuiteJob]) -> None:
    seen: set[tuple[str, int]] = set()
    for job in jobs:
        identity = (job.row.scenario_id, job.repeat_index)
        if identity in seen:
            raise ValueError(f"duplicate declared scenario/repeat identity: {identity}")
        seen.add(identity)


def _known_pair_key(job: _SuiteJob) -> _KnownPairTuple:
    row = job.row
    return (
        row.task_id,
        row.source_seed,
        row.scenario.action_mode,
        row.scenario.observation_profile,
        job.repeat_index,
    )


def _shard_group_key(job: _SuiteJob) -> _ShardTuple:
    row = job.row
    owner = "paired" if row.partition in {"test_id", "ood"} else row.scenario_id
    return (
        owner,
        row.task_id,
        row.source_seed,
        row.scenario.action_mode,
        row.scenario.observation_profile,
    )


def _shard_group_ordinals(jobs: Sequence[_SuiteJob]) -> dict[_ShardTuple, int]:
    ordinals: dict[_ShardTuple, int] = {}
    for job in jobs:
        key = _shard_group_key(job)
        if key not in ordinals:
            ordinals[key] = len(ordinals)
    return ordinals


def _select_shard_jobs(
    jobs: Sequence[_SuiteJob],
    ordinals: Mapping[_ShardTuple, int],
    *,
    shard_index: int,
    shard_count: int,
) -> tuple[_SuiteJob, ...]:
    selected: list[_SuiteJob] = []
    for job in jobs:
        ordinal = ordinals.get(_shard_group_key(job))
        if ordinal is None:
            raise RuntimeError("Suite job has no declared shard group")
        if ordinal % shard_count == shard_index:
            selected.append(job)
    return tuple(selected)


def _validate_evaluated_identity(job: _SuiteJob, result: EpisodeResult) -> None:
    row = job.row
    expected = (
        row.scenario_id,
        row.task_id,
        row.partition,
        row.factor,
        job.repeat_index,
        row.scenario.action_mode,
        row.scenario.observation_profile,
    )
    actual = (
        result.scenario_id,
        result.task_id,
        result.partition,
        result.factor,
        result.repeat_index,
        result.action_mode,
        result.observation_profile,
    )
    if actual != expected:
        raise RuntimeError("rollout result identity does not match its Suite job")


def _evaluate_jobs(
    policy: BenchmarkPolicy,
    jobs: Sequence[_SuiteJob],
    *,
    wall_control_period_s: float | None,
    execution_translation_limit_m: float,
) -> tuple[_EvaluatedEpisode, ...]:
    evaluated: list[_EvaluatedEpisode] = []
    for job in jobs:
        row = job.row
        trace = _rollout_episode(
            load_task(row.task_id),
            row.scenario,
            policy,
            scenario_id=row.scenario_id,
            partition=row.partition,
            factor=row.factor,
            repeat_index=job.repeat_index,
            wall_control_period_s=wall_control_period_s,
            execution_translation_limit_m=execution_translation_limit_m,
        )
        result = _evaluate_episode(trace)
        _validate_evaluated_identity(job, result)
        evaluated.append(_EvaluatedEpisode(result, row.source_seed))
    return tuple(evaluated)


def _standalone_ood_reference_jobs(
    suite: SuiteSpec,
    declared_manifests: tuple[ScenarioManifest, ...],
    selected_ood_jobs: Sequence[_SuiteJob],
) -> tuple[_SuiteJob, ...]:
    if len(suite.members) != 1 or len(declared_manifests) != 1:
        return ()
    member = suite.members[0]
    stem = member.manifest.stem
    if (
        suite.suite_id != stem
        or not stem.startswith("ood_")
        or member.manifest.parent.name != "v1"
        or member.manifest.parent.parent.name != "manifests"
    ):
        return ()
    factor = stem.removeprefix("ood_")
    if factor not in OOD_FACTORS:
        return ()
    manifest = declared_manifests[0]
    if any(row.partition != "ood" or row.factor != factor for row in manifest):
        raise ValueError("standalone OOD Suite member does not match its named factor")
    reference_path = member.manifest.with_name("test_id.jsonl")
    if not reference_path.is_file():
        raise FileNotFoundError(reference_path)
    reference = load_manifest(reference_path)
    needed = {_known_pair_key(job) for job in selected_ood_jobs}
    jobs: list[_SuiteJob] = []
    for row in _member_rows(SuiteMember(reference_path, member.task_ids), reference):
        for repeat_index in range(suite.repeats):
            candidate = _SuiteJob(row, repeat_index)
            key = _known_pair_key(candidate)
            if key in needed:
                jobs.append(candidate)
    return tuple(jobs)


def _validate_known_pair_candidates(
    declared_jobs: Sequence[_SuiteJob],
    hidden_reference_jobs: Sequence[_SuiteJob],
) -> None:
    references = {
        _known_pair_key(job)
        for job in (*declared_jobs, *hidden_reference_jobs)
        if job.row.partition == "test_id"
    }
    for job in declared_jobs:
        if job.row.partition == "ood" and _known_pair_key(job) not in references:
            raise ValueError(
                f"missing test-ID reference for known paired identity: {_known_pair_key(job)}"
            )


def _prepare_suite_jobs(
    suite: SuiteSpec,
    *,
    shard_index: int,
    shard_count: int,
) -> tuple[tuple[_SuiteJob, ...], tuple[_SuiteJob, ...]]:
    declared_jobs, manifests = _load_declared_jobs(suite)
    hidden_reference_jobs = _standalone_ood_reference_jobs(
        suite,
        manifests,
        declared_jobs,
    )
    _validate_static_job_identities((*declared_jobs, *hidden_reference_jobs))
    _validate_known_pair_candidates(declared_jobs, hidden_reference_jobs)
    ordinals = _shard_group_ordinals(declared_jobs)
    return (
        _select_shard_jobs(
            declared_jobs,
            ordinals,
            shard_index=shard_index,
            shard_count=shard_count,
        ),
        _select_shard_jobs(
            hidden_reference_jobs,
            ordinals,
            shard_index=shard_index,
            shard_count=shard_count,
        ),
    )


def _scenario_groups(
    episodes: Sequence[_EvaluatedEpisode],
) -> tuple[_ScenarioMetrics, ...]:
    grouped: dict[str, list[_EvaluatedEpisode]] = {}
    for episode in episodes:
        grouped.setdefault(episode.result.scenario_id, []).append(episode)
    scenarios: list[_ScenarioMetrics] = []
    for scenario_id, values in grouped.items():
        first = values[0]
        identity = (
            first.result.task_id,
            first.result.partition,
            first.result.factor,
            first.result.action_mode,
            first.result.action_representation,
            first.result.observation_profile,
            first.source_seed,
        )
        if any(
            (
                value.result.task_id,
                value.result.partition,
                value.result.factor,
                value.result.action_mode,
                value.result.action_representation,
                value.result.observation_profile,
                value.source_seed,
            )
            != identity
            for value in values[1:]
        ):
            raise ValueError("scenario repeats must share one complete evaluation identity")
        repeat_indices = tuple(value.result.repeat_index for value in values)
        if len(repeat_indices) != len(set(repeat_indices)):
            raise ValueError("scenario repeat identities must be unique")
        completion = tuple(
            value.result.metrics.completion_time_s
            for value in values
            if value.result.metrics.completion_time_s is not None
        )
        scenarios.append(
            _ScenarioMetrics(
                scenario_id=scenario_id,
                task_id=first.result.task_id,
                partition=first.result.partition,
                factor=first.result.factor,
                action_mode=first.result.action_mode,
                action_representation=first.result.action_representation,
                observation_profile=first.result.observation_profile,
                source_seed=first.source_seed,
                n_total=len(values),
                n_success=sum(value.result.success for value in values),
                n_failure=sum(not value.result.success for value in values),
                completion_time_n_valid=len(completion),
                success_rate=float(
                    np.mean([value.result.metrics.success_rate for value in values])
                ),
                task_completion=float(
                    np.mean([value.result.metrics.task_completion for value in values])
                ),
                completion_time_s=float(np.mean(completion)) if completion else None,
                safety_failure_rate=float(
                    np.mean([value.result.metrics.safety_failure_rate for value in values])
                ),
                failure_rates=tuple(
                    float(
                        np.mean(
                            [1.0 if value.result.failure_code == code else 0.0 for value in values]
                        )
                    )
                    for code in FAILURE_CODES
                ),
            )
        )
    return tuple(scenarios)


def _metric_distribution(
    observations: Sequence[_EstimateObservation], *, macro: bool
) -> tuple[float, ...]:
    if not macro:
        return tuple(observation.value for observation in observations)
    by_task: dict[str, list[float]] = {}
    for observation in observations:
        by_task.setdefault(observation.task_id, []).append(observation.value)
    return tuple(float(np.mean(values)) for values in by_task.values())


def _clustered_bootstrap_interval(
    observations: Sequence[_EstimateObservation], *, macro: bool
) -> tuple[float, float]:
    by_task: dict[str, dict[int, list[float]]] = {}
    for observation in observations:
        by_task.setdefault(observation.task_id, {}).setdefault(observation.source_seed, []).append(
            observation.value
        )
    rng = np.random.Generator(np.random.PCG64(_BOOTSTRAP_SEED))
    task_samples: list[npt.NDArray[np.float64]] = []
    for clusters in by_task.values():
        sums = np.asarray([sum(values) for values in clusters.values()], dtype=np.float64)
        counts = np.asarray([len(values) for values in clusters.values()], dtype=np.float64)
        size = len(sums)
        draws = rng.integers(0, size, size=(_BOOTSTRAP_SAMPLES, size))
        task_samples.append(np.sum(sums[draws], axis=1) / np.sum(counts[draws], axis=1))
    samples = np.mean(np.stack(task_samples, axis=1), axis=1) if macro else task_samples[0]
    lower, upper = np.quantile(samples, (0.025, 0.975))
    return float(lower), float(upper)


def _wilson_interval(values: Sequence[float]) -> tuple[float, float]:
    count = len(values)
    probability = float(np.mean(values))
    z_squared = _WILSON_Z_95 * _WILSON_Z_95
    denominator = 1.0 + z_squared / count
    center = (probability + z_squared / (2.0 * count)) / denominator
    margin = (
        _WILSON_Z_95
        * math.sqrt(probability * (1.0 - probability) / count + z_squared / (4.0 * count * count))
        / denominator
    )
    return max(0.0, center - margin), min(1.0, center + margin)


def _estimate(
    observations: Sequence[_EstimateObservation],
    *,
    n_total: int,
    n_valid: int,
    binary: bool,
    macro: bool,
) -> MetricEstimate:
    if not observations:
        return MetricEstimate(None, None, None, None, None, n_total, n_valid)
    distribution = _metric_distribution(observations, macro=macro)
    values = np.asarray(distribution, dtype=np.float64)
    p25, median, p75 = np.quantile(values, (0.25, 0.5, 0.75))
    interval = (
        _wilson_interval(distribution)
        if binary and not macro
        else _clustered_bootstrap_interval(observations, macro=macro)
    )
    return MetricEstimate(
        mean=float(np.mean(values)),
        median=float(median),
        p25=float(p25),
        p75=float(p75),
        interval_95=interval,
        n_total=n_total,
        n_valid=n_valid,
    )


def _observations(
    scenarios: Sequence[_Scenario],
    value_for: Callable[[_Scenario], float | None],
) -> tuple[_EstimateObservation, ...]:
    result: list[_EstimateObservation] = []
    for scenario in scenarios:
        value = value_for(scenario)
        if value is not None:
            result.append(
                _EstimateObservation(scenario.task_id, scenario.source_seed, float(value))
            )
    return tuple(result)


def _aggregate_metrics(scenarios: Sequence[_ScenarioMetrics], *, macro: bool) -> AggregateMetrics:
    n_total = sum(scenario.n_total for scenario in scenarios)
    n_success = sum(scenario.n_success for scenario in scenarios)
    n_failure = sum(scenario.n_failure for scenario in scenarios)
    completion_n_valid = sum(scenario.completion_time_n_valid for scenario in scenarios)
    failure_rates = tuple(
        FailureRate(
            cast(FailureCode, code),
            _estimate(
                tuple(
                    _EstimateObservation(
                        scenario.task_id,
                        scenario.source_seed,
                        scenario.failure_rates[index],
                    )
                    for scenario in scenarios
                ),
                n_total=n_total,
                n_valid=n_total,
                binary=True,
                macro=macro,
            ),
        )
        for index, code in enumerate(FAILURE_CODES)
    )
    return AggregateMetrics(
        n_success=n_success,
        n_failure=n_failure,
        success_rate=_estimate(
            _observations(scenarios, lambda scenario: scenario.success_rate),
            n_total=n_total,
            n_valid=n_total,
            binary=True,
            macro=macro,
        ),
        task_completion=_estimate(
            _observations(scenarios, lambda scenario: scenario.task_completion),
            n_total=n_total,
            n_valid=n_total,
            binary=False,
            macro=macro,
        ),
        completion_time_s=_estimate(
            _observations(scenarios, lambda scenario: scenario.completion_time_s),
            n_total=n_total,
            n_valid=completion_n_valid,
            binary=False,
            macro=macro,
        ),
        safety_failure_rate=_estimate(
            _observations(scenarios, lambda scenario: scenario.safety_failure_rate),
            n_total=n_total,
            n_valid=n_total,
            binary=True,
            macro=macro,
        ),
        failure_rates=failure_rates,
    )


def _pair_key(episode: _EvaluatedEpisode) -> _PairTuple:
    result = episode.result
    return (
        result.task_id,
        episode.source_seed,
        result.action_mode,
        result.action_representation,
        result.observation_profile,
        result.repeat_index,
    )


def _paired_scenarios(
    visible: Sequence[_EvaluatedEpisode],
    references: Sequence[_EvaluatedEpisode],
) -> tuple[_PairedScenarioMetrics, ...]:
    reference_by_key: dict[_PairTuple, _EvaluatedEpisode] = {}
    for reference in references:
        if reference.result.partition != "test_id":
            continue
        key = _pair_key(reference)
        if key in reference_by_key:
            raise ValueError(f"duplicate test-ID reference for paired identity: {key}")
        reference_by_key[key] = reference
    differences: dict[str, list[tuple[_EvaluatedEpisode, _EvaluatedEpisode]]] = {}
    seen_ood: set[tuple[str, _PairTuple]] = set()
    for episode in visible:
        if episode.result.partition != "ood":
            continue
        factor = episode.result.factor
        if factor is None:
            raise RuntimeError("OOD EpisodeResult is missing its factor")
        key = _pair_key(episode)
        owned_key = (factor, key)
        if owned_key in seen_ood:
            raise ValueError(f"duplicate OOD episode for paired identity: {owned_key}")
        seen_ood.add(owned_key)
        try:
            reference = reference_by_key[key]
        except KeyError:
            raise ValueError(f"missing test-ID reference for paired identity: {key}") from None
        differences.setdefault(episode.result.scenario_id, []).append((episode, reference))
    scenarios: list[_PairedScenarioMetrics] = []
    for scenario_id, pairs in differences.items():
        first = pairs[0][0]
        result = first.result
        factor = result.factor
        if factor is None:
            raise RuntimeError("OOD EpisodeResult is missing its factor")
        identity = (
            result.task_id,
            factor,
            result.action_mode,
            result.action_representation,
            result.observation_profile,
            first.source_seed,
        )
        if any(
            (
                ood.result.task_id,
                ood.result.factor,
                ood.result.action_mode,
                ood.result.action_representation,
                ood.result.observation_profile,
                ood.source_seed,
            )
            != identity
            for ood, _test_id in pairs[1:]
        ):
            raise ValueError("paired scenario repeats must share one complete identity")
        repeat_indices = tuple(ood.result.repeat_index for ood, _test_id in pairs)
        if len(repeat_indices) != len(set(repeat_indices)):
            raise ValueError("paired scenario repeat identities must be unique")
        completion_differences = tuple(
            ood.result.metrics.completion_time_s - test_id.result.metrics.completion_time_s
            for ood, test_id in pairs
            if ood.result.metrics.completion_time_s is not None
            and test_id.result.metrics.completion_time_s is not None
        )
        scenarios.append(
            _PairedScenarioMetrics(
                scenario_id=scenario_id,
                task_id=result.task_id,
                factor=factor,
                action_mode=result.action_mode,
                action_representation=result.action_representation,
                observation_profile=result.observation_profile,
                source_seed=first.source_seed,
                n_total=len(pairs),
                completion_time_n_valid=len(completion_differences),
                success_rate=float(
                    np.mean(
                        [
                            ood.result.metrics.success_rate - test_id.result.metrics.success_rate
                            for ood, test_id in pairs
                        ]
                    )
                ),
                task_completion=float(
                    np.mean(
                        [
                            ood.result.metrics.task_completion
                            - test_id.result.metrics.task_completion
                            for ood, test_id in pairs
                        ]
                    )
                ),
                completion_time_s=(
                    float(np.mean(completion_differences)) if completion_differences else None
                ),
                safety_failure_rate=float(
                    np.mean(
                        [
                            ood.result.metrics.safety_failure_rate
                            - test_id.result.metrics.safety_failure_rate
                            for ood, test_id in pairs
                        ]
                    )
                ),
                failure_rates=tuple(
                    float(
                        np.mean(
                            [
                                (1.0 if ood.result.failure_code == code else 0.0)
                                - (1.0 if test_id.result.failure_code == code else 0.0)
                                for ood, test_id in pairs
                            ]
                        )
                    )
                    for code in FAILURE_CODES
                ),
            )
        )
    return tuple(scenarios)


def _aggregate_paired(
    scenarios: Sequence[_PairedScenarioMetrics], *, macro: bool
) -> PairedDifferenceMetrics:
    n_total = sum(scenario.n_total for scenario in scenarios)
    completion_n_valid = sum(scenario.completion_time_n_valid for scenario in scenarios)

    def estimate(
        value_for: Callable[[_PairedScenarioMetrics], float | None],
        *,
        n_valid: int = n_total,
    ) -> MetricEstimate:
        return _estimate(
            _observations(scenarios, value_for),
            n_total=n_total,
            n_valid=n_valid,
            binary=False,
            macro=macro,
        )

    return PairedDifferenceMetrics(
        success_rate=estimate(lambda scenario: scenario.success_rate),
        task_completion=estimate(lambda scenario: scenario.task_completion),
        completion_time_s=estimate(
            lambda scenario: scenario.completion_time_s,
            n_valid=completion_n_valid,
        ),
        safety_failure_rate=estimate(lambda scenario: scenario.safety_failure_rate),
        failure_rates=tuple(
            FailureRate(
                cast(FailureCode, code),
                _estimate(
                    tuple(
                        _EstimateObservation(
                            scenario.task_id,
                            scenario.source_seed,
                            scenario.failure_rates[index],
                        )
                        for scenario in scenarios
                    ),
                    n_total=n_total,
                    n_valid=n_total,
                    binary=False,
                    macro=macro,
                ),
            )
            for index, code in enumerate(FAILURE_CODES)
        ),
    )


def _group_tuple(scenario: _ScenarioMetrics) -> _GroupTuple:
    return (
        scenario.task_id,
        scenario.partition,
        scenario.factor,
        scenario.action_mode,
        scenario.action_representation,
        scenario.observation_profile,
    )


def _macro_tuple(key: _GroupTuple) -> _MacroTuple:
    return key[1:]


def _evaluation_key(key: _GroupTuple | _MacroTuple, *, macro: bool) -> EvaluationGroupKey:
    if macro:
        partition, factor, mode, representation, profile = cast(_MacroTuple, key)
        task_id = None
    else:
        task_id, partition, factor, mode, representation, profile = cast(_GroupTuple, key)
    return EvaluationGroupKey(
        task_id=task_id,
        partition=partition,
        factor=factor,
        action_mode=mode,
        action_representation=representation,
        observation_profile=profile,
    )


def _build_groups(
    visible: Sequence[_EvaluatedEpisode],
    references: Sequence[_EvaluatedEpisode],
) -> tuple[EvaluationGroup, ...]:
    scenarios = _scenario_groups(visible)
    paired = _paired_scenarios(visible, references)
    task_buckets: dict[_GroupTuple, list[_ScenarioMetrics]] = {}
    for absolute_scenario in scenarios:
        task_buckets.setdefault(_group_tuple(absolute_scenario), []).append(absolute_scenario)
    paired_task_buckets: dict[_GroupTuple, list[_PairedScenarioMetrics]] = {}
    for paired_scenario in paired:
        paired_key: _GroupTuple = (
            paired_scenario.task_id,
            "ood",
            paired_scenario.factor,
            paired_scenario.action_mode,
            paired_scenario.action_representation,
            paired_scenario.observation_profile,
        )
        paired_task_buckets.setdefault(paired_key, []).append(paired_scenario)
    groups: list[EvaluationGroup] = []
    for task_key, task_bucket in task_buckets.items():
        paired_metrics = None
        if task_key[1] == "ood":
            paired_bucket = paired_task_buckets.get(task_key)
            if paired_bucket is None:
                raise ValueError("OOD group has no paired test-ID observations")
            paired_metrics = _aggregate_paired(paired_bucket, macro=False)
        groups.append(
            EvaluationGroup(
                _evaluation_key(task_key, macro=False),
                _aggregate_metrics(task_bucket, macro=False),
                paired_metrics,
            )
        )
    macro_buckets: dict[_MacroTuple, list[_ScenarioMetrics]] = {}
    for task_key, task_bucket in task_buckets.items():
        macro_buckets.setdefault(_macro_tuple(task_key), []).extend(task_bucket)
    paired_macro_buckets: dict[_MacroTuple, list[_PairedScenarioMetrics]] = {}
    for paired_key, paired_bucket in paired_task_buckets.items():
        paired_macro_buckets.setdefault(_macro_tuple(paired_key), []).extend(paired_bucket)
    for macro_key, macro_bucket in macro_buckets.items():
        paired_metrics = None
        if macro_key[0] == "ood":
            paired_bucket = paired_macro_buckets.get(macro_key)
            if paired_bucket is None:
                raise ValueError("OOD macro group has no paired test-ID observations")
            paired_metrics = _aggregate_paired(paired_bucket, macro=True)
        groups.append(
            EvaluationGroup(
                _evaluation_key(macro_key, macro=True),
                _aggregate_metrics(macro_bucket, macro=True),
                paired_metrics,
            )
        )
    return tuple(groups)


def _validate_shard(shard_index: int, shard_count: int) -> None:
    if (
        isinstance(shard_index, bool)
        or not isinstance(shard_index, int)
        or isinstance(shard_count, bool)
        or not isinstance(shard_count, int)
        or shard_count <= 0
        or shard_index < 0
        or shard_index >= shard_count
    ):
        raise ValueError("invalid shard")


def evaluate(
    policy: BenchmarkPolicy,
    suite: str | Path,
    *,
    shard_index: int = 0,
    shard_count: int = 1,
    wall_control_period_s: float | None = None,
    execution_translation_limit_m: float = 0.05,
) -> EvaluationSummary:
    _validate_shard(shard_index, shard_count)
    wall_period_s = _validated_wall_control_period_s(wall_control_period_s)
    _validate_execution_translation_limit(execution_translation_limit_m)
    suite_spec = load_suite(suite)
    jobs, reference_jobs = _prepare_suite_jobs(
        suite_spec,
        shard_index=shard_index,
        shard_count=shard_count,
    )
    visible = _evaluate_jobs(
        policy,
        jobs,
        wall_control_period_s=wall_period_s,
        execution_translation_limit_m=execution_translation_limit_m,
    )
    references = tuple(episode for episode in visible if episode.result.partition == "test_id")
    if reference_jobs:
        references += _evaluate_jobs(
            policy,
            reference_jobs,
            wall_control_period_s=wall_period_s,
            execution_translation_limit_m=execution_translation_limit_m,
        )
    return EvaluationSummary(
        results=tuple(episode.result for episode in visible),
        groups=_build_groups(visible, references),
    )


__all__ = ["evaluate"]
