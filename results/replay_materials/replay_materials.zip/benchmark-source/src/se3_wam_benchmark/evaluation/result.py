from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Literal, TypeAlias

from se3_wam_benchmark.control.action import (
    ActionMode,
    ActionRepresentation,
    ActionSpec,
    BenchmarkAction,
    _validate_action_spec,
)
from se3_wam_benchmark.scenarios.manifest import OOD_FACTORS, Partition
from se3_wam_benchmark.tasks.registry import TASK_IDS

FailureCode: TypeAlias = Literal[
    "invalid_state",
    "unsafe_contact",
    "workspace_exit",
    "downstream_exit",
    "drop",
    "driver_blocked",
    "timeout",
    "rim_impulse_exceeded",
    "release_outside_goal",
    "goal_window_expired",
    "wire_contact",
    "stage_block",
    "path_deviation",
    "path_backtrack",
    "premature_release",
    "release_impulse",
    "early_robot_contact",
    "tray_contact",
    "stop_or_deflect_only",
    "unstable_tipping",
    "gripper_support_contact",
    "no_selected_impact",
    "extra_impact",
    "wrong_striker_contact",
    "insufficient_outgoing_change",
    "striker_trap",
]
FailureClass: TypeAlias = Literal["safety", "task_violation", "boundary", "timeout", "invalid"]
StageName: TypeAlias = Literal[
    "approach",
    "fingerpad_contact",
    "bilateral_hold",
    "clearance",
    "stable_dwell",
    "goal_approach",
    "full_containment",
    "release",
    "low_relative_motion",
    "phase_alignment",
    "loop_entry",
    "path_progress_0_60",
    "terminal_arrival",
    "wand_acquisition",
    "wire_exit",
    "wand_release",
    "valid_selected_impact",
]

PARTITIONS = {"train", "validation", "test_id", "ood", "stress"}
ACTION_MODES = {"E7", "J8"}
ACTION_REPRESENTATIONS = {"delta", "absolute"}
OBSERVATION_PROFILES = {"agentview", "agentview_wrist"}
STAGE_NAMES = {
    "approach",
    "fingerpad_contact",
    "bilateral_hold",
    "clearance",
    "stable_dwell",
    "goal_approach",
    "full_containment",
    "release",
    "low_relative_motion",
    "phase_alignment",
    "loop_entry",
    "path_progress_0_60",
    "terminal_arrival",
    "wand_acquisition",
    "wire_exit",
    "wand_release",
    "valid_selected_impact",
}


SAFETY_FAILURES = {
    "unsafe_contact",
    "rim_impulse_exceeded",
    "wire_contact",
    "stage_block",
    "release_impulse",
    "early_robot_contact",
    "tray_contact",
    "gripper_support_contact",
    "striker_trap",
}
TASK_FAILURES = {
    "driver_blocked",
    "release_outside_goal",
    "path_deviation",
    "path_backtrack",
    "premature_release",
    "stop_or_deflect_only",
    "unstable_tipping",
    "no_selected_impact",
    "extra_impact",
    "wrong_striker_contact",
    "insufficient_outgoing_change",
}
BOUNDARY_FAILURES = {
    "workspace_exit",
    "downstream_exit",
    "drop",
    "goal_window_expired",
}
FAILURE_CODES = (
    "invalid_state",
    *sorted(SAFETY_FAILURES),
    *sorted(TASK_FAILURES),
    *sorted(BOUNDARY_FAILURES),
    "timeout",
)


def failure_class_for(code: str) -> FailureClass:
    if not isinstance(code, str):
        raise ValueError("failure code must be a string")
    if code == "invalid_state":
        return "invalid"
    if code == "timeout":
        return "timeout"
    if code in SAFETY_FAILURES:
        return "safety"
    if code in TASK_FAILURES:
        return "task_violation"
    if code in BOUNDARY_FAILURES:
        return "boundary"
    raise ValueError(f"unknown failure code: {code}")


def _validate_scenario_identity(
    scenario_id: str, task_id: str, partition: str, factor: str | None
) -> None:
    if not isinstance(scenario_id, str) or not isinstance(task_id, str):
        raise ValueError("scenario_id and task_id must be strings")
    escaped_task = re.escape(task_id)
    if partition == "ood":
        pattern = rf"v1:ood:{re.escape(str(factor))}:{escaped_task}:\d{{6}}"
    else:
        pattern = rf"v1:{re.escape(partition)}:{escaped_task}:\d{{6}}"
    if re.fullmatch(pattern, scenario_id) is None:
        raise ValueError("scenario_id does not match task/partition/factor")


@dataclass(frozen=True, slots=True)
class StageProgress:
    stage_name: StageName
    completed: bool
    progress: float
    consecutive_steps: int

    def __post_init__(self) -> None:
        if not isinstance(self.stage_name, str) or self.stage_name not in STAGE_NAMES:
            raise ValueError(f"unknown stage name: {self.stage_name}")
        if (
            isinstance(self.progress, bool)
            or not isinstance(self.progress, (int, float))
            or not math.isfinite(self.progress)
            or not 0 <= self.progress <= 1
        ):
            raise ValueError("stage progress must be in [0, 1]")
        if (
            isinstance(self.completed, bool) is False
            or isinstance(self.consecutive_steps, bool)
            or not isinstance(self.consecutive_steps, int)
            or self.consecutive_steps < 0
        ):
            raise ValueError("stage consecutive_steps must be non-negative")
        if self.completed != (self.progress == 1.0):
            raise ValueError("completed stage status must agree with progress=1")


@dataclass(frozen=True, slots=True)
class StepTrace:
    tick: int
    timestamp_s: float
    observation_tick: int
    action: BenchmarkAction
    issued_tick: int
    applied_tick: int | None
    reward: float
    done: bool
    success: bool
    failure_code: FailureCode | None
    event_flags: tuple[bool, ...]
    stage_progress: tuple[StageProgress, ...]

    def __post_init__(self) -> None:
        ticks = (self.tick, self.observation_tick, self.issued_tick)
        if any(isinstance(value, bool) or not isinstance(value, int) for value in ticks):
            raise ValueError("trace ticks must be integers")
        if min(ticks) < 0:
            raise ValueError("trace ticks must be non-negative")
        if self.observation_tick != self.tick or self.issued_tick != self.tick:
            raise ValueError("observation and issued Action must align to the trace tick")
        if self.applied_tick is not None:
            if isinstance(self.applied_tick, bool) or not isinstance(self.applied_tick, int):
                raise ValueError("applied_tick must be an integer or None")
            if self.applied_tick < self.issued_tick:
                raise ValueError("applied_tick cannot precede issued_tick")
        if not isinstance(self.action, BenchmarkAction):
            raise ValueError("trace action must be BenchmarkAction")
        if not isinstance(self.done, bool) or not isinstance(self.success, bool):
            raise ValueError("done and success must be bool")
        if (
            isinstance(self.timestamp_s, bool)
            or not isinstance(self.timestamp_s, (int, float))
            or not math.isfinite(self.timestamp_s)
            or self.timestamp_s < 0
        ):
            raise ValueError("trace timestamp must be finite and non-negative")
        if (
            isinstance(self.reward, bool)
            or not isinstance(self.reward, (int, float))
            or not math.isfinite(self.reward)
        ):
            raise ValueError("trace reward must be finite")
        if self.success and self.failure_code is not None:
            raise ValueError("a successful step cannot have a failure code")
        if not self.done and (self.success or self.failure_code is not None):
            raise ValueError("non-terminal steps cannot carry a terminal outcome")
        if self.done and not self.success and self.failure_code is None:
            raise ValueError("a failed terminal step requires one failure code")
        if self.failure_code is not None:
            failure_class_for(self.failure_code)
        if not isinstance(self.event_flags, tuple) or not all(
            isinstance(flag, bool) for flag in self.event_flags
        ):
            raise ValueError("event_flags must contain only bool values")
        if not isinstance(self.stage_progress, tuple) or not all(
            isinstance(stage, StageProgress) for stage in self.stage_progress
        ):
            raise ValueError("stage_progress must contain StageProgress records")
        names = tuple(stage.stage_name for stage in self.stage_progress)
        if len(names) != len(set(names)):
            raise ValueError("stage names must be unique")
        reached_incomplete = False
        for stage in self.stage_progress:
            if reached_incomplete and stage.progress != 0:
                raise ValueError(
                    "stage progress must form a completed prefix plus one active stage"
                )
            if not stage.completed:
                reached_incomplete = True


@dataclass(frozen=True, slots=True)
class EpisodeTrace:
    task_id: str
    scenario_id: str
    partition: Partition
    factor: str | None
    repeat_index: int
    observation_profile: Literal["agentview", "agentview_wrist"]
    action_spec: ActionSpec
    event_names: tuple[str, ...]
    steps: tuple[StepTrace, ...]
    success: bool
    failure_code: FailureCode | None
    elapsed_s: float

    def __post_init__(self) -> None:
        if not self.task_id or not self.scenario_id or not self.steps:
            raise ValueError("EpisodeTrace requires task, scenario, and at least one step")
        if not isinstance(self.partition, str) or self.partition not in PARTITIONS:
            raise ValueError(f"unknown partition: {self.partition}")
        if (
            not isinstance(self.observation_profile, str)
            or self.observation_profile not in OBSERVATION_PROFILES
        ):
            raise ValueError(f"unknown observation profile: {self.observation_profile}")
        if self.task_id not in TASK_IDS:
            raise ValueError(f"unknown task: {self.task_id}")
        if (
            isinstance(self.repeat_index, bool)
            or not isinstance(self.repeat_index, int)
            or self.repeat_index < 0
        ):
            raise ValueError("repeat_index must be non-negative")
        if self.partition == "ood":
            if not isinstance(self.factor, str) or self.factor not in OOD_FACTORS:
                raise ValueError("OOD trace requires a known factor")
        elif self.factor is not None:
            raise ValueError("factor must be None outside OOD")
        _validate_scenario_identity(self.scenario_id, self.task_id, self.partition, self.factor)
        if not isinstance(self.action_spec, ActionSpec):
            raise ValueError("action_spec must be ActionSpec")
        if (
            not isinstance(self.event_names, tuple)
            or not self.event_names
            or not all(isinstance(name, str) and name for name in self.event_names)
        ):
            raise ValueError("event_names must be a non-empty tuple of non-empty strings")
        if len(set(self.event_names)) != len(self.event_names):
            raise ValueError("event_names must be unique")
        if not isinstance(self.steps, tuple) or not all(
            isinstance(step, StepTrace) for step in self.steps
        ):
            raise ValueError("steps must be a StepTrace tuple")
        if not isinstance(self.success, bool):
            raise ValueError("success must be bool")
        previous_event_flags = (False,) * len(self.event_names)
        previous_applied_tick = -1
        reached_pending_action = False
        for expected_tick, step in enumerate(self.steps):
            if step.tick != expected_tick:
                raise ValueError("StepTrace ticks must be contiguous and zero-based")
            if len(step.event_flags) != len(self.event_names):
                raise ValueError("event_flags must align with event_names")
            if tuple(stage.stage_name for stage in step.stage_progress) != self.event_names:
                raise ValueError("stage_progress names must align with event_names")
            if step.event_flags != tuple(stage.completed for stage in step.stage_progress):
                raise ValueError("event_flags must agree with completed stage facts")
            if any(
                previous and not current
                for previous, current in zip(
                    previous_event_flags,
                    step.event_flags,
                    strict=True,
                )
            ):
                raise ValueError("event_flags must be monotonic within an episode")
            previous_event_flags = step.event_flags
            if step.applied_tick is None:
                reached_pending_action = True
            else:
                if reached_pending_action:
                    raise ValueError("unapplied Actions must form a terminal pending suffix")
                if step.applied_tick >= len(self.steps):
                    raise ValueError("applied_tick must name an execution tick in the episode")
                if step.applied_tick <= previous_applied_tick:
                    raise ValueError("applied Actions must execute once in issued order")
                previous_applied_tick = step.applied_tick
            _validate_action_spec(step.action, self.action_spec)
        if any(step.done for step in self.steps[:-1]):
            raise ValueError("only the final StepTrace may be terminal")
        terminal = self.steps[-1]
        if not terminal.done:
            raise ValueError("the final StepTrace must be terminal")
        if (self.success, self.failure_code) != (terminal.success, terminal.failure_code):
            raise ValueError("EpisodeTrace outcome must equal the final step outcome")
        if not self.success and self.failure_code is None:
            raise ValueError("a failed EpisodeTrace requires one failure code")
        if (
            isinstance(self.elapsed_s, bool)
            or not isinstance(self.elapsed_s, (int, float))
            or not math.isfinite(self.elapsed_s)
            or self.elapsed_s < 0
        ):
            raise ValueError("elapsed_s must be finite and non-negative")


@dataclass(frozen=True, slots=True)
class ManipulationMetrics:
    success_rate: float
    task_completion: float
    completion_time_s: float | None
    safety_failure_rate: float

    def __post_init__(self) -> None:
        rates = (self.success_rate, self.task_completion, self.safety_failure_rate)
        if any(
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
            or not 0 <= value <= 1
            for value in rates
        ):
            raise ValueError("single-episode rates and completion must be in [0, 1]")
        if self.completion_time_s is not None and (
            isinstance(self.completion_time_s, bool)
            or not isinstance(self.completion_time_s, (int, float))
            or not math.isfinite(self.completion_time_s)
            or self.completion_time_s < 0
        ):
            raise ValueError("completion_time_s must be non-negative or None")


@dataclass(frozen=True, slots=True)
class EpisodeResult:
    scenario_id: str
    task_id: str
    partition: Partition
    factor: str | None
    repeat_index: int
    action_mode: ActionMode
    action_representation: ActionRepresentation
    observation_profile: Literal["agentview", "agentview_wrist"]
    success: bool
    failure_code: FailureCode | None
    failure_class: FailureClass | None
    episode_steps: int
    elapsed_s: float
    metrics: ManipulationMetrics

    def __post_init__(self) -> None:
        if not self.scenario_id or not self.task_id:
            raise ValueError("EpisodeResult identity fields must be non-empty")
        if self.task_id not in TASK_IDS:
            raise ValueError(f"unknown task: {self.task_id}")
        if not isinstance(self.partition, str) or self.partition not in PARTITIONS:
            raise ValueError(f"unknown partition: {self.partition}")
        if not isinstance(self.action_mode, str) or self.action_mode not in ACTION_MODES:
            raise ValueError(f"unknown action mode: {self.action_mode}")
        if (
            not isinstance(self.action_representation, str)
            or self.action_representation not in ACTION_REPRESENTATIONS
        ):
            raise ValueError(f"unknown action representation: {self.action_representation}")
        if (
            not isinstance(self.observation_profile, str)
            or self.observation_profile not in OBSERVATION_PROFILES
        ):
            raise ValueError(f"unknown observation profile: {self.observation_profile}")
        if (
            isinstance(self.repeat_index, bool)
            or not isinstance(self.repeat_index, int)
            or self.repeat_index < 0
        ):
            raise ValueError("repeat_index must be non-negative")
        if self.partition == "ood":
            if not isinstance(self.factor, str) or self.factor not in OOD_FACTORS:
                raise ValueError("OOD result requires a known factor")
        elif self.factor is not None:
            raise ValueError("factor must be None outside OOD")
        _validate_scenario_identity(self.scenario_id, self.task_id, self.partition, self.factor)
        if not isinstance(self.success, bool):
            raise ValueError("success must be bool")
        if not isinstance(self.metrics, ManipulationMetrics):
            raise ValueError("metrics must be ManipulationMetrics")
        if self.success:
            if self.failure_code is not None or self.failure_class is not None:
                raise ValueError("successful EpisodeResult cannot have a failure")
            if self.metrics.success_rate != 1 or self.metrics.completion_time_s is None:
                raise ValueError("successful metrics require SR=1 and completion_time_s")
        else:
            if self.failure_code is None or self.failure_class is None:
                raise ValueError("failed EpisodeResult requires failure code and class")
            if self.failure_class != failure_class_for(self.failure_code):
                raise ValueError("failure_class does not match failure_code")
            if self.metrics.success_rate != 0 or self.metrics.completion_time_s is not None:
                raise ValueError("failed metrics require SR=0 and null completion_time_s")
        if (self.metrics.task_completion == 1) != self.success:
            raise ValueError("task_completion=1 must hold exactly for successful episodes")
        expected_safety = 1.0 if self.failure_code in SAFETY_FAILURES else 0.0
        if self.metrics.safety_failure_rate != expected_safety:
            raise ValueError("safety_failure_rate does not match failure_code")
        if (
            isinstance(self.episode_steps, bool)
            or not isinstance(self.episode_steps, int)
            or self.episode_steps <= 0
            or isinstance(self.elapsed_s, bool)
            or not isinstance(self.elapsed_s, (int, float))
            or not math.isfinite(self.elapsed_s)
            or self.elapsed_s < 0
        ):
            raise ValueError("episode length must be positive and elapsed time non-negative")


@dataclass(frozen=True, slots=True)
class MetricEstimate:
    mean: float | None
    median: float | None
    p25: float | None
    p75: float | None
    interval_95: tuple[float, float] | None
    n_total: int
    n_valid: int

    def __post_init__(self) -> None:
        if (
            isinstance(self.n_total, bool)
            or not isinstance(self.n_total, int)
            or isinstance(self.n_valid, bool)
            or not isinstance(self.n_valid, int)
            or self.n_total < 0
            or not 0 <= self.n_valid <= self.n_total
        ):
            raise ValueError("metric counts require 0 <= n_valid <= n_total")
        values = (self.mean, self.median, self.p25, self.p75)
        if any(
            value is not None
            and (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(value)
            )
            for value in values
        ):
            raise ValueError("metric estimates must be finite or None")
        if self.interval_95 is not None:
            if not isinstance(self.interval_95, tuple) or len(self.interval_95) != 2:
                raise ValueError("interval_95 must be a two-value tuple or None")
            lower, upper = self.interval_95
            if (
                isinstance(lower, bool)
                or not isinstance(lower, (int, float))
                or isinstance(upper, bool)
                or not isinstance(upper, (int, float))
                or not math.isfinite(lower)
                or not math.isfinite(upper)
                or lower > upper
            ):
                raise ValueError("interval_95 must be finite and ordered")
        if self.n_valid == 0 and any(value is not None for value in (*values, self.interval_95)):
            raise ValueError("an empty metric must use null estimates")
        if self.n_valid > 0 and (
            any(value is None for value in values) or self.interval_95 is None
        ):
            raise ValueError("a non-empty metric requires all estimates and interval_95")
        if (
            self.n_valid > 0
            and self.p25 is not None
            and self.median is not None
            and self.p75 is not None
            and not self.p25 <= self.median <= self.p75
        ):
            raise ValueError("metric quantiles must be ordered")


def _estimate_values(estimate: MetricEstimate) -> tuple[float, ...]:
    values = tuple(
        value
        for value in (estimate.mean, estimate.median, estimate.p25, estimate.p75)
        if value is not None
    )
    if estimate.interval_95 is not None:
        values += estimate.interval_95
    return values


def _validate_rate_estimate(estimate: MetricEstimate) -> None:
    if any(value < 0 or value > 1 for value in _estimate_values(estimate)):
        raise ValueError("rate estimates must be in [0, 1]")


def _validate_nonnegative_estimate(estimate: MetricEstimate) -> None:
    if any(value < 0 for value in _estimate_values(estimate)):
        raise ValueError("non-negative metric estimates cannot be negative")


@dataclass(frozen=True, slots=True)
class FailureRate:
    code: FailureCode
    estimate: MetricEstimate

    def __post_init__(self) -> None:
        failure_class_for(self.code)
        if not isinstance(self.estimate, MetricEstimate):
            raise ValueError("failure rate estimate must be MetricEstimate")


@dataclass(frozen=True, slots=True)
class AggregateMetrics:
    n_success: int
    n_failure: int
    success_rate: MetricEstimate
    task_completion: MetricEstimate
    completion_time_s: MetricEstimate
    safety_failure_rate: MetricEstimate
    failure_rates: tuple[FailureRate, ...]

    def __post_init__(self) -> None:
        if (
            isinstance(self.n_success, bool)
            or not isinstance(self.n_success, int)
            or isinstance(self.n_failure, bool)
            or not isinstance(self.n_failure, int)
            or self.n_success < 0
            or self.n_failure < 0
        ):
            raise ValueError("success and failure counts must be non-negative")
        estimates = (
            self.success_rate,
            self.task_completion,
            self.completion_time_s,
            self.safety_failure_rate,
        )
        if not all(isinstance(estimate, MetricEstimate) for estimate in estimates):
            raise ValueError("aggregate metric fields must be MetricEstimate records")
        total = self.n_success + self.n_failure
        if total != self.success_rate.n_total:
            raise ValueError("success and failure counts must equal success_rate.n_total")
        if self.success_rate.n_valid != total:
            raise ValueError("success_rate must be valid for every episode")
        if any(
            estimate.n_total != total or estimate.n_valid != total
            for estimate in (
                self.task_completion,
                self.safety_failure_rate,
            )
        ):
            raise ValueError("TC and safety rate must be valid for every episode")
        if (
            self.completion_time_s.n_total != total
            or self.completion_time_s.n_valid != self.n_success
        ):
            raise ValueError("completion_time_s validity must equal n_success")
        for estimate in (self.success_rate, self.task_completion, self.safety_failure_rate):
            _validate_rate_estimate(estimate)
        _validate_nonnegative_estimate(self.completion_time_s)
        if not isinstance(self.failure_rates, tuple) or not all(
            isinstance(item, FailureRate) for item in self.failure_rates
        ):
            raise ValueError("failure_rates must be FailureRate records")
        codes = tuple(item.code for item in self.failure_rates)
        if codes != FAILURE_CODES:
            raise ValueError("failure_rates must cover every frozen failure code in order")
        for item in self.failure_rates:
            if item.estimate.n_total != total or item.estimate.n_valid != total:
                raise ValueError("failure rates must be valid for every episode")
            _validate_rate_estimate(item.estimate)
        if total:
            if self.n_success == 0 and self.success_rate.mean != 0.0:
                raise ValueError("zero successful episodes require a zero success rate")
            if self.n_failure == 0 and self.success_rate.mean != 1.0:
                raise ValueError("zero failed episodes require a unit success rate")
            failure_sum = sum(item.estimate.mean or 0.0 for item in self.failure_rates)
            if not math.isclose(
                failure_sum,
                1.0 - (self.success_rate.mean or 0.0),
                abs_tol=1e-12,
            ):
                raise ValueError("failure rates must complement the success rate")
            safety_sum = sum(
                item.estimate.mean or 0.0
                for item in self.failure_rates
                if item.code in SAFETY_FAILURES
            )
            if not math.isclose(safety_sum, self.safety_failure_rate.mean or 0.0, abs_tol=1e-12):
                raise ValueError("safety failure rate must equal safety-code rates")


@dataclass(frozen=True, slots=True)
class PairedDifferenceMetrics:
    success_rate: MetricEstimate
    task_completion: MetricEstimate
    completion_time_s: MetricEstimate
    safety_failure_rate: MetricEstimate
    failure_rates: tuple[FailureRate, ...]

    def __post_init__(self) -> None:
        estimates = (
            self.success_rate,
            self.task_completion,
            self.completion_time_s,
            self.safety_failure_rate,
        )
        if not all(isinstance(estimate, MetricEstimate) for estimate in estimates):
            raise ValueError("paired differences must use MetricEstimate records")
        totals = {estimate.n_total for estimate in estimates}
        if len(totals) != 1:
            raise ValueError("paired differences must share one n_total")
        total = next(iter(totals))
        for estimate in (self.success_rate, self.task_completion, self.safety_failure_rate):
            if estimate.n_valid != total:
                raise ValueError("paired rate differences must be valid for every matched pair")
            if any(value < -1 or value > 1 for value in _estimate_values(estimate)):
                raise ValueError("paired rate differences must be in [-1, 1]")
        if (
            not isinstance(self.failure_rates, tuple)
            or not all(isinstance(item, FailureRate) for item in self.failure_rates)
            or tuple(item.code for item in self.failure_rates) != FAILURE_CODES
        ):
            raise ValueError("paired failure differences must cover frozen codes in order")
        if any(item.estimate.n_total not in totals for item in self.failure_rates):
            raise ValueError("paired failure differences must share n_total")
        for item in self.failure_rates:
            if item.estimate.n_valid != total:
                raise ValueError("paired failure differences must be valid for every matched pair")
            if any(value < -1 or value > 1 for value in _estimate_values(item.estimate)):
                raise ValueError("paired failure differences must be in [-1, 1]")
        if total:
            failure_sum = sum(item.estimate.mean or 0.0 for item in self.failure_rates)
            if not math.isclose(
                failure_sum,
                -(self.success_rate.mean or 0.0),
                abs_tol=1e-12,
            ):
                raise ValueError("paired failure differences must negate the success difference")
            safety_sum = sum(
                item.estimate.mean or 0.0
                for item in self.failure_rates
                if item.code in SAFETY_FAILURES
            )
            if not math.isclose(
                safety_sum,
                self.safety_failure_rate.mean or 0.0,
                abs_tol=1e-12,
            ):
                raise ValueError("paired safety difference must equal safety-code differences")


@dataclass(frozen=True, slots=True)
class EvaluationGroupKey:
    task_id: str | None
    partition: Partition
    factor: str | None
    action_mode: ActionMode
    action_representation: ActionRepresentation
    observation_profile: Literal["agentview", "agentview_wrist"]

    def __post_init__(self) -> None:
        if self.task_id is not None and self.task_id not in TASK_IDS:
            raise ValueError("group task_id must be registered or None for Suite macro")
        if not isinstance(self.partition, str) or self.partition not in PARTITIONS:
            raise ValueError(f"unknown partition: {self.partition}")
        if not isinstance(self.action_mode, str) or self.action_mode not in ACTION_MODES:
            raise ValueError(f"unknown action mode: {self.action_mode}")
        if (
            not isinstance(self.action_representation, str)
            or self.action_representation not in ACTION_REPRESENTATIONS
        ):
            raise ValueError(f"unknown action representation: {self.action_representation}")
        if (
            not isinstance(self.observation_profile, str)
            or self.observation_profile not in OBSERVATION_PROFILES
        ):
            raise ValueError(f"unknown observation profile: {self.observation_profile}")
        if self.partition == "ood":
            if not isinstance(self.factor, str) or self.factor not in OOD_FACTORS:
                raise ValueError("OOD group requires a known factor")
        elif self.factor is not None:
            raise ValueError("factor must be None outside OOD")


@dataclass(frozen=True, slots=True)
class EvaluationGroup:
    key: EvaluationGroupKey
    metrics: AggregateMetrics
    paired_test_id_difference: PairedDifferenceMetrics | None

    def __post_init__(self) -> None:
        if not isinstance(self.key, EvaluationGroupKey) or not isinstance(
            self.metrics, AggregateMetrics
        ):
            raise ValueError("EvaluationGroup requires typed key and metrics")
        if self.key.partition == "ood":
            if not isinstance(self.paired_test_id_difference, PairedDifferenceMetrics):
                raise ValueError("OOD groups require paired test-ID differences")
        elif self.paired_test_id_difference is not None:
            raise ValueError("paired test-ID differences are only valid for OOD groups")


@dataclass(frozen=True, slots=True)
class EvaluationSummary:
    results: tuple[EpisodeResult, ...]
    groups: tuple[EvaluationGroup, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.results, tuple) or not all(
            isinstance(result, EpisodeResult) for result in self.results
        ):
            raise ValueError("results must be an EpisodeResult tuple")
        if not isinstance(self.groups, tuple) or not all(
            isinstance(group, EvaluationGroup) for group in self.groups
        ):
            raise ValueError("groups must be an EvaluationGroup tuple")
        identities = tuple((result.scenario_id, result.repeat_index) for result in self.results)
        if len(identities) != len(set(identities)):
            raise ValueError(
                "EvaluationSummary results must have unique scenario/repeat identities"
            )
        keys = tuple(group.key for group in self.groups)
        if len(keys) != len(set(keys)):
            raise ValueError("EvaluationSummary group keys must be unique")


__all__ = ["EpisodeResult", "EpisodeTrace", "EvaluationSummary", "StepTrace"]
