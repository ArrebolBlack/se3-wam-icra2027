from __future__ import annotations

from importlib import import_module
from typing import Protocol, cast

from se3_wam_benchmark.control.action import BenchmarkAction
from se3_wam_benchmark.sensing.observation import BenchmarkObservation


class BenchmarkPolicy(Protocol):
    def reset(self) -> None: ...

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction: ...


def _load_policy_factory(specification: str) -> BenchmarkPolicy:
    if not isinstance(specification, str) or specification.count(":") != 1:
        raise ValueError("policy must use the explicit module:factory form")
    module_name, factory_name = specification.split(":")
    if not module_name or not factory_name:
        raise ValueError("policy must use the explicit module:factory form")
    module = import_module(module_name)
    factory = cast(object, getattr(module, factory_name, None))
    if not callable(factory):
        raise ValueError("policy factory must be callable")
    policy = factory()
    reset = cast(object, getattr(policy, "reset", None))
    act = cast(object, getattr(policy, "act", None))
    if not callable(reset) or not callable(act):
        raise ValueError("policy factory must return an object with callable reset and act")
    return cast(BenchmarkPolicy, policy)


__all__ = ["BenchmarkPolicy"]
