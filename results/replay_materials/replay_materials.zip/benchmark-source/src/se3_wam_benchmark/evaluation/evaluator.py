"""B3 owner for EpisodeTrace to EpisodeResult conversion."""

from __future__ import annotations

from se3_wam_benchmark.evaluation.metrics.manipulation import (
    _failure_class,
    _manipulation_metrics,
)
from se3_wam_benchmark.evaluation.result import EpisodeResult, EpisodeTrace


def _evaluate_episode(trace: EpisodeTrace) -> EpisodeResult:
    if not isinstance(trace, EpisodeTrace):
        raise ValueError("trace must be an EpisodeTrace")
    return EpisodeResult(
        scenario_id=trace.scenario_id,
        task_id=trace.task_id,
        partition=trace.partition,
        factor=trace.factor,
        repeat_index=trace.repeat_index,
        action_mode=trace.action_spec.mode,
        action_representation=trace.action_spec.representation,
        observation_profile=trace.observation_profile,
        success=trace.success,
        failure_code=trace.failure_code,
        failure_class=_failure_class(trace),
        episode_steps=len(trace.steps),
        elapsed_s=trace.elapsed_s,
        metrics=_manipulation_metrics(trace),
    )


__all__: list[str] = []
