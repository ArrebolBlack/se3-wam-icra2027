"""B3 owner for the sole formal interaction loop."""

from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import cast

from se3_wam_benchmark.control.action import ActionSpec, BenchmarkAction
from se3_wam_benchmark.data.recorder import EpisodeRecorder
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy
from se3_wam_benchmark.evaluation.result import (
    FAILURE_CODES,
    EpisodeTrace,
    FailureCode,
    StageName,
    StageProgress,
    StepTrace,
)
from se3_wam_benchmark.scenarios._native_oracle import _make_native_oracle
from se3_wam_benchmark.scenarios.manifest import Partition
from se3_wam_benchmark.scenarios.spec import ScenarioSpec
from se3_wam_benchmark.tasks.spec import TaskSpec

_WALL_CLOCK: Callable[[], float] = time.monotonic
_WALL_SLEEP: Callable[[float], None] = time.sleep
_LOGGER = logging.getLogger(__name__)


def _validated_wall_control_period_s(value: float | None) -> float | None:
    if value is None:
        return None
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not math.isfinite(value)
        or value <= 0.0
    ):
        raise ValueError("wall_control_period_s must be finite and positive or None")
    return float(value)


class _WallControlPacer:
    """Pace complete control ticks against one fixed monotonic epoch."""

    def __init__(self, period_s: float) -> None:
        period = _validated_wall_control_period_s(period_s)
        if period is None:
            raise ValueError("Wall control pacing requires a period")
        self._period_s = period
        self._epoch_s: float | None = None
        self._last_now_s: float | None = None

    def _now(self) -> float:
        value = _WALL_CLOCK()
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))
            or not math.isfinite(value)
        ):
            raise RuntimeError("wall control clock must return a finite number")
        now_s = float(value)
        if self._last_now_s is not None and now_s < self._last_now_s:
            raise RuntimeError("wall control clock must be monotonic")
        self._last_now_s = now_s
        return now_s

    def _scheduled_time(self, tick: int) -> float:
        if self._epoch_s is None:
            raise RuntimeError("wall control pacing has not started")
        scheduled_s = self._epoch_s + tick * self._period_s
        if not math.isfinite(scheduled_s):
            raise RuntimeError("wall control schedule must be finite")
        return scheduled_s

    def _deadline(self, tick: int) -> float:
        return self._scheduled_time(tick + 1)

    def start_after_first_action(self) -> None:
        if self._epoch_s is not None:
            raise RuntimeError("wall control pacing can start only once")
        self._epoch_s = self._now()

    def wait_for_tick(self, tick: int) -> None:
        if tick <= 0:
            raise RuntimeError("only ticks after tick zero have a wall-clock start target")
        target_s = self._scheduled_time(tick)
        deadline_s = self._deadline(tick)
        while True:
            now_s = self._now()
            if now_s > deadline_s:
                raise RuntimeError("wall control tick exceeded its deadline")
            remaining_s = target_s - now_s
            if remaining_s <= 0.0:
                return
            _WALL_SLEEP(remaining_s)

    def complete_tick(self, tick: int) -> None:
        if self._now() > self._deadline(tick):
            raise RuntimeError("wall control tick exceeded its deadline")


@dataclass(frozen=True, slots=True)
class _StepDraft:
    tick: int
    timestamp_s: float
    action: BenchmarkAction
    reward: float
    done: bool
    success: bool
    failure_code: FailureCode | None
    events: tuple[tuple[str, float], ...]
    stage_progress: tuple[StageProgress, ...]


def _required_info_value(info: Mapping[str, object], name: str) -> object:
    if name not in info:
        raise RuntimeError(f"Family Env step info is missing {name!r}")
    return info[name]


def _step_outcome(
    info: Mapping[str, object], *, done: bool
) -> tuple[bool, FailureCode | None, float | None]:
    success_value = _required_info_value(info, "success")
    if not isinstance(success_value, bool):
        raise RuntimeError("Family Env success fact must be bool")
    failure_value = _required_info_value(info, "failure_code")
    if failure_value is None:
        failure_code = None
    elif isinstance(failure_value, str) and failure_value in FAILURE_CODES:
        failure_code = cast(FailureCode, failure_value)
    else:
        raise RuntimeError("Family Env failure_code fact is not in the frozen closed set")
    terminal_value = _required_info_value(info, "terminal_time_s")
    if terminal_value is None:
        terminal_time_s = None
    elif (
        isinstance(terminal_value, bool)
        or not isinstance(terminal_value, (int, float))
        or not math.isfinite(terminal_value)
        or terminal_value < 0.0
    ):
        raise RuntimeError("Family Env terminal_time_s fact must be finite and non-negative")
    else:
        terminal_time_s = float(terminal_value)
    if done:
        if success_value == (failure_code is not None) or terminal_time_s is None:
            raise RuntimeError("Family Env terminal facts are inconsistent")
    elif success_value or failure_code is not None or terminal_time_s is not None:
        raise RuntimeError("Family Env exposed terminal facts before done")
    return success_value, failure_code, terminal_time_s


def _step_events(info: Mapping[str, object]) -> tuple[tuple[str, float], ...]:
    value = _required_info_value(info, "events")
    if not isinstance(value, Mapping):
        raise RuntimeError("Family Env events fact must be a mapping")
    result: list[tuple[str, float]] = []
    for name, timestamp in value.items():
        if not isinstance(name, str) or not name:
            raise RuntimeError("Family Env event names must be non-empty strings")
        if (
            isinstance(timestamp, bool)
            or not isinstance(timestamp, (int, float))
            or not math.isfinite(timestamp)
            or timestamp < 0.0
        ):
            raise RuntimeError("Family Env event timestamps must be finite and non-negative")
        result.append((name, float(timestamp)))
    if len({name for name, _ in result}) != len(result):
        raise RuntimeError("Family Env event names must be unique")
    return tuple(result)


def _step_stage_progress(info: Mapping[str, object]) -> tuple[StageProgress, ...]:
    value = _required_info_value(info, "stage_facts")
    if not isinstance(value, tuple):
        raise RuntimeError("Family Env stage_facts must be a tuple")
    result: list[StageProgress] = []
    for raw in value:
        if not isinstance(raw, tuple) or len(raw) != 4:
            raise RuntimeError("Family Env stage facts must be four-value tuples")
        name, completed, progress, consecutive_steps = raw
        if not isinstance(name, str):
            raise RuntimeError("Family Env stage names must be strings")
        if not isinstance(completed, bool):
            raise RuntimeError("Family Env stage completed facts must be bool")
        if (
            isinstance(progress, bool)
            or not isinstance(progress, (int, float))
            or not math.isfinite(progress)
        ):
            raise RuntimeError("Family Env stage progress facts must be finite numbers")
        if (
            isinstance(consecutive_steps, bool)
            or not isinstance(consecutive_steps, int)
            or consecutive_steps < 0
        ):
            raise RuntimeError("Family Env stage counters must be non-negative integers")
        result.append(
            StageProgress(
                cast(StageName, name),
                completed,
                float(progress),
                consecutive_steps,
            )
        )
    return tuple(result)


def _append_applied_action_fact(
    applied_tick_by_issued_tick: list[int | None],
    issued_actions: list[BenchmarkAction],
    fact: tuple[int, int, BenchmarkAction] | None,
    *,
    current_tick: int,
) -> None:
    if fact is None:
        return
    issued_tick, applied_tick, applied_action = fact
    if applied_tick != current_tick:
        raise RuntimeError("Family Env applied Action fact must name the current execution tick")
    if issued_tick < 0 or issued_tick >= len(issued_actions):
        raise RuntimeError("Family Env applied Action fact names an unknown issued tick")
    if applied_tick_by_issued_tick[issued_tick] is not None:
        raise RuntimeError("one issued Action cannot be applied more than once")
    if issued_actions[issued_tick] is not applied_action:
        raise RuntimeError("Family Env applied Action fact does not match the issued command")
    applied_tick_by_issued_tick[issued_tick] = applied_tick


def _build_step_traces(
    drafts: list[_StepDraft],
    applied_tick_by_issued_tick: list[int | None],
) -> tuple[tuple[str, ...], tuple[StepTrace, ...]]:
    event_names = tuple(stage.stage_name for stage in drafts[0].stage_progress)
    previous_events: tuple[tuple[str, float], ...] = ()
    for draft in drafts:
        if tuple(stage.stage_name for stage in draft.stage_progress) != event_names:
            raise RuntimeError("Family Env stage fact vocabulary changed within the episode")
        if draft.events[: len(previous_events)] != previous_events:
            raise RuntimeError("Family Env events must be an append-only ordered history")
        previous_events = draft.events
    return event_names, tuple(
        StepTrace(
            tick=draft.tick,
            timestamp_s=draft.timestamp_s,
            observation_tick=draft.tick,
            action=draft.action,
            issued_tick=draft.tick,
            applied_tick=applied_tick_by_issued_tick[draft.tick],
            reward=draft.reward,
            done=draft.done,
            success=draft.success,
            failure_code=draft.failure_code,
            event_flags=tuple(stage.completed for stage in draft.stage_progress),
            stage_progress=draft.stage_progress,
        )
        for draft in drafts
    )


def _rollout_episode(
    task: TaskSpec,
    scenario: ScenarioSpec,
    policy: BenchmarkPolicy | None,
    *,
    scenario_id: str,
    partition: Partition,
    factor: str | None,
    repeat_index: int,
    record_directory: str | Path | None = None,
    wall_control_period_s: float | None = None,
    execution_translation_limit_m: float = 0.05,
    _native_oracle: bool = False,
) -> EpisodeTrace:
    """Execute the one formal policy-observation-action loop for an episode."""
    if not isinstance(task, TaskSpec):
        raise ValueError("task must be a TaskSpec")
    if not isinstance(scenario, ScenarioSpec):
        raise ValueError("scenario must be a ScenarioSpec")
    if _native_oracle:
        if execution_translation_limit_m != 0.05:
            raise ValueError("native oracle recording requires the original 0.05 m execution limit")
        if policy is not None or record_directory is None or wall_control_period_s is not None:
            raise ValueError("native oracle requires offline recording without an external policy")
    elif policy is None:
        raise ValueError("rollout requires a policy")
    wall_period_s = _validated_wall_control_period_s(wall_control_period_s)
    pacer = None if wall_period_s is None else _WallControlPacer(wall_period_s)
    environment = make_env(
        task.task_id, scenario, execution_translation_limit_m=execution_translation_limit_m
    )
    recorder: EpisodeRecorder | None = None
    drafts: list[_StepDraft] = []
    issued_actions: list[BenchmarkAction] = []
    applied_tick_by_issued_tick: list[int | None] = []
    action_spec: ActionSpec | None = None
    terminal_time_s: float | None = None
    try:
        if record_directory is not None:
            recorder = EpisodeRecorder(
                environment,
                record_directory,
                task=task,
                scenario=scenario,
                scenario_id=scenario_id,
                partition=partition,
                factor=factor,
                repeat_index=repeat_index,
            )
        if environment._task_spec != task or environment._scenario_spec != scenario:
            raise RuntimeError("Family Env was not compiled from the requested task and scenario")
        raw_observation = environment.reset() if recorder is None else recorder.reset()
        oracle = _make_native_oracle(environment) if _native_oracle else None
        if policy is not None:
            policy.reset()
        if _LOGGER.isEnabledFor(logging.INFO):
            _LOGGER.info(
                json.dumps(
                    {
                        "event": "benchmark_episode_reset",
                        "process_id": os.getpid(),
                        "thread_id": threading.get_ident(),
                        "scenario_id": scenario_id,
                        "repeat_index": repeat_index,
                    },
                    separators=(",", ":"),
                )
            )
        if not isinstance(raw_observation, Mapping):
            raise RuntimeError("Family Env raw observation must be a mapping")
        observation = environment._benchmark_observation(raw_observation)
        if recorder is not None:
            recorder.capture_reset_frame(observation)
        for tick in range(task.episode_horizon_steps):
            if observation.tick != tick:
                raise RuntimeError("policy observation tick is not aligned with the rollout tick")
            if tick > 0 and pacer is not None:
                pacer.wait_for_tick(tick)
            if oracle is not None:
                action = oracle.action()
            else:
                assert policy is not None
                action = policy.act(observation)
            if tick == 0 and pacer is not None:
                pacer.start_after_first_action()
            issued_actions.append(action)
            applied_tick_by_issued_tick.append(None)
            next_raw, reward, done, raw_info = (
                environment.step(action) if recorder is None else recorder.step(action)
            )
            if not isinstance(done, bool):
                raise RuntimeError("Family Env done fact must be bool")
            if (
                isinstance(reward, bool)
                or not isinstance(reward, (int, float))
                or not math.isfinite(reward)
            ):
                raise RuntimeError("Family Env reward must be finite")
            if not isinstance(raw_info, Mapping):
                raise RuntimeError("Family Env step info must be a mapping")
            info: Mapping[str, object] = raw_info
            success, failure_code, current_terminal_time = _step_outcome(info, done=done)
            if oracle is not None:
                oracle.observe_step(done=done, success=success)
            drafts.append(
                _StepDraft(
                    tick=tick,
                    timestamp_s=observation.timestamp_s,
                    action=action,
                    reward=float(reward),
                    done=done,
                    success=success,
                    failure_code=failure_code,
                    events=_step_events(info),
                    stage_progress=_step_stage_progress(info),
                )
            )
            _append_applied_action_fact(
                applied_tick_by_issued_tick,
                issued_actions,
                environment._last_action_application_fact(),
                current_tick=tick,
            )
            if environment._action_spec is None:
                raise RuntimeError("Family Env did not latch the episode ActionSpec")
            if action_spec is None:
                action_spec = environment._action_spec
            elif environment._action_spec != action_spec:
                raise RuntimeError("Family Env changed ActionSpec within an episode")
            if not done or recorder is not None:
                if not isinstance(next_raw, Mapping):
                    raise RuntimeError("Family Env raw observation must be a mapping")
                next_observation = environment._benchmark_observation(next_raw)
                if recorder is not None:
                    recorder.capture_post_step_frame(next_observation)
                if not done:
                    observation = next_observation
            if pacer is not None:
                pacer.complete_tick(tick)
            if done:
                terminal_time_s = current_terminal_time
                break
        if not drafts or not drafts[-1].done or terminal_time_s is None:
            raise RuntimeError("Family Env did not terminate within the task horizon")
        if action_spec is None:
            raise RuntimeError("rollout terminated without an ActionSpec")
        event_names, steps = _build_step_traces(drafts, applied_tick_by_issued_tick)
        terminal = steps[-1]
        trace = EpisodeTrace(
            task_id=task.task_id,
            scenario_id=scenario_id,
            partition=partition,
            factor=factor,
            repeat_index=repeat_index,
            observation_profile=scenario.observation_profile,
            action_spec=action_spec,
            event_names=event_names,
            steps=steps,
            success=terminal.success,
            failure_code=terminal.failure_code,
            elapsed_s=terminal_time_s,
        )
        if recorder is not None:
            recorder.finalize_episode(
                action_spec=action_spec,
                event_names=event_names,
                success=terminal.success,
                failure_code=terminal.failure_code,
                terminal_time_s=terminal_time_s,
            )
        if _LOGGER.isEnabledFor(logging.INFO):
            for step in trace.steps:
                _LOGGER.info(
                    json.dumps(
                        {
                            "event": "benchmark_action",
                            "process_id": os.getpid(),
                            "thread_id": threading.get_ident(),
                            "scenario_id": trace.scenario_id,
                            "repeat_index": trace.repeat_index,
                            "issued_tick": step.issued_tick,
                            "applied_tick": step.applied_tick,
                            "command": step.action.value.tolist(),
                            "episode_done": step.done,
                        },
                        separators=(",", ":"),
                    )
                )
    except BaseException as episode_error:
        try:
            environment.close()
        except BaseException as close_error:
            episode_error.add_note(f"Family Env close also failed: {close_error!r}")
        raise
    else:
        environment.close()
        return trace


__all__: list[str] = []
