"""SE(3)-WAM Dynamic Benchmark package."""

__all__: list[str] = []
