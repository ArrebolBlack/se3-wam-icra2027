from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import numpy.typing as npt
import torch
from se3_wam.api import (
    ActionSpec as SE3WAMActionSpec,
)
from se3_wam.api import (
    PolicyObservation,
    SE3WAMPolicy,
)
from torch import Tensor

from se3_wam_benchmark.control.action import ActionSpec, BenchmarkAction, _validate_action_spec
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy
from se3_wam_benchmark.sensing.observation import BenchmarkObservation


def _require_bool(name: str, value: bool) -> None:
    if type(value) is not bool:
        raise ValueError(f"{name} must be a bool")


def _copy_tensor(value: npt.NDArray[np.generic]) -> Tensor:
    return torch.from_numpy(np.array(value, copy=True, order="C"))


def _float32_tensor(value: npt.NDArray[np.generic]) -> Tensor:
    return torch.from_numpy(np.array(value, dtype=np.float32, copy=True, order="C"))


def _benchmark_action_spec(model_spec: object) -> ActionSpec:
    if not isinstance(model_spec, SE3WAMActionSpec):
        raise ValueError("SE3-WAM policy action_spec must be a se3_wam.api.ActionSpec")
    if model_spec.gripper_mode != "discrete":
        raise ValueError("Dynamic Benchmark requires the discrete gripper contract")
    return ActionSpec(
        mode=model_spec.mode,
        representation=model_spec.representation,
        motion_limits=tuple(float(value) for value in model_spec.motion_limits),
    )


def _policy_observation(
    observation: BenchmarkObservation,
    *,
    camera_geometry_enabled: bool,
    observation_depth_enabled: bool,
) -> PolicyObservation:
    rgb = _copy_tensor(observation.rgb.transpose(0, 3, 1, 2))
    timestamp = torch.tensor(observation.timestamp_s, dtype=torch.float64, device="cpu")
    joint_position = _copy_tensor(observation.joint_position)
    eef_position = _copy_tensor(observation.eef_position)
    eef_quaternion = _copy_tensor(observation.eef_quaternion_xyzw)
    gripper_fraction = torch.tensor(
        float(observation.gripper_position[0] - observation.gripper_position[1]) / 0.08,
        dtype=torch.float32,
        device="cpu",
    )

    camera_intrinsics: Tensor | None = None
    robot_base_from_camera: Tensor | None = None
    if camera_geometry_enabled:
        camera_intrinsics = _float32_tensor(observation.camera_intrinsics)
        transforms = np.matmul(
            observation.T_robot_base_from_world[None, ...],
            observation.world_from_camera_cv,
        )
        robot_base_from_camera = _float32_tensor(transforms)

    depth_m: Tensor | None = None
    depth_valid: Tensor | None = None
    if observation_depth_enabled:
        depth = observation.depth_m[:, None, :, :]
        depth_m = _copy_tensor(depth)
        depth_valid = _copy_tensor(depth > 0)

    with torch.device("cpu"):
        return PolicyObservation(
            view_names=observation.view_names,
            rgb=rgb,
            timestamp_s=timestamp,
            joint_position_rad=joint_position,
            eef_position_robot_base_m=eef_position,
            eef_quaternion_robot_base_xyzw=eef_quaternion,
            gripper_open_fraction=gripper_fraction,
            camera_intrinsics=camera_intrinsics,
            T_robot_base_from_camera=robot_base_from_camera,
            depth_m=depth_m,
            depth_valid=depth_valid,
            past_flow_px=None,
            past_flow_valid=None,
            anchor_position_m=None,
            anchor_quaternion_xyzw=None,
            anchor_valid=None,
        )


def _benchmark_action(value: object, spec: ActionSpec) -> BenchmarkAction:
    if not isinstance(value, Tensor):
        raise ValueError("SE3-WAM select_action must return a torch.Tensor")
    expected_dimension = 7 if spec.mode == "E7" else 8
    if value.device.type != "cpu":
        raise ValueError("SE3-WAM Action must be on CPU")
    if value.dtype != torch.float32 or tuple(value.shape) != (expected_dimension,):
        raise ValueError(f"SE3-WAM {spec.mode} Action must be float32[{expected_dimension}]")
    if not value.is_contiguous():
        raise ValueError("SE3-WAM Action must be contiguous")
    if value.requires_grad or value.grad_fn is not None:
        raise ValueError("SE3-WAM Action must be detached")
    if not bool(torch.isfinite(value).all().item()):
        raise ValueError("SE3-WAM Action must be finite")
    action = np.array(value.numpy(), dtype=np.float64, copy=True, order="C")
    action.setflags(write=False)
    result = BenchmarkAction(spec.mode, spec.representation, action)
    _validate_action_spec(result, spec)
    return result


@dataclass(frozen=True, slots=True)
class _SE3WAMBenchmarkPolicy:
    _policy: SE3WAMPolicy
    _action_spec: ActionSpec
    _camera_geometry_enabled: bool
    _observation_depth_enabled: bool

    def reset(self) -> None:
        self._policy.reset()

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
        model_observation = _policy_observation(
            observation,
            camera_geometry_enabled=self._camera_geometry_enabled,
            observation_depth_enabled=self._observation_depth_enabled,
        )
        return _benchmark_action(self._policy.select_action(model_observation), self._action_spec)


def bind_policy(
    policy: SE3WAMPolicy,
    *,
    camera_geometry_enabled: bool,
    observation_depth_enabled: bool,
    observation_flow_enabled: bool,
    observation_anchor_enabled: bool,
) -> BenchmarkPolicy:
    """Bind a loaded Model policy using its caller-owned resolved input configuration."""

    for name, value in (
        ("camera_geometry_enabled", camera_geometry_enabled),
        ("observation_depth_enabled", observation_depth_enabled),
        ("observation_flow_enabled", observation_flow_enabled),
        ("observation_anchor_enabled", observation_anchor_enabled),
    ):
        _require_bool(name, value)
    if observation_flow_enabled:
        raise ValueError("BenchmarkObservation cannot provide upstream past Flow")
    if observation_anchor_enabled:
        raise ValueError("BenchmarkObservation cannot provide an upstream Anchor")
    action_spec = _benchmark_action_spec(policy.action_spec)
    return _SE3WAMBenchmarkPolicy(
        policy,
        action_spec,
        camera_geometry_enabled,
        observation_depth_enabled,
    )


__all__ = ["bind_policy"]
