"""Target-object body-origin pose supervision."""

from __future__ import annotations

import math

import mujoco
import numpy as np
import numpy.typing as npt


def _continuous_object_quaternion_xyzw(
    quaternion_xyzw: npt.NDArray[np.float64],
    *,
    tick: int,
    previous_quaternion_xyzw: npt.NDArray[np.float64] | None,
) -> npt.NDArray[np.float64]:
    if isinstance(tick, bool) or not isinstance(tick, int) or tick < 0:
        raise ValueError("target pose tick must be a non-negative integer")
    if (
        not isinstance(quaternion_xyzw, np.ndarray)
        or quaternion_xyzw.dtype != np.float64
        or quaternion_xyzw.shape != (4,)
        or not np.isfinite(quaternion_xyzw).all()
    ):
        raise ValueError("target object quaternion must be a finite float64[4] array")
    norm = float(np.linalg.norm(quaternion_xyzw))
    if not math.isclose(norm, 1.0, rel_tol=0.0, abs_tol=1e-8):
        raise ValueError("target object quaternion must be unit length")
    current = quaternion_xyzw / norm
    if tick == 0:
        if previous_quaternion_xyzw is not None:
            raise ValueError("previous target quaternion must be cleared at episode reset")
        return -current if current[3] < 0.0 else current
    if (
        not isinstance(previous_quaternion_xyzw, np.ndarray)
        or previous_quaternion_xyzw.dtype != np.float64
        or previous_quaternion_xyzw.shape != (4,)
        or not np.isfinite(previous_quaternion_xyzw).all()
        or not math.isclose(
            float(np.linalg.norm(previous_quaternion_xyzw)),
            1.0,
            rel_tol=0.0,
            abs_tol=1e-8,
        )
    ):
        raise ValueError("previous target quaternion must be a finite unit float64[4] array")
    return -current if float(np.dot(previous_quaternion_xyzw, current)) < 0.0 else current


def _target_body_origin_pose_world(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    *,
    target_body_id: int,
    tick: int,
    previous_quaternion_xyzw: npt.NDArray[np.float64] | None,
) -> npt.NDArray[np.float64]:
    if not isinstance(model, mujoco.MjModel) or not isinstance(data, mujoco.MjData):
        raise ValueError("model and data must be MuJoCo MjModel and MjData")
    if data.model is not model:
        raise ValueError("MjData must belong to the supplied MjModel")
    if (
        isinstance(target_body_id, bool)
        or not isinstance(target_body_id, int)
        or not 0 <= target_body_id < model.nbody
    ):
        raise ValueError("target_body_id must index a compiled body")
    if isinstance(tick, bool) or not isinstance(tick, int) or tick < 0:
        raise ValueError("target pose tick must be a non-negative integer")
    joint = int(model.body_jntadr[target_body_id])
    if (
        model.body_jntnum[target_body_id] == 1
        and model.jnt_type[joint] == mujoco.mjtJoint.mjJNT_FREE
    ):
        # DB0 labels the integrated free-body state. Reading it does not refresh
        # cached geometry or change the controller's next physics update.
        address = int(model.jnt_qposadr[joint])
        position = np.asarray(data.qpos[address : address + 3], dtype=np.float64)
        quaternion_wxyz = np.asarray(data.qpos[address + 3 : address + 7], dtype=np.float64)
    else:
        position = np.asarray(data.xpos[target_body_id], dtype=np.float64)
        quaternion_wxyz = np.asarray(data.xquat[target_body_id], dtype=np.float64)
    if not np.isfinite(position).all() or not np.isfinite(quaternion_wxyz).all():
        raise ValueError("compiled target body-origin pose must be finite")
    quaternion_xyzw = np.ascontiguousarray(quaternion_wxyz[[1, 2, 3, 0]], dtype=np.float64)
    quaternion_xyzw = _continuous_object_quaternion_xyzw(
        quaternion_xyzw,
        tick=tick,
        previous_quaternion_xyzw=previous_quaternion_xyzw,
    )
    pose = np.ascontiguousarray(np.concatenate((position, quaternion_xyzw)), dtype=np.float64)
    pose.setflags(write=False)
    return pose


__all__: list[str] = []
