from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

import yaml
from yaml.constructor import ConstructorError
from yaml.nodes import MappingNode
from yaml.tokens import AliasToken, AnchorToken

from se3_wam_benchmark.tasks.spec import Family, TaskSpec, parse_task_spec

_TASK_REGISTRATIONS: dict[str, tuple[Family, str]] = {
    "grasp": ("grasp", "grasp.yaml"),
    "t1_belt": ("driven_interception", "t1_belt.yaml"),
    "t1_xyz": ("driven_interception", "t1_xyz.yaml"),
    "t1_so3": ("driven_interception", "t1_so3.yaml"),
    "t1_occ": ("driven_interception", "t1_occ.yaml"),
    "t2_trans": ("moving_placement", "t2_trans.yaml"),
    "t2_se3": ("moving_placement", "t2_se3.yaml"),
    "t3_phase": ("rotating_interaction", "t3_phase.yaml"),
    "t3_full": ("rotating_interaction", "t3_full.yaml"),
    "t4_sphere": ("free_dynamics_interception", "t4_sphere.yaml"),
    "t4_sphere_tabletop": (
        "free_dynamics_interception",
        "t4_sphere_tabletop.yaml",
    ),
    "t4_slider": ("free_dynamics_interception", "t4_slider.yaml"),
    "t4_can": ("free_dynamics_interception", "t4_can.yaml"),
    "t5_replan": ("replanning", "t5_replan.yaml"),
}

TASK_IDS = tuple(_TASK_REGISTRATIONS)
TASK_FAMILIES: dict[str, Family] = {
    task_id: registration[0] for task_id, registration in _TASK_REGISTRATIONS.items()
}


class _StrictLoader(yaml.SafeLoader):  # type: ignore[misc]
    pass


def _construct_mapping(
    loader: _StrictLoader, node: MappingNode, deep: bool = False
) -> dict[str, Any]:
    mapping: dict[str, Any] = {}
    for key_node, value_node in node.value:
        if key_node.tag == "tag:yaml.org,2002:merge":
            raise ConstructorError(
                None, None, "YAML merge keys are not allowed", key_node.start_mark
            )
        key = loader.construct_object(key_node, deep=deep)
        if not isinstance(key, str):
            raise ConstructorError(None, None, "mapping keys must be strings", key_node.start_mark)
        if key in mapping:
            raise ConstructorError(None, None, f"duplicate mapping key: {key}", key_node.start_mark)
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


_StrictLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_mapping,
)


def load_yaml_strict(path: Path) -> Mapping[str, object]:
    text = path.read_text(encoding="utf-8")
    try:
        for token in yaml.scan(text):
            if isinstance(token, (AliasToken, AnchorToken)):
                raise ValueError(f"{path}: YAML anchors and aliases are not allowed")
        value = yaml.load(text, Loader=_StrictLoader)
    except (ValueError, yaml.YAMLError) as exc:
        if str(path) not in getattr(exc, "__notes__", ()):
            exc.add_note(str(path))
        raise
    if not isinstance(value, Mapping) or not all(isinstance(key, str) for key in value):
        raise ValueError(f"{path}: root must be a string-keyed mapping")
    return value


def load_task(task_id: str, config_dir: Path | None = None) -> TaskSpec:
    if not isinstance(task_id, str) or not task_id:
        raise ValueError("task_id must be a non-empty string")
    try:
        family, filename = _TASK_REGISTRATIONS[task_id]
    except KeyError:
        raise ValueError(f"unknown task: {task_id}") from None
    directory = config_dir or Path(__file__).resolve().parents[3] / "configs" / "tasks"
    path = directory / filename
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        return parse_task_spec(load_yaml_strict(path), task_id=task_id, family=family)
    except (ValueError, yaml.YAMLError) as exc:
        if str(path) not in getattr(exc, "__notes__", ()):
            exc.add_note(str(path))
        raise


def load_tasks(config_dir: Path | None = None) -> tuple[TaskSpec, ...]:
    return tuple(load_task(task_id, config_dir) for task_id in TASK_IDS)


__all__ = ["TASK_IDS", "load_task", "load_tasks"]
