from se3_wam_benchmark.tasks.spec import TaskSpec

__all__ = ["TaskSpec"]
