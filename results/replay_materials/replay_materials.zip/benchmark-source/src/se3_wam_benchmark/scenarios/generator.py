"""Public scenario generation orchestration."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from se3_wam_benchmark.scenarios import _recipes
from se3_wam_benchmark.scenarios._feasibility import _validate_physical_scenario
from se3_wam_benchmark.scenarios._validation import _validate_declarative_scenario
from se3_wam_benchmark.scenarios.manifest import Partition
from se3_wam_benchmark.scenarios.spec import ScenarioSpec
from se3_wam_benchmark.tasks.registry import load_yaml_strict
from se3_wam_benchmark.tasks.spec import TaskSpec


def generate_scenario(
    task: TaskSpec,
    recipe_path: str | Path,
    seed: int,
    *,
    partition: Partition,
    recipe_name: str,
    factor: str | None = None,
) -> ScenarioSpec:
    if isinstance(seed, bool) or not isinstance(seed, int) or seed < 0:
        raise ValueError("seed must be a non-negative integer")
    source = Path(recipe_path)
    if not source.is_file():
        raise FileNotFoundError(source)
    document = load_yaml_strict(source)
    recipe = _recipes._select_recipe(
        document,
        partition=partition,
        factor=factor,
        recipe_name=recipe_name,
    )
    scenario = _recipes._materialize_recipe(
        task,
        recipe,
        np.random.Generator(np.random.PCG64(seed)),
    )
    _validate_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        document=document,
        recipe_name=recipe_name,
    )
    return _validate_physical_scenario(task, scenario)


__all__ = ["generate_scenario"]
