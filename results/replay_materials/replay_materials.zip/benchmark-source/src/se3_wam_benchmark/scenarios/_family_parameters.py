"""Fixed family parameters shared by compilation, validation and native control."""

from __future__ import annotations

import math

_GRASP_ASSET_IDS = {
    "obj.cuboid_grasp_v1",
    "obj.bottle_v1",
    "obj.rod_v1",
    "obj.asym_t_t1_v1",
}
_GRASP_ID_ASSET_ID = "obj.cuboid_grasp_v1"
_GRASP_OBJECT_OOD_ASSET_IDS = _GRASP_ASSET_IDS - {_GRASP_ID_ASSET_ID}
_GRASP_SUPPORT_SURFACE_Z_M = 0.8
_GRASP_WORKSPACE_BOUNDS_XY_M = ((-0.31, -0.40), (0.31, 0.40))
_GRASP_DOWNSTREAM_EXIT_Y_M = 0.39
_GRASP_ID_X_RANGE_M = (-0.08, 0.08)
_GRASP_ID_Y_RANGE_M = (-0.26, -0.19)
_GRASP_ID_YAW_RANGE_RAD = (-1.10, 1.10)
_GRASP_OOD_X_RANGE_M = (-0.12, 0.12)
_GRASP_OOD_Y_RANGE_M = (-0.30, -0.16)
_GRASP_OOD_YAW_RANGE_RAD = (-1.50, 1.50)
_CANONICAL_AGENTVIEW = (
    (0.68, -0.58, 1.62),
    (0.38402708798262114, 0.178438700438381, 0.38173834046499744, 0.8215586803755892),
    40.0,
)
_CANONICAL_WRIST = (
    (0.05, 0.0, 0.0),
    (0.7071067811865476, 0.7071067811865476, 0.0, 0.0),
    75.0,
)
_GRASP_CANONICAL_LIGHT = {
    "light_id": "table_key",
    "position_world_m": (1.0, 1.0, 1.5),
    "direction_world": (
        -0.19245008972987526,
        -0.19245008972987526,
        -0.9622504486493763,
    ),
    "ambient_rgb": (0.0, 0.0, 0.0),
    "diffuse_rgb": (0.7, 0.7, 0.7),
    "specular_rgb": (0.3, 0.3, 0.3),
    "attenuation": (1.0, 0.0, 0.0),
    "cutoff_deg": 45.0,
    "active": True,
}
_GRASP_ID_FRICTION = (1.0, 0.005, 0.0001)
_GRASP_ID_SOLREF = (0.02, 1.0)
_GRASP_ID_SOLIMP = (0.9, 0.95, 0.001, 0.5, 2.0)
_GRASP_PANDA_JOINT_POSITION_RAD = (
    0.0,
    0.19634954084936207,
    0.0,
    -2.617993877991494,
    0.0,
    2.941592653589793,
    0.7853981633974483,
)
_GRASP_PANDA_GRIPPER_POSITION_M = (0.020833, -0.020833)
_T3_ID_PHASE_RANGE_RAD = (-0.25, 0.35)
_T3_ID_SPEEDS_RAD_S = tuple(-math.radians(2.5 + 0.5 * index) for index in range(11))
_T4_ASSETS = {
    "t4_sphere": ("arena.unsupported_ramp_v1", "obj.sphere_r030_v1"),
    "t4_sphere_tabletop": ("arena.supported_ramp_v1", "obj.sphere_r030_v1"),
    "t4_slider": ("arena.supported_ramp_v1", "obj.slider_v1"),
    "t4_can": ("arena.supported_ramp_v1", "obj.can_v1"),
}
_T4_ID_RAMP_ANGLES_RAD = tuple(math.radians(value) for value in (5.0, 10.0, 15.0))
_T4_OOD_RAMP_ANGLES_RAD = tuple(math.radians(value) for value in (3.0, 18.0))
_T4_ID_LATERAL_RANGE_M = (-0.015, 0.015)
_T4_CAN_ID_YAW_RANGE_RAD = (-math.radians(4.0), math.radians(4.0))
_T4_CAN_OOD_YAW_RANGE_RAD = (-math.radians(12.0), math.radians(12.0))
_T4_SUPPORTED_FRICTION_ID_RANGES = {
    "t4_slider": {"ramp": (0.025, 0.045), "table": (0.012, 0.018)},
    "t4_can": {"ramp": (0.25, 0.45), "table": (0.09, 0.15)},
}
_T4_TARGET_SUPPORT_EXTENT_M = {
    "t4_sphere": 0.030,
    "t4_sphere_tabletop": 0.030,
    "t4_slider": 0.020,
    "t4_can": 0.024,
}
_T4_CAN_FRAME_QUATERNION_XYZW = (0.5, 0.5, 0.5, 0.5)
_T4_CANONICAL_LIGHT = {**_GRASP_CANONICAL_LIGHT, "light_id": "free_dynamics_key"}
_T5_BELT_SPEED_ID_RANGE_M_S = (0.12, 0.14)
_T5_BELT_SPEED_OOD_VALUES_M_S = (0.09, 0.17)
_T5_X_ID_RANGE_M = (-0.005, 0.005)
_T5_YAW_ID_RANGE_RAD = (-0.08, 0.08)
_T5_STRIKER_SCALE_ID_RANGE = (1.0, 1.1)
_T5_STRIKER_SCALE_OOD_VALUES = (0.8, 1.2)
_T5_CANONICAL_LIGHT = {**_GRASP_CANONICAL_LIGHT, "light_id": "replanning_key"}
