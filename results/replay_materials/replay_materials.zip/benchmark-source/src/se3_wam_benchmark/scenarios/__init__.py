from se3_wam_benchmark.scenarios.spec import ScenarioSpec

__all__ = ["ScenarioSpec"]
