"""Concrete scenario constraints and declared ID/OOD support checks."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import cast

import mujoco
import numpy as np
import numpy.typing as npt
from robosuite.models.arenas import TableArena
from robosuite.models.objects import MujocoXMLObject
from robosuite.models.tasks import ManipulationTask

from se3_wam_benchmark.envs.base import _AssetRecord, _load_asset_catalog
from se3_wam_benchmark.envs.components.motion import (
    _motion_state_at_time,
    _validate_motion_initial_pose,
)
from se3_wam_benchmark.scenarios._family_parameters import (
    _CANONICAL_AGENTVIEW,
    _CANONICAL_WRIST,
    _GRASP_ASSET_IDS,
    _GRASP_CANONICAL_LIGHT,
    _GRASP_DOWNSTREAM_EXIT_Y_M,
    _GRASP_ID_ASSET_ID,
    _GRASP_ID_FRICTION,
    _GRASP_ID_SOLIMP,
    _GRASP_ID_SOLREF,
    _GRASP_ID_X_RANGE_M,
    _GRASP_ID_Y_RANGE_M,
    _GRASP_ID_YAW_RANGE_RAD,
    _GRASP_OBJECT_OOD_ASSET_IDS,
    _GRASP_OOD_X_RANGE_M,
    _GRASP_OOD_Y_RANGE_M,
    _GRASP_OOD_YAW_RANGE_RAD,
    _GRASP_PANDA_GRIPPER_POSITION_M,
    _GRASP_PANDA_JOINT_POSITION_RAD,
    _GRASP_SUPPORT_SURFACE_Z_M,
    _GRASP_WORKSPACE_BOUNDS_XY_M,
    _T3_ID_PHASE_RANGE_RAD,
    _T3_ID_SPEEDS_RAD_S,
    _T4_ASSETS,
    _T4_CAN_FRAME_QUATERNION_XYZW,
    _T4_CAN_ID_YAW_RANGE_RAD,
    _T4_CAN_OOD_YAW_RANGE_RAD,
    _T4_CANONICAL_LIGHT,
    _T4_ID_LATERAL_RANGE_M,
    _T4_ID_RAMP_ANGLES_RAD,
    _T4_OOD_RAMP_ANGLES_RAD,
    _T4_SUPPORTED_FRICTION_ID_RANGES,
    _T4_TARGET_SUPPORT_EXTENT_M,
    _T5_BELT_SPEED_ID_RANGE_M_S,
    _T5_BELT_SPEED_OOD_VALUES_M_S,
    _T5_CANONICAL_LIGHT,
    _T5_STRIKER_SCALE_ID_RANGE,
    _T5_STRIKER_SCALE_OOD_VALUES,
    _T5_X_ID_RANGE_M,
    _T5_YAW_ID_RANGE_RAD,
)
from se3_wam_benchmark.scenarios._recipes import (
    _PARTITIONS,
    _choice_values,
    _mapping,
    _number,
    _radians_recipe,
    _recipe_sequence,
    _select_recipe,
    _t4_ramp_center,
    _t4_ramp_rotation,
    _t4_target_quaternion,
    _uniform_intervals,
    _validate_free_dynamics_recipe,
    _validate_placement_recipe,
    _validate_replanning_recipe,
    _validate_rotating_recipe,
    _vector3_tuple,
)
from se3_wam_benchmark.scenarios.manifest import Partition
from se3_wam_benchmark.scenarios.spec import (
    ConstantAngularVelocityRotation,
    ConstantVelocityTranslation,
    DrivenInterceptionGeometrySpec,
    FixedRotation,
    FixedTranslation,
    FreeDynamicsInterceptionGeometrySpec,
    GraspGeometrySpec,
    HarmonicRotation,
    HarmonicTranslation,
    JointPhysicsSpec,
    MovingPlacementGeometrySpec,
    ReleaseGateRetractionEffectSpec,
    ReplanningGeometrySpec,
    RotatingInteractionGeometrySpec,
    ScenarioSpec,
    StateTriggerSpec,
    StrikerPulseEffectSpec,
    TimeTriggerSpec,
    scenario_to_dict,
)
from se3_wam_benchmark.tasks.spec import (
    DrivenInterceptionBindings,
    FreeDynamicsInterceptionBindings,
    GraspBindings,
    MovingPlacementBindings,
    ReplanningBindings,
    RotatingInteractionBindings,
    TaskSpec,
)


def _same_numbers(left: Sequence[float], right: Sequence[float]) -> bool:
    return len(left) == len(right) and all(
        math.isclose(float(a), float(b), rel_tol=0.0, abs_tol=1e-12)
        for a, b in zip(left, right, strict=True)
    )


@dataclass(frozen=True, slots=True)
class _ObjectAssetFacts:
    bottom_offset_m: float
    mass_kg: float
    diagonal_inertia_kg_m2: tuple[float, float, float]
    friction: tuple[float, float, float]
    solref: tuple[float, float]
    solimp: tuple[float, float, float, float, float]


def _compiled_object_asset_facts(asset: _AssetRecord) -> _ObjectAssetFacts:
    object_model = MujocoXMLObject(
        str(asset.path),
        name="compiled_asset",
        joints="default",
        obj_type="all",
        duplicate_collision_geoms=False,
    )
    task_model = ManipulationTask(
        mujoco_arena=TableArena(table_full_size=(0.8, 0.8, 0.05), table_offset=(0.0, 0.0, 0.8)),
        mujoco_robots=[],
        mujoco_objects=[object_model],
    )
    model = mujoco.MjModel.from_xml_string(task_model.get_xml())
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_model.root_body)
    if body_id < 0 or not object_model.contact_geoms:
        raise ValueError(f"asset lacks its compiled body/contact geoms: {asset.asset_id}")
    body_rotation = data.xmat[body_id].reshape(3, 3)
    bottoms: list[float] = []
    for name in object_model.contact_geoms:
        geom_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        if geom_id < 0 or model.geom_bodyid[geom_id] != body_id:
            raise ValueError(f"Grasp asset contact geom is not owned by its body: {name}")
        position = body_rotation.T @ (data.geom_xpos[geom_id] - data.xpos[body_id])
        rotation = body_rotation.T @ data.geom_xmat[geom_id].reshape(3, 3)
        size = model.geom_size[geom_id]
        if model.geom_type[geom_id] == mujoco.mjtGeom.mjGEOM_BOX:
            half_height = float(np.dot(np.abs(rotation[2]), size))
        elif model.geom_type[geom_id] == mujoco.mjtGeom.mjGEOM_CYLINDER:
            half_height = float(
                size[0] * math.hypot(rotation[2, 0], rotation[2, 1]) + size[1] * abs(rotation[2, 2])
            )
        elif model.geom_type[geom_id] == mujoco.mjtGeom.mjGEOM_SPHERE:
            half_height = float(size[0])
        elif model.geom_type[geom_id] == mujoco.mjtGeom.mjGEOM_CAPSULE:
            half_height = float(size[0] + size[1] * abs(rotation[2, 2]))
        else:
            raise ValueError(f"unexpected collision geometry in compiled object asset: {name}")
        bottoms.append(float(position[2]) - half_height)
    mass = float(model.body_mass[body_id])
    inertia = _vector3_tuple(model.body_inertia[body_id])
    bottom = min(bottoms)
    if (
        not all(math.isfinite(value) for value in (bottom, mass, *inertia))
        or min(mass, *inertia) <= 0.0
    ):
        raise ValueError(f"Grasp asset has invalid compiled physical values: {asset.asset_id}")
    first_geom = int(model.geom(object_model.contact_geoms[0]).id)
    return _ObjectAssetFacts(
        bottom,
        mass,
        inertia,
        _vector3_tuple(model.geom_friction[first_geom]),
        cast(tuple[float, float], tuple(float(v) for v in model.geom_solref[first_geom])),
        cast(
            tuple[float, float, float, float, float],
            tuple(float(v) for v in model.geom_solimp[first_geom]),
        ),
    )


def _grasp_translation_uses_id_parameters(scenario: ScenarioSpec) -> bool:
    translation = scenario.motion[0].translation
    return (
        isinstance(translation, HarmonicTranslation)
        and translation.drift_velocity_world_m_s[::2] == (0.0, 0.0)
        and 0.025 <= translation.drift_velocity_world_m_s[1] <= 0.125
        and 0.015 <= translation.amplitude_m[0] <= 0.035
        and translation.amplitude_m[1:] == (0.0, 0.0)
        and 0.30 <= translation.frequency_hz[0] <= 0.70
        and translation.frequency_hz[1:] == (0.0, 0.0)
        and -math.pi <= translation.phase_rad[0] <= math.pi
        and translation.phase_rad[1:] == (0.0, 0.0)
    )


def _grasp_motion_uses_id_law_pair(scenario: ScenarioSpec) -> bool:
    motion = scenario.motion[0]
    return isinstance(motion.translation, HarmonicTranslation) and isinstance(
        motion.rotation, ConstantAngularVelocityRotation
    )


def _grasp_motion_uses_id_parameters(scenario: ScenarioSpec) -> bool:
    rotation = scenario.motion[0].rotation
    id_rotation = (
        isinstance(rotation, ConstantAngularVelocityRotation)
        and rotation.axis_world == (0.0, 0.0, 1.0)
        and -1.2 <= rotation.angular_speed_rad_s <= 1.2
    )
    return _grasp_translation_uses_id_parameters(scenario) and id_rotation


def _validate_camera_and_lighting(
    scenario: ScenarioSpec,
    *,
    factor: str | None,
    stress: bool,
    canonical_light: Mapping[str, object],
    name: str,
) -> None:
    agentview = scenario.cameras.views[0]
    canonical_position, canonical_quaternion, canonical_fov = _CANONICAL_AGENTVIEW
    agent_position = tuple(agentview.position_parent_m)
    agent_quaternion = tuple(agentview.quaternion_parent_xyzw)
    canonical_camera = (
        _same_numbers(agent_position, canonical_position)
        and _same_numbers(agent_quaternion, canonical_quaternion)
        and math.isclose(agentview.vertical_fov_deg, canonical_fov, abs_tol=1e-12)
    )
    if len(scenario.cameras.views) == 2:
        wrist = scenario.cameras.views[1]
        wrist_position, wrist_quaternion, wrist_fov = _CANONICAL_WRIST
        if not (
            _same_numbers(wrist.position_parent_m, wrist_position)
            and _same_numbers(wrist.quaternion_parent_xyzw, wrist_quaternion)
            and math.isclose(wrist.vertical_fov_deg, wrist_fov, abs_tol=1e-12)
        ):
            raise ValueError(f"{name} wrist camera must remain canonical")
    if factor == "camera":
        deltas = tuple(
            value - canonical
            for value, canonical in zip(agent_position, canonical_position, strict=True)
        )
        translated = sum(not math.isclose(delta, 0.0, abs_tol=1e-12) for delta in deltas) == 1
        allowed_translation = (
            translated
            and math.isclose(agentview.vertical_fov_deg, canonical_fov, abs_tol=1e-12)
            and all(
                math.isclose(abs(delta), 0.05, abs_tol=1e-12)
                if not math.isclose(delta, 0.0, abs_tol=1e-12)
                else True
                for delta in deltas
            )
        )
        fov_intervention = _same_numbers(
            agent_position, canonical_position
        ) and agentview.vertical_fov_deg in (35.0, 45.0)
        if not (
            _same_numbers(agent_quaternion, canonical_quaternion)
            and (allowed_translation or fov_intervention)
            and not canonical_camera
        ):
            raise ValueError(
                f"{name} camera OOD requires exactly one frozen agentview intervention"
            )
    elif not stress and not canonical_camera:
        raise ValueError(f"{name} non-camera recipe must use canonical agentview")

    if len(scenario.lighting.lights) != 1:
        raise ValueError(f"{name} requires its single canonical arena light")
    light = scenario.lighting.lights[0]
    fixed_light_values = {
        "light_id": light.light_id,
        "position_world_m": light.position_world_m,
        "direction_world": light.direction_world,
        "ambient_rgb": light.ambient_rgb,
        "attenuation": light.attenuation,
        "cutoff_deg": light.cutoff_deg,
        "active": light.active,
    }
    for field, expected in canonical_light.items():
        if field in {"diffuse_rgb", "specular_rgb"}:
            continue
        actual = fixed_light_values[field]
        if isinstance(expected, tuple):
            if not isinstance(actual, tuple) or not _same_numbers(actual, expected):
                raise ValueError(f"{name} light geometry must remain canonical")
        elif actual != expected:
            raise ValueError(f"{name} light identity must remain canonical")
    diffuse = tuple(light.diffuse_rgb)
    specular = tuple(light.specular_rgb)
    canonical_diffuse = cast(tuple[float, float, float], canonical_light["diffuse_rgb"])
    canonical_specular = cast(tuple[float, float, float], canonical_light["specular_rgb"])
    if factor == "appearance":
        if not any(
            _same_numbers(diffuse, tuple(scale * value for value in canonical_diffuse))
            and _same_numbers(specular, tuple(scale * value for value in canonical_specular))
            for scale in (0.7, 1.3)
        ):
            raise ValueError(f"{name} appearance OOD must use one frozen light scale")
    elif not stress and not (
        _same_numbers(diffuse, canonical_diffuse) and _same_numbers(specular, canonical_specular)
    ):
        raise ValueError(f"{name} non-appearance recipe must use canonical light values")


def _validate_grasp_structure_and_geometry(
    scenario: ScenarioSpec, target_id: str
) -> GraspGeometrySpec:
    if len(scenario.object_states) != 1 or scenario.object_states[0].instance_id != target_id:
        raise ValueError("Grasp requires exactly one bound target object")
    if scenario.fixture_states or scenario.events:
        raise ValueError("Grasp declarative scenario does not accept fixtures or events")
    if len(scenario.motion) != 1 or scenario.motion[0].entity_id != target_id:
        raise ValueError("Grasp requires exactly one target motion record")
    if not (
        _same_numbers(
            scenario.robot_initial_state.joint_position_rad,
            _GRASP_PANDA_JOINT_POSITION_RAD,
        )
        and _same_numbers(
            scenario.robot_initial_state.gripper_position_m,
            _GRASP_PANDA_GRIPPER_POSITION_M,
        )
    ):
        raise ValueError("Grasp requires the frozen Panda initial state")
    geometry = scenario.geometry
    if not isinstance(geometry, GraspGeometrySpec) or (
        not math.isclose(geometry.support_surface_z_m, _GRASP_SUPPORT_SURFACE_Z_M, abs_tol=1e-12)
        or geometry.workspace_bounds_xy_m != _GRASP_WORKSPACE_BOUNDS_XY_M
        or not math.isclose(geometry.downstream_exit_y_m, _GRASP_DOWNSTREAM_EXIT_Y_M, abs_tol=1e-12)
    ):
        raise ValueError("Grasp geometry must use the frozen TableArena bounds")
    return geometry


def _validate_grasp_asset_and_spatial(
    scenario: ScenarioSpec,
    *,
    geometry: GraspGeometrySpec,
    factor: str | None,
    stress: bool,
    catalog: Mapping[str, _AssetRecord],
) -> _ObjectAssetFacts:
    target = scenario.object_states[0]
    if target.asset_id not in _GRASP_ASSET_IDS or target.asset_id not in catalog:
        raise ValueError("Grasp target asset must resolve through the frozen catalog")
    asset_facts = _compiled_object_asset_facts(catalog[target.asset_id])
    if factor == "object":
        if target.asset_id not in _GRASP_OBJECT_OOD_ASSET_IDS:
            raise ValueError("Grasp object OOD requires one frozen OOD asset")
    elif not stress and target.asset_id != _GRASP_ID_ASSET_ID:
        raise ValueError("Grasp non-object recipe must use the ID cuboid")

    x, y, z = target.position_world_m
    yaw = 2.0 * math.atan2(target.quaternion_world_xyzw[2], target.quaternion_world_xyzw[3])
    if target.quaternion_world_xyzw[0:2] != (0.0, 0.0):
        raise ValueError("Grasp initial orientation must be yaw-only")
    workspace_lower, workspace_upper = geometry.workspace_bounds_xy_m
    if not (
        workspace_lower[0] <= x <= workspace_upper[0]
        and workspace_lower[1] <= y <= workspace_upper[1]
        and y < geometry.downstream_exit_y_m
        and math.isclose(
            z + asset_facts.bottom_offset_m,
            geometry.support_surface_z_m,
            rel_tol=0.0,
            abs_tol=1e-12,
        )
    ):
        raise ValueError("Grasp target initial pose must lie on support inside workspace")
    translation = scenario.motion[0].translation
    center_x = translation.center_world_m[0] if isinstance(translation, HarmonicTranslation) else x
    id_spatial = (
        _GRASP_ID_X_RANGE_M[0] <= center_x <= _GRASP_ID_X_RANGE_M[1]
        and _GRASP_ID_Y_RANGE_M[0] <= y <= _GRASP_ID_Y_RANGE_M[1]
        and _GRASP_ID_YAW_RANGE_RAD[0] <= yaw <= _GRASP_ID_YAW_RANGE_RAD[1]
    )
    if factor == "spatial":
        if id_spatial or not (
            _GRASP_OOD_X_RANGE_M[0] <= center_x <= _GRASP_OOD_X_RANGE_M[1]
            and _GRASP_OOD_Y_RANGE_M[0] <= y <= _GRASP_OOD_Y_RANGE_M[1]
            and _GRASP_OOD_YAW_RANGE_RAD[0] <= yaw <= _GRASP_OOD_YAW_RANGE_RAD[1]
        ):
            raise ValueError("Grasp spatial OOD must be outside ID support")
    elif not stress and not id_spatial:
        raise ValueError("Grasp non-spatial recipe must remain inside ID pose support")
    return asset_facts


def _validate_grasp_declarative_physics(
    scenario: ScenarioSpec,
    *,
    target_id: str,
    asset_facts: _ObjectAssetFacts,
    factor: str | None,
    stress: bool,
) -> None:
    if scenario.physics.gravity_world_m_s2 != (0.0, 0.0, -9.81):
        raise ValueError("Grasp gravity must remain canonical")
    if (
        len(scenario.physics.bodies) != 1
        or scenario.physics.bodies[0].entity_id != target_id
        or len(scenario.physics.contacts) != 1
        or scenario.physics.contacts[0].entity_id != target_id
    ):
        raise ValueError("Grasp physics must resolve one body and contact record to target")
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={(target_id, f"{target_id}_joint0"): 6},
        name="Grasp joint physics",
    )
    if not stress and not _joint_physics_is_canonical(scenario.physics.joints):
        raise ValueError("Grasp non-stress recipes must retain canonical joint physics")
    body = scenario.physics.bodies[0]
    contact = scenario.physics.contacts[0]
    density_scale = body.mass_kg / asset_facts.mass_kg
    if not _same_numbers(
        body.diagonal_inertia_kg_m2,
        tuple(density_scale * value for value in asset_facts.diagonal_inertia_kg_m2),
    ):
        raise ValueError(
            "Grasp proposal rejected: body physics does not match selected asset "
            f"{scenario.object_states[0].asset_id}"
        )
    id_physics = (
        math.isclose(density_scale, 1.0, rel_tol=0.0, abs_tol=1e-12)
        and _same_numbers(contact.friction_slide_spin_roll, _GRASP_ID_FRICTION)
        and _same_numbers(contact.solref, _GRASP_ID_SOLREF)
        and _same_numbers(contact.solimp, _GRASP_ID_SOLIMP)
        and _joint_physics_is_canonical(scenario.physics.joints)
    )
    if factor == "physics":
        if id_physics:
            raise ValueError("Grasp physics OOD must leave ID physics support")
    elif not stress and not id_physics:
        raise ValueError("Grasp non-physics recipe must use canonical physics")


def _validate_grasp_declarative_motion(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    id_motion_parameters = _grasp_motion_uses_id_parameters(scenario)
    id_law_pair = _grasp_motion_uses_id_law_pair(scenario)
    rotation = scenario.motion[0].rotation
    if factor == "motion_parameters":
        if id_motion_parameters or not id_law_pair:
            raise ValueError("Grasp motion-parameters OOD must change only known-law values")
    elif factor == "motion_law":
        if not _grasp_translation_uses_id_parameters(scenario) or not isinstance(
            rotation, HarmonicRotation
        ):
            raise ValueError("Grasp motion-law OOD must introduce only a frozen new law type")
    elif not stress and (not id_motion_parameters or not id_law_pair):
        raise ValueError("Grasp ID recipes must use ID motion laws and parameters")


def _validate_grasp_declarative_delay(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    if factor == "action_delay":
        if scenario.action_delay_steps not in (1, 2):
            raise ValueError("Grasp action-delay OOD must use one or two ticks")
    elif not stress and scenario.action_delay_steps != 0:
        raise ValueError("Grasp non-delay recipes require zero action delay")


def _validate_grasp_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
) -> None:
    if task.family != "grasp" or not isinstance(task.bindings, GraspBindings):
        raise ValueError("Grasp declarative validation requires the grasp TaskSpec")
    if partition == "ood" and factor not in {
        "object",
        "spatial",
        "motion_parameters",
        "motion_law",
        "physics",
        "appearance",
        "camera",
        "action_delay",
    }:
        raise ValueError("Grasp recipe uses an inapplicable OOD factor")
    stress = partition == "stress"
    target_id = task.bindings.target_object_id
    geometry = _validate_grasp_structure_and_geometry(scenario, target_id)
    asset_facts = _validate_grasp_asset_and_spatial(
        scenario,
        geometry=geometry,
        factor=factor,
        stress=stress,
        catalog=catalog,
    )
    _validate_grasp_declarative_physics(
        scenario,
        target_id=target_id,
        asset_facts=asset_facts,
        factor=factor,
        stress=stress,
    )
    _validate_grasp_declarative_motion(scenario, factor=factor, stress=stress)
    _validate_grasp_declarative_delay(scenario, factor=factor, stress=stress)
    _validate_camera_and_lighting(
        scenario, factor=factor, stress=stress, canonical_light=_GRASP_CANONICAL_LIGHT, name="Grasp"
    )


def _validate_surface_declarative_entities(
    scenario: ScenarioSpec,
    *,
    occluded: bool,
    target_id: str,
    belt_id: str,
    occluder_ids: tuple[str, ...],
    catalog: Mapping[str, _AssetRecord],
) -> None:
    fixtures = {item.instance_id: item for item in scenario.fixture_states}
    if (
        len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != target_id
        or len(scenario.fixture_states) != 1 + int(occluded)
        or set(fixtures) != {belt_id, *occluder_ids}
        or len(scenario.motion) != 1
        or scenario.motion[0].entity_id != belt_id
        or scenario.events
        or len(occluder_ids) != int(occluded)
    ):
        raise ValueError(
            "surface-driven T1 must contain exactly its free target, static belt and surface motion"
        )
    target, belt = scenario.object_states[0], fixtures[belt_id]
    if occluded:
        canopy = fixtures[occluder_ids[0]]
        if (
            canopy.asset_id != "fixture.occlusion_canopy_v1"
            or canopy.asset_id not in catalog
            or catalog[canopy.asset_id].kind != "fixture"
        ):
            raise ValueError("T1-OCC canopy must resolve its frozen catalog fixture")
    if (
        target.asset_id != "obj.cube_44_v1"
        or belt.asset_id != "arena.conveyor_v1"
        or target.asset_id not in catalog
        or belt.asset_id not in catalog
        or catalog[target.asset_id].kind != "object"
        or catalog[belt.asset_id].kind != "arena"
    ):
        raise ValueError(
            "surface-driven T1 target and belt must resolve their frozen catalog assets"
        )
    if (
        belt.position_world_m != (0.0, 0.0, 0.78)
        or belt.quaternion_world_xyzw != (0.0, 0.0, 0.0, 1.0)
        or target.quaternion_world_xyzw != (0.0, 0.0, 0.0, 1.0)
    ):
        raise ValueError(
            "surface-driven T1 canonical fixture pose and initial target orientation "
            "must remain fixed"
        )


def _validate_surface_declarative_geometry(
    scenario: ScenarioSpec,
    *,
    occluded: bool,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
) -> _ObjectAssetFacts:
    geometry = scenario.geometry
    if not isinstance(geometry, DrivenInterceptionGeometrySpec) or (
        geometry.support_surface_z_m != 0.8
        or geometry.workspace_bounds_xy_m != ((-0.31, -0.40), (0.31, 0.40))
        or geometry.capture_corridor_bounds_xy_m != ((-0.28, -0.40), (0.28, 0.39))
        or geometry.downstream_exit_y_m != 0.39
        or geometry.occlusion_target_clearance_m != (0.20 if occluded else 0.0)
    ):
        raise ValueError("surface-driven T1 geometry must use its canonical conveyor bounds")
    if not (
        _same_numbers(
            scenario.robot_initial_state.joint_position_rad, _GRASP_PANDA_JOINT_POSITION_RAD
        )
        and _same_numbers(
            scenario.robot_initial_state.gripper_position_m, _GRASP_PANDA_GRIPPER_POSITION_M
        )
    ):
        raise ValueError("surface-driven T1 requires the frozen Panda initial state")
    target = scenario.object_states[0]
    facts = _compiled_object_asset_facts(catalog[target.asset_id])
    x, y, z = target.position_world_m
    if not math.isclose(
        z + facts.bottom_offset_m, geometry.support_surface_z_m, rel_tol=0.0, abs_tol=1e-12
    ):
        raise ValueError("surface-driven T1 target collision bottom must start on support")
    id_spatial = -0.08 <= x <= 0.08 and -0.26 <= y <= -0.18
    workspace_lower, workspace_upper = geometry.workspace_bounds_xy_m
    if not (
        workspace_lower[0] <= x <= workspace_upper[0]
        and workspace_lower[1] <= y <= workspace_upper[1]
        and y < geometry.downstream_exit_y_m
    ):
        raise ValueError("surface-driven T1 initial pose must remain inside workspace and upstream")
    if factor == "spatial" and id_spatial:
        raise ValueError("surface-driven T1 spatial OOD must be outside ID pose support")
    if factor != "spatial" and not id_spatial:
        raise ValueError("surface-driven T1 initial position lies outside its declared support")
    return facts


def _validate_surface_declarative_motion(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    target = scenario.object_states[0]
    if target.linear_velocity_world_m_s != (
        0.0,
        0.0,
        0.0,
    ) or target.angular_velocity_world_rad_s != (0.0, 0.0, 0.0):
        raise ValueError("surface-driven T1 target requires zero initial physical twist")
    motion = scenario.motion[0]
    if not isinstance(motion.translation, ConstantVelocityTranslation) or not isinstance(
        motion.rotation, FixedRotation
    ):
        raise ValueError(
            "surface-driven T1 requires constant surface translation and fixed fixture rotation"
        )
    vx, speed, vz = motion.translation.velocity_world_m_s
    lower_speed, upper_speed = (
        (0.04, 0.16)
        if stress
        else ((0.105, 0.120) if factor == "motion_parameters" else (0.04, 0.10))
    )
    if vx != 0.0 or vz != 0.0 or not lower_speed <= speed <= upper_speed:
        raise ValueError(
            "surface-driven T1 world +Y speed lies outside its declared motion support"
        )


def _validate_surface_declarative_physics(
    scenario: ScenarioSpec,
    *,
    target_id: str,
    belt_id: str,
    occluder_ids: tuple[str, ...],
    occluded: bool,
    facts: _ObjectAssetFacts,
    factor: str | None,
) -> None:
    contacts = {contact.entity_id: contact for contact in scenario.physics.contacts}
    if (
        len(scenario.physics.bodies) != 1
        or scenario.physics.bodies[0].entity_id != target_id
        or len(scenario.physics.contacts) != 2 + int(occluded)
        or set(contacts) != {target_id, belt_id, *occluder_ids}
    ):
        raise ValueError("surface-driven T1 physics requires exact target/fixture references")
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={(target_id, f"{target_id}_joint0"): 6},
        name="surface-driven T1 joint physics",
    )
    if not _joint_physics_is_canonical(scenario.physics.joints):
        raise ValueError("surface-driven T1 recipes must retain canonical joint physics")
    body = scenario.physics.bodies[0]
    id_physics = (
        scenario.physics.gravity_world_m_s2 == (0.0, 0.0, -9.81)
        and _same_numbers((body.mass_kg,), (facts.mass_kg,))
        and _same_numbers(body.diagonal_inertia_kg_m2, facts.diagonal_inertia_kg_m2)
        and all(
            _same_numbers(
                contact.friction_slide_spin_roll,
                (0.8, 0.005, 0.0001) if contact.entity_id in occluder_ids else _GRASP_ID_FRICTION,
            )
            and _same_numbers(contact.solref, _GRASP_ID_SOLREF)
            and _same_numbers(contact.solimp, _GRASP_ID_SOLIMP)
            for contact in contacts.values()
        )
        and _joint_physics_is_canonical(scenario.physics.joints)
    )
    if factor == "physics" and id_physics:
        raise ValueError("surface-driven T1 physics OOD must leave ID physics support")
    if factor != "physics" and not id_physics:
        raise ValueError("surface-driven T1 non-physics recipe must use canonical physics")


def _validate_surface_declarative_delay(scenario: ScenarioSpec, *, factor: str | None) -> None:
    if factor == "action_delay" and scenario.action_delay_steps not in (1, 2):
        raise ValueError("surface-driven T1 action-delay OOD requires one or two ticks")
    if factor != "action_delay" and scenario.action_delay_steps != 0:
        raise ValueError("surface-driven T1 non-delay recipes require zero action delay")


def _validate_surface_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
) -> None:
    if task.task_id not in ("t1_belt", "t1_occ") or not isinstance(
        task.bindings, DrivenInterceptionBindings
    ):
        raise ValueError("surface-driven T1 validation requires Belt or OCC TaskSpec")
    if (
        partition not in _PARTITIONS
        or (
            partition == "ood"
            and factor
            not in {
                "spatial",
                "motion_parameters",
                "physics",
                "appearance",
                "camera",
                "action_delay",
            }
        )
        or (partition != "ood" and factor is not None)
    ):
        raise ValueError("surface-driven T1 recipe uses an inapplicable partition/factor")
    occluded = task.task_id == "t1_occ"
    target_id, belt_id = task.bindings.target_object_id, task.bindings.driver_entity_id
    occluder_ids = task.bindings.occluder_fixture_ids
    _validate_surface_declarative_entities(
        scenario,
        occluded=occluded,
        target_id=target_id,
        belt_id=belt_id,
        occluder_ids=occluder_ids,
        catalog=catalog,
    )
    if partition == "stress":
        translation = scenario.motion[0].translation
        if not isinstance(translation, ConstantVelocityTranslation) or (
            scenario.object_states[0].position_world_m[:2],
            translation.velocity_world_m_s,
        ) not in (
            ((-0.08, -0.26), (0.0, 0.04, 0.0)),
            ((0.08, -0.18), (0.0, 0.10, 0.0)),
            ((0.0, -0.22), (0.0, 0.16, 0.0)),
            ((0.0, -0.22), (0.0, 0.07, 0.0)),
        ):
            raise ValueError("surface-driven T1 stress requires a fixed DB0 QA tuple")
    facts = _validate_surface_declarative_geometry(
        scenario,
        occluded=occluded,
        factor=factor,
        catalog=catalog,
    )
    _validate_surface_declarative_motion(scenario, factor=factor, stress=partition == "stress")
    _validate_surface_declarative_physics(
        scenario,
        target_id=target_id,
        belt_id=belt_id,
        occluder_ids=occluder_ids,
        occluded=occluded,
        facts=facts,
        factor=factor,
    )
    _validate_surface_declarative_delay(scenario, factor=factor)
    _validate_camera_and_lighting(
        scenario,
        factor=factor,
        stress=False,
        canonical_light={**_GRASP_CANONICAL_LIGHT, "light_id": "conveyor_key"},
        name="surface-driven T1",
    )


def _validate_matched_structure_and_spatial(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    target_id: str,
    factor: str | None,
    stress: bool,
    catalog: Mapping[str, _AssetRecord],
) -> _ObjectAssetFacts:
    bindings = cast(DrivenInterceptionBindings, task.bindings)
    if (
        bindings.driver_entity_id != target_id
        or bindings.occluder_fixture_ids
        or len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != target_id
        or scenario.fixture_states
        or scenario.events
        or len(scenario.motion) != 1
        or scenario.motion[0].entity_id != target_id
    ):
        raise ValueError(
            "T1 matched scenario requires exactly its target and continuous free-body motion"
        )
    target = scenario.object_states[0]
    if (
        target.asset_id != "obj.asym_t_t1_v1"
        or target.asset_id not in catalog
        or catalog[target.asset_id].kind != "object"
    ):
        raise ValueError("T1 matched target must resolve the fixed asymmetric T asset")
    geometry = scenario.geometry
    if not isinstance(geometry, DrivenInterceptionGeometrySpec) or (
        geometry.support_surface_z_m != 0.8
        or geometry.workspace_bounds_xy_m != ((-0.31, -0.40), (0.31, 0.40))
        or geometry.capture_corridor_bounds_xy_m != ((-0.28, -0.40), (0.28, 0.39))
        or geometry.downstream_exit_y_m != 0.39
        or geometry.occlusion_target_clearance_m != 0.0
    ):
        raise ValueError("T1 matched geometry must use its canonical TableArena bounds")
    if not (
        _same_numbers(
            scenario.robot_initial_state.joint_position_rad, _GRASP_PANDA_JOINT_POSITION_RAD
        )
        and _same_numbers(
            scenario.robot_initial_state.gripper_position_m, _GRASP_PANDA_GRIPPER_POSITION_M
        )
    ):
        raise ValueError("T1 matched scenario requires the frozen Panda initial state")
    facts = _compiled_object_asset_facts(catalog[target.asset_id])
    x, y, z = target.position_world_m
    if target.quaternion_world_xyzw[:2] != (0.0, 0.0) or not math.isclose(
        z + facts.bottom_offset_m, geometry.support_surface_z_m, rel_tol=0.0, abs_tol=1e-12
    ):
        raise ValueError("T1 matched target must start yaw-only with collision bottom on support")
    qz, qw = target.quaternion_world_xyzw[2:]
    yaw = math.atan2(2.0 * qz * qw, qw * qw - qz * qz)
    workspace_lower, workspace_upper = geometry.workspace_bounds_xy_m
    if not (
        workspace_lower[0] <= x <= workspace_upper[0]
        and workspace_lower[1] <= y <= workspace_upper[1]
        and y < geometry.downstream_exit_y_m
    ):
        raise ValueError("T1 matched initial pose must remain inside workspace and upstream")
    translation = scenario.motion[0].translation
    center_x = translation.center_world_m[0] if isinstance(translation, HarmonicTranslation) else x
    id_spatial = -0.025 <= center_x <= 0.025 and -0.24 <= y <= -0.20 and -0.35 <= yaw <= 0.35
    if (factor == "spatial" and id_spatial) or (
        factor != "spatial" and not stress and not id_spatial
    ):
        raise ValueError("T1 matched pose may leave ID spatial support only for its factor")
    initial_motion = _motion_state_at_time(
        scenario.motion[0],
        initial_position_world_m=target.position_world_m,
        initial_quaternion_world_xyzw=target.quaternion_world_xyzw,
        simulator_time_s=0.0,
    )
    if not _same_numbers(
        target.linear_velocity_world_m_s, _vector3_tuple(initial_motion.linear_velocity_world_m_s)
    ) or not _same_numbers(
        target.angular_velocity_world_rad_s,
        _vector3_tuple(initial_motion.angular_velocity_world_rad_s),
    ):
        raise ValueError("T1 matched initial physical twist must match its declared motion")
    return facts


def _validate_matched_declarative_motion(
    task: TaskSpec, scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    target = scenario.object_states[0]
    translation, rotation = scenario.motion[0].translation, scenario.motion[0].rotation
    if not isinstance(rotation, ConstantAngularVelocityRotation) or rotation.axis_world != (
        0.0,
        0.0,
        1.0,
    ):
        raise ValueError("T1 matched rotation must be constant angular velocity about world +Z")
    yaw_speed = abs(rotation.angular_speed_rad_s)
    if task.task_id == "t1_xyz" and yaw_speed != 0.0:
        raise ValueError("T1-XYZ requires zero yaw rate")
    if task.task_id == "t1_so3" and yaw_speed == 0.0:
        raise ValueError("T1-SO3 requires nonzero yaw rate")
    id_rotation = yaw_speed == 0.0 if task.task_id == "t1_xyz" else 0.4 <= yaw_speed <= 1.2
    if isinstance(translation, HarmonicTranslation):
        drift = translation.drift_velocity_world_m_s
        amplitude, frequency, phase = (
            translation.amplitude_m,
            translation.frequency_hz,
            translation.phase_rad,
        )
        if (
            drift[0] != 0.0
            or drift[2] != 0.0
            or amplitude[1:] != (0.0, 0.0)
            or frequency[1:] != (0.0, 0.0)
            or phase[1:] != (0.0, 0.0)
            or drift[1] <= 0.0
        ):
            raise ValueError(
                "T1 matched harmonic must use positive forward drift and X-only oscillation"
            )
        id_translation = (
            0.04 <= drift[1] <= 0.09
            and 0.0 <= amplitude[0] <= 0.03
            and 0.25 <= frequency[0] <= 0.65
        )
        if factor == "motion_law":
            raise ValueError(
                "T1 matched motion-law OOD must introduce the untrained constant translation law"
            )
    elif isinstance(translation, ConstantVelocityTranslation):
        vx, forward, vz = translation.velocity_world_m_s
        if vx != 0.0 or vz != 0.0 or forward <= 0.0 or (factor != "motion_law" and not stress):
            raise ValueError(
                "T1 matched positive constant translation belongs only to motion-law OOD or stress"
            )
        id_translation = 0.04 <= forward <= 0.09
    else:
        raise ValueError("T1 matched scenario requires harmonic or constant translation")
    if (
        factor == "motion_parameters"
        and id_translation
        and id_rotation
        and task.task_id != "t1_xyz"
    ):
        raise ValueError("T1 matched motion-parameters OOD must leave ID numeric support")
    if factor != "motion_parameters" and not stress and not (id_translation and id_rotation):
        raise ValueError("T1 matched non-parameter recipe must retain ID motion values")
    _validate_motion_initial_pose(
        scenario.motion[0],
        initial_position_world_m=target.position_world_m,
        initial_quaternion_world_xyzw=target.quaternion_world_xyzw,
    )


def _validate_matched_declarative_physics(
    scenario: ScenarioSpec,
    *,
    target_id: str,
    facts: _ObjectAssetFacts,
    factor: str | None,
    stress: bool,
) -> None:
    physics = scenario.physics
    if (
        len(physics.bodies) != 1
        or physics.bodies[0].entity_id != target_id
        or len(physics.contacts) != 1
        or physics.contacts[0].entity_id != target_id
    ):
        raise ValueError("T1 matched physics requires target body/contact references")
    _validate_joint_physics_specs(
        physics.joints,
        allowed_dofs={(target_id, f"{target_id}_joint0"): 6},
        name="T1 matched joint physics",
    )
    if not stress and not _joint_physics_is_canonical(physics.joints):
        raise ValueError("T1 matched non-stress recipes must retain canonical joint physics")
    body, contact = physics.bodies[0], physics.contacts[0]
    id_physics = (
        physics.gravity_world_m_s2 == (0.0, 0.0, -9.81)
        and _same_numbers((body.mass_kg,), (facts.mass_kg,))
        and _same_numbers(body.diagonal_inertia_kg_m2, facts.diagonal_inertia_kg_m2)
        and _same_numbers(contact.friction_slide_spin_roll, _GRASP_ID_FRICTION)
        and _same_numbers(contact.solref, _GRASP_ID_SOLREF)
        and _same_numbers(contact.solimp, _GRASP_ID_SOLIMP)
        and _joint_physics_is_canonical(physics.joints)
    )
    if (factor == "physics" and id_physics) or (
        factor != "physics" and not stress and not id_physics
    ):
        raise ValueError("T1 matched physics intervention must belong only to its factor")


def _validate_matched_declarative_delay(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    if (
        (factor == "action_delay" and scenario.action_delay_steps not in (1, 2))
        or (factor != "action_delay" and not stress and scenario.action_delay_steps != 0)
        or (stress and scenario.action_delay_steps > 4)
    ):
        raise ValueError("T1 matched action delay lies outside its declared factor support")


def _validate_matched_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
) -> None:
    if task.task_id not in ("t1_xyz", "t1_so3") or not isinstance(
        task.bindings, DrivenInterceptionBindings
    ):
        raise ValueError("T1 matched validation requires XYZ or SO3 TaskSpec")
    if (
        partition not in _PARTITIONS
        or (
            partition == "ood"
            and factor
            not in {
                "spatial",
                "motion_parameters",
                "motion_law",
                "physics",
                "appearance",
                "camera",
                "action_delay",
            }
        )
        or (partition != "ood" and factor is not None)
    ):
        raise ValueError("T1 matched recipe uses an inapplicable partition/factor")
    stress = partition == "stress"
    target_id = task.bindings.target_object_id
    facts = _validate_matched_structure_and_spatial(
        task,
        scenario,
        target_id=target_id,
        factor=factor,
        stress=stress,
        catalog=catalog,
    )
    _validate_matched_declarative_motion(task, scenario, factor=factor, stress=stress)
    _validate_matched_declarative_physics(
        scenario, target_id=target_id, facts=facts, factor=factor, stress=stress
    )
    _validate_matched_declarative_delay(scenario, factor=factor, stress=stress)
    _validate_camera_and_lighting(
        scenario,
        factor=factor,
        stress=stress,
        canonical_light=_GRASP_CANONICAL_LIGHT,
        name="T1 matched",
    )


def _in_recipe_support(
    value: object,
    recipe: object,
    *,
    owned_paths: frozenset[tuple[str | int, ...]] = frozenset(),
    path: tuple[str | int, ...] = (),
) -> bool:
    """Membership in the existing closed sampling syntax, without taking any draw."""
    if path in owned_paths:
        return True
    if isinstance(recipe, Mapping):
        if set(recipe) == {"degrees"}:
            return _in_recipe_support(
                value, _radians_recipe(recipe["degrees"]), owned_paths=owned_paths, path=path
            )
        if set(recipe) == {"uniform_intervals"}:
            return any(
                _in_recipe_support(
                    value, {"min": low, "max": high}, owned_paths=owned_paths, path=path
                )
                for low, high in _uniform_intervals(recipe["uniform_intervals"], "angle intervals")
            )
        if set(recipe) == {"yaw_rad"} and isinstance(value, Sequence) and len(value) == 4:
            if value[0] != 0.0 or value[1] != 0.0:
                return False
            yaw = 2.0 * math.atan2(float(value[2]), float(value[3]))
            return _in_recipe_support(yaw, recipe["yaw_rad"], owned_paths=owned_paths, path=path)
        if set(recipe) == {"choices"}:
            return any(
                _in_recipe_support(value, candidate, owned_paths=owned_paths, path=path)
                for candidate in _choice_values(recipe, "ID support")
            )
        if set(recipe) == {"min", "max"}:
            lower, upper = recipe["min"], recipe["max"]
            if isinstance(lower, Sequence) and not isinstance(lower, (str, bytes)):
                highs = _recipe_sequence(upper, "ID upper support")
                return _in_recipe_support(
                    value,
                    [{"min": a, "max": b} for a, b in zip(lower, highs, strict=True)],
                    owned_paths=owned_paths,
                    path=path,
                )
            return (
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and _number(lower, "ID lower support")
                <= value
                <= _number(upper, "ID upper support")
            )
        return (
            isinstance(value, Mapping)
            and set(value) == set(recipe)
            and all(
                _in_recipe_support(value[key], item, owned_paths=owned_paths, path=(*path, key))
                for key, item in recipe.items()
            )
        )
    if isinstance(recipe, Sequence) and not isinstance(recipe, (str, bytes)):
        return (
            isinstance(value, Sequence)
            and not isinstance(value, (str, bytes))
            and len(value) == len(recipe)
            and all(
                _in_recipe_support(actual, expected, owned_paths=owned_paths, path=(*path, index))
                for index, (actual, expected) in enumerate(zip(value, recipe, strict=True))
            )
        )
    return bool(value == recipe)


def _t4_rotation_from_quaternion(
    quaternion_xyzw: npt.ArrayLike, *, name: str
) -> npt.NDArray[np.float64]:
    quaternion = np.asarray(quaternion_xyzw, dtype=np.float64)
    if quaternion.shape != (4,) or not np.isfinite(quaternion).all():
        raise ValueError(f"{name} requires a finite quaternion")
    norm = float(np.linalg.norm(quaternion))
    if norm == 0.0:
        raise ValueError(f"{name} requires a nonzero quaternion")
    x, y, z, w = quaternion / norm
    return np.asarray(
        (
            (1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y - z * w), 2.0 * (x * z + y * w)),
            (2.0 * (x * y + z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z - x * w)),
            (2.0 * (x * z - y * w), 2.0 * (y * z + x * w), 1.0 - 2.0 * (x * x + y * y)),
        ),
        dtype=np.float64,
    )


def _t4_atomic_coordinates(task: TaskSpec, scenario: ScenarioSpec) -> tuple[float, float, float]:
    geometry = scenario.geometry
    if not isinstance(geometry, FreeDynamicsInterceptionGeometrySpec):
        raise ValueError("T4 requires FreeDynamicsInterceptionGeometrySpec")
    target = scenario.object_states[0]
    ramp_rotation = _t4_ramp_rotation(geometry.ramp_angle_rad)
    local = ramp_rotation.T @ (
        np.asarray(target.position_world_m, dtype=np.float64)
        - np.asarray(geometry.ramp_downstream_lip_world_m, dtype=np.float64)
    )
    if not math.isclose(
        float(local[2]),
        _T4_TARGET_SUPPORT_EXTENT_M[task.task_id],
        rel_tol=0.0,
        abs_tol=1e-10,
    ):
        raise ValueError("T4 target collision geometry must begin supported on the ramp")
    target_rotation = _t4_rotation_from_quaternion(
        target.quaternion_world_xyzw, name="T4 target orientation"
    )
    if task.task_id == "t4_can":
        frame_rotation = _t4_rotation_from_quaternion(
            _T4_CAN_FRAME_QUATERNION_XYZW, name="T4 can frame"
        )
        relative = ramp_rotation.T @ target_rotation @ frame_rotation.T
        axis_yaw = math.atan2(float(relative[1, 0]), float(relative[0, 0]))
    else:
        axis_yaw = 0.0
    expected_rotation = _t4_rotation_from_quaternion(
        _t4_target_quaternion(task.task_id, geometry.ramp_angle_rad, axis_yaw),
        name="T4 compiled target orientation",
    )
    if not np.allclose(target_rotation, expected_rotation, rtol=0.0, atol=1e-10):
        raise ValueError("T4 target orientation must be compiled atomically from ramp and axis yaw")
    return float(local[0]), float(local[1]), axis_yaw


def _t4_recipe_projection(
    task: TaskSpec, scenario: ScenarioSpec, id_recipe: Mapping[str, object]
) -> dict[str, object]:
    concrete = scenario_to_dict(scenario)
    delay = concrete.pop("action_delay_steps")
    concrete["action_delay"] = {
        "enabled": scenario.action_delay_steps > 0,
        "delay_steps": delay,
    }
    lateral, along, axis_yaw = _t4_atomic_coordinates(task, scenario)
    objects = cast(list[dict[str, object]], concrete["object_states"])
    objects[0]["position_world_m"] = {
        "lateral_offset_m": float(round(lateral, 15)),
        "along_ramp_offset_m": float(round(along, 15)),
    }
    objects[0]["quaternion_world_xyzw"] = {"axis_yaw_rad": float(round(axis_yaw, 15))}
    template = _mapping(
        _recipe_sequence(id_recipe["object_states"], "T4 ID objects")[0], "T4 ID object"
    )
    yaw_template = _mapping(template["quaternion_world_xyzw"], "T4 ID orientation")["axis_yaw_rad"]
    declared_yaw = yaw_template
    if isinstance(yaw_template, Mapping) and set(yaw_template) == {"degrees"}:
        degrees = yaw_template["degrees"]
        if isinstance(degrees, (int, float)) and not isinstance(degrees, bool):
            declared_yaw = math.radians(degrees)
    if isinstance(declared_yaw, (int, float)) and not isinstance(declared_yaw, bool):
        if math.isclose(axis_yaw, declared_yaw, rel_tol=0.0, abs_tol=1e-12):
            objects[0]["quaternion_world_xyzw"] = {"axis_yaw_rad": float(declared_yaw)}
    position_template = _mapping(template["position_world_m"], "T4 ID position")
    geometry = cast(FreeDynamicsInterceptionGeometrySpec, scenario.geometry)
    rotation = _t4_ramp_rotation(geometry.ramp_angle_rad)
    concrete_geometry = _mapping(concrete["geometry"], "T4 concrete geometry")
    center = _t4_ramp_center(task.task_id, concrete_geometry, rotation)
    if set(position_template) == {"ramp_center_offset_m"}:
        local = rotation.T @ (np.asarray(scenario.object_states[0].position_world_m) - center)
        offset: list[object] = [float(round(value, 15)) for value in local]
        source_offset = _recipe_sequence(
            position_template["ramp_center_offset_m"], "T4 ID center offset"
        )
        for index, declared_coordinate in enumerate(source_offset):
            if isinstance(declared_coordinate, (int, float)) and not isinstance(
                declared_coordinate, bool
            ):
                if math.isclose(
                    float(local[index]), declared_coordinate, rel_tol=0.0, abs_tol=1e-12
                ):
                    offset[index] = float(declared_coordinate)
        if isinstance(source_offset[1], Mapping) and set(source_offset[1]) == {"from_release_gate"}:
            gate = scenario.fixture_states[1]
            gate_local = rotation.T @ (np.asarray(gate.position_world_m) - center)
            extent = 0.045 * abs(math.sin(axis_yaw)) + 0.024 * abs(math.cos(axis_yaw))
            expected = float(gate_local[1]) - 0.004 - extent
            if not math.isclose(float(local[1]), expected, rel_tol=0.0, abs_tol=1e-12):
                raise ValueError("T4 can start must use the same gate and sampled yaw")
            offset[1] = {"from_release_gate": True}
        objects[0]["position_world_m"] = {"ramp_center_offset_m": offset}
    else:
        projected_position = cast(dict[str, object], objects[0]["position_world_m"])
        for key, actual in (("lateral_offset_m", lateral), ("along_ramp_offset_m", along)):
            declared_coordinate = position_template[key]
            if isinstance(declared_coordinate, (int, float)) and not isinstance(
                declared_coordinate, bool
            ):
                if math.isclose(actual, declared_coordinate, rel_tol=0.0, abs_tol=1e-12):
                    projected_position[key] = float(declared_coordinate)
    fixtures = cast(list[dict[str, object]], concrete["fixture_states"])
    for fixture, raw_template in zip(
        fixtures, _recipe_sequence(id_recipe["fixture_states"], "T4 ID fixtures"), strict=True
    ):
        fixture_template = _mapping(raw_template, "T4 fixture")["position_world_m"]
        if isinstance(fixture_template, Mapping) and set(fixture_template) == {
            "ramp_center_offset_m"
        }:
            declared = np.asarray(fixture_template["ramp_center_offset_m"], dtype=np.float64)
            expected_position = center + rotation @ declared
            if not np.allclose(
                np.asarray(fixture["position_world_m"], dtype=np.float64),
                expected_position,
                rtol=0.0,
                atol=1e-12,
            ):
                raise ValueError("T4 gate must use the same sampled ramp frame")
            fixture["position_world_m"] = dict(fixture_template)
    physics = cast(dict[str, object], concrete["physics"])
    contacts = cast(list[dict[str, object]], physics["contacts"])
    by_id = {str(contact["entity_id"]): contact for contact in contacts}
    templates = _recipe_sequence(
        _mapping(id_recipe["physics"], "T4 ID physics")["contacts"], "T4 ID contacts"
    )
    for contact, raw_template in zip(contacts, templates, strict=True):
        friction_template = _mapping(raw_template, "T4 ID contact")["friction_slide_spin_roll"]
        if isinstance(friction_template, Mapping) and set(friction_template) == {"from_entity_id"}:
            source = by_id[str(friction_template["from_entity_id"])]["friction_slide_spin_roll"]
            if contact["friction_slide_spin_roll"] != source:
                raise ValueError("T4 target and ramp must share the same sampled friction")
            contact["friction_slide_spin_roll"] = dict(friction_template)
    return concrete


def _validate_free_dynamics_declarative_structure(
    scenario: ScenarioSpec,
    *,
    bindings: FreeDynamicsInterceptionBindings,
    arena_asset: str,
    target_asset: str,
    fixture_ids: tuple[str, str, str],
    catalog: Mapping[str, _AssetRecord],
) -> None:
    fixtures = {item.instance_id: item for item in scenario.fixture_states}
    if (
        len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != bindings.target_object_id
        or scenario.object_states[0].asset_id != target_asset
        or len(fixtures) != 3
        or set(fixtures) != set(fixture_ids)
        or any(item.asset_id != arena_asset for item in fixtures.values())
        or scenario.motion
        or len(scenario.events) != 1
    ):
        raise ValueError(
            "T4 requires exactly its target and composite ramp/gate/downstream fixtures"
        )
    for asset_id in (arena_asset, target_asset):
        if asset_id not in catalog:
            raise ValueError(f"T4 asset reference does not resolve: {asset_id}")
    target = scenario.object_states[0]
    if target.linear_velocity_world_m_s != (0.0, 0.0, 0.0) or (
        target.angular_velocity_world_rad_s != (0.0, 0.0, 0.0)
    ):
        raise ValueError("T4 scored t0 target twist must be zero")


def _validate_free_dynamics_declarative_geometry(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    supported: bool,
    factor: str | None,
    stress: bool,
) -> None:
    bindings = cast(FreeDynamicsInterceptionBindings, task.bindings)
    fixtures = {item.instance_id: item for item in scenario.fixture_states}
    geometry = scenario.geometry
    if not isinstance(geometry, FreeDynamicsInterceptionGeometrySpec):
        raise ValueError("T4 requires FreeDynamicsInterceptionGeometrySpec")
    expected_half = (0.12, 0.20, 0.010) if not supported else (0.105, 0.17, 0.004)
    if geometry.ramp_half_size_m != expected_half or geometry.support_surface_z_m != 0.8:
        raise ValueError("T4 geometry must resolve its frozen composite arena dimensions")
    ramp_fixture = fixtures[bindings.ramp_fixture_id]
    if ramp_fixture.position_world_m != geometry.ramp_downstream_lip_world_m or any(
        fixture.quaternion_world_xyzw != (0.0, 0.0, 0.0, 1.0) for fixture in fixtures.values()
    ):
        raise ValueError(
            "T4 fixture poses must preserve the explicit world-frame composite assembly"
        )
    angle = geometry.ramp_angle_rad
    in_id_angle = any(
        math.isclose(angle, expected, rel_tol=0.0, abs_tol=1e-12)
        for expected in _T4_ID_RAMP_ANGLES_RAD
    )
    in_ood_angle = any(
        math.isclose(angle, expected, rel_tol=0.0, abs_tol=1e-12)
        for expected in _T4_OOD_RAMP_ANGLES_RAD
    )
    if factor == "geometry":
        if not in_ood_angle:
            raise ValueError("T4 geometry OOD requires the frozen 3 or 18 degree slope")
    elif stress:
        if not (in_id_angle or math.isclose(angle, math.radians(18.0), rel_tol=0.0, abs_tol=1e-12)):
            raise ValueError("T4 stress requires a fixed old QA slope")
    elif partition in {"train", "validation"}:
        if not _T4_ID_RAMP_ANGLES_RAD[0] <= angle <= _T4_ID_RAMP_ANGLES_RAD[-1]:
            raise ValueError("T4 training and validation slopes must remain within 5 to 15 degrees")
    elif not in_id_angle:
        raise ValueError("T4 non-geometry recipe must use the frozen 5/10/15 degree slope grid")

    lateral, along, axis_yaw = _t4_atomic_coordinates(task, scenario)
    if not (-2.0 * geometry.ramp_half_size_m[1] < along < 0.0):
        raise ValueError("T4 target must begin upstream on the finite ramp")
    if abs(lateral) >= geometry.ramp_half_size_m[0]:
        raise ValueError("T4 target center must begin inside the finite ramp width")
    in_id_lateral = _T4_ID_LATERAL_RANGE_M[0] <= lateral <= _T4_ID_LATERAL_RANGE_M[1]
    if factor == "spatial":
        if in_id_lateral:
            raise ValueError("T4 spatial OOD must leave the frozen lateral ID support")
    elif not stress and not in_id_lateral:
        raise ValueError("T4 non-spatial recipe must retain the frozen lateral ID support")
    if task.task_id == "t4_can":
        in_id_yaw = _T4_CAN_ID_YAW_RANGE_RAD[0] <= axis_yaw <= _T4_CAN_ID_YAW_RANGE_RAD[1]
        in_ood_yaw = _T4_CAN_OOD_YAW_RANGE_RAD[0] <= axis_yaw <= _T4_CAN_OOD_YAW_RANGE_RAD[1]
        if factor == "geometry":
            if not in_ood_yaw:
                raise ValueError("T4 can geometry OOD axis yaw exceeds the frozen range")
        elif not stress and not in_id_yaw:
            raise ValueError("T4 can non-geometry recipe must retain ID axis yaw")
    elif axis_yaw != 0.0:
        raise ValueError("only the T4 can defines a nonzero in-plane axis yaw")

    lower, upper = geometry.capture_region_bounds_world_m
    if supported and (
        lower[:2] != (-0.12, -0.03)
        or upper[:2] != (0.12, 0.17)
        or geometry.exit_region_bounds_xy_m != ((-0.135, 0.20), (0.135, 0.24))
    ):
        raise ValueError("supported T4 must retain its frozen catch and exit regions")
    if not all(lower[index] < upper[index] for index in range(3)):
        raise ValueError("T4 capture region must be nonempty")


def _validate_free_dynamics_declarative_physics(
    scenario: ScenarioSpec,
    *,
    task_id: str,
    bindings: FreeDynamicsInterceptionBindings,
    fixture_ids: tuple[str, str, str],
    factor: str | None,
    stress: bool,
) -> None:
    bodies = {item.entity_id: item for item in scenario.physics.bodies}
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    if set(bodies) != {bindings.target_object_id} or set(contacts) != {
        bindings.target_object_id,
        *fixture_ids,
    }:
        raise ValueError("T4 physics must bind target and fixtures exactly once")
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={
            (bindings.target_object_id, f"{bindings.target_object_id}_joint0"): 6,
        },
        required=frozenset(),
        name="T4 joint physics",
    )
    target_key = (bindings.target_object_id, f"{bindings.target_object_id}_joint0")
    if not stress and not _selected_joint_physics_is_canonical(
        scenario.physics.joints, frozenset({target_key})
    ):
        raise ValueError("T4 non-stress recipes must retain canonical target joint physics")
    friction_ranges = _T4_SUPPORTED_FRICTION_ID_RANGES.get(task_id)
    if friction_ranges is not None:
        in_id_friction = {
            entity_id: bounds[0] <= contacts[entity_id].friction_slide_spin_roll[0] <= bounds[1]
            for entity_id, bounds in friction_ranges.items()
        }
        if factor != "physics" and not stress and not all(in_id_friction.values()):
            raise ValueError("T4 non-physics recipe friction must remain in frozen ID support")


def _validate_free_dynamics_declarative_event(
    scenario: ScenarioSpec, bindings: FreeDynamicsInterceptionBindings
) -> None:
    event = scenario.events[0]
    if (
        event.event_id != "release_gate"
        or not isinstance(event.trigger, TimeTriggerSpec)
        or event.trigger.control_tick != 0
        or not isinstance(event.effect, ReleaseGateRetractionEffectSpec)
        or event.effect.gate_entity_id != bindings.release_gate_fixture_id
        or event.effect.parked_position_world_m != (0.0, -0.25, 0.55)
    ):
        raise ValueError("T4 requires its exact tick-0 release-gate event")


def _validate_free_dynamics_declarative_delay(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    if factor == "action_delay":
        if scenario.action_delay_steps not in (1, 2):
            raise ValueError("T4 action-delay OOD requires one or two ticks")
    elif stress:
        if scenario.action_delay_steps != 0:
            raise ValueError("T4 fixed stress requires zero action delay")
    elif scenario.action_delay_steps != 0:
        raise ValueError("T4 non-delay intervention requires zero delay")


def _validate_free_dynamics_declarative_ownership(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    id_recipe: Mapping[str, object],
) -> None:
    _validate_free_dynamics_recipe(task, id_recipe)
    owned: dict[str, frozenset[tuple[str | int, ...]]] = {
        "spatial": frozenset({("object_states", 0, "position_world_m")}),
        "geometry": frozenset(
            {
                ("geometry",),
                ("object_states", 0, "position_world_m"),
                ("object_states", 0, "quaternion_world_xyzw"),
            }
        ),
        "physics": frozenset({("physics",)}),
        "appearance": frozenset({("lighting",)}),
        "camera": frozenset({("cameras",)}),
        "action_delay": frozenset({("action_delay",)}),
    }
    concrete = _t4_recipe_projection(task, scenario, id_recipe)
    owned_paths = owned.get(factor or "", frozenset())
    if not _in_recipe_support(concrete, id_recipe, owned_paths=owned_paths):
        raise ValueError("T4 non-owning factor fields must retain complete test-ID support")
    if partition == "ood" and _in_recipe_support(concrete, id_recipe):
        raise ValueError("T4 OOD must leave test-ID support in its declared factor")


def _validate_free_dynamics_fixed_stress(
    task: TaskSpec, scenario: ScenarioSpec, id_recipe: Mapping[str, object]
) -> None:
    geometry = cast(FreeDynamicsInterceptionGeometrySpec, scenario.geometry)
    lateral, _, yaw = _t4_atomic_coordinates(task, scenario)
    nominal_mu = {
        "t4_sphere": 0.8,
        "t4_sphere_tabletop": 0.8,
        "t4_slider": 0.035,
        "t4_can": 0.35,
    }[task.task_id]
    offset = 0.01 if task.task_id == "t4_can" else 0.015
    rows = (
        (5.0, -offset, nominal_mu, -4.0 if task.task_id == "t4_can" else 0.0),
        (15.0, offset, nominal_mu, 4.0 if task.task_id == "t4_can" else 0.0),
        (
            18.0,
            0.0,
            0.07 if task.task_id == "t4_slider" else 0.02,
            12.0 if task.task_id == "t4_can" else 0.0,
        ),
        (10.0, 0.0, nominal_mu, 0.0),
    )
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    actual = (
        geometry.ramp_angle_rad,
        lateral,
        contacts["target"].friction_slide_spin_roll[0],
        yaw,
    )
    matching = [
        row
        for row in rows
        if all(
            math.isclose(a, b, rel_tol=0.0, abs_tol=1e-12)
            for a, b in zip(
                actual,
                (math.radians(row[0]), row[1], row[2], math.radians(row[3])),
                strict=True,
            )
        )
    ]
    if not matching:
        raise ValueError("T4 stress must preserve one complete old factor or nominal QA tuple")
    angle, offset, friction, axis_yaw = matching[0]
    expected = deepcopy(dict(id_recipe))
    cast(dict[str, object], expected["geometry"])["ramp_angle_rad"] = {"degrees": angle}
    target = cast(list[dict[str, object]], expected["object_states"])[0]
    position = cast(dict[str, object], target["position_world_m"])
    if "ramp_center_offset_m" in position:
        cast(list[object], position["ramp_center_offset_m"])[0] = offset
    else:
        position["lateral_offset_m"] = offset
    target["quaternion_world_xyzw"] = {"axis_yaw_rad": {"degrees": axis_yaw}}
    physics = cast(dict[str, object], expected["physics"])
    for contact in cast(list[dict[str, object]], physics["contacts"]):
        if contact["entity_id"] == "target":
            contact["friction_slide_spin_roll"] = [friction, 0.005, 0.0001]
        elif contact["entity_id"] == "table":
            contact["friction_slide_spin_roll"] = [
                {"t4_can": 0.12, "t4_slider": 0.015, "t4_sphere_tabletop": 0.35}[task.task_id],
                0.005,
                0.0001,
            ]
    if not _in_recipe_support(_t4_recipe_projection(task, scenario, expected), expected):
        raise ValueError("T4 fixed stress must retain all nominal non-case fields")


def _validate_free_dynamics_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
    id_recipe: Mapping[str, object],
) -> None:
    if task.task_id not in _T4_ASSETS or not isinstance(
        task.bindings, FreeDynamicsInterceptionBindings
    ):
        raise ValueError("T4 validation requires FreeDynamicsInterceptionBindings")
    supported = task.task_id != "t4_sphere"
    factors = {"geometry", "physics", "appearance", "camera", "action_delay"}
    if supported:
        factors.add("spatial")
    if partition == "ood" and factor not in factors:
        raise ValueError("T4 recipe uses an inapplicable OOD factor")
    stress = partition == "stress"
    bindings = task.bindings
    arena_asset, target_asset = _T4_ASSETS[task.task_id]
    fixture_ids = (
        bindings.ramp_fixture_id,
        bindings.release_gate_fixture_id,
        bindings.downstream_surface_fixture_id,
    )
    _validate_free_dynamics_declarative_structure(
        scenario,
        bindings=bindings,
        arena_asset=arena_asset,
        target_asset=target_asset,
        fixture_ids=fixture_ids,
        catalog=catalog,
    )
    _validate_free_dynamics_declarative_geometry(
        task,
        scenario,
        partition=partition,
        supported=supported,
        factor=factor,
        stress=stress,
    )
    _validate_free_dynamics_declarative_physics(
        scenario,
        task_id=task.task_id,
        bindings=bindings,
        fixture_ids=fixture_ids,
        factor=factor,
        stress=stress,
    )
    _validate_free_dynamics_declarative_event(scenario, bindings)
    _validate_free_dynamics_declarative_delay(scenario, factor=factor, stress=stress)
    _validate_camera_and_lighting(
        scenario,
        factor=factor,
        stress=stress,
        canonical_light=_T4_CANONICAL_LIGHT,
        name="T4",
    )

    if stress:
        _validate_free_dynamics_fixed_stress(task, scenario, id_recipe)
    else:
        _validate_free_dynamics_declarative_ownership(
            task,
            scenario,
            partition=partition,
            factor=factor,
            id_recipe=id_recipe,
        )


def _t5_yaw_from_quaternion(quaternion_xyzw: Sequence[float]) -> float:
    rotation = _t4_rotation_from_quaternion(quaternion_xyzw, name="T5 target orientation")
    if not np.allclose(rotation[2], (0.0, 0.0, 1.0), rtol=0.0, atol=1e-12):
        raise ValueError("T5 target orientation must be a world-Z yaw")
    yaw = math.atan2(float(rotation[1, 0]), float(rotation[0, 0]))
    for exact in (*_T5_YAW_ID_RANGE_RAD, 0.0):
        if math.isclose(yaw, exact, rel_tol=0.0, abs_tol=1e-12):
            return exact
    return yaw


def _t5_recipe_projection(scenario: ScenarioSpec) -> dict[str, object]:
    concrete = scenario_to_dict(scenario)
    delay = concrete.pop("action_delay_steps")
    concrete["action_delay"] = {
        "enabled": scenario.action_delay_steps > 0,
        "delay_steps": delay,
    }
    objects = cast(list[dict[str, object]], concrete["object_states"])
    target = scenario.object_states[0]
    objects[0]["position_world_m"] = {"x_m": target.position_world_m[0]}
    objects[0]["quaternion_world_xyzw"] = {
        "yaw_rad": _t5_yaw_from_quaternion(target.quaternion_world_xyzw)
    }
    return concrete


def _validate_replanning_declarative_structure(
    scenario: ScenarioSpec,
    *,
    bindings: ReplanningBindings,
    fixture_ids: tuple[str, str, str],
    catalog: Mapping[str, _AssetRecord],
) -> None:
    fixtures = {item.instance_id: item for item in scenario.fixture_states}
    if (
        len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != bindings.target_object_id
        or scenario.object_states[0].asset_id != "obj.keyed_puck_v1"
        or len(fixtures) != 3
        or set(fixtures) != set(fixture_ids)
        or any(item.asset_id != "arena.replanning_conveyor_v1" for item in fixtures.values())
        or len(scenario.motion) != 1
        or scenario.motion[0].entity_id != bindings.belt_fixture_id
        or len(scenario.events) != 1
    ):
        raise ValueError("T5 requires exactly its keyed puck, belt, two strikers, and event")
    for asset_id in ("arena.replanning_conveyor_v1", "obj.keyed_puck_v1"):
        if asset_id not in catalog:
            raise ValueError(f"T5 asset reference does not resolve: {asset_id}")
    expected_fixtures = {
        bindings.belt_fixture_id: (0.0, 0.0, 0.78),
        bindings.left_striker_fixture_id: (-0.13, -0.15, 0.818),
        bindings.right_striker_fixture_id: (0.13, -0.15, 0.818),
    }
    if any(
        fixture.position_world_m != expected_fixtures[entity_id]
        or fixture.quaternion_world_xyzw != (0.0, 0.0, 0.0, 1.0)
        for entity_id, fixture in fixtures.items()
    ):
        raise ValueError("T5 composite fixture poses must retain the frozen native assembly")

    geometry = scenario.geometry
    if not isinstance(geometry, ReplanningGeometrySpec) or (
        geometry.support_surface_z_m,
        geometry.observation_boundary_y_m,
        geometry.workspace_bounds_xy_m,
        geometry.striker_travel_m,
    ) != (0.8, -0.13, ((-0.27, -0.35), (0.27, 0.34)), 0.098):
        raise ValueError(
            "T5 geometry must retain the frozen support, trigger, workspace, and travel"
        )
    target = scenario.object_states[0]
    if target.position_world_m[1:] != (-0.29, 0.812):
        raise ValueError("T5 target must start at the frozen observation-lane support pose")
    if target.linear_velocity_world_m_s != (0.0, 0.0, 0.0) or (
        target.angular_velocity_world_rad_s != (0.0, 0.0, 0.0)
    ):
        raise ValueError("T5 scored t0 target twist must be zero")
    initial_x = target.position_world_m[0]
    yaw = _t5_yaw_from_quaternion(target.quaternion_world_xyzw)
    if not (_T5_X_ID_RANGE_M[0] <= initial_x <= _T5_X_ID_RANGE_M[1]):
        raise ValueError("T5 target x must remain in the frozen ID support")
    if not (_T5_YAW_ID_RANGE_RAD[0] <= yaw <= _T5_YAW_ID_RANGE_RAD[1]):
        raise ValueError("T5 target yaw must remain in the frozen ID support")


def _validate_replanning_declarative_motion_and_event(
    scenario: ScenarioSpec, *, bindings: ReplanningBindings, factor: str | None, stress: bool
) -> None:
    motion = scenario.motion[0]
    if not isinstance(motion.translation, ConstantVelocityTranslation) or not isinstance(
        motion.rotation, FixedRotation
    ):
        raise ValueError("T5 belt requires constant translation and fixed rotation")
    vx, belt_speed, vz = motion.translation.velocity_world_m_s
    if vx != 0.0 or vz != 0.0:
        raise ValueError("T5 belt velocity must be exactly world +Y")
    event = scenario.events[0]
    effect = event.effect
    if (
        event.event_id != "selected_strike"
        or not isinstance(event.trigger, StateTriggerSpec)
        or not isinstance(effect, StrikerPulseEffectSpec)
    ):
        raise ValueError("T5 requires exactly one selected StateTrigger striker pulse")
    branch = (
        "left"
        if effect.striker_entity_id == bindings.left_striker_fixture_id
        else "right"
        if effect.striker_entity_id == bindings.right_striker_fixture_id
        else ""
    )
    if (
        not branch
        or effect.joint_name != f"{branch}_slide"
        or effect.strike_position_m != 0.098
        or effect.pulse_duration_s != 0.350
        or effect.kp_n_m != 100.0
        or effect.kd_n_s_m != 1.0
        or effect.maximum_force_n != 4.0
        or effect.contact_cutoff_delay_s != 0.020
        or effect.contact_grouping_hysteresis_s != 0.012
        or effect.maximum_contact_duration_s != 0.100
    ):
        raise ValueError("T5 event differs from the frozen selected-striker contract")
    in_id_speed = _T5_BELT_SPEED_ID_RANGE_M_S[0] <= belt_speed <= (_T5_BELT_SPEED_ID_RANGE_M_S[1])
    in_ood_speed = belt_speed in _T5_BELT_SPEED_OOD_VALUES_M_S
    in_id_scale = (
        _T5_STRIKER_SCALE_ID_RANGE[0] <= effect.actuator_scale <= (_T5_STRIKER_SCALE_ID_RANGE[1])
    )
    in_ood_scale = effect.actuator_scale in _T5_STRIKER_SCALE_OOD_VALUES
    if stress:
        target = scenario.object_states[0]
        actual = (
            belt_speed,
            target.position_world_m[0],
            _t5_yaw_from_quaternion(target.quaternion_world_xyzw),
        )
        if (
            actual
            not in (
                (0.12, -0.005, -0.08),
                (0.14, 0.005, 0.08),
                (0.09, 0.0, 0.0),
                (0.17, 0.0, 0.0),
                (0.13, 0.0, 0.0),
            )
            or not in_id_scale
        ):
            raise ValueError("T5 stress requires a fixed DB0 QA tuple and nominal striker scale")
    elif factor == "motion_parameters":
        if not (in_id_speed or in_ood_speed) or not (in_id_scale or in_ood_scale):
            raise ValueError("T5 motion-parameter OOD lies outside its frozen supports")
        if not (in_ood_speed or in_ood_scale):
            raise ValueError("T5 motion-parameter OOD must leave at least one ID support")
    elif not in_id_speed or not in_id_scale:
        raise ValueError("T5 non-motion intervention must retain belt speed and striker scale ID")


def _validate_replanning_declarative_physics(
    scenario: ScenarioSpec,
    *,
    bindings: ReplanningBindings,
    fixture_ids: tuple[str, str, str],
    catalog: Mapping[str, _AssetRecord],
) -> None:
    bodies = {item.entity_id: item for item in scenario.physics.bodies}
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    joints = {(item.entity_id, item.joint_name): item for item in scenario.physics.joints}
    expected_contacts = {bindings.target_object_id, *fixture_ids}
    expected_joints = frozenset(
        {
            (bindings.left_striker_fixture_id, "left_slide"),
            (bindings.right_striker_fixture_id, "right_slide"),
        }
    )
    if set(bodies) != {bindings.target_object_id} or set(contacts) != expected_contacts:
        raise ValueError("T5 physics must bind its target and fixtures exactly once")
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={
            (bindings.target_object_id, f"{bindings.target_object_id}_joint0"): 6,
            **{key: 1 for key in expected_joints},
        },
        required=expected_joints,
        name="T5 joint physics",
    )
    facts = _compiled_object_asset_facts(catalog["obj.keyed_puck_v1"])
    body = bodies[bindings.target_object_id]
    canonical_contacts = {
        bindings.target_object_id: (
            (0.05, 0.001, 0.000001),
            (0.02, 1.0),
            (0.9, 0.95, 0.001, 0.5, 2.0),
        ),
        bindings.belt_fixture_id: (
            (0.08, 0.001, 0.000001),
            (0.02, 1.0),
            (0.9, 0.95, 0.001, 0.5, 2.0),
        ),
        bindings.left_striker_fixture_id: (
            (0.65, 0.006, 0.0001),
            (0.004, 0.7),
            (0.95, 0.99, 0.001, 0.5, 2.0),
        ),
        bindings.right_striker_fixture_id: (
            (0.65, 0.006, 0.0001),
            (0.004, 0.7),
            (0.95, 0.99, 0.001, 0.5, 2.0),
        ),
    }
    if (
        scenario.physics.gravity_world_m_s2 != (0.0, 0.0, -9.81)
        or not math.isclose(body.mass_kg, facts.mass_kg, rel_tol=0.0, abs_tol=1e-12)
        or not _same_numbers(body.diagonal_inertia_kg_m2, facts.diagonal_inertia_kg_m2)
        or any(
            not (
                _same_numbers(contacts[entity_id].friction_slide_spin_roll, expected[0])
                and _same_numbers(contacts[entity_id].solref, expected[1])
                and _same_numbers(contacts[entity_id].solimp, expected[2])
            )
            for entity_id, expected in canonical_contacts.items()
        )
        or any(
            spec.damping_per_dof != ((4.0,) if key in expected_joints else (0.0,) * 6)
            or any(value != 0.0 for value in spec.friction_loss_per_dof)
            for key, spec in joints.items()
        )
    ):
        raise ValueError("T5 recipes must retain complete canonical physics")


def _validate_replanning_declarative_delay(scenario: ScenarioSpec) -> None:
    if scenario.action_delay_steps != 1:
        raise ValueError("T5 recipes require exactly one delay tick")


def _validate_replanning_declarative_ownership(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    id_recipe: Mapping[str, object],
) -> None:
    _validate_replanning_recipe(task, id_recipe)
    owned = frozenset(
        {
            ("motion", 0, "translation", "velocity_world_m_s", 1),
            ("events", 0, "effect", "actuator_scale"),
        }
    )
    concrete = _t5_recipe_projection(scenario)
    if not _in_recipe_support(
        concrete,
        id_recipe,
        owned_paths=owned if factor == "motion_parameters" else frozenset(),
    ):
        raise ValueError("T5 non-owning fields must retain complete test-ID recipe support")
    if partition == "ood" and _in_recipe_support(concrete, id_recipe):
        raise ValueError("T5 OOD must leave test-ID support in motion parameters")


def _validate_replanning_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
    id_recipe: Mapping[str, object],
) -> None:
    if task.task_id != "t5_replan" or not isinstance(task.bindings, ReplanningBindings):
        raise ValueError("T5 validation requires ReplanningBindings")
    if partition == "ood" and factor != "motion_parameters":
        raise ValueError("T5 only defines the motion_parameters OOD factor")
    stress = partition == "stress"
    bindings = task.bindings
    fixture_ids = (
        bindings.belt_fixture_id,
        bindings.left_striker_fixture_id,
        bindings.right_striker_fixture_id,
    )
    _validate_replanning_declarative_structure(
        scenario, bindings=bindings, fixture_ids=fixture_ids, catalog=catalog
    )
    _validate_replanning_declarative_motion_and_event(
        scenario, bindings=bindings, factor=factor, stress=stress
    )
    _validate_replanning_declarative_physics(
        scenario,
        bindings=bindings,
        fixture_ids=fixture_ids,
        catalog=catalog,
    )
    _validate_replanning_declarative_delay(scenario)
    _validate_camera_and_lighting(
        scenario,
        factor=None,
        stress=False,
        canonical_light=_T5_CANONICAL_LIGHT,
        name="T5",
    )

    if partition in ("test_id", "ood"):
        _validate_replanning_declarative_ownership(
            task,
            scenario,
            partition=partition,
            factor=factor,
            id_recipe=id_recipe,
        )


def _validate_placement_declarative_structure(
    scenario: ScenarioSpec,
    *,
    payload_id: str,
    goal_id: str,
    expected_assets: tuple[str, str],
    catalog: Mapping[str, _AssetRecord],
) -> None:
    if (
        len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != payload_id
        or len(scenario.fixture_states) != 1
        or scenario.fixture_states[0].instance_id != goal_id
        or (scenario.object_states[0].asset_id, scenario.fixture_states[0].asset_id)
        != expected_assets
        or len(scenario.motion) != 1
        or scenario.motion[0].entity_id != goal_id
        or scenario.events
    ):
        raise ValueError("T2 requires exactly its functional payload, goal and goal motion")
    for asset_id in ("arena.conveyor_v1", *expected_assets):
        if asset_id not in catalog:
            raise ValueError(f"T2 asset reference does not resolve: {asset_id}")


def _validate_placement_declarative_motion(
    scenario: ScenarioSpec, *, is_se3: bool, partition: Partition, factor: str | None, stress: bool
) -> None:
    motion = scenario.motion[0]
    if not isinstance(motion.translation, ConstantVelocityTranslation):
        raise ValueError("T2 requires constant world +Y goal translation")
    vx, forward, vz = motion.translation.velocity_world_m_s
    if vx != 0.0 or vz != 0.0 or forward <= 0.0:
        raise ValueError("T2 translation must be strictly world +Y")
    id_motion = 0.03 <= forward <= 0.06
    if is_se3:
        if not isinstance(
            motion.rotation, ConstantAngularVelocityRotation
        ) or motion.rotation.axis_world != (0.0, 0.0, 1.0):
            raise ValueError("T2-SE3 requires world-Z constant angular velocity")
        speed = abs(motion.rotation.angular_speed_rad_s)
        id_motion = id_motion and (0.0 if partition == "train" else 0.08) <= speed <= 0.25
        if (factor == "motion_parameters" or stress) and speed > 0.40:
            raise ValueError("T2-SE3 yaw exceeds the frozen OOD range")
    elif not isinstance(motion.rotation, FixedRotation):
        raise ValueError("T2-TRANS requires fixed rotation")
    if stress and is_se3:
        goal = scenario.fixture_states[0]
        initial_x, initial_y, _ = goal.position_world_m
        cases = (
            (-0.13, -0.18, 0.03, -0.35, -0.25),
            (-0.08, -0.12, 0.06, 0.35, 0.25),
            (-0.05, -0.08, 0.10, 0.35, 0.40),
            (-0.105, -0.15, 0.045, 0.10, 0.20),
        )
        if not any(
            (
                initial_x,
                initial_y,
                forward,
                cast(ConstantAngularVelocityRotation, motion.rotation).angular_speed_rad_s,
            )
            == (x, y, velocity, omega)
            and _same_numbers(
                goal.quaternion_world_xyzw,
                (0.0, 0.0, math.sin(0.5 * yaw), math.cos(0.5 * yaw)),
            )
            for x, y, velocity, yaw, omega in cases
        ):
            raise ValueError("T2-SE3 stress requires one complete fixed DB0 case")
    elif stress and not is_se3:
        goal = scenario.fixture_states[0]
        initial_x, initial_y, _ = goal.position_world_m
        if (initial_x, initial_y, forward) not in (
            (-0.13, -0.18, 0.03),
            (-0.08, -0.12, 0.06),
            (-0.05, -0.08, 0.10),
            (-0.105, -0.15, 0.045),
        ) or goal.quaternion_world_xyzw != (0.0, 0.0, 0.0, 1.0):
            raise ValueError("T2-TRANS stress requires one complete fixed DB0 case and zero yaw")
    elif factor == "motion_parameters" or stress:
        if not (0.03 <= forward <= 0.06 or 0.07 <= forward <= 0.10):
            raise ValueError("T2 forward speed must remain in its frozen ID or OOD ranges")
    elif not id_motion:
        raise ValueError("T2 non-motion intervention must retain the complete frozen ID motion")


def _validate_placement_declarative_geometry(
    scenario: ScenarioSpec, *, is_se3: bool, factor: str | None, stress: bool
) -> None:
    motion = scenario.motion[0]
    geometry = scenario.geometry
    if not isinstance(geometry, MovingPlacementGeometrySpec):
        raise ValueError("T2 requires MovingPlacementGeometrySpec")
    if geometry.goal_window_exit_y_m != 0.30:
        raise ValueError("T2 goal window exit is fixed at world Y=.30")
    if (
        not stress
        and factor != "geometry"
        and geometry.goal_planar_clearance_m != (0.004 if is_se3 else 0.008)
    ):
        raise ValueError("T2 non-geometry intervention must retain its frozen opening clearance")
    goal = scenario.fixture_states[0]
    if goal.position_world_m[2] != geometry.goal_bottom_center_z_m:
        raise ValueError("T2 goal pose and bottom-center height must agree")
    if goal.quaternion_world_xyzw[:2] != (0.0, 0.0):
        raise ValueError("T2 goal rail requires planar initial yaw")
    _validate_motion_initial_pose(
        motion,
        initial_position_world_m=goal.position_world_m,
        initial_quaternion_world_xyzw=goal.quaternion_world_xyzw,
    )


def _validate_placement_declarative_physics(
    scenario: ScenarioSpec,
    *,
    payload_id: str,
    goal_id: str,
    expected_assets: tuple[str, str],
    catalog: Mapping[str, _AssetRecord],
    factor: str | None,
    stress: bool,
) -> None:
    bodies = {item.entity_id: item for item in scenario.physics.bodies}
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    if set(bodies) != {payload_id, goal_id} or set(contacts) != {payload_id, goal_id}:
        raise ValueError("T2 physics requires each bound payload/goal entity exactly once")
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={
            (payload_id, f"{payload_id}_joint0"): 6,
            (goal_id, f"{goal_id}_travel"): 1,
            (goal_id, f"{goal_id}_x"): 1,
            (goal_id, f"{goal_id}_z"): 1,
            (goal_id, f"{goal_id}_yaw"): 1,
        },
        name="T2 joint physics",
    )
    if not stress and not _joint_physics_is_canonical(scenario.physics.joints):
        raise ValueError("T2 non-stress recipes must retain canonical joint physics")
    if not stress and factor != "physics":
        if scenario.physics.gravity_world_m_s2 != (0.0, 0.0, -9.81):
            raise ValueError("T2 non-physics intervention must retain canonical gravity")
        for entity_id, asset_id in zip((payload_id, goal_id), expected_assets, strict=True):
            facts = _compiled_object_asset_facts(catalog[asset_id])
            body, contact = bodies[entity_id], contacts[entity_id]
            if not (
                math.isclose(body.mass_kg, facts.mass_kg, rel_tol=0.0, abs_tol=1e-12)
                and _same_numbers(body.diagonal_inertia_kg_m2, facts.diagonal_inertia_kg_m2)
                and _same_numbers(contact.friction_slide_spin_roll, facts.friction)
                and _same_numbers(contact.solref, facts.solref)
                and _same_numbers(contact.solimp, facts.solimp)
            ):
                raise ValueError(
                    "T2 non-physics intervention must retain the complete canonical physics block"
                )
        if not _joint_physics_is_canonical(scenario.physics.joints):
            raise ValueError("T2 non-physics intervention must retain canonical joint physics")


def _validate_placement_declarative_delay(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    if factor == "action_delay":
        if scenario.action_delay_steps not in (1, 2):
            raise ValueError("T2 action-delay OOD requires 1 or 2 ticks")
    elif stress:
        if scenario.action_delay_steps != 0:
            raise ValueError("T2 DB0 stress requires zero action delay")
    elif scenario.action_delay_steps != 0:
        raise ValueError("T2 non-delay intervention must have zero delay")


def _validate_placement_declarative_ownership(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    id_recipe: Mapping[str, object],
) -> None:
    _validate_placement_recipe(task, id_recipe)
    owned: dict[str, frozenset[tuple[str | int, ...]]] = {
        "spatial": frozenset(
            {
                ("robot_initial_state",),
                ("object_states", 0, "position_world_m"),
                ("object_states", 0, "quaternion_world_xyzw"),
                ("fixture_states", 0, "position_world_m"),
                ("fixture_states", 0, "quaternion_world_xyzw"),
            }
        ),
        "geometry": frozenset({("geometry",), ("fixture_states", 0, "position_world_m", 2)}),
        "motion_parameters": frozenset(
            {
                ("motion",),
                ("object_states", 0, "linear_velocity_world_m_s"),
                ("object_states", 0, "angular_velocity_world_rad_s"),
            }
        ),
        "physics": frozenset({("physics",)}),
        "appearance": frozenset({("lighting",)}),
        "camera": frozenset({("cameras",)}),
        "action_delay": frozenset({("action_delay",)}),
    }
    concrete = scenario_to_dict(scenario)
    steps = concrete.pop("action_delay_steps")
    concrete["action_delay"] = {
        "enabled": scenario.action_delay_steps > 0,
        "delay_steps": steps,
    }
    if not _in_recipe_support(
        concrete, id_recipe, owned_paths=owned.get(factor or "", frozenset())
    ):
        raise ValueError("T2 non-owning factor fields must retain complete test-ID recipe support")
    if partition == "ood" and _in_recipe_support(concrete, id_recipe):
        raise ValueError("T2 OOD must leave test-ID support in its declared factor")


def _validate_placement_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
    id_recipe: Mapping[str, object],
) -> None:
    if task.family != "moving_placement" or not isinstance(task.bindings, MovingPlacementBindings):
        raise ValueError("T2 validation requires MovingPlacementBindings")
    factors = {
        "spatial",
        "geometry",
        "motion_parameters",
        "physics",
        "appearance",
        "camera",
        "action_delay",
    }
    if partition == "ood" and factor not in factors:
        raise ValueError("T2 recipe uses an inapplicable OOD factor")
    stress = partition == "stress"
    payload_id, goal_id = task.bindings.payload_object_id, task.bindings.goal_fixture_id
    is_se3 = task.variant == "se3"
    expected_assets = (
        ("obj.asym_t_t2_handle_v1", "fixture.t_slot_v1")
        if is_se3
        else ("obj.cuboid_t2_handle_v1", "fixture.open_tray_v1")
    )
    _validate_placement_declarative_structure(
        scenario,
        payload_id=payload_id,
        goal_id=goal_id,
        expected_assets=expected_assets,
        catalog=catalog,
    )
    _validate_placement_declarative_motion(
        scenario, is_se3=is_se3, partition=partition, factor=factor, stress=stress
    )
    nominal_stress = stress and not is_se3
    _validate_placement_declarative_geometry(
        scenario, is_se3=is_se3, factor=factor, stress=nominal_stress
    )
    _validate_placement_declarative_physics(
        scenario,
        payload_id=payload_id,
        goal_id=goal_id,
        expected_assets=expected_assets,
        catalog=catalog,
        factor=factor,
        stress=nominal_stress,
    )
    _validate_camera_and_lighting(
        scenario,
        factor=factor,
        stress=nominal_stress,
        canonical_light={**_GRASP_CANONICAL_LIGHT, "light_id": "conveyor_key"},
        name="T2",
    )
    _validate_placement_declarative_delay(scenario, factor=factor, stress=stress)

    # YAML owns preparation and finite sampling supports. Only the selected factor's
    # existing fields may leave test-ID support; no OOD YAML bound becomes a new task limit.
    if not stress:
        _validate_placement_declarative_ownership(
            task,
            scenario,
            partition=partition,
            factor=factor,
            id_recipe=id_recipe,
        )


def _t3_phase_from_quaternion(quaternion_xyzw: Sequence[float]) -> float:
    quaternion = np.asarray(quaternion_xyzw, dtype=np.float64)
    if quaternion.shape != (4,) or not np.isfinite(quaternion).all():
        raise ValueError("T3 phase requires a finite quaternion")
    for boundary in _T3_ID_PHASE_RANGE_RAD:
        exact = np.asarray((math.sin(0.5 * boundary), 0.0, 0.0, math.cos(0.5 * boundary)))
        if np.array_equal(quaternion, exact) or np.array_equal(quaternion, -exact):
            return boundary
    quaternion /= np.linalg.norm(quaternion)
    if quaternion[3] < 0.0:
        quaternion *= -1.0
    if not np.allclose(quaternion[1:3], 0.0, rtol=0.0, atol=1e-12):
        raise ValueError("T3 phase must be a world-X rotation")
    phase = 2.0 * math.atan2(float(quaternion[0]), float(quaternion[3]))
    return phase


def _t3_recipe_projection(scenario: ScenarioSpec) -> dict[str, object]:
    concrete = scenario_to_dict(scenario)
    delay = concrete.pop("action_delay_steps")
    concrete["action_delay"] = {"enabled": scenario.action_delay_steps > 0, "delay_steps": delay}
    fixtures = cast(list[dict[str, object]], concrete["fixture_states"])
    phase = _t3_phase_from_quaternion(scenario.fixture_states[0].quaternion_world_xyzw)
    fixtures[0]["quaternion_world_xyzw"] = {"phase_x_rad": phase}
    return concrete


def _validate_rotating_declarative_entities_and_phase(
    scenario: ScenarioSpec,
    *,
    bindings: RotatingInteractionBindings,
    expected_fixture_ids: tuple[str, ...],
    expected_asset_ids: tuple[str, ...],
    factor: str | None,
    stress: bool,
    catalog: Mapping[str, _AssetRecord],
) -> None:
    if (
        len(scenario.object_states) != 1
        or scenario.object_states[0].instance_id != bindings.wand_object_id
        or scenario.object_states[0].asset_id != "obj.wand_loop_v1"
        or tuple(item.instance_id for item in scenario.fixture_states) != expected_fixture_ids
        or tuple(item.asset_id for item in scenario.fixture_states) != expected_asset_ids
        or len(scenario.motion) != 1
        or scenario.motion[0].entity_id != bindings.wire_fixture_id
        or scenario.events
    ):
        raise ValueError("T3 requires exactly its functional wand, wire and optional cradle")
    for asset_id in ("arena.rotating_wire_v1", "obj.wand_loop_v1", *expected_asset_ids):
        if asset_id not in catalog:
            raise ValueError(f"T3 asset reference does not resolve: {asset_id}")

    wire = scenario.fixture_states[0]
    wire_phase = _t3_phase_from_quaternion(wire.quaternion_world_xyzw)
    in_id_phase = _T3_ID_PHASE_RANGE_RAD[0] <= wire_phase <= _T3_ID_PHASE_RANGE_RAD[1]
    if factor == "spatial":
        if in_id_phase:
            raise ValueError("T3 spatial OOD must leave the frozen ID phase range")
    elif not stress and not in_id_phase:
        raise ValueError("T3 non-spatial intervention must retain the frozen ID phase range")


def _validate_rotating_declarative_motion(scenario: ScenarioSpec, *, stress: bool) -> None:
    wire = scenario.fixture_states[0]
    motion = scenario.motion[0]
    if not isinstance(motion.translation, FixedTranslation) or not isinstance(
        motion.rotation, ConstantAngularVelocityRotation
    ):
        raise ValueError("T3 requires fixed translation and constant angular velocity")
    if motion.rotation.axis_world != (1.0, 0.0, 0.0):
        raise ValueError("T3 wire must rotate about world X")
    speed = motion.rotation.angular_speed_rad_s
    id_speed = any(
        math.isclose(speed, value, rel_tol=0.0, abs_tol=1e-12) for value in _T3_ID_SPEEDS_RAD_S
    )
    if stress:
        phase = _t3_phase_from_quaternion(wire.quaternion_world_xyzw)
        cases = ((-0.25, -2.5), (0.35, -7.5), (0.70, 25.0), (0.05, -5.0))
        if not any(
            math.isclose(phase, expected_phase, rel_tol=0.0, abs_tol=1e-12)
            and math.isclose(speed, math.radians(speed_deg_s), rel_tol=0.0, abs_tol=1e-12)
            for expected_phase, speed_deg_s in cases
        ):
            raise ValueError(
                "T3 stress must use a paired DB0 factor or nominal cross-seed condition"
            )
    elif not id_speed:
        raise ValueError("T3 non-stress motion must use the DB0 2.5-7.5 deg/s half-degree grid")
    _validate_motion_initial_pose(
        motion,
        initial_position_world_m=wire.position_world_m,
        initial_quaternion_world_xyzw=wire.quaternion_world_xyzw,
    )


def _validate_rotating_declarative_geometry(scenario: ScenarioSpec) -> None:
    wire = scenario.fixture_states[0]
    geometry = scenario.geometry
    if not isinstance(geometry, RotatingInteractionGeometrySpec):
        raise ValueError("T3 requires RotatingInteractionGeometrySpec")
    if (
        geometry.frame_center_world_m != wire.position_world_m
        or geometry.rotation_axis_world != (1.0, 0.0, 0.0)
        or len(geometry.wire_path_points_frame_m) < 2
    ):
        raise ValueError("T3 geometry must resolve its finite world-X wire fixture")


def _validate_rotating_declarative_physics(
    scenario: ScenarioSpec,
    *,
    bindings: RotatingInteractionBindings,
    expected_fixture_ids: tuple[str, ...],
    expected_asset_ids: tuple[str, ...],
    factor: str | None,
    stress: bool,
    catalog: Mapping[str, _AssetRecord],
) -> None:
    expected_entities = {bindings.wand_object_id, *expected_fixture_ids}
    bodies = {item.entity_id: item for item in scenario.physics.bodies}
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    if set(bodies) != expected_entities or set(contacts) != expected_entities:
        raise ValueError("T3 physics must bind each wand/wire/cradle entity exactly once")
    wire_id = bindings.wire_fixture_id
    _validate_joint_physics_specs(
        scenario.physics.joints,
        allowed_dofs={
            (bindings.wand_object_id, f"{bindings.wand_object_id}_joint0"): 6,
            (wire_id, f"{wire_id}_hinge"): 1,
        },
        name="T3 joint physics",
    )
    if not stress and not _joint_physics_is_canonical(scenario.physics.joints):
        raise ValueError("T3 non-stress recipes must retain canonical joint physics")
    if not stress and factor != "physics":
        if scenario.physics.gravity_world_m_s2 != (0.0, 0.0, -9.81):
            raise ValueError("T3 non-physics intervention must retain canonical gravity")
        for entity_id, asset_id in zip(
            (bindings.wand_object_id, *expected_fixture_ids),
            ("obj.wand_loop_v1", *expected_asset_ids),
            strict=True,
        ):
            facts = _compiled_object_asset_facts(catalog[asset_id])
            body, contact = bodies[entity_id], contacts[entity_id]
            if not (
                math.isclose(body.mass_kg, facts.mass_kg, rel_tol=0.0, abs_tol=1e-12)
                and _same_numbers(body.diagonal_inertia_kg_m2, facts.diagonal_inertia_kg_m2)
                and _same_numbers(contact.friction_slide_spin_roll, facts.friction)
                and _same_numbers(contact.solref, facts.solref)
                and _same_numbers(contact.solimp, facts.solimp)
            ):
                raise ValueError(
                    "T3 non-physics intervention must retain the complete canonical physics block"
                )
        if not _joint_physics_is_canonical(scenario.physics.joints):
            raise ValueError("T3 non-physics intervention must retain canonical joint physics")


def _validate_rotating_declarative_delay(
    scenario: ScenarioSpec, *, factor: str | None, stress: bool
) -> None:
    if factor == "action_delay":
        if scenario.action_delay_steps not in (1, 2):
            raise ValueError("T3 action-delay OOD requires one or two ticks")
    elif stress:
        if scenario.action_delay_steps != 0:
            raise ValueError("T3 DB0 stress conditions require zero action delay")
    elif scenario.action_delay_steps != 0:
        raise ValueError("T3 non-delay intervention must have zero delay")


def _validate_rotating_declarative_ownership(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    id_recipe: Mapping[str, object],
) -> None:
    _validate_rotating_recipe(task, id_recipe)
    owned: dict[str, frozenset[tuple[str | int, ...]]] = {
        "spatial": frozenset(
            {
                ("object_states", 0, "quaternion_world_xyzw"),
                ("fixture_states", 0, "quaternion_world_xyzw"),
            }
        ),
        "geometry": frozenset({("geometry",)}),
        "physics": frozenset({("physics",)}),
        "appearance": frozenset({("lighting",)}),
        "camera": frozenset({("cameras",)}),
        "action_delay": frozenset({("action_delay",)}),
    }
    concrete = _t3_recipe_projection(scenario)
    owned_paths = owned.get(factor or "", frozenset())
    if not _in_recipe_support(concrete, id_recipe, owned_paths=owned_paths):
        raise ValueError("T3 non-owning factor fields must retain complete test-ID support")
    if partition == "ood" and _in_recipe_support(concrete, id_recipe):
        raise ValueError("T3 OOD must leave test-ID support in its declared factor")


def _validate_rotating_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    catalog: Mapping[str, _AssetRecord],
    id_recipe: Mapping[str, object],
) -> None:
    if task.family != "rotating_interaction" or not isinstance(
        task.bindings, RotatingInteractionBindings
    ):
        raise ValueError("T3 validation requires RotatingInteractionBindings")
    factors = {"spatial", "geometry", "physics", "appearance", "camera", "action_delay"}
    if partition == "ood" and factor not in factors:
        raise ValueError("T3 recipe uses an inapplicable OOD factor")
    stress = partition == "stress"
    bindings = task.bindings
    full = task.variant == "full"
    expected_fixture_ids = (bindings.wire_fixture_id, *bindings.cradle_fixture_ids)
    expected_asset_ids = (
        "fixture.rotating_wire_v1",
        *(("fixture.wand_cradle_v1",) if full else ()),
    )
    _validate_rotating_declarative_entities_and_phase(
        scenario,
        bindings=bindings,
        expected_fixture_ids=expected_fixture_ids,
        expected_asset_ids=expected_asset_ids,
        factor=factor,
        stress=stress,
        catalog=catalog,
    )
    _validate_rotating_declarative_motion(scenario, stress=stress)
    _validate_rotating_declarative_geometry(scenario)
    _validate_rotating_declarative_physics(
        scenario,
        bindings=bindings,
        expected_fixture_ids=expected_fixture_ids,
        expected_asset_ids=expected_asset_ids,
        factor=factor,
        stress=stress,
        catalog=catalog,
    )
    _validate_camera_and_lighting(
        scenario,
        factor=factor,
        stress=stress,
        canonical_light={**_GRASP_CANONICAL_LIGHT, "light_id": "rotating_wire_key"},
        name="T3",
    )
    _validate_rotating_declarative_delay(scenario, factor=factor, stress=stress)

    if not stress:
        _validate_rotating_declarative_ownership(
            task,
            scenario,
            partition=partition,
            factor=factor,
            id_recipe=id_recipe,
        )


def _validate_joint_physics_specs(
    specs: Sequence[JointPhysicsSpec],
    *,
    allowed_dofs: Mapping[tuple[str, str], int],
    required: frozenset[tuple[str, str]] = frozenset(),
    name: str,
) -> None:
    keys = {(spec.entity_id, spec.joint_name) for spec in specs}
    if not keys.issubset(allowed_dofs) or not required.issubset(keys):
        raise ValueError(f"{name} contains an invalid or missing entity/joint binding")
    for spec in specs:
        dof_count = allowed_dofs[(spec.entity_id, spec.joint_name)]
        if len(spec.damping_per_dof) != dof_count or len(spec.friction_loss_per_dof) != dof_count:
            raise ValueError(
                f"{name} for {spec.joint_name!r} must contain exactly {dof_count} per-DOF values"
            )


def _joint_physics_is_canonical(specs: Sequence[JointPhysicsSpec]) -> bool:
    return all(
        all(value == 0.0 for value in (*spec.damping_per_dof, *spec.friction_loss_per_dof))
        for spec in specs
    )


def _selected_joint_physics_is_canonical(
    specs: Sequence[JointPhysicsSpec], keys: frozenset[tuple[str, str]]
) -> bool:
    return _joint_physics_is_canonical(
        tuple(spec for spec in specs if (spec.entity_id, spec.joint_name) in keys)
    )


def _validate_declarative_scenario(
    task: TaskSpec,
    scenario: ScenarioSpec,
    *,
    partition: Partition,
    factor: str | None,
    document: Mapping[str, object],
    recipe_name: str,
) -> None:
    if task.family in (
        "replanning",
        "free_dynamics_interception",
        "moving_placement",
        "rotating_interaction",
    ):
        catalog = _load_asset_catalog(Path(__file__).resolve().parents[3] / "assets/catalog.yaml")
        if task.family == "replanning":
            validate_with_recipe = _validate_replanning_declarative_scenario
        elif task.family == "free_dynamics_interception":
            validate_with_recipe = _validate_free_dynamics_declarative_scenario
        elif task.family == "moving_placement":
            validate_with_recipe = _validate_placement_declarative_scenario
        else:
            validate_with_recipe = _validate_rotating_declarative_scenario
        validate_with_recipe(
            task,
            scenario,
            partition=partition,
            factor=factor,
            catalog=catalog,
            id_recipe=_select_recipe(
                document,
                partition=partition if partition in ("train", "validation") else "test_id",
                factor=None,
                recipe_name=recipe_name,
            ),
        )
    elif task.family == "grasp" or task.task_id in ("t1_belt", "t1_xyz", "t1_so3", "t1_occ"):
        catalog = _load_asset_catalog(Path(__file__).resolve().parents[3] / "assets/catalog.yaml")
        if task.family == "grasp":
            validate = _validate_grasp_declarative_scenario
        elif task.task_id in ("t1_belt", "t1_occ"):
            validate = _validate_surface_declarative_scenario
        else:
            validate = _validate_matched_declarative_scenario
        validate(task, scenario, partition=partition, factor=factor, catalog=catalog)
