"""Structured rejection facts shared by reset and native oracle checks."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Literal

from se3_wam_benchmark.envs.components.occlusion import _OcclusionVisibilityState


class _CaptureProposalRejected(ValueError):
    def __init__(
        self,
        stage: Literal["reset", "visibility", "oracle"],
        failure_code: str,
        *,
        task_id: str,
        terminal_time_s: float | None = None,
        events: Mapping[str, float] | None = None,
        visibility_state: _OcclusionVisibilityState | None = None,
    ) -> None:
        self.stage = stage
        self.failure_code = failure_code
        self.terminal_time_s = terminal_time_s
        self.events = dict(events) if events is not None else {}
        self.visibility_state = visibility_state
        names = {
            "grasp": "Grasp",
            "t1_belt": "T1-Belt",
            "t1_xyz": "T1-XYZ",
            "t1_so3": "T1-SO3",
            "t1_occ": "T1-OCC",
            "t2_trans": "T2-TRANS",
            "t2_se3": "T2-SE3",
            "t3_phase": "T3-Phase",
            "t3_full": "T3-Full",
            "t4_sphere": "T4-Sphere",
            "t4_sphere_tabletop": "T4-Sphere-Tabletop",
            "t4_slider": "T4-Slider",
            "t4_can": "T4-Can",
            "t5_replan": "T5-Replan",
        }
        if task_id not in names:
            raise ValueError("proposal rejection requires an implemented task")
        super().__init__(f"{names[task_id]} proposal rejected: {stage} {failure_code}")
