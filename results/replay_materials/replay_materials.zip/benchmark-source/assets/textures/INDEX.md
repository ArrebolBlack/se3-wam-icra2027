# Scene textures

- [`red-wood.png`](red-wood.png): Robosuite 1.4.0 `models/assets/textures/red-wood.png`, used by the restored DB0 wand, P0/T1/T2 cuboids and T4 objects; read when checking scene appearance.
