# Benchmark assets

[catalog.yaml](catalog.yaml) is the asset identity and symmetry registry. The assets
below are original MJCF rewrites in this repository; they contain primitive
collision geometry and original plain materials, not copied meshes or textures.

| Asset | Source of geometry and when to read |
| --- | --- |
| [cuboid_grasp_v1.xml](objects/cuboid_grasp_v1.xml) | Grasp ID cuboid. Dimensions preserved from revision `74bb73f1`, `packages/runtime/src/se3wam_benchmark_runtime/configs/p0_grasp_v0_1.yaml`. |
| [bottle_v1.xml](objects/bottle_v1.xml) | Grasp object OOD bottle. Coaxial body/neck dimensions are specified in the frozen architecture, section 11.7.7. |
| [rod_v1.xml](objects/rod_v1.xml) | Grasp object OOD rod. Radius and half-length are specified in the frozen architecture, section 11.7.7. |
| [asym_t_t1_v1.xml](objects/asym_t_t1_v1.xml) | Asymmetric T object. Bar/stem geometry preserved from revision `74bb73f1`, `packages/runtime/src/se3wam_benchmark_runtime/configs/t1_xyz_v0_16.yaml`. |
| [conveyor_v1.xml](arenas/conveyor_v1.xml) | T1 conveyor support; half-size `[.28,.40,.020] m`, top `.8 m`, contact friction from revision `74bb73f1`, `packages/runtime/src/se3wam_benchmark_runtime/configs/t1_belt_v0_2.yaml`. Native surface velocity is supplied explicitly by each ScenarioSpec before compilation. |
| [cube_44_v1.xml](objects/cube_44_v1.xml) | T1 44 mm cube, centered object frame and 700 kg/m³ collision density from the same T1-Belt configuration. Its 24 proper-rotation symmetries are registered in the catalog. |
| [occlusion_canopy_v1.xml](arenas/occlusion_canopy_v1.xml) | Original static T1-OCC panel, half-size `[.10,.045,.015] m`. These implementation dimensions are not frozen task thresholds; its collision-enabled geometry and explicit placement are checked with the real camera and simulator. |
| [cuboid_t2_handle_v1.xml](objects/cuboid_t2_handle_v1.xml) | Original T2-TRANS payload: a centered rectangular body and two symmetric, physical handles. The complete collision solid has the frozen D2 symmetry. |
| [asym_t_t2_handle_v1.xml](objects/asym_t_t2_handle_v1.xml) | Original T2-SE3 payload with a 72 mm bar and a real top handle. The historical T primitives informed the shape, not a preserved geometry; its full collision solid allows physical Panda release at the frozen 4 mm slot clearance. |
| [open_tray_v1.xml](arenas/open_tray_v1.xml) and [t_slot_v1.xml](arenas/t_slot_v1.xml) | Original moving receptacles enclosing the full corresponding payload, including every handle. The Family derives each opening from the actual payload footprint and ScenarioSpec clearance; XML owns fixed wall/floor construction. |
| [rotating_wire_v1.xml](arenas/rotating_wire_v1.xml), [rotating_wire_fixture_v1.xml](arenas/rotating_wire_fixture_v1.xml), [wand_loop_v1.xml](objects/wand_loop_v1.xml), and [wand_cradle_v1.xml](arenas/wand_cradle_v1.xml) | Original T3 support, finite capsule wire, complete collision loop-and-handle wand, and gravity cradle. The Family owns the native hinge and inactive weld used by the frozen Phase and Full preparation protocols. |
| [unsupported_ramp_v1.xml](arenas/unsupported_ramp_v1.xml) and [supported_ramp_v1.xml](arenas/supported_ramp_v1.xml) | Original T4 composite arenas. Each contains an independently bound physical ramp, finite sliding release gate, and safety tray or tabletop; ScenarioSpec owns their concrete poses, contact parameters, and gate joint values. |
| [sphere_r030_v1.xml](objects/sphere_r030_v1.xml), [slider_v1.xml](objects/slider_v1.xml), and [can_v1.xml](objects/can_v1.xml) | T4 functional targets. The sphere radius, slider half-size, and can radius/half-length follow the frozen task matrix; their primitive MJCF geometry is an original repository implementation. |
| [replanning_conveyor_v1.xml](arenas/replanning_conveyor_v1.xml) and [keyed_puck_v1.xml](objects/keyed_puck_v1.xml) | Original T5 composite conveyor with two finite native slide strikers and the asymmetric keyed puck. ScenarioSpec selects one pulse branch while both compiled strikers remain present; the puck frame is its compiled center of mass. |

The [frozen architecture](https://www.notion.so/3c17e1a21323800c941ed3227eeb24aa)
owns the task/asset requirements. Historical sources above provide dimensions only; their
retired class hierarchy and runtime are not retained. Cuboid and rod object frames are at
their symmetry centers; the T1 asymmetric T frame is at its center of mass. Its collision
and visual geoms share a rigid coordinate translation; shape, mass, and principal inertia
are unchanged. Support sites expose the corresponding offsets. The T radius helper is
Robosuite metadata enclosing the compiled collision corners, not a geometric marker.
The T2 asymmetric payload retains a bar-centered body frame; its true COM and principal
inertial frame are read from the compiled model, independently of its body pose.
Both T2 floors have a fixed native 1 mm contact margin. This permits positive geometric
floor clearance under compliant contact without allowing collision penetration in the
containment predicate. The explicit canonical rail heights leave 2 mm between each floor's
collision bottom and the conveyor support. Openings and containment include all payload
collision geoms, including the handles; no grasp-only geometry is excluded.

The conveyor's canonical light retains Robosuite 1.5.2 TableArena's fixed native
directional type and disabled shadows. Scenario LightSpec owns the explicit position,
direction and illumination values. The canopy has no joint or motion driver; its concrete
pose, compiled collision clearance, and actual visible raster are checked separately.

These assets follow the repository's [LicenseRef-Research-Only status](../LICENSE).
The complete project-owner-approved legal text is still pending; the root license is a
factual placeholder, not release or redistribution clearance. No additional license grant
is asserted here.
