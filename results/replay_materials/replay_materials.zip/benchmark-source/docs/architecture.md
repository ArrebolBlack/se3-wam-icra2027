# Architecture

The repository contains one installable package, `se3_wam_benchmark`. Public imports go
through `se3_wam_benchmark.api`; internal modules import the real owner and never the
facade. Scenario records are dependency leaves. Only `integrations/se3_wam.py` may depend
on `se3_wam.api`, and the model package never depends on this benchmark.

B1 implements contracts and parsing. B2 owns Family Envs, components, sensors, action
execution, and real scenario generation. B3 owns supervision, rollout, HDF5 recording,
metrics, and Suite execution. Generation calls the environment factory; environments
depend on concrete scenario records and never import the generator.

Scenario generation stays within the existing `scenarios` package. Read the following
owners when changing a generation stage:

| Module | Responsibility |
| --- | --- |
| `generator.py` | Public entry point; recipe selection, one seeded RNG, proposal, validation and export orchestration. |
| `_recipes.py` | Recipe shape and family recipe checks, sampling and deterministic compilation into concrete records. Atomic correlated sampling and its draw order stay together. |
| `_validation.py` | Concrete scenario constraints, compiled asset facts and ID/OOD ownership checks against the declared recipe support. |
| `_feasibility.py` | Real environment construction, reset checks, oracle solvability and export; closes every environment it creates. |
| `_native_oracle.py` | Current-state controllers, factory binding and per-step visibility updates; shared by feasibility and formal recording. |
| `_family_parameters.py` | Existing fixed family parameters shared by recipe compilation, concrete validation and native control. |
| `_rejection.py` | Existing structured proposal rejection used by reset and oracle checks. |

The generator calls recipes, concrete validation and feasibility in that order.
Concrete validation can read recipe constraints; recipes never import validation or
feasibility. Feasibility calls the native oracle. The oracle imports neither the
generator nor recipe/validation code, and cannot construct or replace an environment.
Shared parameters and rejection records do not import these consumers. None of these
private modules extends the public API or changes the frozen scenario semantics.

For offline demonstration recording, `evaluation/rollout.py` calls
`scenarios/_native_oracle.py` after resetting its own environment. The factory binds
the same current-state controllers used by scenario feasibility checks. Oracle actions
and post-step visibility updates run inside the existing formal rollout; the teacher
cannot replace the environment, controller, physics, termination rules, or recorder.
This private dependency does not extend `BenchmarkPolicy`, policy-visible observations,
or the evaluation API.
