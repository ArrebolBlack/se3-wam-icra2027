# Data

The formal recorder writes one self-contained HDF5 file per successful or failed episode.
It uses the frozen `metadata/`, `policy/`, `action/`, and `supervision/` groups, `N+1`
frames for `N` transitions, and adjacent-frame global 2D optical-flow supervision.
`se3-wam-record` selects a deterministic Manifest shard and delegates each episode to the
single rollout and recorder owners.

An offline privileged teacher is selected explicitly with:

```sh
se3-wam-record --manifest manifests/v1/train.jsonl --policy native-oracle --output episodes
```

The output directory must already exist. `native-oracle` is a recording-only choice;
ordinary policies continue to use `module:factory`. The teacher reads the current native
state and issues bounded `BenchmarkAction` commands through the same controller and
failure state machine. It uses the generator's private oracle factory and the existing
`EpisodeRecorder`, including issued/applied ticks and all frozen supervision fields.
Native failures remain failed episodes; recording does not turn them into demonstrations
or substitute another scenario. The HDF5 schema stays at version 1.

Replay uses the stored issued actions, the stored concrete scenario, and the same formal
rollout. Validate metadata and non-RGB arrays exactly; report RGB differences separately
because raster rounding can depend on the rendering backend. Feasibility acceptance
alone is not evidence that an HDF5 episode has been recorded and replayed successfully.
