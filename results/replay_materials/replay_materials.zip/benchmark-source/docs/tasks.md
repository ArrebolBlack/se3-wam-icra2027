# Tasks

`configs/tasks/` is the declaration source for 14 tasks. `tasks/registry.py` is the sole
task-to-family mapping owner. The frozen mapping contains one grasp task, four driven
interception tasks, two moving-placement tasks, two rotating-interaction tasks, four
free-dynamics interception tasks, and one replanning task.

`envs/families/grasp.py` implements the real Panda/TableArena Grasp scene, continuously
driven free target, and the single physics-rate capture/outcome state machine. Its
registered factory route consumes only a concrete ScenarioSpec and exports the reset
state verified against the compiled simulator.

`envs/families/driven_interception.py` implements the registered `t1_belt` route using
the catalog conveyor and 44 mm cube. MuJoCo's compiled geom-local surface velocity
drives the free target through contact, without runtime target pose/velocity or external
force writes. The surface remains active through contact, lift, dwell, and the remaining
native substeps after the first terminal fact.

The same Family Env implements `t1_xyz` and `t1_so3` on TableArena with the asymmetric
T's center-of-mass frame. Both use one continuous bounded planar-wrench mechanism in
`envs/components/motion.py`; the Family owns capture and terminal facts. Their same-seed
reference COM trajectory and TTC match exactly, while only yaw evolution differs.
Different yaw/contact dynamics need not yield identical measured trajectories. The
500 Hz tracking tests report reference error and actual crossings separately. T1 resolves
the declared target joints, applies their per-DOF damping/friction loss, and validates
the compiled values against the concrete ScenarioSpec.

`t1_occ` uses the same surface-driven cube with a static, collision-enabled canopy.
`envs/components/occlusion.py` measures its distance from the complete compiled target
collision sweep defined by the frozen capture corridor and minimum lift, without using
the oracle's private lift target. Actual robot/target-canopy contacts feed the Family's
`unsafe_contact` failure. Other ordinary contacts do not introduce new terminal rules.
Active/parked comparisons retain identical physical inputs apart from canopy placement.

`envs/families/moving_placement.py` implements T2-TRANS/SE3 with native rail/yaw joints
for the moving goal and a free payload. Reset applies and reads back the concrete preparation
input, including body-origin world twist, then runs exactly 20 hidden native control ticks
to establish stable opposing fingerpad pregrasp. The resulting qpos/qvel are retained while
the scored clock, observables, action representation latch and delay queue start afresh at
tick zero. Export represents the verified preparation input, **not** a scored-t0 snapshot.
Repeat reset and manifest replay reapply that input and repeat the same preparation; they
do not settle an already-settled snapshot. Native contact, complete collision containment,
physical release, COM-relative motion, rim impulse and consecutive hold/dwell drive the
Family's sole success and first-terminal facts. T2 applies and reads back the declared
entity joint damping/friction loss, body/contact physics, and gravity.

`envs/families/rotating_interaction.py` implements T3-Phase/Full with a native world-X
hinge motor, finite capsule wire, complete collision wand and gravity cradle. Phase starts
the scored episode after real bilateral pregrasp and a current-pose native weld. Full starts
from real cradle support without pregrasp or attachment, requires 0.05 s of bilateral hold,
then activates the same releasable weld. Activation and release preserve qpos/qvel and
body pose/twist exactly. Native contact impulse, penetration, finite-path progress and
first-terminal facts remain owned by the Family; the wire motor continues through the
remaining native substeps. Export records the verified concrete preparation input, while
repeat reset and manifest replay repeat the prescribed preparation rather than serializing
a scored-state snapshot.

`envs/families/free_dynamics_interception.py` implements the four T4 release-gate routes
with native free targets, finite-force gate retraction and unsupported or supported ramp
contact. Reset performs 12 hidden control ticks, verifies native ramp support, preserves the
settled pose, sets the scored target twist to zero and restarts the scored clock before the
single tick-zero release event. Export records the verified preparation input rather than a
scored-state snapshot. Native per-physics-state contact impulse, the eligibility facts at
the first physical opposing bilateral contact, ramp exit, target support, can barrel topology and consecutive capture
counters own the sole success and first-terminal facts; no oracle writes target state.

`envs/families/replanning.py` implements T5 with one native surface-driven free keyed puck
and two always-present finite slide strikers. A single state-trigger event selects one pulse;
the unselected striker remains at rest. The Family owns impact grouping, outgoing-twist
validation, post-impact robot-contact ordering, oriented bilateral capture and all first-terminal
facts at 500 Hz. Public proposal validation runs both event branches from the same verified
physical reset and requires distinct outgoing SE(3) states and successful capture before the
shared horizon. Neither the event branch nor future trigger state enters policy observation.

`scenarios/generator.py` checks Grasp and T1--T5 proposals declaratively, then validates a real
reset and target visibility before running a deterministic privileged geometric oracle
through the same BenchmarkAction/controller path. An unsolved proposal is rejected
without resampling and retains structured reset/visibility/oracle rejection facts. OCC
also checks the full 20 Hz initial-visible, hidden, and reappearance sequence using the
live agentview raster and an isolated target silhouette. This is proposal validation,
not another Env success predicate. Recipes may be
loaded from another location; canonical assets always belong to this repository.

The XYZ/SO3 sampler draws law parameters in a fixed order before other interventions,
then atomically compiles the common initial COM and motion center. Four complete
action/view recipes preserve physical pairing. Tests compare every concrete block to
ensure that a non-motion OOD intervention does not also change the SO3 yaw draw.
The finite XYZ/SO3 sampling ranges belong to their recipe YAMLs. Declarative validation
enforces frozen ID bounds, factor ownership, and physical consistency; it does not promote
the packaged OOD/stress recipe ranges into additional task-wide admissibility limits.
Native mass, inertia, friction components, contact parameters, and gravity are independent
physics inputs; non-physics interventions retain the complete canonical physics block.
The surface-driven validator follows the same ownership rule; its explicitly frozen
ID/OOD/stress speed intervals remain task constraints.

`tests/integration/test_grasp.py`, `test_t1_belt.py`, `test_t1_matched.py`, and `test_t1_occ.py` cover these
vertical slices, continuous actuation through capture, and temporary-manifest replay.
The T1 oracle uses current-state tracking for E7 and downstream prepositioning for J8;
the T variant selects graspable bar/stem geometry from the current compiled pose. It
does not guarantee acceptance of every proposal. Same-seed XYZ/SO3 accepted pairs and
fixed rejected proposals are both tested. OCC tests separately cover compiled clearance,
real Panda visibility sequences, capture, target-region lighting, and active/parked
physical/raster comparisons. `tests/integration/test_t2.py` covers real hidden preparation,
scored-zero replay, both placement controllers, complete-handle containment and native
moving-goal velocity. Its accepted and fixed rejected proposals use the same public
generator; recipe labels never substitute for physical acceptance. T2 non-owning fields
are checked against the explicit test-ID recipe support, without turning OOD sampling
choices into task-wide admissibility bounds. `tests/integration/test_t3.py` covers both
rotating protocols, controller/action/view/delay paths, native threshold routing, weld
continuity, deterministic accepted and rejected proposals, and exact manifest replay.
`tests/integration/test_t4.py` covers hidden release preparation, native contact and terminal
boundaries, all four E7/J8 oracle routes, deterministic rejection, and exact manifest replay.
`tests/integration/test_t5.py` covers the dual-striker compiled scene, event/impact boundaries,
same-reset branch counterfactuals, E7/J8 oriented capture, deterministic rejection, reset reuse
and exact manifest replay.
These engineering checks are not benchmark policy results.
