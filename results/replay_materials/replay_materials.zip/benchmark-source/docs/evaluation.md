# Evaluation

The formal interaction loop has one owner: `evaluation/rollout.py`. Family Env success
and event state are the sole episode facts; Evaluator forms an `EpisodeResult`, and Suite
execution aggregates ordered results without reconstructing success. The public
`evaluate()` and `se3-wam-evaluate` CLI execute this path from a Suite's declared
Manifests; the CLI writes the resulting ordered episode and aggregate records as JSON.

## Reading aggregate metrics

Suite first averages repeats of each scenario, then gives each scenario equal weight
within its task/cell. The macro gives each applicable task equal weight. Partition,
factor, Action mode, Action representation, and observation profile define separate
cells throughout. A task with more scenarios or repeats does not gain macro weight.

`n_total` and `n_valid` count episode repeats, while estimates use the scenario/task
weighting above. Failed completion times remain `null`; only valid values enter that
metric, and a group with no valid values stays `null`. OOD paired completion time is
valid only when both matched episodes succeeded. A zero paired difference is valid.

Task/cell binary rates use 95% Wilson intervals. Continuous metrics, paired
differences, and every task macro use the frozen 10,000-sample percentile bootstrap
with RNG seed 0. It resamples source-seed clusters within each task/cell, preserving
matched scenarios and repeat groups. Macro tasks remain fixed and equally weighted.
These intervals describe one policy's scenario uncertainty; research owns aggregation
across independent training seeds.

Each OOD group reports its absolute metrics and OOD-minus-test-ID paired differences.
The formal standalone OOD Suite's exact `manifests/v1/test_id.jsonl` reference is only
a pairing input. It does not enter the returned ordered results or absolute groups.
The complete contract is in sections 11.8.8–11.8.9 of the
[frozen design](https://app.notion.com/p/3c17e1a21323800c941ed3227eeb24aa).

The targeted Suite regression checks run with:

```bash
python -m pytest tests/unit/test_public_records.py -k suite
python -m pytest tests/integration/test_grasp.py::test_public_evaluate_runs_a_real_manifest_episode_and_builds_task_and_macro_groups
```

They cover repeat/scenario/task weighting, seed clusters, Wilson versus bootstrap,
exact OOD pairing, zero paired CT, and missing-value counts. The native test uses a
privileged oracle fixture to check the real Manifest/evaluate/episode path, grouping,
Action ticks and simulation-time alignment, without a wall-clock deadline. It requires
a working native rendering backend and does not measure learned-policy performance.
Full verification commands are listed in the [README](../README.md#verification).

## Running a synchronous evaluation

Use a complete installed checkout and working native rendering backend as described
in the [README](../README.md). Scenario generation runs real proposal validation;
it can reject an unsolved proposal and does not silently resample it. For example:

```bash
mkdir -p run/manifests run/episodes
se3-wam-generate-scenarios --task-id grasp --recipe configs/scenarios/grasp.yaml --partition test_id --recipe-name e7_agentview_wrist --seed 0 --count 1 --output run/manifests/test_id.jsonl
```

After generation succeeds, save this explicit one-task Suite as `run/test_id.yaml`.
`suite_id` must match the filename stem. Manifest paths are relative to the Suite
file, so this one names the file above; it is not a full 14-task evaluation:

```yaml
schema_version: 1
suite_id: test_id
protocol_version: v1
repeats: 1
members:
  - manifest: manifests/test_id.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
```

Choose a policy compatible with that Manifest's ActionSpec and observation profile.
The installed CLI loads only an explicit, importable zero-argument `module:factory`.
For a Model policy, install Model in the same environment and export a synchronous
bundle following its [artifact guide](https://github.com/ArrebolBlack/SE3-WAM/blob/master/docs/artifacts.md#training-to-deployment).
For example, an application-owned `my_policy:make_policy` can contain:

```python
from se3_wam.api import load_policy
from se3_wam_benchmark.integrations.se3_wam import bind_policy


def make_policy():
    model_policy = load_policy("/absolute/path/policy.pt")
    return bind_policy(
        model_policy,
        camera_geometry_enabled=True,
        observation_depth_enabled=True,
        observation_flow_enabled=False,
        observation_anchor_enabled=False,
    )
```

This is application code, not a new Benchmark package or a bundled pretrained policy.
Use the flags from the configuration you explicitly deployed: the example assumes
Camera Geometry and upstream simulator Depth, no upstream Flow or Anchor, and any
past Flow computed inside Model. These are upstream-presence flags, not switches
for Flow supervision or all Model Flow computation. Do not inspect private bundle
fields to guess them. The bundle's views and ActionSpec must match the selected
Manifest; the example `e7_agentview_wrist` recipe matches the Model usage template's
E7/delta dual-view configuration, not a J8 deployment. Select a matching recipe
instead of coercing an Action.

With your application module importable, evaluate or record using new output paths:

```bash
se3-wam-evaluate --suite run/test_id.yaml --policy my_policy:make_policy --output run/summary.json
se3-wam-record --manifest run/manifests/test_id.jsonl --policy my_policy:make_policy --shard-index 0 --shard-count 1 --output run/episodes
```

Parent output directories must exist; existing outputs are not silently overwritten.
The generated recording is the canonical HDF5 product, not a Model checkpoint or
deployment bundle. The ordinary `evaluate(policy, suite)` Python API uses the same
loop as the CLI. A caller that retains the loaded Model Policy should call its
`reset()` when finished, including error paths, to release its execution state.

For a Model bundle explicitly exported with E7 delta translation clipping at
±0.10 m, pass `execution_translation_limit_m=0.10` to `evaluate` or add
`--execution-translation-limit-m 0.10` to either CLI above. The default remains
0.05. Select the matching deployment bundle explicitly; the adapter validates its
Model ActionSpec, and the environment validates commands against the selected
execution limits. Native-oracle recording only accepts the original 0.05 setting.
This is a deployment/evaluation choice: Model training-data validation and its
training action normalization remain at their original 0.05 contract. A 0.10
rollout is not thereby accepted as Model training data.

For raw-to-applied action evidence, enable the existing Model executor INFO log.
Its `model_action_selected` entries contain the raw prediction and selected command
for each process/thread, reset episode and zero-based tick. Associate each rollout's
reset with its recorded episode; the command widened from float32 to float64 equals
that episode's HDF5 `action/value` at `issued_tick`. `applied_tick` records the actual
environment application; a terminal pending suffix uses -1 and was never applied.
Chunk replanning preserves this tick association. Episode summaries contain outcome
metrics; formal recording owns per-action application evidence.

For the same correspondence during `evaluate`, a caller may enable INFO on the
standard logger `se3_wam_benchmark.evaluation.rollout`. It emits JSON
`benchmark_episode_reset` after reset, followed at normal episode completion by
one `benchmark_action` per issued action from the validated EpisodeTrace.
Each row identifies process/thread, scenario and repeat, and contains the physical
`command`, `issued_tick`, final `applied_tick`, and `episode_done`. A null
`applied_tick` means the action remained pending and was never applied. Associate
the following Model reset episode on that process/thread with the reset entry,
then join Model `tick` to `issued_tick`. Action rows are emitted after the control
loop, outside wall pacing; an aborted episode has no completed trace rows. This
INFO log is disabled at Python's default logging level and requires no CLI flag.

## Functional evaluation and optional wall pacing

Without `wall_control_period_s` (CLI: without `--wall-control-period-s`), the formal
loop waits for synchronous inference as needed. Each issued Action still advances
the same native physics/control timeline. Wall time and physical time are distinct:
waiting longer does not lower the simulated control frequency or alter Action units.

An explicitly wall-paced run may pass `--wall-control-period-s 0.5`, provided the
selected asynchronous Model bundle was exported for that same wall period. Benchmark
does not rewrite or infer the Model execution profile. The caller must supply matching
choices; a synchronous run is not RTC merely because a wall period was provided.

Full-FTA native synchronous integration has passed through the real exported Policy,
recording/replay, and public evaluator. Historical performance validation also recorded
real 0.5 s wall-paced RTC runs; those results describe their explicitly configured
execution profile. The former 100 ms target has been withdrawn. Functional acceptance
does not require a fixed wall period. Performance changes need evidence for their
stated execution profile before independent acceptance and integration.

The learned-policy acceptance scene runs 160 Actions over 8 s of physical time with
a small full-FTA configuration. Its terminal outcome is timeout, not success. This
proves the product path, not a trained policy's success rate or all-task performance.
Non-RGB arrays and metadata replay exactly; small renderer RGB differences are
reported separately, not hidden by asserting bitwise image replay.
