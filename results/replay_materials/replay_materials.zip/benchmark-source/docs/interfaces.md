# Interfaces

The stable API contains exactly `ScenarioSpec`, `BenchmarkObservation`,
`BenchmarkAction`, `BenchmarkPolicy`, `EpisodeResult`, `EvaluationSummary`, `make_env`,
and `evaluate`.

Records are frozen slotted dataclasses. Persistent values use JSON-compatible data;
runtime arrays have fixed NumPy dtypes and read-only semantics. Policy observations never
contain scenario/split identity, event identity, segmentation, future state, or privileged
supervision. Each policy call returns one E7 or J8 delta/absolute action for one control
tick.

BenchmarkAction carries physical values in a contiguous, read-only float64 array.
Recorded action/value uses the same dtype. Model Action tensors remain float32;
the adapter preserves their numerical values when widening the carrier. E7 applies
the original normalized float32 conversion at the controller entrance, after frame
mapping. Execution limits retain their existing float32-represented values; J8 keeps
its established execution rounding and scaling.

`make_env(..., execution_translation_limit_m=0.10)` explicitly selects E7 delta
translation limits of ±0.10 m per axis per control step. The default remains 0.05;
rotation remains ±0.5 rad per axis and gripper remains discrete. Only these two
translation settings are accepted; 0.10 rejects J8 and absolute actions. ActionSpec
owns the limits at adapter, enqueue/application, trace and recorded-file boundaries.
BenchmarkAction owns shape, finite physical values and gripper representation.
The caller selects matching Model deployment and environment settings. Benchmark
rejects out-of-range commands instead of clipping them again.

Hidden DB0 preparation and every reset retain the original 0.05 m OSC scale. The
0.10 scale is installed only when the first scoring action is accepted, after
preparation; action delay and the original normalized float32 conversion remain.

Episode metadata stores event_times_s, mapping original event names to their raw
simulation times in seconds. These events include entry and terminal facts that need
not be task stages. StageProgress continues to own event_names and event_flags.
The recorder checks that raw event history is append-only and preserves its values;
it does not quantize event times to control ticks. Readers require the updated metadata
and float64 action dataset. Historical DB0 files remain on the explicit DB0 reader.

The optional Model integration receives a loaded `SE3WAMPolicy` and an explicit projection
of its already-resolved input-presence configuration. It maps the visible observation into
the Model's CPU tensor carrier, calls `select_action` exactly once, and preserves the returned
Action mode, representation, and physical values. It neither reloads bundle configuration
nor converts absolute Actions to deltas; upstream Flow or Anchor requirements fail because
those privileged fields are absent from `BenchmarkObservation`.
`bind_policy` accepts only a Model `ActionSpec.gripper_mode` of `discrete`; it rejects
`continuous` before constructing observations or calling the Policy, without converting
physical values.

Family reset/step observations retain Robosuite's native dictionary format. The private
sensing adapter requires native OpenGL row order, then reverses RGB and depth together
into the frozen top-left, downward-v CV raster. Metric depth and current compiled camera
calibration refer to that same raster. Integer `(u, v)` coordinates denote pixel centers;
the 224x224 intrinsic principal point is `(111.5, 111.5)`, while focal length uses
`112 / tan(vertical_fov / 2)`. Consumers use the supplied K without another half-pixel
offset. Changing the upstream image convention fails
explicitly instead of selecting a second conversion path.

B2 restores the old DB0 renderer with MuJoCo 3.11.0 and
`visual/quality offsamples="4"`. RGB uses the original multisample antialiasing;
metric depth and categorical geometry IDs use an Env-owned single-sample context so
category colors are never averaged during multisample readback. They share pixel-center
camera calibration and raster, but a categorical
ID does not describe every RGB sample at an antialiased edge. Compiled helper sites
are reduced to the old DB0 size before the first observation. Restoration comparisons
use the fixed old RGB, depth, and geometry-ID outputs independently.

T4 scenarios declare one preparation_object_states entry using ObjectStateSpec.
It names the released target and asset, with an explicit temporary table pose and
zero twist. The Family performs the old staging and settling sequence, installs the
release pose, and parks the static gate before the first observation. Reset preserves
the resulting robot velocity, control and warm-start state. Recipe sampling resolves
and serializes the preparation pose; reset does not draw it again.

Moving placement, rotating interaction, free-dynamics interception, and replanning
complete hidden preparation with DB0's original OSC controller. The declared action
mode selects the scoring controller. A J8 scenario then replaces only the live arm
controller and updates its action dimension, preserving the prepared physical state
and gripper controller before the first observation. Repeated reset starts with OSC
again and follows the same preparation sequence.

Free-body pose supervision reads integrated free-joint position and quaternion.
Metric depth retains the old arithmetic on normalized float32 depth. These observation
conventions do not change physics integration or event timing.
