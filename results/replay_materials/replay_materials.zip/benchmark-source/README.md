# SE(3)-WAM Dynamic Benchmark

Dynamic Benchmark is the source-checkout-first simulation and evaluation product
for dynamic robot manipulation. The single package, `se3_wam_benchmark`, owns task
declarations, scenarios, Manifests, environments, recording, and evaluation.
Its stable facade is `se3_wam_benchmark.api`.

The [frozen Benchmark design](https://app.notion.com/p/3c17e1a21323800c941ed3227eeb24aa)
is the TO-BE authority. This repository records the implemented behavior and
engineering acceptance, not a second architecture or a policy-performance claim.

## Delivered functionality and limits

The functional mainline includes:

- All 14 task declarations and six registered native Robosuite Family Envs,
  concrete scenario materialization, real reset/step, privileged deterministic
  proposal validation, and Manifest replay.
- Privileged supervision, manipulation/pose/Flow metrics, the single rollout
  and Suite evaluator, strict schema-1 HDF5 recording, and three CLI entry points.
- The explicit Model adapter and accepted full-FTA synchronous simulation through
  a real exported Model bundle: native rollout, recording, replay, and evaluation.

The complete synchronous loop may wait for inference. It keeps the physical
control timeline and does not require a 100 ms wall-clock deadline. RTC and
inference performance are an independent track; their remaining speed work does
not reopen the delivered synchronous path.

The learned-policy acceptance uses a small full-FTA model and a real Grasp scene.
It verifies integration and physical Action routing, not successful learning,
success rate across the 14 tasks, or every model size/configuration. The accepted
episode ended in timeout; non-RGB recorded arrays and metadata replay exactly,
while small RGB renderer differences are diagnostic rather than a bitwise claim.
Environment and oracle checks are not learned-policy benchmark results.

## Installation

Clone the complete repository and install it from the checkout:

```bash
git clone https://github.com/ArrebolBlack/se3-wam-dynamic-benchmark.git
cd se3-wam-dynamic-benchmark
python -m pip install -e ".[dev]"
```

Benchmark requires Python 3.11 or newer; use Python 3.12 when installing it with
the Model product. Native dependencies are pinned in [pyproject.toml](pyproject.toml):
Robosuite `1.5.2`, MuJoCo `3.11.0`, and HDF5's Python binding `h5py==3.16.0`.
The accepted runtime used NumPy `1.26.4`. Install Model separately in the same
environment only when using its optional adapter.

Keep the checkout's `configs/` and canonical assets available. Standalone
Benchmark-wheel distribution is not the accepted installation route. The
private version-exact joint-address bridge is inside the environment boundary;
no external shim or change to Robosuite/MuJoCo registries is required.

Native camera runs need a working rendering backend. The accepted CUDA
closed-loop environment uses Linux EGL; select `MUJOCO_GL=egl` before starting
Python on a suitable headless NVIDIA host. Installing Python dependencies alone
does not provision a graphics driver or rendering backend.

## Public API and operation

```python
from se3_wam_benchmark.api import (
    BenchmarkAction,
    BenchmarkObservation,
    BenchmarkPolicy,
    EpisodeResult,
    EvaluationSummary,
    ScenarioSpec,
    evaluate,
    make_env,
)
```

Policies return one physical E7/J8 delta/absolute Action per control tick.
`make_env(task_id, scenario_spec)` consumes a concrete scenario, not a sampling
recipe. Invalid declarations or missing inputs fail explicitly.

Start with [the evaluation guide](docs/evaluation.md#running-a-synchronous-evaluation)
to generate a Manifest, write the matching explicit Suite, bind a real Model
Policy, and evaluate or record it. The installed commands are:

```bash
se3-wam-generate-scenarios --help
se3-wam-evaluate --help
se3-wam-record --help
```

A policy CLI argument is an importable `module:factory`, not a checkpoint path.
The factory must return a Benchmark Policy. The optional
`se3_wam_benchmark.integrations.se3_wam.bind_policy` accepts an already-loaded
Model Policy and caller-owned input-presence choices; it does not inspect or
reinterpret bundle internals. Upstream Flow and Anchor are absent from the visible
Benchmark observation. This does not prohibit the Model's own causal online Flow
estimator. See [interfaces](docs/interfaces.md).

Suite execution consumes only explicitly declared Manifests. Supplied Suite
YAMLs do not imply that their referenced data have already been generated.
Recording shards one Manifest by global line ordinal; it does not automatically
resample rejected proposals or choose a different policy.

## Verification

```bash
python -m pytest
python -m ruff check src tests
python -m ruff format --check src tests
python -m mypy
git diff --check
```

Real native, rendering, data, and Model integration gates require their stated
environment and inputs. A skip is not a pass. The learned-policy integration gate
is explicit: `tests/integration/se3_wam_adapter_gate.py`; run its affected tests
with the prerequisites declared there rather than treating the default suite
alone as proof of Model integration. See [evaluation](docs/evaluation.md) for
synchronous versus wall-paced execution.

## Documentation

- [Architecture](docs/architecture.md): package ownership and dependency direction.
- [Tasks](docs/tasks.md): the 14 task routes, native physics, and proposal validation.
- [Interfaces](docs/interfaces.md): visible carriers and the Model adapter.
- [Data](docs/data.md): strict episode recording and supervision boundaries.
- [Evaluation and usage](docs/evaluation.md): Manifests, Suites, policies, and runtime modes.

## License and publication

[LICENSE](LICENSE) contains the factual `LicenseRef-Research-Only` placeholder,
not the owner's complete legal terms. Functional engineering delivery does not
close publication or redistribution acceptance. Those still require the complete
approved legal text; no release rights are inferred here.
