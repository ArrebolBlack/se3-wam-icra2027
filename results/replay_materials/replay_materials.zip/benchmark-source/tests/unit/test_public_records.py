from __future__ import annotations

from dataclasses import fields, replace
from typing import Any

import numpy as np
import numpy.typing as npt
import pytest

from se3_wam_benchmark.control.action import ActionSpec, BenchmarkAction
from se3_wam_benchmark.evaluation.metrics.manipulation import (
    _failure_class,
    _manipulation_metrics,
    _stage_names_for_task,
)
from se3_wam_benchmark.evaluation.result import (
    BOUNDARY_FAILURES,
    FAILURE_CODES,
    SAFETY_FAILURES,
    TASK_FAILURES,
    AggregateMetrics,
    EpisodeResult,
    EpisodeTrace,
    EvaluationGroup,
    EvaluationGroupKey,
    EvaluationSummary,
    FailureClass,
    FailureCode,
    FailureRate,
    ManipulationMetrics,
    MetricEstimate,
    PairedDifferenceMetrics,
    StageName,
    StageProgress,
    StepTrace,
    failure_class_for,
)
from se3_wam_benchmark.evaluation.suite import _build_groups, _EvaluatedEpisode
from se3_wam_benchmark.scenarios.manifest import Partition
from se3_wam_benchmark.sensing.observation import BenchmarkObservation, ObservationSpec
from se3_wam_benchmark.supervision.snapshot import SupervisionSnapshot


def _readonly(value: npt.NDArray[Any]) -> npt.NDArray[Any]:
    value.setflags(write=False)
    return value


def _action(
    mode: str = "E7",
    representation: str = "delta",
    value: npt.NDArray[Any] | None = None,
) -> BenchmarkAction:
    dimension = 7 if mode == "E7" else 8
    array = value if value is not None else np.zeros(dimension, dtype=np.float64)
    return BenchmarkAction(mode, representation, _readonly(array))  # type: ignore[arg-type]


def test_action_spec_accepts_default_and_explicit_e7_delta_execution_limits() -> None:
    ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5))
    ActionSpec("J8", "absolute", (0.05,) * 7)
    ActionSpec("E7", "delta", (0.10, 0.10, 0.10, 0.5, 0.5, 0.5))
    with pytest.raises(ValueError, match="default profile"):
        ActionSpec("E7", "delta", (0.1,) * 6)
    with pytest.raises(ValueError, match="E7 delta"):
        ActionSpec("E7", "absolute", (0.10, 0.10, 0.10, 0.5, 0.5, 0.5))
    with pytest.raises(ValueError, match="default profile"):
        ActionSpec("J8", "delta", (0.10,) * 7)
    with pytest.raises(ValueError, match="mode or representation"):
        ActionSpec("bad", "delta", (0.05,) * 7)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="mode or representation"):
        ActionSpec("J8", "bad", (0.05,) * 7)  # type: ignore[arg-type]


def test_benchmark_action_accepts_exact_e7_and_j8_records() -> None:
    assert _action("E7").value.shape == (7,)
    assert _action("J8").value.shape == (8,)
    absolute = np.zeros(7, dtype=np.float64)
    absolute[:3] = (0.4, -0.1, 0.8)
    _action("E7", "absolute", absolute)


def test_episode_trace_owns_its_declared_delta_limits() -> None:
    trace = _trace("grasp", (StageProgress("approach", False, 0.0, 0),))
    action = _action(value=np.asarray([0.075, 0, 0, 0, 0, 0, -1], dtype=np.float64))
    steps = (replace(trace.steps[0], action=action),)
    with pytest.raises(ValueError, match="execution-delta"):
        replace(trace, steps=steps)
    expanded = ActionSpec("E7", "delta", (0.10, 0.10, 0.10, 0.5, 0.5, 0.5))
    assert replace(trace, action_spec=expanded, steps=steps).steps[0].action is action


@pytest.mark.parametrize(
    ("value", "message"),
    [
        (np.zeros(6, dtype=np.float64), "float64\\[7\\]"),
        (np.zeros(7, dtype=np.float32), "float64\\[7\\]"),
        (np.array([0, 0, 0, 0, 0, 0, np.nan], dtype=np.float64), "finite"),
        (np.array([0, 0, 0, 0, 0, 0, 0.5], dtype=np.float64), "gripper"),
    ],
)
def test_benchmark_action_rejects_invalid_values(value: npt.NDArray[Any], message: str) -> None:
    with pytest.raises(ValueError, match=message):
        _action(value=value)


def test_benchmark_action_requires_read_only_c_contiguous_arrays() -> None:
    with pytest.raises(ValueError, match="read-only"):
        BenchmarkAction("E7", "delta", np.zeros(7, dtype=np.float64))
    non_contiguous = np.zeros(14, dtype=np.float64)[::2]
    assert not non_contiguous.flags.c_contiguous
    with pytest.raises(ValueError, match="contiguous"):
        _action(value=non_contiguous)


def test_benchmark_action_rejects_invalid_enums_and_nonprincipal_rotation() -> None:
    with pytest.raises(ValueError, match="mode"):
        BenchmarkAction("bad", "delta", _readonly(np.zeros(7, dtype=np.float64)))  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="mode"):
        BenchmarkAction([], "delta", _readonly(np.zeros(7, dtype=np.float64)))  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="representation"):
        BenchmarkAction("E7", "bad", _readonly(np.zeros(7, dtype=np.float64)))  # type: ignore[arg-type]
    value = np.zeros(7, dtype=np.float64)
    value[3] = np.float64(np.pi + 0.01)
    with pytest.raises(ValueError, match="principal"):
        _action("E7", "absolute", value)


def _observation() -> BenchmarkObservation:
    view_count = 1
    return BenchmarkObservation(
        tick=0,
        timestamp_s=0.0,
        view_names=("agentview",),
        rgb=_readonly(np.zeros((view_count, 224, 224, 3), dtype=np.uint8)),
        depth_m=_readonly(np.ones((view_count, 224, 224), dtype=np.float32)),
        camera_intrinsics=_readonly(np.eye(3, dtype=np.float64)[None, ...]),
        world_from_camera_cv=_readonly(np.eye(4, dtype=np.float64)[None, ...]),
        T_robot_base_from_world=_readonly(np.eye(4, dtype=np.float64)),
        joint_position=_readonly(np.zeros(7, dtype=np.float32)),
        joint_velocity=_readonly(np.zeros(7, dtype=np.float32)),
        eef_position=_readonly(np.zeros(3, dtype=np.float32)),
        eef_quaternion_xyzw=_readonly(np.array([0, 0, 0, 1], dtype=np.float32)),
        gripper_position=_readonly(np.zeros(2, dtype=np.float32)),
        gripper_velocity=_readonly(np.zeros(2, dtype=np.float32)),
    )


def test_observation_field_set_is_exact_and_excludes_privileged_facts() -> None:
    assert {field.name for field in fields(BenchmarkObservation)} == {
        "tick",
        "timestamp_s",
        "view_names",
        "rgb",
        "depth_m",
        "camera_intrinsics",
        "world_from_camera_cv",
        "T_robot_base_from_world",
        "joint_position",
        "joint_velocity",
        "eef_position",
        "eef_quaternion_xyzw",
        "gripper_position",
        "gripper_velocity",
    }
    assert not {
        "scenario_id",
        "partition",
        "factor",
        "geom_id",
        "segmentation",
        "optical_flow",
        "event_flags",
        "future_state",
        "supervision",
    } & {field.name for field in fields(BenchmarkObservation)}
    _observation()


def test_raster_dimensions_require_exact_integer_224() -> None:
    with pytest.raises(ValueError, match="224x224"):
        ObservationSpec(("agentview",), 224.0, 224)  # type: ignore[arg-type]


def test_observation_rejects_shape_dtype_writeability_and_nonfinite_values() -> None:
    observation = _observation()
    with pytest.raises(ValueError, match="joint_position"):
        replace(observation, joint_position=_readonly(np.zeros(8, dtype=np.float32)))
    with pytest.raises(ValueError, match="depth_m"):
        replace(
            observation,
            depth_m=_readonly(np.ones((1, 224, 224), dtype=np.float64)),
        )
    with pytest.raises(ValueError, match="read-only"):
        replace(observation, gripper_velocity=np.zeros(2, dtype=np.float32))
    nonfinite = np.zeros(7, dtype=np.float32)
    nonfinite[0] = np.nan
    with pytest.raises(ValueError, match="finite"):
        replace(observation, joint_velocity=_readonly(nonfinite))
    with pytest.raises(ValueError, match="non-negative"):
        replace(
            observation,
            depth_m=_readonly(-np.ones((1, 224, 224), dtype=np.float32)),
        )
    with pytest.raises(ValueError, match="tick"):
        replace(observation, tick=True)


@pytest.mark.parametrize(
    ("field", "matrix", "message"),
    [
        (
            "T_robot_base_from_world",
            np.diag([2.0, 1.0, 1.0, 1.0]),
            "orthogonal",
        ),
        (
            "T_robot_base_from_world",
            np.array(
                [
                    [1.0, 0.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0, 0.0],
                    [0.0, 0.0, 1.0, 0.0],
                    [1.0, 0.0, 0.0, 1.0],
                ]
            ),
            "last row",
        ),
        (
            "world_from_camera_cv",
            np.diag([-1.0, 1.0, 1.0, 1.0])[None, ...],
            "determinant",
        ),
    ],
)
def test_observation_rejects_non_se3_rigid_transforms(
    field: str, matrix: npt.NDArray[Any], message: str
) -> None:
    value = _readonly(matrix.astype(np.float64))
    with pytest.raises(ValueError, match=message):
        if field == "T_robot_base_from_world":
            replace(_observation(), T_robot_base_from_world=value)
        else:
            replace(_observation(), world_from_camera_cv=value)


def _metrics(*, success: bool, safety: bool = False) -> ManipulationMetrics:
    return ManipulationMetrics(
        success_rate=1.0 if success else 0.0,
        task_completion=1.0 if success else 0.5,
        completion_time_s=1.2 if success else None,
        safety_failure_rate=1.0 if safety else 0.0,
    )


def _result(
    *,
    success: bool,
    code: str | None,
    failure_class: str | None,
    repeat_index: int = 0,
) -> EpisodeResult:
    return EpisodeResult(
        scenario_id="v1:test_id:grasp:000000",
        task_id="grasp",
        partition="test_id",
        factor=None,
        repeat_index=repeat_index,
        action_mode="E7",
        action_representation="delta",
        observation_profile="agentview",
        success=success,
        failure_code=code,  # type: ignore[arg-type]
        failure_class=failure_class,  # type: ignore[arg-type]
        episode_steps=10,
        elapsed_s=0.5,
        metrics=_metrics(success=success, safety=code == "unsafe_contact"),
    )


def test_episode_result_enforces_success_failure_and_classification_consistency() -> None:
    _result(success=True, code=None, failure_class=None)
    _result(success=False, code="timeout", failure_class="timeout")
    _result(success=False, code="unsafe_contact", failure_class="safety")
    with pytest.raises(ValueError, match="cannot have a failure"):
        _result(success=True, code="timeout", failure_class="timeout")
    with pytest.raises(ValueError, match="requires failure code"):
        _result(success=False, code=None, failure_class=None)
    with pytest.raises(ValueError, match="does not match"):
        _result(success=False, code="timeout", failure_class="boundary")
    successful = _result(success=True, code=None, failure_class=None)
    with pytest.raises(ValueError, match="task_completion=1"):
        replace(
            successful,
            metrics=replace(successful.metrics, task_completion=0.5),
        )
    failed = _result(success=False, code="timeout", failure_class="timeout")
    with pytest.raises(ValueError, match="task_completion=1"):
        replace(failed, metrics=replace(failed.metrics, task_completion=1.0))


def _step(
    *,
    done: bool,
    success: bool,
    code: str | None,
    tick: int = 0,
    stage_progress: tuple[StageProgress, ...] = (),
) -> StepTrace:
    return StepTrace(
        tick=tick,
        timestamp_s=tick * 0.05,
        observation_tick=tick,
        action=_action(),
        issued_tick=tick,
        applied_tick=None,
        reward=0.0,
        done=done,
        success=success,
        failure_code=code,  # type: ignore[arg-type]
        event_flags=tuple(stage.completed for stage in stage_progress),
        stage_progress=stage_progress,
    )


_CAPTURE_STAGE_NAMES: tuple[StageName, ...] = (
    "approach",
    "fingerpad_contact",
    "bilateral_hold",
    "clearance",
    "stable_dwell",
)


def _empty_capture_progress() -> tuple[StageProgress, ...]:
    return tuple(StageProgress(name, False, 0.0, 0) for name in _CAPTURE_STAGE_NAMES)


def test_step_trace_requires_a_single_terminal_outcome_and_ordered_stage_progress() -> None:
    _step(done=True, success=False, code="timeout")
    with pytest.raises(ValueError, match="requires one failure code"):
        _step(done=True, success=False, code=None)
    with pytest.raises(ValueError, match="non-terminal"):
        _step(done=False, success=False, code="timeout")
    stages = (
        StageProgress("approach", True, 1.0, 3),
        StageProgress("fingerpad_contact", False, 0.5, 2),
        StageProgress("bilateral_hold", False, 0.1, 1),
    )
    with pytest.raises(ValueError, match="completed prefix"):
        _step(done=True, success=True, code=None, stage_progress=stages)


def test_episode_trace_rejects_terminal_steps_before_the_final_step() -> None:
    stages = _empty_capture_progress()
    with pytest.raises(ValueError, match="only the final"):
        EpisodeTrace(
            task_id="grasp",
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            observation_profile="agentview",
            action_spec=ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
            event_names=_CAPTURE_STAGE_NAMES,
            steps=(
                _step(
                    done=True,
                    success=False,
                    code="timeout",
                    tick=0,
                    stage_progress=stages,
                ),
                _step(
                    done=True,
                    success=False,
                    code="timeout",
                    tick=1,
                    stage_progress=stages,
                ),
            ),
            success=False,
            failure_code="timeout",
            elapsed_s=0.1,
        )


def test_episode_trace_requires_a_terminal_pending_action_suffix() -> None:
    stages = _empty_capture_progress()
    with pytest.raises(ValueError, match="terminal pending suffix"):
        EpisodeTrace(
            task_id="grasp",
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            observation_profile="agentview",
            action_spec=ActionSpec(
                "E7",
                "delta",
                (0.05, 0.05, 0.05, 0.5, 0.5, 0.5),
            ),
            event_names=_CAPTURE_STAGE_NAMES,
            steps=(
                _step(
                    done=False,
                    success=False,
                    code=None,
                    tick=0,
                    stage_progress=stages,
                ),
                replace(
                    _step(
                        done=True,
                        success=False,
                        code="timeout",
                        tick=1,
                        stage_progress=stages,
                    ),
                    applied_tick=1,
                ),
            ),
            success=False,
            failure_code="timeout",
            elapsed_s=0.1,
        )


def test_episode_trace_requires_event_names_and_flags_to_equal_each_step_stage_facts() -> None:
    stages = _empty_capture_progress()
    common = {
        "task_id": "grasp",
        "scenario_id": "v1:test_id:grasp:000000",
        "partition": "test_id",
        "factor": None,
        "repeat_index": 0,
        "observation_profile": "agentview",
        "action_spec": ActionSpec(
            "E7",
            "delta",
            (0.05, 0.05, 0.05, 0.5, 0.5, 0.5),
        ),
        "event_names": _CAPTURE_STAGE_NAMES,
        "success": False,
        "failure_code": "timeout",
        "elapsed_s": 0.1,
    }
    terminal = _step(
        done=True,
        success=False,
        code="timeout",
        stage_progress=stages,
    )
    with pytest.raises(ValueError, match="stage_progress names must align"):
        EpisodeTrace(
            **common,
            steps=(replace(terminal, stage_progress=tuple(reversed(stages))),),
        )
    with pytest.raises(ValueError, match="event_flags must agree"):
        EpisodeTrace(
            **common,
            steps=(replace(terminal, event_flags=(True, False, False, False, False)),),
        )
    with pytest.raises(ValueError, match="stage_progress names must align"):
        EpisodeTrace(
            **common,
            steps=(
                _step(
                    done=False,
                    success=False,
                    code=None,
                    stage_progress=stages,
                ),
                replace(
                    terminal,
                    tick=1,
                    observation_tick=1,
                    issued_tick=1,
                    stage_progress=tuple(reversed(stages)),
                ),
            ),
        )


def _trace(
    task_id: str,
    stages: tuple[StageProgress, ...],
    *,
    success: bool = False,
    failure_code: FailureCode | None = "timeout",
    elapsed_s: float = 1.25,
) -> EpisodeTrace:
    return EpisodeTrace(
        task_id=task_id,
        scenario_id=f"v1:test_id:{task_id}:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
        observation_profile="agentview",
        action_spec=ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        event_names=tuple(stage.stage_name for stage in stages),
        steps=(
            _step(
                done=True,
                success=success,
                code=failure_code,
                stage_progress=stages,
            ),
        ),
        success=success,
        failure_code=failure_code,
        elapsed_s=elapsed_s,
    )


def test_episode_trace_requires_a_non_empty_event_vocabulary() -> None:
    with pytest.raises(ValueError, match="event_names must be a non-empty tuple"):
        replace(_trace("grasp", _empty_capture_progress()), event_names=())


@pytest.mark.parametrize(
    ("task_id", "names"),
    [
        (
            "grasp",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t1_belt",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t1_xyz",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t1_so3",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t1_occ",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t2_trans",
            (
                "goal_approach",
                "full_containment",
                "release",
                "low_relative_motion",
                "stable_dwell",
            ),
        ),
        (
            "t2_se3",
            (
                "goal_approach",
                "full_containment",
                "release",
                "low_relative_motion",
                "stable_dwell",
            ),
        ),
        (
            "t3_phase",
            ("phase_alignment", "loop_entry", "path_progress_0_60", "terminal_arrival"),
        ),
        (
            "t3_full",
            (
                "wand_acquisition",
                "phase_alignment",
                "loop_entry",
                "path_progress_0_60",
                "terminal_arrival",
                "wire_exit",
                "wand_release",
            ),
        ),
        (
            "t4_sphere",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t4_sphere_tabletop",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t4_slider",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t4_can",
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"),
        ),
        (
            "t5_replan",
            (
                "valid_selected_impact",
                "approach",
                "fingerpad_contact",
                "bilateral_hold",
                "clearance",
                "stable_dwell",
            ),
        ),
    ],
)
def test_manipulation_metrics_use_each_frozen_ordered_stage_sequence(
    task_id: str, names: tuple[StageName, ...]
) -> None:
    stages = tuple(
        StageProgress(name, index == 0, 1.0 if index == 0 else 0.0, 0)
        for index, name in enumerate(names)
    )
    metrics = _manipulation_metrics(_trace(task_id, stages))
    assert metrics.success_rate == 0.0
    assert metrics.task_completion == pytest.approx(1.0 / len(names))
    assert metrics.completion_time_s is None
    assert metrics.safety_failure_rate == 0.0


def test_manipulation_stage_routing_does_not_infer_future_task_ids_from_prefixes() -> None:
    with pytest.raises(ValueError, match="not defined"):
        _stage_names_for_task("t1_future")
    with pytest.raises(ValueError, match="not defined"):
        _stage_names_for_task("t4_future")


def test_manipulation_metrics_compute_partial_completion_and_success_time() -> None:
    names = ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell")
    partial = tuple(
        StageProgress(name, index < 2, 1.0 if index < 2 else 0.4 if index == 2 else 0.0, 10)
        for index, name in enumerate(names)
    )
    failed = _manipulation_metrics(_trace("grasp", partial))
    assert failed.task_completion == pytest.approx((2.0 + 0.4) / 5.0)
    complete = tuple(StageProgress(name, True, 1.0, 0) for name in names)
    succeeded = _manipulation_metrics(
        _trace("grasp", complete, success=True, failure_code=None, elapsed_s=3.456)
    )
    assert succeeded == ManipulationMetrics(1.0, 1.0, 3.456, 0.0)


@pytest.mark.parametrize("failure_code", sorted(SAFETY_FAILURES))
def test_manipulation_metrics_classify_every_safety_failure(failure_code: FailureCode) -> None:
    stages = tuple(
        StageProgress(name, False, 0.0, 0)
        for name in ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell")
    )
    trace = _trace("grasp", stages, failure_code=failure_code)
    assert _failure_class(trace) == "safety"
    assert _manipulation_metrics(trace).safety_failure_rate == 1.0


@pytest.mark.parametrize(
    ("failure_code", "expected"),
    [
        *((code, "task_violation") for code in sorted(TASK_FAILURES)),
        *((code, "boundary") for code in sorted(BOUNDARY_FAILURES)),
        ("timeout", "timeout"),
        ("invalid_state", "invalid"),
    ],
)
def test_manipulation_metrics_reuse_the_closed_failure_classification(
    failure_code: FailureCode, expected: FailureClass
) -> None:
    stages = tuple(
        StageProgress(name, False, 0.0, 0)
        for name in ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell")
    )
    trace = _trace("grasp", stages, failure_code=failure_code)
    assert _failure_class(trace) == expected
    assert _manipulation_metrics(trace).safety_failure_rate == 0.0


def test_manipulation_metrics_reject_wrong_or_incomplete_terminal_stage_facts() -> None:
    wrong = (
        StageProgress("fingerpad_contact", False, 0.0, 0),
        StageProgress("approach", False, 0.0, 0),
    )
    with pytest.raises(ValueError, match="frozen task stage sequence"):
        _manipulation_metrics(_trace("grasp", wrong))
    incomplete = tuple(
        StageProgress(name, index < 4, 1.0 if index < 4 else 0.5, 0)
        for index, name in enumerate(
            ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell")
        )
    )
    with pytest.raises(ValueError, match="successful EpisodeTrace"):
        _manipulation_metrics(_trace("grasp", incomplete, success=True, failure_code=None))


def test_manipulation_metrics_validate_the_fixed_stage_sequence_on_every_step() -> None:
    placement_stages = tuple(
        StageProgress(name, False, 0.0, 0)
        for name in (
            "goal_approach",
            "full_containment",
            "release",
            "low_relative_motion",
            "stable_dwell",
        )
    )
    trace = EpisodeTrace(
        task_id="grasp",
        scenario_id="v1:test_id:grasp:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
        observation_profile="agentview",
        action_spec=ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        event_names=tuple(stage.stage_name for stage in placement_stages),
        steps=(
            _step(
                done=False,
                success=False,
                code=None,
                tick=0,
                stage_progress=placement_stages,
            ),
            _step(
                done=True,
                success=False,
                code="timeout",
                tick=1,
                stage_progress=placement_stages,
            ),
        ),
        success=False,
        failure_code="timeout",
        elapsed_s=0.05,
    )
    with pytest.raises(ValueError, match="frozen task stage sequence"):
        _manipulation_metrics(trace)


def _estimate(value: float | None, *, n_total: int, n_valid: int) -> MetricEstimate:
    return MetricEstimate(
        mean=value,
        median=value,
        p25=value,
        p75=value,
        interval_95=None if value is None else (value, value),
        n_total=n_total,
        n_valid=n_valid,
    )


def _failure_rates(
    *, n_total: int, failure_code: str | None = None, value: float = 0.0
) -> tuple[FailureRate, ...]:
    return tuple(
        FailureRate(
            code,  # type: ignore[arg-type]
            _estimate(
                value if failure_code is None or code == failure_code else 0.0,
                n_total=n_total,
                n_valid=n_total,
            ),
        )
        for code in FAILURE_CODES
    )


def test_summary_supports_repeats_macro_groups_counts_and_null_metrics() -> None:
    first = _result(success=True, code=None, failure_class=None, repeat_index=0)
    second = _result(success=False, code="timeout", failure_class="timeout", repeat_index=1)
    group = EvaluationGroup(
        key=EvaluationGroupKey(
            task_id=None,
            partition="test_id",
            factor=None,
            action_mode="E7",
            action_representation="delta",
            observation_profile="agentview",
        ),
        metrics=AggregateMetrics(
            n_success=1,
            n_failure=1,
            success_rate=_estimate(0.5, n_total=2, n_valid=2),
            task_completion=_estimate(0.75, n_total=2, n_valid=2),
            completion_time_s=_estimate(1.2, n_total=2, n_valid=1),
            safety_failure_rate=_estimate(0.0, n_total=2, n_valid=2),
            failure_rates=_failure_rates(n_total=2, failure_code="timeout", value=0.5),
        ),
        paired_test_id_difference=None,
    )
    EvaluationSummary(results=(first, second), groups=(group,))
    _estimate(None, n_total=2, n_valid=0)
    with pytest.raises(ValueError, match="scenario/repeat"):
        EvaluationSummary(results=(first, first), groups=(group,))


def test_aggregate_metrics_rejects_impossible_extreme_success_rates() -> None:
    with pytest.raises(ValueError, match="zero successful episodes require a zero success rate"):
        AggregateMetrics(
            n_success=0,
            n_failure=1,
            success_rate=_estimate(1.0, n_total=1, n_valid=1),
            task_completion=_estimate(0.0, n_total=1, n_valid=1),
            completion_time_s=_estimate(None, n_total=1, n_valid=0),
            safety_failure_rate=_estimate(0.0, n_total=1, n_valid=1),
            failure_rates=_failure_rates(n_total=1),
        )
    with pytest.raises(ValueError, match="zero failed episodes require a unit success rate"):
        AggregateMetrics(
            n_success=1,
            n_failure=0,
            success_rate=_estimate(0.0, n_total=1, n_valid=1),
            task_completion=_estimate(1.0, n_total=1, n_valid=1),
            completion_time_s=_estimate(1.0, n_total=1, n_valid=1),
            safety_failure_rate=_estimate(0.0, n_total=1, n_valid=1),
            failure_rates=_failure_rates(n_total=1, failure_code="timeout", value=1.0),
        )


def _suite_episode(
    *,
    scenario_id: str,
    task_id: str,
    partition: Partition,
    factor: str | None,
    repeat_index: int,
    source_seed: int,
    success: bool,
    failure_code: FailureCode | None,
) -> _EvaluatedEpisode:
    return _EvaluatedEpisode(
        EpisodeResult(
            scenario_id=scenario_id,
            task_id=task_id,
            partition=partition,
            factor=factor,
            repeat_index=repeat_index,
            action_mode="E7",
            action_representation="delta",
            observation_profile="agentview",
            success=success,
            failure_code=failure_code,
            failure_class=(failure_class_for(failure_code) if failure_code is not None else None),
            episode_steps=10,
            elapsed_s=0.5,
            metrics=_metrics(success=success, safety=failure_code in SAFETY_FAILURES),
        ),
        source_seed,
    )


def test_suite_statistics_aggregate_repeat_then_scenario_then_unweighted_task() -> None:
    episodes = (
        _suite_episode(
            scenario_id="v1:test_id:grasp:000000",
            task_id="grasp",
            partition="test_id",
            factor=None,
            repeat_index=0,
            source_seed=11,
            success=True,
            failure_code=None,
        ),
        _suite_episode(
            scenario_id="v1:test_id:grasp:000000",
            task_id="grasp",
            partition="test_id",
            factor=None,
            repeat_index=1,
            source_seed=11,
            success=False,
            failure_code="timeout",
        ),
        _suite_episode(
            scenario_id="v1:test_id:t1_belt:000000",
            task_id="t1_belt",
            partition="test_id",
            factor=None,
            repeat_index=0,
            source_seed=22,
            success=True,
            failure_code=None,
        ),
    )
    first = _build_groups(episodes, episodes)
    second = _build_groups(episodes, episodes)
    assert first == second
    macro = next(group for group in first if group.key.task_id is None)
    assert (macro.metrics.n_success, macro.metrics.n_failure) == (2, 1)
    assert macro.metrics.success_rate.mean == pytest.approx(0.75)
    assert macro.metrics.success_rate.interval_95 == pytest.approx((0.75, 0.75))
    assert macro.metrics.task_completion.mean == pytest.approx(0.875)
    assert macro.metrics.task_completion.interval_95 == pytest.approx((0.875, 0.875))
    assert macro.metrics.completion_time_s.mean == pytest.approx(1.2)
    assert macro.metrics.completion_time_s.n_valid == 2
    timeout = next(item for item in macro.metrics.failure_rates if item.code == "timeout")
    assert timeout.estimate.mean == pytest.approx(0.25)


def test_suite_binary_intervals_use_wilson_per_task_and_clustered_bootstrap_for_macro() -> None:
    episodes = (
        _suite_episode(
            scenario_id="v1:validation:grasp:000000",
            task_id="grasp",
            partition="validation",
            factor=None,
            repeat_index=0,
            source_seed=11,
            success=True,
            failure_code=None,
        ),
        _suite_episode(
            scenario_id="v1:validation:grasp:000001",
            task_id="grasp",
            partition="validation",
            factor=None,
            repeat_index=0,
            source_seed=11,
            success=False,
            failure_code="timeout",
        ),
        _suite_episode(
            scenario_id="v1:validation:t1_belt:000000",
            task_id="t1_belt",
            partition="validation",
            factor=None,
            repeat_index=0,
            source_seed=22,
            success=True,
            failure_code=None,
        ),
    )
    groups = _build_groups(episodes, episodes)
    grasp = next(group for group in groups if group.key.task_id == "grasp")
    assert grasp.metrics.success_rate.interval_95 == pytest.approx(
        (0.09453120573423074, 0.9054687942657693)
    )
    macro = next(group for group in groups if group.key.task_id is None)
    assert macro.metrics.success_rate.mean == pytest.approx(0.75)
    assert macro.metrics.success_rate.interval_95 == pytest.approx((0.75, 0.75))


def test_suite_ood_pairing_is_unique_exact_and_reports_ood_minus_test_id() -> None:
    test_id = _suite_episode(
        scenario_id="v1:test_id:grasp:000000",
        task_id="grasp",
        partition="test_id",
        factor=None,
        repeat_index=0,
        source_seed=7,
        success=True,
        failure_code=None,
    )
    ood = _suite_episode(
        scenario_id="v1:ood:object:grasp:000000",
        task_id="grasp",
        partition="ood",
        factor="object",
        repeat_index=0,
        source_seed=7,
        success=False,
        failure_code="timeout",
    )
    groups = _build_groups((ood,), (test_id,))
    assert len(groups) == 2
    for group in groups:
        assert group.metrics.success_rate.mean == 0.0
        paired = group.paired_test_id_difference
        assert paired is not None
        assert paired.success_rate.mean == -1.0
        assert paired.task_completion.mean == -0.5
        assert paired.completion_time_s.mean is None
        assert paired.completion_time_s.n_valid == 0
        timeout = next(item for item in paired.failure_rates if item.code == "timeout")
        assert timeout.estimate.mean == 1.0
    with pytest.raises(ValueError, match="missing test-ID reference"):
        _build_groups((ood,), ())
    duplicate = replace(
        test_id,
        result=replace(test_id.result, scenario_id="v1:test_id:grasp:000001"),
    )
    with pytest.raises(ValueError, match="duplicate test-ID reference"):
        _build_groups((ood,), (test_id, duplicate))
    test_id_failure = replace(
        test_id,
        result=replace(
            test_id.result,
            success=False,
            failure_code="timeout",
            failure_class="timeout",
            metrics=_metrics(success=False),
        ),
    )
    ood_success = replace(
        ood,
        result=replace(
            ood.result,
            success=True,
            failure_code=None,
            failure_class=None,
            metrics=_metrics(success=True),
        ),
    )
    positive = _build_groups((ood_success,), (test_id_failure,))[0]
    assert positive.paired_test_id_difference is not None
    assert positive.paired_test_id_difference.success_rate.mean == 1.0
    timeout = next(
        item for item in positive.paired_test_id_difference.failure_rates if item.code == "timeout"
    )
    assert timeout.estimate.mean == -1.0
    mismatched_representation = replace(
        test_id,
        result=replace(test_id.result, action_representation="absolute"),
    )
    with pytest.raises(ValueError, match="missing test-ID reference"):
        _build_groups((ood,), (mismatched_representation,))
    absolute_ood = replace(
        ood,
        result=replace(
            ood.result,
            scenario_id="v1:ood:object:grasp:000001",
            action_representation="absolute",
        ),
    )
    groups_by_real_representation = _build_groups(
        (ood, absolute_ood),
        (test_id, mismatched_representation),
    )
    assert {group.key.action_representation for group in groups_by_real_representation} == {
        "delta",
        "absolute",
    }


def test_suite_completion_time_preserves_valid_zero_paired_differences_and_missing_counts() -> None:
    reference = _suite_episode(
        scenario_id="v1:test_id:grasp:000000",
        task_id="grasp",
        partition="test_id",
        factor=None,
        repeat_index=0,
        source_seed=7,
        success=True,
        failure_code=None,
    )
    success = replace(
        reference,
        result=replace(
            reference.result,
            scenario_id="v1:ood:object:grasp:000000",
            partition="ood",
            factor="object",
        ),
    )
    failure = _suite_episode(
        scenario_id="v1:ood:object:grasp:000001",
        task_id="grasp",
        partition="ood",
        factor="object",
        repeat_index=0,
        source_seed=8,
        success=False,
        failure_code="timeout",
    )
    second_reference = replace(
        reference,
        result=replace(reference.result, scenario_id="v1:test_id:grasp:000001"),
        source_seed=8,
    )
    groups = _build_groups((success, failure), (reference, second_reference))
    for group in groups:
        absolute_ct = group.metrics.completion_time_s
        assert absolute_ct.mean == pytest.approx(1.2)
        assert (absolute_ct.n_total, absolute_ct.n_valid) == (2, 1)
        paired = group.paired_test_id_difference
        assert paired is not None
        assert paired.success_rate.mean == -0.5
        assert paired.success_rate.interval_95 == (-1.0, 0.0)
        assert paired.completion_time_s.mean == 0.0
        assert paired.completion_time_s.interval_95 == (0.0, 0.0)
        assert (paired.completion_time_s.n_total, paired.completion_time_s.n_valid) == (2, 1)


def test_suite_statistics_cover_every_closed_failure_code_and_safety_subset() -> None:
    episodes = tuple(
        _suite_episode(
            scenario_id=f"v1:test_id:grasp:{index:06d}",
            task_id="grasp",
            partition="test_id",
            factor=None,
            repeat_index=0,
            source_seed=index,
            success=False,
            failure_code=code,
        )
        for index, code in enumerate(FAILURE_CODES)
    )
    task_group = next(
        group for group in _build_groups(episodes, episodes) if group.key.task_id == "grasp"
    )
    assert tuple(item.code for item in task_group.metrics.failure_rates) == FAILURE_CODES
    assert all(
        item.estimate.mean == pytest.approx(1.0 / len(FAILURE_CODES))
        for item in task_group.metrics.failure_rates
    )
    assert task_group.metrics.safety_failure_rate.mean == pytest.approx(
        len(SAFETY_FAILURES) / len(FAILURE_CODES)
    )


def test_ood_group_requires_typed_paired_test_id_differences() -> None:
    key = EvaluationGroupKey(
        task_id="grasp",
        partition="ood",
        factor="object",
        action_mode="E7",
        action_representation="delta",
        observation_profile="agentview",
    )
    metrics = AggregateMetrics(
        n_success=1,
        n_failure=0,
        success_rate=_estimate(1.0, n_total=1, n_valid=1),
        task_completion=_estimate(1.0, n_total=1, n_valid=1),
        completion_time_s=_estimate(1.0, n_total=1, n_valid=1),
        safety_failure_rate=_estimate(0.0, n_total=1, n_valid=1),
        failure_rates=_failure_rates(n_total=1),
    )
    with pytest.raises(ValueError, match="paired test-ID"):
        EvaluationGroup(key, metrics, None)
    difference = PairedDifferenceMetrics(
        success_rate=_estimate(-0.1, n_total=1, n_valid=1),
        task_completion=_estimate(-0.2, n_total=1, n_valid=1),
        completion_time_s=_estimate(0.3, n_total=1, n_valid=1),
        safety_failure_rate=_estimate(0.0, n_total=1, n_valid=1),
        failure_rates=_failure_rates(n_total=1, failure_code="timeout", value=0.1),
    )
    EvaluationGroup(key, metrics, difference)
    with pytest.raises(ValueError, match="negate the success difference"):
        replace(difference, failure_rates=_failure_rates(n_total=1))


def test_metric_carriers_reject_incompatible_counts_nulls_rates_and_codes() -> None:
    with pytest.raises(ValueError, match="null estimates"):
        _estimate(0.0, n_total=2, n_valid=0)
    with pytest.raises(ValueError, match="counts"):
        _estimate(0.0, n_total=True, n_valid=1)
    with pytest.raises(ValueError, match="failure code"):
        FailureRate("unknown", _estimate(0.0, n_total=1, n_valid=1))  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="all estimates"):
        MetricEstimate(0.0, None, 0.0, 0.0, (0.0, 0.0), 1, 1)
    with pytest.raises(ValueError, match="quantiles"):
        MetricEstimate(0.5, 0.5, 0.8, 0.2, (0.0, 1.0), 1, 1)
    with pytest.raises(ValueError, match="MetricEstimate"):
        FailureRate("timeout", None)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="finite"):
        MetricEstimate("bad", 0.0, 0.0, 0.0, (0.0, 0.0), 1, 1)  # type: ignore[arg-type]


def test_supervision_snapshot_accepts_background_and_shared_semantic_identity() -> None:
    def snapshot(depth: npt.NDArray[Any], identities: tuple[str, ...]) -> SupervisionSnapshot:
        return SupervisionSnapshot(
            tick=0,
            timestamp_s=0.0,
            view_names=("agentview",),
            depth_m=_readonly(depth),
            geom_id=_readonly(np.zeros((1, 224, 224), dtype=np.int32)),
            camera_intrinsics=_readonly(np.eye(3, dtype=np.float64)[None, ...]),
            world_from_camera_cv=_readonly(np.eye(4, dtype=np.float64)[None, ...]),
            world_from_geom=_readonly(np.repeat(np.eye(4)[None, ...], len(identities), axis=0)),
            target_object_pose_world=_readonly(np.array([0, 0, 0, 0, 0, 0, 1], dtype=np.float64)),
            geom_semantic_identity=identities,
        )

    snapshot(np.ones((1, 224, 224), dtype=np.float32), ("target",))
    with pytest.raises(ValueError, match="non-negative"):
        snapshot(-np.ones((1, 224, 224), dtype=np.float32), ("target",))
    duplicate = snapshot(np.ones((1, 224, 224), dtype=np.float32), ("target", "target"))
    replace(
        duplicate,
        geom_id=_readonly(-np.ones((1, 224, 224), dtype=np.int32)),
    )
    invalid_geom = snapshot(np.ones((1, 224, 224), dtype=np.float32), ("target",))
    with pytest.raises(ValueError, match="geom_id"):
        replace(
            invalid_geom,
            geom_id=_readonly(np.full((1, 224, 224), -2, dtype=np.int32)),
        )
    with pytest.raises(ValueError, match="geom_id"):
        replace(
            invalid_geom,
            geom_id=_readonly(np.ones((1, 224, 224), dtype=np.int32)),
        )
    with pytest.raises(ValueError, match="non-empty strings"):
        replace(invalid_geom, geom_semantic_identity=[])  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="at least one"):
        replace(
            invalid_geom,
            geom_semantic_identity=(),
            world_from_geom=_readonly(np.empty((0, 4, 4), dtype=np.float64)),
        )
    bad_world_from_geom = np.eye(4, dtype=np.float64)[None, ...]
    bad_world_from_geom[0, 0, 0] = 2.0
    with pytest.raises(ValueError, match="orthogonal"):
        replace(invalid_geom, world_from_geom=_readonly(bad_world_from_geom))
