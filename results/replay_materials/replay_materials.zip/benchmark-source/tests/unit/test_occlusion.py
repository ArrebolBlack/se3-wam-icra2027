from __future__ import annotations

import math

import mujoco
import numpy as np
import pytest

from se3_wam_benchmark.envs.components.occlusion import (
    _compiled_lift_envelope_clearance,
    _CompiledOcclusionFacts,
    _OcclusionVisibilityAudit,
    _OcclusionVisibilityState,
    _validate_compiled_occlusion,
)
from se3_wam_benchmark.scenarios.spec import DrivenInterceptionGeometrySpec


def _feed(
    audit: _OcclusionVisibilityAudit,
    ratios: list[float],
    *,
    start_frame: int = 0,
    contact_frames: tuple[int, ...] = (),
    hold_frames: tuple[int, ...] = (),
    position_step_m: float = 0.002,
) -> _OcclusionVisibilityState:
    result: _OcclusionVisibilityState | None = None
    for frame_index, ratio in enumerate(ratios, start=start_frame):
        result = audit.observe(
            sensor_time_s=frame_index / 20.0,
            target_visible_ratio=ratio,
            target_position_world_m=(0.0, frame_index * position_step_m, 0.822),
            fingerpad_contact_event=frame_index in contact_frames,
            bilateral_hold_event=frame_index in hold_frames,
        )
    assert result is not None
    return result


def test_visibility_sequence_accepts_partial_frames_between_contiguous_runs() -> None:
    audit = _OcclusionVisibilityAudit()
    visible = _feed(audit, [0.95] * 8)
    assert visible.phase == "await_hidden"
    assert visible.initial_visible_frames == 8

    partial = _feed(audit, [0.50, 0.06], start_frame=8)
    assert partial.phase == "await_hidden"
    hidden = _feed(audit, [0.05] * 10, start_frame=10, contact_frames=(12,), hold_frames=(15,))
    assert hidden.phase == "hidden"
    assert hidden.hidden_run_frames == 10

    between = _feed(audit, [0.50, 0.79], start_frame=20)
    assert between.phase == "await_reappearance"
    assert between.selected_hidden_duration_s == pytest.approx(0.5)
    complete = _feed(audit, [0.80] * 3, start_frame=22)
    assert complete.complete
    assert complete.phase == "complete"
    assert complete.reappearance_frames == 3
    assert complete.failure_codes == ()
    assert not complete.failure_facts.initial_visibility_lost
    assert not complete.failure_facts.hidden_run_too_long


def test_short_hidden_and_interrupted_reappearance_keep_selected_interval_evidence() -> None:
    audit = _OcclusionVisibilityAudit()
    _feed(audit, [1.0] * 8)
    short = _feed(audit, [0.0] * 9, start_frame=8)
    assert short.hidden_run_frames == 9
    short_ended = _feed(audit, [0.5], start_frame=17)
    # Old occ_protocol.py keeps the best complete run; it does not erase evidence.
    assert short_ended.phase == "await_reappearance"
    assert short_ended.hidden_run_frames == 9
    assert "full_occlusion_duration_too_short" in short_ended.failure_codes

    _feed(audit, [0.0] * 10, start_frame=18, contact_frames=(20,), hold_frames=(23,))
    first_reappearance = _feed(audit, [0.8, 0.79], start_frame=28)
    assert first_reappearance.phase == "reappearance"
    assert first_reappearance.reappearance_frames == 1
    assert not first_reappearance.complete
    complete = _feed(audit, [0.8, 0.9, 1.0], start_frame=30)
    assert complete.complete
    assert complete.selected_hidden_duration_s == pytest.approx(0.5)
    assert complete.reappearance_frames == 3
    assert complete.failure_codes == ()


def test_sixty_hidden_frames_are_valid_but_sixty_one_emit_failure_fact() -> None:
    accepted = _OcclusionVisibilityAudit()
    _feed(accepted, [1.0] * 8)
    exact_maximum = _feed(
        accepted, [0.0] * 60, start_frame=8, contact_frames=(10,), hold_frames=(12,)
    )
    assert exact_maximum.phase == "hidden"
    assert not exact_maximum.failure_facts.hidden_run_too_long
    complete = _feed(accepted, [0.8] * 3, start_frame=68)
    assert complete.complete
    assert complete.selected_hidden_duration_s == pytest.approx(3.0)

    rejected = _OcclusionVisibilityAudit()
    _feed(rejected, [1.0] * 8)
    too_long = _feed(rejected, [0.0] * 61, start_frame=8)
    assert too_long.phase == "hidden"
    assert too_long.failure_facts.hidden_run_too_long
    assert "full_occlusion_duration_too_long" in too_long.failure_codes
    assert not too_long.complete
    # The fixed task config allows 0.5--3.0 s. A later event-bearing interval may
    # replace a long eventless run, per old occ_protocol.py's interval score.
    _feed(rejected, [0.5], start_frame=69)
    _feed(rejected, [0.0] * 10, start_frame=70, contact_frames=(72,), hold_frames=(75,))
    later = _feed(rejected, [0.8] * 3, start_frame=80)
    assert later.complete
    assert later.selected_hidden_duration_s == pytest.approx(0.5)
    assert later.failure_codes == ()


def test_initial_visibility_requires_eight_contiguous_frames_and_reset_reuses_audit() -> None:
    audit = _OcclusionVisibilityAudit()
    failed = _feed(audit, [0.95] * 7 + [0.949])
    assert failed.phase == "failed"
    assert failed.failure_facts.initial_visibility_lost

    audit.reset()
    reset = _feed(audit, [0.95])
    assert reset.frame_index == 0
    assert reset.phase == "initial_visible"
    assert not reset.failure_facts.initial_visibility_lost


@pytest.mark.parametrize("displacement_m", [0.0, 0.012 - 1e-7, 0.012, 0.012 + 1e-7])
def test_initial_visible_displacement_has_inclusive_twelve_mm_boundary(
    displacement_m: float,
) -> None:
    complete = _feed(
        _OcclusionVisibilityAudit(),
        [1.0] * 8 + [0.0] * 10 + [0.8] * 3,
        contact_frames=(10,),
        hold_frames=(13,),
        position_step_m=displacement_m / 7,
    )
    assert complete.complete is (displacement_m >= 0.012)
    assert ("initial_visible_displacement_too_small" in complete.failure_codes) is (
        displacement_m < 0.012
    )


@pytest.mark.parametrize(
    ("contacts", "holds", "failure_code"),
    [
        ((), (13,), "fingerpad_contact_event_missing"),
        ((10,), (), "bilateral_hold_event_missing"),
        ((9,), (13,), "fingerpad_contact_boundary_margin_failed"),
        ((10,), (17,), "bilateral_hold_boundary_margin_failed"),
        ((13,), (10,), "capture_event_order_invalid"),
    ],
)
def test_capture_pulses_require_presence_order_and_both_boundary_margins(
    contacts: tuple[int, ...],
    holds: tuple[int, ...],
    failure_code: str,
) -> None:
    result = _feed(
        _OcclusionVisibilityAudit(),
        [1.0] * 8 + [0.0] * 10 + [0.8] * 3,
        contact_frames=contacts,
        hold_frames=holds,
    )
    assert not result.complete
    assert failure_code in result.failure_codes


def test_capture_pulses_in_different_hidden_intervals_cannot_complete_protocol() -> None:
    result = _feed(
        _OcclusionVisibilityAudit(),
        [1.0] * 8 + [0.0] * 10 + [0.5] + [0.0] * 10 + [0.8] * 3,
        contact_frames=(10,),
        hold_frames=(22,),
    )
    assert not result.complete
    assert "capture_events_not_in_same_occlusion" in result.failure_codes


def test_sensor_time_must_match_every_twenty_hz_frame_without_consuming_errors() -> None:
    audit = _OcclusionVisibilityAudit()
    with pytest.raises(ValueError, match="20 Hz"):
        audit.observe(
            sensor_time_s=0.001,
            target_visible_ratio=1.0,
            target_position_world_m=(0.0, 0.0, 0.822),
            fingerpad_contact_event=False,
            bilateral_hold_event=False,
        )
    first = _feed(audit, [1.0])
    assert first.frame_index == 0
    with pytest.raises(ValueError, match="20 Hz"):
        audit.observe(
            sensor_time_s=0.10,
            target_visible_ratio=1.0,
            target_position_world_m=(0.0, 0.0, 0.822),
            fingerpad_contact_event=False,
            bilateral_hold_event=False,
        )
    second = _feed(audit, [1.0], start_frame=1)
    assert second.frame_index == 1


@pytest.mark.parametrize("timestamp_s", [-0.05, math.nan, math.inf, True])
def test_sensor_time_rejects_negative_nonfinite_and_bool(timestamp_s: object) -> None:
    audit = _OcclusionVisibilityAudit()
    with pytest.raises(ValueError, match="sensor_time_s"):
        audit.observe(
            sensor_time_s=timestamp_s,  # type: ignore[arg-type]
            target_visible_ratio=1.0,
            target_position_world_m=(0.0, 0.0, 0.822),
            fingerpad_contact_event=False,
            bilateral_hold_event=False,
        )


@pytest.mark.parametrize("ratio", [-0.001, 1.001, math.nan, math.inf, True])
def test_visibility_ratio_is_strictly_validated(ratio: object) -> None:
    audit = _OcclusionVisibilityAudit()
    with pytest.raises(ValueError, match="target_visible_ratio"):
        audit.observe(
            sensor_time_s=0.0,
            target_visible_ratio=ratio,  # type: ignore[arg-type]
            target_position_world_m=(0.0, 0.0, 0.822),
            fingerpad_contact_event=False,
            bilateral_hold_event=False,
        )


def test_compiled_physical_facts_require_collision_clearance_and_no_contact() -> None:
    safe = _validate_compiled_occlusion(_CompiledOcclusionFacts(True, 0.20, False, False))
    assert safe.safe
    assert not safe.failure_facts.canopy_collision_disabled
    assert not safe.failure_facts.lift_envelope_clearance_insufficient
    assert not safe.failure_facts.unsafe_canopy_contact

    unsafe = _validate_compiled_occlusion(_CompiledOcclusionFacts(False, 0.199, True, False))
    assert not unsafe.safe
    assert unsafe.failure_facts.canopy_collision_disabled
    assert unsafe.failure_facts.lift_envelope_clearance_insufficient
    assert unsafe.failure_facts.unsafe_canopy_contact

    target_contact = _validate_compiled_occlusion(_CompiledOcclusionFacts(True, 1.0, False, True))
    assert target_contact.failure_facts.unsafe_canopy_contact


def test_compiled_physical_facts_reject_invalid_types_and_nonfinite_clearance() -> None:
    with pytest.raises(ValueError, match="collision_enabled"):
        _CompiledOcclusionFacts(1, 0.2, False, False)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="finite"):
        _CompiledOcclusionFacts(True, math.nan, False, False)
    with pytest.raises(ValueError, match="robot_canopy_contact"):
        _CompiledOcclusionFacts(True, 0.2, 0, False)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="facts"):
        _validate_compiled_occlusion(object())  # type: ignore[arg-type]


def _geometry_distance(
    position: tuple[float, float, float],
    *,
    canopy_roll: float = 0.0,
    canopy_yaw: float = 0.0,
) -> float:
    model = mujoco.MjModel.from_xml_string(
        '<mujoco><compiler angle="radian"/><worldbody>'
        '<body name="target" pos="0 -.24 .822"><freejoint/>'
        '<geom name="cube" type="box" size=".022 .022 .022"/></body>'
        f'<body pos="{" ".join(str(v) for v in position)}" '
        f'euler="{canopy_roll} 0 {canopy_yaw}">'
        '<geom name="occluder_screen" type="box" size=".12 .036 .006"/>'
        '<geom name="occluder_far_support" type="box" '
        'pos=".12 0 -.203" size=".006 .036 .197"/></body>'
        "</worldbody></mujoco>"
    )
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    before = (data.qpos.copy(), data.qvel.copy(), model.geom_pos.copy(), data.geom_xpos.copy())
    geometry = DrivenInterceptionGeometrySpec(
        0.8, ((-0.31, -0.40), (0.31, 0.40)), ((-0.28, -0.40), (0.28, 0.39)), 0.39, 0.20
    )
    distance = _compiled_lift_envelope_clearance(
        model,
        data,
        target_body_id=model.body("target").id,
        target_geom_ids=(model.geom("cube").id,),
        canopy_geom_ids=(model.geom("occluder_screen").id, model.geom("occluder_far_support").id),
        geometry=geometry,
        minimum_lift_m=0.05,
    )
    for saved, actual in zip(
        before, (data.qpos, data.qvel, model.geom_pos, data.geom_xpos), strict=True
    ):
        np.testing.assert_array_equal(saved, actual)
    return distance


@pytest.mark.parametrize("difference", [-1e-7, 0.0, 1e-7])
def test_real_compiled_envelope_distance_has_inclusive_point_two_boundary(
    difference: float,
) -> None:
    # Swept target top is .8 + .044 + .05 = .894, not the oracle's private goal.
    distance = _geometry_distance((0.0, 0.0, 0.894 + 0.006 + 0.20 + difference))
    assert distance == pytest.approx(0.20 + difference, abs=1e-12)
    facts = _validate_compiled_occlusion(_CompiledOcclusionFacts(True, distance, False, False))
    assert facts.safe is (difference >= 0.0)


def test_lateral_offset_cannot_replace_required_vertical_roof_clearance() -> None:
    # The fixed source declares vertical clearance above the full lifted cube.
    # Neither the remote roof nor the closer support upright changes that axis.
    distance = _geometry_distance((0.45, 0.0, 1.09))
    assert distance == pytest.approx(1.09 - 0.006 - (0.8 + 0.044 + 0.05), abs=1e-12)
    assert distance < 0.20
    assert not _validate_compiled_occlusion(
        _CompiledOcclusionFacts(True, distance, False, False)
    ).safe


def test_real_compiled_intersecting_envelope_has_zero_unsigned_distance() -> None:
    assert _geometry_distance((0.0, 0.0, 0.85)) == 0.0


def test_real_compiled_canopy_orientation_changes_its_geometric_clearance() -> None:
    distance = _geometry_distance((0.45, 0.0, 1.1), canopy_roll=math.pi / 2)
    # A roll changes the roof's world-Z half-extent to .036 in compiled xmat.
    assert distance == pytest.approx(1.1 - 0.036 - 0.894, abs=1e-12)
    assert distance < 0.20


def test_yaw_rotation_preserves_vertical_roof_clearance() -> None:
    straight = _geometry_distance((0.322, -0.29, 1.2))
    rotated = _geometry_distance((0.322, -0.29, 1.2), canopy_yaw=math.pi / 2)
    assert straight == pytest.approx(0.3, abs=1e-12)
    assert rotated == straight
