from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import cast

import numpy as np
import pytest

import se3_wam_benchmark.cli.evaluate as evaluate_cli
import se3_wam_benchmark.cli.generate_scenarios as generate_cli
import se3_wam_benchmark.cli.record as record_cli
from se3_wam_benchmark.data.recorder import _read_episode_file, _write_episode_file
from se3_wam_benchmark.data.schema import (
    _episode_id,
    _EpisodeArrays,
    _metadata_json,
    _parse_metadata_json,
    _validate_episode_arrays,
)
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy, _load_policy_factory
from se3_wam_benchmark.evaluation.result import EvaluationSummary
from se3_wam_benchmark.evaluation.suite import evaluate
from se3_wam_benchmark.scenarios.manifest import (
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import (
    CameraSetSpec,
    CameraSpec,
    DrivenInterceptionGeometrySpec,
    DrivenMotionSpec,
    FixedRotation,
    FixedTranslation,
    FixtureStateSpec,
    GraspGeometrySpec,
    LightingSpec,
    ObjectStateSpec,
    PhysicsSpec,
    RobotInitialStateSpec,
    ScenarioSpec,
    scenario_to_dict,
)
from se3_wam_benchmark.sensing.camera import _camera_intrinsics

ROOT = Path(__file__).resolve().parents[2]


def _scenario(*, driven: bool = False) -> ScenarioSpec:
    geometry = (
        DrivenInterceptionGeometrySpec(
            0.0,
            ((-0.5, -0.5), (0.5, 0.5)),
            ((-0.2, -0.2), (0.2, 0.2)),
            0.6,
            0.0,
        )
        if driven
        else GraspGeometrySpec(0.0, ((-0.5, -0.5), (0.5, 0.5)), 0.6)
    )
    fixtures = (FixtureStateSpec("belt", "belt_asset", (0.0, 0.0, 0.0), (0.0, 0.0, 0.0, 1.0)),)
    motion_entity = "belt" if driven else "target"
    return ScenarioSpec(
        action_mode="E7",
        observation_profile="agentview",
        physics_timestep_s=0.002,
        control_frequency_hz=20,
        sensor_frequency_hz=20,
        action_delay_steps=0,
        robot_initial_state=RobotInitialStateSpec((0.0,) * 7, (0.0, 0.0)),
        object_states=(
            ObjectStateSpec(
                "target",
                "target_asset",
                (0.0, 0.0, 0.1),
                (0.0, 0.0, 0.0, 1.0),
                (0.0, 0.0, 0.0),
                (0.0, 0.0, 0.0),
            ),
        ),
        fixture_states=fixtures,
        geometry=geometry,
        motion=(DrivenMotionSpec(motion_entity, FixedTranslation(), FixedRotation()),),
        physics=PhysicsSpec((0.0, 0.0, -9.81), (), (), ()),
        cameras=CameraSetSpec(
            224,
            224,
            (CameraSpec("agentview", (0.0, -1.0, 1.0), (0.0, 0.0, 0.0, 1.0), 45.0),),
        ),
        lighting=LightingSpec(()),
        events=(),
    )


def _row(
    *,
    ordinal: int = 0,
    task_id: str = "grasp",
    partition: str = "validation",
    factor: str | None = None,
) -> ScenarioManifestRow:
    if partition == "ood":
        scenario_id = f"v1:ood:{factor}:{task_id}:{ordinal:06d}"
    else:
        scenario_id = f"v1:{partition}:{task_id}:{ordinal:06d}"
    return ScenarioManifestRow(
        schema_version=1,
        protocol_version="v1",
        scenario_id=scenario_id,
        task_id=task_id,
        partition=partition,  # type: ignore[arg-type]
        factor=factor,
        source_seed=ordinal,
        scenario=_scenario(driven=task_id == "t1_belt"),
    )


def _payload(row: ScenarioManifestRow) -> dict[str, object]:
    return {
        "schema_version": row.schema_version,
        "protocol_version": row.protocol_version,
        "scenario_id": row.scenario_id,
        "task_id": row.task_id,
        "partition": row.partition,
        "factor": row.factor,
        "source_seed": row.source_seed,
        "scenario": scenario_to_dict(row.scenario),
    }


def _episode_metadata() -> dict[str, object]:
    scenario = _scenario()
    scenario_id = "v1:test_id:grasp:000000"
    return {
        "episode_id": _episode_id(scenario_id, 0),
        "protocol_version": "v1",
        "task_id": "grasp",
        "scenario_id": scenario_id,
        "partition": "test_id",
        "factor": None,
        "repeat_index": 0,
        "scenario_spec": scenario_to_dict(scenario),
        "observation_profile": "agentview",
        "action_spec": {
            "mode": "E7",
            "representation": "delta",
            "motion_limits": [0.05, 0.05, 0.05, 0.5, 0.5, 0.5],
        },
        "control_frequency_hz": 20,
        "view_names": ["agentview"],
        "geom_table": [
            {
                "geom_id": 0,
                "geom_name": "target_collision",
                "body_identity": "target_main",
                "instance_identity": "target",
                "semantic_identity": "target_asset",
            },
            {
                "geom_id": 1,
                "geom_name": "belt_collision",
                "body_identity": "belt_main",
                "instance_identity": "belt",
                "semantic_identity": "belt_asset",
            },
        ],
        "event_names": [
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
        ],
        "event_times_s": {"target_enters_observation_region": 0.0, "timeout": 8.0},
        "outcome": {
            "success": False,
            "termination_reason": "timeout",
            "failure_code": "timeout",
        },
        "software_versions": {
            "benchmark": "0.1.0",
            "robosuite": "1.5.2",
            "mujoco": "3.11.0",
        },
    }


def _episode_arrays() -> _EpisodeArrays:
    frames, transitions, views, geoms, events = 2, 1, 1, 2, 5
    rigid_frames = np.repeat(np.eye(4, dtype=np.float64)[None, None], frames, axis=0)
    rigid_geoms = np.repeat(
        np.eye(4, dtype=np.float64)[None, None], frames * geoms, axis=0
    ).reshape(frames, geoms, 4, 4)
    quaternions = np.repeat(np.asarray([[0.0, 0.0, 0.0, 1.0]], dtype=np.float32), frames, axis=0)
    target_pose = np.zeros((frames, 7), dtype=np.float64)
    target_pose[:, 6] = 1.0
    return _EpisodeArrays(
        tick=np.arange(frames, dtype=np.int64),
        timestamp_s=np.arange(frames, dtype=np.float64) / 20.0,
        rgb=np.zeros((frames, views, 224, 224, 3), dtype=np.uint8),
        depth_m=np.ones((frames, views, 224, 224), dtype=np.float32),
        camera_intrinsics=np.repeat(
            _camera_intrinsics(45.0, 224, 224)[None, None],
            frames,
            axis=0,
        ),
        world_from_camera_cv=rigid_frames,
        T_robot_base_from_world=np.eye(4, dtype=np.float64),
        joint_position=np.zeros((frames, 7), dtype=np.float32),
        joint_velocity=np.zeros((frames, 7), dtype=np.float32),
        eef_position=np.zeros((frames, 3), dtype=np.float32),
        eef_quaternion_xyzw=quaternions,
        gripper_position=np.zeros((frames, 2), dtype=np.float32),
        gripper_velocity=np.zeros((frames, 2), dtype=np.float32),
        action_value=np.zeros((transitions, 7), dtype=np.float64),
        issued_tick=np.arange(transitions, dtype=np.int64),
        applied_tick=np.arange(transitions, dtype=np.int64),
        geom_id=np.full((frames, views, 224, 224), -1, dtype=np.int32),
        world_from_geom=rigid_geoms,
        target_object_pose_world=target_pose,
        flow_2d_px=np.zeros((transitions, views, 224, 224, 2), dtype=np.float32),
        flow_valid=np.zeros((transitions, views, 224, 224), dtype=np.bool_),
        flow_future_visible=np.zeros((transitions, views, 224, 224), dtype=np.bool_),
        reward=np.zeros(transitions, dtype=np.float32),
        done=np.ones(transitions, dtype=np.bool_),
        success=np.zeros(frames, dtype=np.bool_),
        event_flags=np.zeros((frames, events), dtype=np.bool_),
    )


def test_frozen_episode_schema_round_trips_exact_hdf5_and_rejects_partial(
    tmp_path: Path,
) -> None:
    metadata, arrays = _episode_metadata(), _episode_arrays()
    arrays.action_value[0, 0] = np.nextafter(np.float64(0.01), np.float64(1.0))
    assert arrays.action_value[0, 0] != np.float64(np.float32(arrays.action_value[0, 0]))
    _validate_episode_arrays(arrays, metadata)
    encoded = _metadata_json(metadata)
    assert _parse_metadata_json(encoded) == metadata
    destination = tmp_path / f"{metadata['episode_id']}.hdf5"
    _write_episode_file(destination, metadata, arrays)
    actual_metadata, actual_arrays = _read_episode_file(destination)
    assert actual_metadata == metadata
    assert actual_arrays.action_value.dtype == np.float64
    for field in actual_arrays.__dataclass_fields__:
        np.testing.assert_array_equal(getattr(actual_arrays, field), getattr(arrays, field))
    partial = tmp_path / "interrupted.partial.hdf5"
    _write_episode_file(partial, metadata, arrays)
    with pytest.raises(ValueError, match="partial episode files"):
        _read_episode_file(partial)


def test_frozen_episode_schema_rejects_alignment_identity_and_mask_mutations() -> None:
    metadata, arrays = _episode_metadata(), _episode_arrays()
    with pytest.raises(ValueError, match="scenario identity and repeat_index"):
        _metadata_json({**metadata, "episode_id": "arbitrary"})
    with pytest.raises(ValueError, match="unknown fields"):
        _metadata_json({**metadata, "host_path": "forbidden"})
    duplicate_geom = [dict(entry) for entry in metadata["geom_table"]]
    duplicate_geom[1]["geom_name"] = duplicate_geom[0]["geom_name"]
    with pytest.raises(ValueError, match="geom_name values must be unique"):
        _metadata_json({**metadata, "geom_table": duplicate_geom})
    wrong_semantic = [dict(entry) for entry in metadata["geom_table"]]
    wrong_semantic[0]["semantic_identity"] = "another_asset"
    with pytest.raises(ValueError, match="concrete asset identity"):
        _metadata_json({**metadata, "geom_table": wrong_semantic})
    with pytest.raises(ValueError, match="frozen Action delay"):
        _validate_episode_arrays(
            replace(arrays, applied_tick=np.asarray([-1], dtype=np.int64)), metadata
        )
    delayed_metadata = {
        **metadata,
        "scenario_spec": scenario_to_dict(replace(_scenario(), action_delay_steps=1)),
    }
    _validate_episode_arrays(
        replace(arrays, applied_tick=np.asarray([-1], dtype=np.int64)), delayed_metadata
    )
    with pytest.raises(ValueError, match="frozen Action delay"):
        _validate_episode_arrays(arrays, delayed_metadata)
    bad_gripper = arrays.action_value.copy()
    bad_gripper[0, -1] = 0.5
    with pytest.raises(ValueError, match="gripper"):
        _validate_episode_arrays(replace(arrays, action_value=bad_gripper), metadata)
    excessive_delta = arrays.action_value.copy()
    excessive_delta[0, 0] = np.nextafter(np.float32(0.05), np.float32(np.inf))
    with pytest.raises(ValueError, match="execution-delta"):
        _validate_episode_arrays(replace(arrays, action_value=excessive_delta), metadata)
    bad_intrinsics = arrays.camera_intrinsics.copy()
    bad_intrinsics[0, 0, 0, 0] += 1.0
    with pytest.raises(ValueError, match="concrete ScenarioSpec calibration"):
        _validate_episode_arrays(replace(arrays, camera_intrinsics=bad_intrinsics), metadata)
    invalid_visible = arrays.flow_future_visible.copy()
    invalid_visible[0, 0, 0, 0] = True
    with pytest.raises(ValueError, match="subset"):
        _validate_episode_arrays(replace(arrays, flow_future_visible=invalid_visible), metadata)
    bad_flags = np.zeros_like(arrays.event_flags)
    bad_flags[0, 0], bad_flags[1, 0] = True, False
    with pytest.raises(ValueError, match="cumulative"):
        _validate_episode_arrays(replace(arrays, event_flags=bad_flags), metadata)
    reset_flags = np.ones_like(arrays.event_flags)
    with pytest.raises(ValueError, match="reset frame event_flags"):
        _validate_episode_arrays(replace(arrays, event_flags=reset_flags), metadata)
    success_metadata = {
        **metadata,
        "outcome": {
            "success": True,
            "termination_reason": "success",
            "failure_code": None,
        },
    }
    terminal_success = arrays.success.copy()
    terminal_success[-1] = True
    with pytest.raises(ValueError, match="complete every formal event"):
        _validate_episode_arrays(
            replace(arrays, success=terminal_success),
            success_metadata,
        )


def test_empty_b1_manifest_is_a_valid_ordered_shell() -> None:
    manifest = load_manifest(ROOT / "manifests" / "v1" / "validation.jsonl")
    assert isinstance(manifest, ScenarioManifest)
    assert tuple(manifest) == ()
    assert tuple(manifest.shard(0, 1)) == ()


def test_nonempty_manifest_round_trip_preserves_fixed_order_and_local_ordinals(
    tmp_path: Path,
) -> None:
    expected = ScenarioManifest((_row(ordinal=0), _row(ordinal=1)))
    path = tmp_path / "external.jsonl"
    write_manifest(expected, path)
    assert load_manifest(path) == expected
    assert tuple(load_manifest(path)) == expected.rows


def test_manifest_shards_preserve_original_ids_and_relative_order() -> None:
    manifest = ScenarioManifest(tuple(_row(ordinal=index) for index in range(3)))
    left = manifest.shard(0, 2)
    right = manifest.shard(1, 2)
    assert tuple(row.scenario_id for row in left) == (
        "v1:validation:grasp:000000",
        "v1:validation:grasp:000002",
    )
    assert tuple(row.scenario_id for row in right) == ("v1:validation:grasp:000001",)
    assert left.rows == (manifest.rows[0], manifest.rows[2])
    assert right.rows == (manifest.rows[1],)


def test_manifest_direct_construction_rejects_bad_order_duplicate_id_and_mixed_identity() -> None:
    with pytest.raises(ValueError, match="strictly increasing"):
        ScenarioManifest((_row(ordinal=1), _row(ordinal=0)))
    with pytest.raises(ValueError, match="duplicate scenario_id"):
        ScenarioManifest((_row(), _row()))
    with pytest.raises(ValueError, match="registry order"):
        ScenarioManifest((_row(task_id="t1_belt"), _row(task_id="grasp")))
    with pytest.raises(ValueError, match="partition/factor"):
        ScenarioManifest((_row(), _row(ordinal=1, partition="test_id")))
    with pytest.raises(ValueError, match="tuple"):
        ScenarioManifest([_row()])  # type: ignore[arg-type]


@pytest.mark.parametrize("schema_version", [True, 1.0])
def test_manifest_row_rejects_non_integer_schema_version(schema_version: object) -> None:
    with pytest.raises(ValueError, match="schema_version"):
        replace(_row(), schema_version=schema_version)  # type: ignore[arg-type]


def test_manifest_row_direct_construction_rejects_version_partition_factor_and_seed() -> None:
    row = _row()
    with pytest.raises(ValueError, match="schema_version"):
        replace(row, schema_version=2)
    with pytest.raises(ValueError, match="partition"):
        replace(row, partition="bad")  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="factor"):
        replace(row, factor="object")
    with pytest.raises(ValueError, match="source_seed"):
        replace(row, source_seed=True)
    with pytest.raises(ValueError, match="known factor"):
        _row(partition="ood", factor="bad")
    with pytest.raises(ValueError, match="geometry family"):
        replace(row, task_id="t1_belt", scenario_id="v1:validation:t1_belt:000000")


def test_manifest_rejects_duplicate_json_keys_with_path_context(tmp_path: Path) -> None:
    payload = json.dumps(_payload(_row()), separators=(",", ":"))
    duplicate = payload.replace('"schema_version":1', '"schema_version":1,"schema_version":1')
    path = tmp_path / "duplicate.jsonl"
    path.write_text(duplicate + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate JSON key") as error:
        load_manifest(path)
    assert str(path) in str(error.value)


def test_formal_manifest_basename_validates_partition_and_factor(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="requires partition/factor"):
        write_manifest(
            ScenarioManifest((_row(partition="validation"),)), tmp_path / "test_id.jsonl"
        )
    with pytest.raises(ValueError, match="requires partition/factor"):
        write_manifest(
            ScenarioManifest((_row(partition="ood", factor="object"),)),
            tmp_path / "ood_camera.jsonl",
        )
    write_manifest(
        ScenarioManifest((_row(partition="ood", factor="camera"),)),
        tmp_path / "ood_camera.jsonl",
    )
    with pytest.raises(ValueError, match="unknown formal OOD"):
        write_manifest(
            ScenarioManifest((_row(partition="ood", factor="camera"),)),
            tmp_path / "ood_unregistered.jsonl",
        )
    with pytest.raises(ValueError, match="unknown formal OOD"):
        write_manifest(ScenarioManifest(()), tmp_path / "ood_unregistered.jsonl")
    empty_unknown = tmp_path / "ood_unregistered.jsonl"
    empty_unknown.write_text("", encoding="utf-8")
    with pytest.raises(ValueError, match="unknown formal OOD"):
        load_manifest(empty_unknown)


def test_load_and_write_retain_full_manifest_contiguous_ordinal_checks(tmp_path: Path) -> None:
    gapped = ScenarioManifest((_row(ordinal=1),))
    with pytest.raises(ValueError, match="local ordinal"):
        write_manifest(gapped, tmp_path / "write_gap.jsonl")
    load_gap = tmp_path / "load_gap.jsonl"
    load_gap.write_text(json.dumps(_payload(_row(ordinal=1))) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="local ordinal"):
        load_manifest(load_gap)


def test_write_manifest_never_overwrites(tmp_path: Path) -> None:
    manifest = ScenarioManifest((_row(),))
    path = tmp_path / "external.jsonl"
    write_manifest(manifest, path)
    with pytest.raises(FileExistsError):
        write_manifest(manifest, path)


def test_manifest_preserves_json_error_and_adds_path(tmp_path: Path) -> None:
    path = tmp_path / "bad.jsonl"
    path.write_text("{bad json}\n", encoding="utf-8")
    with pytest.raises(json.JSONDecodeError, match="bad.jsonl"):
        load_manifest(path)


@pytest.mark.parametrize(("index", "count"), [(1, 1), (0, 0), (True, 1), (0, True), (0.0, 1)])
def test_manifest_rejects_invalid_shards(index: object, count: object) -> None:
    manifest = ScenarioManifest(rows=())
    with pytest.raises(ValueError, match="shard"):
        manifest.shard(index, count)  # type: ignore[arg-type]


def test_manifest_rejects_blank_physical_rows(tmp_path: Path) -> None:
    path = tmp_path / "blank.jsonl"
    path.write_text("\n", encoding="utf-8")
    with pytest.raises(ValueError, match="blank manifest rows"):
        load_manifest(path)


def test_generate_cli_preserves_seed_order_ids_and_structured_rejection(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    output = tmp_path / "test_id.jsonl"
    calls: list[int] = []

    def generated(*args: object, **kwargs: object) -> ScenarioSpec:
        seed = args[2]
        assert isinstance(seed, int)
        calls.append(seed)
        assert kwargs == {
            "partition": "test_id",
            "factor": None,
            "recipe_name": "e7_agentview",
        }
        return _scenario()

    monkeypatch.setattr(generate_cli, "generate_scenario", generated)
    generate_cli.main(
        (
            "--task-id",
            "grasp",
            "--recipe",
            str(tmp_path / "recipe.yaml"),
            "--partition",
            "test_id",
            "--recipe-name",
            "e7_agentview",
            "--seed",
            "7",
            "--count",
            "3",
            "--output",
            str(output),
        )
    )
    manifest = load_manifest(output)
    assert calls == [7, 8, 9]
    assert tuple(row.source_seed for row in manifest) == (7, 8, 9)
    assert tuple(row.scenario_id for row in manifest) == (
        "v1:test_id:grasp:000000",
        "v1:test_id:grasp:000001",
        "v1:test_id:grasp:000002",
    )

    rejected_output = tmp_path / "rejected.jsonl"
    calls.clear()

    def rejected(*args: object, **kwargs: object) -> ScenarioSpec:
        del kwargs
        seed = args[2]
        assert isinstance(seed, int)
        calls.append(seed)
        if seed == 8:
            raise RuntimeError("structured proposal rejection")
        return _scenario()

    monkeypatch.setattr(generate_cli, "generate_scenario", rejected)
    with pytest.raises(RuntimeError, match="structured proposal rejection"):
        generate_cli.main(
            (
                "--task-id",
                "grasp",
                "--recipe",
                str(tmp_path / "recipe.yaml"),
                "--partition",
                "test_id",
                "--recipe-name",
                "e7_agentview",
                "--seed",
                "7",
                "--count",
                "3",
                "--output",
                str(rejected_output),
            )
        )
    assert calls == [7, 8]
    assert not rejected_output.exists()


def test_generate_cli_requires_exact_partition_factor_and_never_overwrites(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    output = tmp_path / "manifest.jsonl"
    output.write_text("owned\n", encoding="utf-8")

    def unexpected(*args: object, **kwargs: object) -> ScenarioSpec:
        raise AssertionError((args, kwargs))

    monkeypatch.setattr(generate_cli, "generate_scenario", unexpected)
    with pytest.raises(FileExistsError):
        generate_cli.main(
            (
                "--task-id",
                "grasp",
                "--recipe",
                "unused.yaml",
                "--partition",
                "test_id",
                "--recipe-name",
                "e7_agentview",
                "--seed",
                "0",
                "--count",
                "1",
                "--output",
                str(output),
            )
        )
    assert output.read_text(encoding="utf-8") == "owned\n"
    with pytest.raises(ValueError, match="requires one known factor"):
        generate_cli.main(
            (
                "--task-id",
                "grasp",
                "--recipe",
                "unused.yaml",
                "--partition",
                "ood",
                "--recipe-name",
                "e7_agentview",
                "--seed",
                "0",
                "--count",
                "1",
                "--output",
                str(tmp_path / "ood.jsonl"),
            )
        )
    with pytest.raises(ValueError, match="only valid for OOD"):
        generate_cli.main(
            (
                "--task-id",
                "grasp",
                "--recipe",
                "unused.yaml",
                "--partition",
                "test_id",
                "--factor",
                "object",
                "--recipe-name",
                "e7_agentview",
                "--seed",
                "0",
                "--count",
                "1",
                "--output",
                str(tmp_path / "test.jsonl"),
            )
        )


def test_explicit_policy_factory_rejects_discovery_and_invalid_objects(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    module = tmp_path / "b36_explicit_policy.py"
    module.write_text(
        """class Policy:
    def reset(self):
        return None

    def act(self, observation):
        raise AssertionError(observation)

def build():
    return Policy()

def missing_act():
    return object()

not_a_factory = 1
""",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))
    policy = _load_policy_factory("b36_explicit_policy:build")
    policy.reset()
    assert callable(policy.act)
    for specification in ("", "b36_explicit_policy", ":build", "b36_explicit_policy:"):
        with pytest.raises(ValueError, match="explicit module:factory"):
            _load_policy_factory(specification)
    with pytest.raises(ValueError, match="factory must be callable"):
        _load_policy_factory("b36_explicit_policy:not_a_factory")
    with pytest.raises(ValueError, match="callable reset and act"):
        _load_policy_factory("b36_explicit_policy:missing_act")


def test_evaluate_cli_writes_only_the_requested_suite_summary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    output = tmp_path / "summary.json"
    policy = object()
    calls: list[tuple[object, Path, int, int, float | None, float]] = []

    monkeypatch.setattr(evaluate_cli, "_load_policy_factory", lambda value: policy)

    def evaluated(
        actual_policy: object,
        suite: Path,
        *,
        shard_index: int,
        shard_count: int,
        wall_control_period_s: float | None,
        execution_translation_limit_m: float,
    ) -> EvaluationSummary:
        calls.append(
            (
                actual_policy,
                suite,
                shard_index,
                shard_count,
                wall_control_period_s,
                execution_translation_limit_m,
            )
        )
        return EvaluationSummary((), ())

    monkeypatch.setattr(evaluate_cli, "evaluate", evaluated)
    evaluate_cli.main(
        (
            "--suite",
            str(tmp_path / "suite.yaml"),
            "--policy",
            "explicit:build",
            "--shard-index",
            "2",
            "--shard-count",
            "5",
            "--wall-control-period-s",
            "0.1",
            "--execution-translation-limit-m",
            "0.1",
            "--output",
            str(output),
        )
    )
    assert calls == [(policy, tmp_path / "suite.yaml", 2, 5, 0.1, 0.1)]
    assert json.loads(output.read_text(encoding="utf-8")) == {"groups": [], "results": []}
    unpaced_output = tmp_path / "unpaced.json"
    evaluate_cli.main(
        (
            "--suite",
            str(tmp_path / "suite.yaml"),
            "--policy",
            "explicit:build",
            "--output",
            str(unpaced_output),
        )
    )
    assert calls[-1] == (policy, tmp_path / "suite.yaml", 0, 1, None, 0.05)
    with pytest.raises(FileExistsError):
        evaluate_cli.main(
            (
                "--suite",
                "not-read.yaml",
                "--policy",
                "not:loaded",
                "--output",
                str(output),
            )
        )
    assert len(calls) == 2


@pytest.mark.parametrize("limit", [0.0, 0.075, np.nan, np.inf, True, "0.1", 0.1 + 0j])
def test_public_evaluate_rejects_invalid_execution_limit_before_loading_suite(
    tmp_path: Path,
    limit: object,
) -> None:
    with pytest.raises(ValueError, match="execution_translation_limit_m"):
        evaluate(
            cast(BenchmarkPolicy, object()),
            tmp_path / "not-read.yaml",
            execution_translation_limit_m=cast(float, limit),
        )


def test_episode_metadata_limits_govern_float32_delta_boundaries() -> None:
    metadata, arrays = _episode_metadata(), _episode_arrays()
    arrays.action_value[0] = np.asarray([0.1, -0.1, 0.1, 0.5, -0.5, 0.5, -1], dtype=np.float32)
    with pytest.raises(ValueError, match="execution-delta"):
        _validate_episode_arrays(arrays, metadata)
    metadata["action_spec"] = {
        "mode": "E7",
        "representation": "delta",
        "motion_limits": [0.10, 0.10, 0.10, 0.5, 0.5, 0.5],
    }
    _validate_episode_arrays(arrays, _parse_metadata_json(_metadata_json(metadata)))
    arrays.action_value[0, 0] = np.nextafter(np.float32(0.1), np.float32(np.inf))
    with pytest.raises(ValueError, match="execution-delta"):
        _validate_episode_arrays(arrays, metadata)


@pytest.mark.parametrize("period", [0.0, -0.1, np.nan, np.inf, -np.inf, True])
def test_public_evaluate_rejects_invalid_wall_period_before_loading_suite(
    tmp_path: Path,
    period: object,
) -> None:
    with pytest.raises(ValueError, match="wall_control_period_s"):
        evaluate(
            cast(BenchmarkPolicy, object()),
            tmp_path / "not-read.yaml",
            wall_control_period_s=cast(float, period),
        )


def test_record_cli_uses_manifest_global_line_modulo_and_the_sole_rollout(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manifest_path = tmp_path / "validation.jsonl"
    write_manifest(
        ScenarioManifest(tuple(_row(ordinal=index) for index in range(5))), manifest_path
    )
    output = tmp_path / "episodes"
    output.mkdir()
    policy = object()
    calls: list[tuple[str, int, object, Path]] = []
    monkeypatch.setattr(record_cli, "_load_policy_factory", lambda value: policy)

    def rolled_out(
        task: object,
        scenario: ScenarioSpec,
        actual_policy: object,
        *,
        scenario_id: str,
        partition: str,
        factor: str | None,
        repeat_index: int,
        record_directory: Path,
        _native_oracle: bool,
        execution_translation_limit_m: float,
    ) -> None:
        del task, scenario, partition, factor
        assert not _native_oracle
        assert execution_translation_limit_m == 0.10
        calls.append((scenario_id, repeat_index, actual_policy, record_directory))

    monkeypatch.setattr(record_cli, "_rollout_episode", rolled_out)
    record_cli.main(
        (
            "--manifest",
            str(manifest_path),
            "--policy",
            "explicit:build",
            "--shard-index",
            "1",
            "--execution-translation-limit-m",
            "0.10",
            "--shard-count",
            "2",
            "--output",
            str(output),
        )
    )
    assert calls == [
        ("v1:validation:grasp:000001", 0, policy, output),
        ("v1:validation:grasp:000003", 0, policy, output),
    ]


def test_recorded_raw_event_times_keep_exact_physics_times_and_stage_vocabulary() -> None:
    metadata = _episode_metadata()
    metadata["event_times_s"] = {
        "target_enters_observation_region": 0.0,
        "downstream_exit": 6.439999999999513,
    }
    original_names = metadata["event_names"]
    encoded = _metadata_json(metadata)
    decoded = _parse_metadata_json(encoded)
    assert decoded["event_names"] == original_names
    assert decoded["event_times_s"] == metadata["event_times_s"]
    _validate_episode_arrays(_episode_arrays(), decoded)


@pytest.mark.parametrize("time_s", [True, -0.002, float("nan"), float("inf"), "8.0"])
def test_recorded_raw_event_times_reject_invalid_values(time_s: object) -> None:
    metadata = _episode_metadata()
    metadata["event_times_s"] = {"timeout": time_s}
    with pytest.raises(ValueError, match="finite and non-negative"):
        _metadata_json(metadata)
