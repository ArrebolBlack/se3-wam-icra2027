from __future__ import annotations

import copy
from dataclasses import replace
from pathlib import Path
from typing import Any

import pytest

from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.scenarios import spec
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.tasks.registry import load_task

ROOT = Path(__file__).resolve().parents[2]


def _object(instance_id: str) -> dict[str, object]:
    return {
        "instance_id": instance_id,
        "asset_id": f"asset_{instance_id}",
        "position_world_m": [0.0, 0.0, 0.1],
        "quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
        "linear_velocity_world_m_s": [0.0, 0.0, 0.0],
        "angular_velocity_world_rad_s": [0.0, 0.0, 0.0],
    }


def _fixture(instance_id: str) -> dict[str, object]:
    return {
        "instance_id": instance_id,
        "asset_id": f"asset_{instance_id}",
        "position_world_m": [0.0, 0.0, 0.0],
        "quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
    }


def scenario_dict(family: str) -> dict[str, Any]:
    entities: dict[str, tuple[list[dict[str, object]], list[dict[str, object]]]] = {
        "grasp": ([_object("target")], [_fixture("table")]),
        "driven_interception": (
            [_object("target")],
            [_fixture("belt"), _fixture("occluder")],
        ),
        "moving_placement": ([_object("payload")], [_fixture("goal")]),
        "rotating_interaction": (
            [_object("wand")],
            [_fixture("wire"), _fixture("cradle")],
        ),
        "free_dynamics_interception": (
            [_object("target")],
            [_fixture("ramp"), _fixture("gate"), _fixture("safety_tray")],
        ),
        "replanning": (
            [_object("target")],
            [_fixture("belt"), _fixture("left_striker"), _fixture("right_striker")],
        ),
    }
    geometries: dict[str, dict[str, object]] = {
        "grasp": {
            "support_surface_z_m": 0.0,
            "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
            "downstream_exit_y_m": 0.6,
        },
        "driven_interception": {
            "support_surface_z_m": 0.0,
            "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
            "capture_corridor_bounds_xy_m": [[-0.2, -0.2], [0.2, 0.2]],
            "downstream_exit_y_m": 0.6,
            "occlusion_target_clearance_m": 0.0,
        },
        "moving_placement": {
            "support_surface_z_m": 0.0,
            "goal_planar_clearance_m": 0.02,
            "goal_bottom_center_z_m": 0.05,
            "goal_window_exit_y_m": 0.4,
        },
        "rotating_interaction": {
            "frame_center_world_m": [0.0, 0.0, 0.3],
            "rotation_axis_world": [0.0, 0.0, 1.0],
            "wire_radius_m": 0.01,
            "wire_path_points_frame_m": [[0.0, 0.0, 0.0], [0.1, 0.0, 0.0]],
        },
        "free_dynamics_interception": {
            "support_surface_z_m": 0.0,
            "ramp_angle_rad": 0.2,
            "ramp_downstream_lip_world_m": [0.0, 0.1, 0.2],
            "ramp_half_size_m": [0.2, 0.3, 0.02],
            "capture_region_bounds_world_m": [[-0.2, -0.2, 0.0], [0.2, 0.2, 0.4]],
            "exit_region_bounds_xy_m": [[-0.3, -0.3], [0.3, 0.3]],
        },
        "replanning": {
            "support_surface_z_m": 0.0,
            "observation_boundary_y_m": 0.1,
            "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
            "striker_travel_m": 0.1,
        },
    }
    objects, fixtures = entities[family]
    physics_entity = objects[0]["instance_id"]
    motion_entity = "belt" if family == "driven_interception" else physics_entity
    motion: list[dict[str, object]] = []
    if family != "free_dynamics_interception":
        motion = [
            {
                "entity_id": motion_entity,
                "translation": {"type": "fixed"},
                "rotation": {"type": "fixed"},
            }
        ]
    events: list[dict[str, object]] = []
    if family == "free_dynamics_interception":
        events = [
            {
                "event_id": "release",
                "trigger": {"type": "time", "control_tick": 0},
                "effect": {
                    "type": "release_gate_retraction",
                    "gate_entity_id": "gate",
                    "parked_position_world_m": [0.0, -0.25, 0.55],
                },
            }
        ]
    elif family == "replanning":
        events = [
            {
                "event_id": "strike",
                "trigger": {"type": "state"},
                "effect": {
                    "type": "striker_pulse",
                    "striker_entity_id": "left_striker",
                    "joint_name": "slide",
                    "strike_position_m": 0.1,
                    "pulse_duration_s": 0.1,
                    "kp_n_m": 100.0,
                    "kd_n_s_m": 5.0,
                    "maximum_force_n": 20.0,
                    "actuator_scale": 1.0,
                    "contact_cutoff_delay_s": 0.01,
                    "contact_grouping_hysteresis_s": 0.01,
                    "maximum_contact_duration_s": 0.2,
                },
            }
        ]
    return {
        "action_mode": "E7",
        "observation_profile": "agentview",
        "physics_timestep_s": 0.002,
        "control_frequency_hz": 20,
        "sensor_frequency_hz": 20,
        "action_delay_steps": 0,
        "robot_initial_state": {
            "joint_position_rad": [0.0] * 7,
            "gripper_position_m": [0.0, 0.0],
        },
        "object_states": objects,
        **(
            {"preparation_object_states": copy.deepcopy(objects)}
            if family == "free_dynamics_interception"
            else {}
        ),
        "fixture_states": fixtures,
        "geometry": geometries[family],
        "motion": motion,
        "physics": {
            "gravity_world_m_s2": [0.0, 0.0, -9.81],
            "bodies": [
                {
                    "entity_id": physics_entity,
                    "mass_kg": 0.2,
                    "diagonal_inertia_kg_m2": [0.01, 0.01, 0.01],
                }
            ],
            "contacts": [
                {
                    "entity_id": physics_entity,
                    "friction_slide_spin_roll": [0.8, 0.01, 0.001],
                    "solref": [0.02, 1.0],
                    "solimp": [0.9, 0.95, 0.001, 0.5, 2.0],
                }
            ],
            "joints": [
                {
                    "entity_id": physics_entity,
                    "joint_name": "free",
                    "damping_per_dof": [0.0],
                    "friction_loss_per_dof": [0.0],
                }
            ],
        },
        "cameras": {
            "image_height_px": 224,
            "image_width_px": 224,
            "views": [
                {
                    "view_name": "agentview",
                    "position_parent_m": [0.0, -1.0, 1.0],
                    "quaternion_parent_xyzw": [0.0, 0.0, 0.0, 1.0],
                    "vertical_fov_deg": 45.0,
                }
            ],
        },
        "lighting": {
            "lights": [
                {
                    "light_id": "key",
                    "position_world_m": [0.0, 0.0, 2.0],
                    "direction_world": [0.0, 0.0, -1.0],
                    "ambient_rgb": [0.1, 0.1, 0.1],
                    "diffuse_rgb": [0.8, 0.8, 0.8],
                    "specular_rgb": [0.2, 0.2, 0.2],
                    "attenuation": [1.0, 0.0, 0.0],
                    "cutoff_deg": 90.0,
                    "active": True,
                }
            ]
        },
        "events": events,
    }


@pytest.mark.parametrize(
    "family",
    [
        "grasp",
        "driven_interception",
        "moving_placement",
        "rotating_interaction",
        "free_dynamics_interception",
        "replanning",
    ],
)
def test_all_six_geometry_records_round_trip(family: str) -> None:
    decoded = spec.scenario_from_dict(scenario_dict(family), family=family)  # type: ignore[arg-type]
    assert spec.family_for_geometry(decoded.geometry) == family
    assert spec.scenario_from_dict(spec.scenario_to_dict(decoded), family=family) == decoded


TRANSLATIONS = (
    {"type": "fixed"},
    {"type": "constant_velocity", "velocity_world_m_s": [0.1, 0.0, 0.0]},
    {
        "type": "harmonic",
        "center_world_m": [0.0, 0.0, 0.1],
        "drift_velocity_world_m_s": [0.0, 0.0, 0.0],
        "amplitude_m": [0.1, 0.0, 0.0],
        "frequency_hz": [1.0, 0.0, 0.0],
        "phase_rad": [0.0, 0.0, 0.0],
    },
    {
        "type": "circular",
        "center_world_m": [0.0, 0.0, 0.1],
        "axis_world": [0.0, 0.0, 1.0],
        "radial_direction_world": [1.0, 0.0, 0.0],
        "radius_m": 0.1,
        "angular_speed_rad_s": 1.0,
        "phase_rad": 0.0,
    },
)
ROTATIONS = (
    {"type": "fixed"},
    {
        "type": "constant_angular_velocity",
        "axis_world": [0.0, 0.0, 1.0],
        "angular_speed_rad_s": 1.0,
    },
    {
        "type": "harmonic",
        "base_quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
        "axis_world": [0.0, 1.0, 0.0],
        "amplitude_rad": 0.5,
        "frequency_hz": 1.0,
        "phase_rad": 0.0,
    },
)


@pytest.mark.parametrize("translation", TRANSLATIONS)
@pytest.mark.parametrize("rotation", ROTATIONS)
def test_all_translation_and_rotation_records_round_trip(
    translation: dict[str, object], rotation: dict[str, object]
) -> None:
    raw = scenario_dict("grasp")
    raw["motion"][0]["translation"] = copy.deepcopy(translation)
    raw["motion"][0]["rotation"] = copy.deepcopy(rotation)
    decoded = spec.scenario_from_dict(raw, family="grasp")
    assert spec.scenario_from_dict(spec.scenario_to_dict(decoded), family="grasp") == decoded


def test_harmonic_drift_round_trips_without_a_new_law_type() -> None:
    raw = scenario_dict("driven_interception")
    translation = copy.deepcopy(TRANSLATIONS[2])
    translation["drift_velocity_world_m_s"] = [-0.02, 0.07, 0.01]
    raw["motion"][0]["translation"] = translation
    scenario = spec.scenario_from_dict(raw, family="driven_interception")
    law = scenario.motion[0].translation
    assert isinstance(law, spec.HarmonicTranslation)
    assert law.drift_velocity_world_m_s == (-0.02, 0.07, 0.01)
    encoded = spec.scenario_to_dict(scenario)
    assert encoded["motion"][0]["translation"] == translation
    assert spec.scenario_from_dict(encoded, family="driven_interception") == scenario


def test_harmonic_drift_is_required_in_parser_and_direct_construction() -> None:
    raw = scenario_dict("driven_interception")
    translation = copy.deepcopy(TRANSLATIONS[2])
    del translation["drift_velocity_world_m_s"]
    raw["motion"][0]["translation"] = translation
    with pytest.raises(ValueError, match="missing fields.*drift_velocity_world_m_s"):
        spec.scenario_from_dict(raw, family="driven_interception")
    with pytest.raises(TypeError, match="drift_velocity_world_m_s"):
        spec.HarmonicTranslation(
            center_world_m=(0.0, 0.0, 0.0),
            amplitude_m=(0.1, 0.0, 0.0),
            frequency_hz=(1.0, 0.0, 0.0),
            phase_rad=(0.0, 0.0, 0.0),
        )


@pytest.mark.parametrize(
    "invalid",
    [
        [],
        [0.0, 0.0],
        [0.0] * 4,
        [True, 0.0, 0.0],
        [float("nan"), 0.0, 0.0],
        [0.0, float("inf"), 0.0],
        [0.0, 0.0, "0"],
    ],
)
def test_harmonic_drift_rejects_invalid_vectors_in_both_entry_points(invalid: list[object]) -> None:
    raw = scenario_dict("driven_interception")
    translation = copy.deepcopy(TRANSLATIONS[2])
    translation["drift_velocity_world_m_s"] = invalid
    raw["motion"][0]["translation"] = translation
    with pytest.raises(ValueError, match="drift_velocity_world_m_s"):
        spec.scenario_from_dict(raw, family="driven_interception")
    with pytest.raises(ValueError, match="drift_velocity_world_m_s"):
        spec.HarmonicTranslation(
            center_world_m=(0.0, 0.0, 0.0),
            drift_velocity_world_m_s=tuple(invalid),
            amplitude_m=(0.1, 0.0, 0.0),
            frequency_hz=(1.0, 0.0, 0.0),
            phase_rad=(0.0, 0.0, 0.0),
        )


def test_three_trigger_variants_and_two_effect_variants_are_closed() -> None:
    t4 = spec.scenario_from_dict(
        scenario_dict("free_dynamics_interception"), family="free_dynamics_interception"
    )
    assert isinstance(t4.events[0].trigger, spec.TimeTriggerSpec)
    assert isinstance(t4.events[0].effect, spec.ReleaseGateRetractionEffectSpec)
    t5 = spec.scenario_from_dict(scenario_dict("replanning"), family="replanning")
    assert isinstance(t5.events[0].trigger, spec.StateTriggerSpec)
    assert isinstance(t5.events[0].effect, spec.StrikerPulseEffectSpec)

    contact = scenario_dict("replanning")
    contact["events"][0]["trigger"] = {
        "type": "contact",
        "entity_a_id": "target",
        "entity_b_id": "belt",
        "minimum_normal_force_n": 0.0,
    }
    with pytest.raises(ValueError, match="StateTriggerSpec"):
        spec.scenario_from_dict(contact, family="replanning")

    old_name = scenario_dict("replanning")
    old_name["events"][0]["trigger"] = {"type": "target_boundary_crossing"}
    with pytest.raises(ValueError, match="unknown event trigger"):
        spec.scenario_from_dict(old_name, family="replanning")
    assert not hasattr(spec, "TargetBoundaryCrossingTriggerSpec")


def test_scenario_parser_rejects_unknown_missing_and_invalid_family() -> None:
    unknown = scenario_dict("grasp")
    unknown["unexpected"] = 1
    with pytest.raises(ValueError, match="unknown fields"):
        spec.scenario_from_dict(unknown, family="grasp")
    missing = scenario_dict("grasp")
    del missing["physics"]
    with pytest.raises(ValueError, match="missing fields"):
        spec.scenario_from_dict(missing, family="grasp")
    with pytest.raises(ValueError, match="invalid scenario family"):
        spec.scenario_from_dict(scenario_dict("grasp"), family="invalid")  # type: ignore[arg-type]


@pytest.mark.parametrize("dimension", [True, 224.0])
def test_scenario_parser_requires_exact_integer_camera_raster(dimension: object) -> None:
    raw = scenario_dict("grasp")
    raw["cameras"]["image_height_px"] = dimension
    with pytest.raises(ValueError, match="224x224"):
        spec.scenario_from_dict(raw, family="grasp")


def test_direct_record_construction_and_replace_share_strict_validation() -> None:
    scenario = spec.scenario_from_dict(scenario_dict("grasp"), family="grasp")
    with pytest.raises(ValueError, match="action_mode"):
        replace(scenario, action_mode="bad")  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="action_mode"):
        replace(scenario, action_mode=[])  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="control_frequency_hz"):
        replace(scenario, control_frequency_hz=True)
    with pytest.raises(ValueError, match="physics_timestep_s"):
        replace(scenario, physics_timestep_s=float("nan"))
    with pytest.raises(ValueError, match="224x224"):
        replace(scenario.cameras, image_height_px=224.0)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="unit length"):
        replace(scenario.object_states[0], quaternion_world_xyzw=(0.0, 0.0, 0.0, 2.0))
    with pytest.raises(ValueError, match="length 3"):
        spec.ConstantVelocityTranslation((0.0, 0.0))  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="unit length"):
        spec.ConstantAngularVelocityRotation((0.0, 0.0, 2.0), 1.0)
    with pytest.raises(ValueError, match="bounds"):
        spec.GraspGeometrySpec(0.0, ((0.0, 0.0), (0.0, 1.0)), 1.0)
    with pytest.raises(ValueError, match="unknown entity"):
        replace(
            scenario,
            motion=(
                spec.DrivenMotionSpec("missing", spec.FixedTranslation(), spec.FixedRotation()),
            ),
        )
    with pytest.raises(ValueError, match="do not accept events"):
        replace(
            scenario,
            events=(
                spec.EventSpec(
                    "illegal",
                    spec.TimeTriggerSpec(0),
                    spec.ReleaseGateRetractionEffectSpec("table", (0.0, -0.25, 0.55)),
                ),
            ),
        )


def test_geometry_domain_invariants_reject_out_of_workspace_corridor_and_zero_goal_height() -> None:
    with pytest.raises(ValueError, match="contained"):
        spec.DrivenInterceptionGeometrySpec(
            0.0,
            ((-0.5, -0.5), (0.5, 0.5)),
            ((-0.6, -0.2), (0.2, 0.2)),
            0.6,
            0.0,
        )
    with pytest.raises(ValueError, match="bottom_center"):
        spec.MovingPlacementGeometrySpec(0.0, 0.02, 0.0, 0.4)


def test_make_env_validates_bindings_before_family_construction() -> None:
    grasp = spec.scenario_from_dict(scenario_dict("grasp"), family="grasp")
    with pytest.raises(ValueError, match="one bound target"):
        make_env("grasp", grasp)
    with pytest.raises(ValueError, match="unknown task"):
        make_env([], grasp)  # type: ignore[arg-type]

    missing_target = scenario_dict("grasp")
    missing_target["object_states"][0]["instance_id"] = "other"
    missing_target["physics"]["bodies"][0]["entity_id"] = "other"
    missing_target["physics"]["contacts"][0]["entity_id"] = "other"
    missing_target["physics"]["joints"][0]["entity_id"] = "other"
    missing_target["motion"][0]["entity_id"] = "other"
    with pytest.raises(ValueError, match="object bindings"):
        make_env("grasp", spec.scenario_from_dict(missing_target, family="grasp"))

    driven = scenario_dict("driven_interception")
    with pytest.raises(ValueError, match="exactly its target"):
        make_env("t1_belt", spec.scenario_from_dict(driven, family="driven_interception"))
    with pytest.raises(ValueError, match="exactly its target"):
        make_env("t1_occ", spec.scenario_from_dict(driven, family="driven_interception"))
    with pytest.raises(ValueError, match="GeometrySpec"):
        make_env(
            "grasp",
            spec.scenario_from_dict(driven, family="driven_interception"),
        )
    driven["geometry"]["occlusion_target_clearance_m"] = 0.01
    with pytest.raises(ValueError, match="only t1_occ"):
        make_env(
            "t1_belt",
            spec.scenario_from_dict(driven, family="driven_interception"),
        )

    t4_raw = scenario_dict("free_dynamics_interception")
    t4_raw["events"][0]["effect"]["gate_entity_id"] = "ramp"
    with pytest.raises(ValueError, match="bound release gate"):
        make_env(
            "t4_sphere",
            spec.scenario_from_dict(t4_raw, family="free_dynamics_interception"),
        )

    t5_raw = scenario_dict("replanning")
    t5_raw["events"][0]["effect"]["striker_entity_id"] = "belt"
    with pytest.raises(ValueError, match="bound striker"):
        make_env(
            "t5_replan",
            spec.scenario_from_dict(t5_raw, family="replanning"),
        )


@pytest.mark.parametrize("seed", [True, 1.5, "1"])
def test_generator_rejects_bool_and_non_integer_seed_before_b2(seed: object) -> None:
    with pytest.raises(ValueError, match="seed"):
        generate_scenario(
            load_task("grasp"),
            ROOT / "configs" / "scenarios" / "grasp.yaml",
            seed,  # type: ignore[arg-type]
            partition="test_id",
            recipe_name="e7_agentview",
        )


@pytest.mark.parametrize("change", ["missing", "entity", "asset", "twist", "duplicate"])
def test_t4_preparation_input_is_explicit_and_bound_to_the_released_target(change: str) -> None:
    data = scenario_dict("free_dynamics_interception")
    if change == "missing":
        data.pop("preparation_object_states")
    elif change == "entity":
        data["preparation_object_states"][0]["instance_id"] = "other"
    elif change == "asset":
        data["preparation_object_states"][0]["asset_id"] = "other_asset"
    elif change == "twist":
        data["preparation_object_states"][0]["linear_velocity_world_m_s"][0] = 0.1
    else:
        data["preparation_object_states"].append(
            copy.deepcopy(data["preparation_object_states"][0])
        )
    with pytest.raises(ValueError):
        spec.scenario_from_dict(data, family="free_dynamics_interception")


def test_t4_preparation_preserves_the_full_signed_input_pose_in_serialization() -> None:
    data = scenario_dict("free_dynamics_interception")
    state = data["preparation_object_states"][0]
    state["position_world_m"] = [-0.027566411144412988, -0.014006824747854106, 0.8300000000000001]
    state["quaternion_world_xyzw"] = [0.0, 0.0, 0.8751793497317224, -0.4837986211257319]
    parsed = spec.scenario_from_dict(data, family="free_dynamics_interception")
    assert spec.scenario_to_dict(parsed) == data
