from __future__ import annotations

import math

import mujoco
import numpy as np
import pytest

from se3_wam_benchmark.envs.components.events import (
    _ContactSample,
    _EventRuntime,
    _EventStepResult,
    _JointState,
    _mujoco_contact_samples,
    _ReleaseGateCommand,
    _StrikerCommand,
)
from se3_wam_benchmark.scenarios.spec import (
    ContactTriggerSpec,
    EventSpec,
    ReleaseGateRetractionEffectSpec,
    StateTriggerSpec,
    StrikerPulseEffectSpec,
    TimeTriggerSpec,
)

_CONTACT_XML = """
<mujoco model="contact-bridge-test">
  <option timestep="0.002" gravity="0 0 -9.81"/>
  <worldbody>
    <geom name="floor_geom" type="plane" size="2 2 0.1"/>
    <body name="left_body" pos="-0.5 0 0.19">
      <freejoint/>
      <geom name="left_geom" type="box" size="0.2 0.2 0.2" mass="1"/>
    </body>
    <body name="right_body" pos="0.5 0 0.19">
      <freejoint/>
      <geom name="right_geom" type="box" size="0.2 0.2 0.2" mass="1"/>
    </body>
    <body name="floating_body" pos="0 1 1">
      <freejoint/>
      <geom name="floating_geom" type="sphere" size="0.1" mass="1"/>
    </body>
  </worldbody>
</mujoco>
"""


def _contact_model_and_data() -> tuple[
    mujoco.MjModel,
    mujoco.MjData,
    dict[str, tuple[int, ...]],
]:
    model = mujoco.MjModel.from_xml_string(_CONTACT_XML)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    geom_ids = {
        entity_id: (mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, geom_name),)
        for entity_id, geom_name in {
            "floor": "floor_geom",
            "left": "left_geom",
            "right": "right_geom",
            "floating": "floating_geom",
        }.items()
    }
    return model, data, geom_ids


def _release_event(event_id: str, trigger: object) -> EventSpec:
    return EventSpec(
        event_id,
        trigger,  # type: ignore[arg-type]
        ReleaseGateRetractionEffectSpec("gate", (0.0, -0.25, 0.55)),
    )


def _striker_event() -> EventSpec:
    return EventSpec(
        "strike",
        StateTriggerSpec(),
        StrikerPulseEffectSpec(
            striker_entity_id="left_striker",
            joint_name="slide",
            strike_position_m=0.098,
            pulse_duration_s=0.350,
            kp_n_m=100.0,
            kd_n_s_m=1.0,
            maximum_force_n=4.0,
            actuator_scale=1.1,
            contact_cutoff_delay_s=0.020,
            contact_grouping_hysteresis_s=0.012,
            maximum_contact_duration_s=0.100,
        ),
    )


def _striker_runtime(*, rest_position_m: float = 0.0) -> _EventRuntime:
    runtime = _EventRuntime(
        (_striker_event(),),
        state_trigger_target_entity_id="target",
        observation_boundary_y_m=-0.130,
    )
    runtime.reset(
        simulator_time_s=0.0,
        target_body_y_m=-0.140,
        joint_states={
            ("left_striker", "slide"): _JointState(rest_position_m, 0.0),
        },
    )
    return runtime


def _step_striker(
    runtime: _EventRuntime,
    time_s: float,
    *,
    target_y_m: float = -0.120,
    contact: bool = False,
    joint_position_m: float = 0.0,
    joint_velocity_m_s: float = 0.0,
) -> _EventStepResult:
    contacts = (_ContactSample("target", "left_striker", 1.0),) if contact else ()
    return runtime.step(
        simulator_time_s=time_s,
        control_tick=int(time_s / 0.05),
        contacts=contacts,
        joint_states={("left_striker", "slide"): _JointState(joint_position_m, joint_velocity_m_s)},
        target_body_y_m=target_y_m,
    )


def test_time_trigger_is_single_fire_and_reset_rearms_the_episode() -> None:
    runtime = _EventRuntime((_release_event("release", TimeTriggerSpec(0)),))
    runtime.reset(simulator_time_s=0.0, joint_states={})
    first = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    assert first.fired_event_ids == ("release",)
    assert first.event_flags == (True,)
    assert isinstance(first.actuator_commands[0], _ReleaseGateCommand)
    assert first.actuator_commands[0].parked_position_world_m == (0.0, -0.25, 0.55)

    second = runtime.step(
        simulator_time_s=0.002,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    assert second.fired_event_ids == ()
    assert second.event_flags == (True,)
    assert second.actuator_commands == ()

    runtime.reset(simulator_time_s=0.0, joint_states={})
    reset_first = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    assert reset_first.fired_event_ids == ("release",)


def test_time_trigger_requires_exact_contiguous_control_tick() -> None:
    runtime = _EventRuntime((_release_event("release", TimeTriggerSpec(2)),))
    runtime.reset(simulator_time_s=0.0, joint_states={})
    tick_zero = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    assert tick_zero.event_flags == (False,)
    same_tick = runtime.step(
        simulator_time_s=0.002,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    assert same_tick.event_flags == (False,)
    tick_one = runtime.step(
        simulator_time_s=0.050,
        control_tick=1,
        contacts=(),
        joint_states={},
    )
    assert tick_one.event_flags == (False,)
    tick_two = runtime.step(
        simulator_time_s=0.100,
        control_tick=2,
        contacts=(),
        joint_states={},
    )
    assert tick_two.fired_event_ids == ("release",)

    runtime.reset(simulator_time_s=0.0, joint_states={})
    with pytest.raises(ValueError, match="first control_tick"):
        runtime.step(
            simulator_time_s=0.0,
            control_tick=1,
            contacts=(),
            joint_states={},
        )
    runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
    )
    with pytest.raises(ValueError, match="increase by exactly one"):
        runtime.step(
            simulator_time_s=0.002,
            control_tick=2,
            contacts=(),
            joint_states={},
        )


def test_contact_trigger_uses_aggregated_pair_force_and_inclusive_threshold() -> None:
    event = _release_event("contact", ContactTriggerSpec("target", "gate", 5.0))
    runtime = _EventRuntime((event,))
    runtime.reset(simulator_time_s=0.0, joint_states={})
    below = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(_ContactSample("gate", "target", 4.999),),
        joint_states={},
    )
    assert below.event_flags == (False,)
    exact = runtime.step(
        simulator_time_s=0.002,
        control_tick=0,
        contacts=(_ContactSample("target", "gate", 5.0),),
        joint_states={},
    )
    assert exact.fired_event_ids == ("contact",)


def test_real_mujoco_bridge_aggregates_contact_points_in_requested_pair_order() -> None:
    model, data, geom_ids = _contact_model_and_data()
    requested_pairs = (
        ("right", "floor"),
        ("floating", "floor"),
        ("floor", "left"),
    )
    samples = _mujoco_contact_samples(
        model,
        data,
        requested_entity_pairs=requested_pairs,
        entity_geom_ids=geom_ids,
    )

    assert data.ncon == 8
    assert tuple((sample.entity_a_id, sample.entity_b_id) for sample in samples) == (
        ("right", "floor"),
        ("floor", "left"),
    )
    geom_owners = {
        geom_id: entity_id
        for entity_id, entity_geoms in geom_ids.items()
        for geom_id in entity_geoms
    }
    direct_forces: dict[tuple[str, str], list[float]] = {}
    force_torque = np.empty(6, dtype=np.float64)
    for contact_index in range(data.ncon):
        contact = data.contact[contact_index]
        entities = tuple(sorted((geom_owners[int(contact.geom1)], geom_owners[int(contact.geom2)])))
        mujoco.mj_contactForce(model, data, contact_index, force_torque)
        direct_forces.setdefault(entities, []).append(float(force_torque[0]))
    assert len(direct_forces[("floor", "left")]) == 4
    assert len(direct_forces[("floor", "right")]) == 4
    np.testing.assert_allclose(
        [sample.normal_force_n for sample in samples],
        [
            sum(direct_forces[("floor", "right")]),
            sum(direct_forces[("floor", "left")]),
        ],
        rtol=0.0,
        atol=0.0,
    )
    assert all(sample.normal_force_n > 0.0 for sample in samples)

    no_contact = _mujoco_contact_samples(
        model,
        data,
        requested_entity_pairs=(("floating", "floor"),),
        entity_geom_ids={"floating": geom_ids["floating"], "floor": geom_ids["floor"]},
    )
    assert no_contact == ()

    threshold = samples[1].normal_force_n
    runtime = _EventRuntime(
        (_release_event("physical-contact", ContactTriggerSpec("left", "floor", threshold)),)
    )
    assert runtime.contact_pairs == (("left", "floor"),)
    runtime.reset(simulator_time_s=0.0, joint_states={})
    result = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=samples,
        joint_states={},
    )
    assert result.fired_event_ids == ("physical-contact",)


def test_mujoco_contact_bridge_rejects_invalid_pairs_bindings_and_model_data() -> None:
    model, data, geom_ids = _contact_model_and_data()
    with pytest.raises(ValueError, match="unique as unordered"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"), ("floor", "left")),
            entity_geom_ids={"left": geom_ids["left"], "floor": geom_ids["floor"]},
        )
    with pytest.raises(ValueError, match="missing requested"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={"left": geom_ids["left"]},
        )
    with pytest.raises(ValueError, match="unrequested"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={
                "left": geom_ids["left"],
                "floor": geom_ids["floor"],
                "right": geom_ids["right"],
            },
        )
    with pytest.raises(ValueError, match="duplicates"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={
                "left": (geom_ids["left"][0], geom_ids["left"][0]),
                "floor": geom_ids["floor"],
            },
        )
    with pytest.raises(ValueError, match="conflicting"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={"left": geom_ids["left"], "floor": geom_ids["left"]},
        )
    with pytest.raises(ValueError, match="valid compiled geom"):
        _mujoco_contact_samples(
            model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={"left": geom_ids["left"], "floor": (model.ngeom,)},
        )

    other_model, _, _ = _contact_model_and_data()
    with pytest.raises(ValueError, match="belong"):
        _mujoco_contact_samples(
            other_model,
            data,
            requested_entity_pairs=(("left", "floor"),),
            entity_geom_ids={"left": geom_ids["left"], "floor": geom_ids["floor"]},
        )


def test_event_runtime_contact_pair_route_is_ordered_and_unordered_deduplicated() -> None:
    runtime = _EventRuntime(
        (
            _release_event("first", ContactTriggerSpec("target", "gate", 1.0)),
            _release_event("duplicate", ContactTriggerSpec("gate", "target", 2.0)),
            _release_event("second", ContactTriggerSpec("target", "table", 1.0)),
        )
    )
    assert runtime.contact_pairs == (("target", "gate"), ("target", "table"))
    assert _striker_runtime().contact_pairs == (("left_striker", "target"),)


def test_state_trigger_requires_the_first_positive_y_boundary_crossing() -> None:
    events = (
        _release_event("second", StateTriggerSpec()),
        _release_event("first", StateTriggerSpec()),
    )
    runtime = _EventRuntime(
        events,
        state_trigger_target_entity_id="target",
        observation_boundary_y_m=-0.130,
    )
    runtime.reset(simulator_time_s=0.0, target_body_y_m=-0.140, joint_states={})
    before = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
        target_body_y_m=-0.131,
    )
    assert before.event_flags == (False, False)
    crossing = runtime.step(
        simulator_time_s=0.002,
        control_tick=0,
        contacts=(),
        joint_states={},
        target_body_y_m=-0.130,
    )
    assert crossing.fired_event_ids == ("second", "first")
    assert tuple(command.event_id for command in crossing.actuator_commands) == (
        "second",
        "first",
    )

    runtime.reset(simulator_time_s=0.0, target_body_y_m=-0.120, joint_states={})
    reverse = runtime.step(
        simulator_time_s=0.0,
        control_tick=0,
        contacts=(),
        joint_states={},
        target_body_y_m=-0.140,
    )
    assert reverse.event_flags == (False, False)


def test_striker_pulse_uses_selected_joint_pd_scale_force_bound_and_sim_seconds() -> None:
    runtime = _striker_runtime(rest_position_m=0.010)
    fired = _step_striker(
        runtime,
        0.002,
        joint_position_m=0.010,
        joint_velocity_m_s=-3.0,
    )
    assert fired.fired_event_ids == ("strike",)
    assert len(fired.actuator_commands) == 1
    command = fired.actuator_commands[0]
    assert isinstance(command, _StrikerCommand)
    assert command.striker_entity_id == "left_striker"
    assert command.target_position_m == pytest.approx(0.098)
    assert command.force_n == pytest.approx(4.0)

    for physics_step in range(2, 176):
        before_endpoint = _step_striker(
            runtime,
            physics_step / 500.0,
            joint_position_m=0.098,
        )
    before_endpoint_command = before_endpoint.actuator_commands[0]
    assert isinstance(before_endpoint_command, _StrikerCommand)
    assert before_endpoint_command.target_position_m == pytest.approx(0.098)

    endpoint = _step_striker(runtime, 0.352, joint_position_m=0.098)
    endpoint_command = endpoint.actuator_commands[0]
    assert isinstance(endpoint_command, _StrikerCommand)
    assert endpoint_command.target_position_m == pytest.approx(0.098)
    after = _step_striker(runtime, 0.354, joint_position_m=0.020)
    after_command = after.actuator_commands[0]
    assert isinstance(after_command, _StrikerCommand)
    assert after_command.target_position_m == pytest.approx(0.010)
    assert after_command.force_n == pytest.approx(-1.1)


def test_selected_contact_cutoff_requires_continuous_twenty_milliseconds() -> None:
    runtime = _striker_runtime()
    _step_striker(runtime, 0.0, target_y_m=-0.130)
    time_s = 0.0
    for _ in range(5):
        time_s += 0.002
        partial = _step_striker(runtime, time_s, contact=True)
    assert not partial.striker_states[0].contact_cutoff_reached
    time_s += 0.002
    gap = _step_striker(runtime, time_s, contact=False)
    assert not gap.striker_states[0].contact_cutoff_reached
    for _ in range(9):
        time_s += 0.002
        partial = _step_striker(runtime, time_s, contact=True)
    assert not partial.striker_states[0].contact_cutoff_reached
    time_s += 0.002
    cutoff = _step_striker(runtime, time_s, contact=True)
    assert cutoff.striker_states[0].contact_cutoff_reached
    command = cutoff.actuator_commands[0]
    assert isinstance(command, _StrikerCommand)
    assert command.target_position_m == 0.0

    runtime.reset(
        simulator_time_s=0.0,
        target_body_y_m=-0.140,
        joint_states={("left_striker", "slide"): _JointState(0.0, 0.0)},
    )
    reset_state = _step_striker(runtime, 0.0, target_y_m=-0.130)
    assert not reset_state.striker_states[0].contact_cutoff_reached
    assert reset_state.striker_states[0].impact_group_count == 0


def test_contact_hysteresis_groups_short_gaps_and_reports_trap_after_max_duration() -> None:
    runtime = _striker_runtime()
    _step_striker(runtime, 0.0, target_y_m=-0.130)
    time_s = 0.0
    for _ in range(25):
        time_s += 0.002
        result = _step_striker(runtime, time_s, contact=True)
    assert result.striker_states[0].impact_group_count == 1
    assert result.striker_states[0].group_contact_duration_s == pytest.approx(0.050)

    for _ in range(5):
        time_s += 0.002
        result = _step_striker(runtime, time_s, contact=False)
    assert result.striker_states[0].impact_active
    time_s += 0.002
    result = _step_striker(runtime, time_s, contact=True)
    assert result.striker_states[0].impact_group_count == 1

    for _ in range(6):
        time_s += 0.002
        result = _step_striker(runtime, time_s, contact=False)
    assert not result.striker_states[0].impact_active
    time_s += 0.002
    result = _step_striker(runtime, time_s, contact=True)
    assert result.striker_states[0].impact_group_count == 2

    for _ in range(49):
        time_s += 0.002
        result = _step_striker(runtime, time_s, contact=True)
    assert result.striker_states[0].group_contact_duration_s == pytest.approx(0.100)
    assert not result.striker_states[0].maximum_contact_duration_exceeded
    time_s += 0.002
    result = _step_striker(runtime, time_s, contact=True)
    assert result.striker_states[0].group_contact_duration_s == pytest.approx(0.102)
    assert result.striker_states[0].maximum_contact_duration_exceeded


def test_event_runtime_rejects_invalid_time_contact_and_joint_state() -> None:
    runtime = _striker_runtime()
    with pytest.raises(ValueError, match="non-negative"):
        _step_striker(runtime, -0.001)

    _step_striker(runtime, 0.0, target_y_m=-0.130)
    with pytest.raises(ValueError, match="strictly increase"):
        _step_striker(runtime, 0.0)
    with pytest.raises(ValueError, match="non-negative"):
        _ContactSample("target", "left_striker", -0.1)
    with pytest.raises(ValueError, match="finite"):
        _JointState(math.nan, 0.0)

    uninitialized = _EventRuntime(
        (_striker_event(),),
        state_trigger_target_entity_id="target",
        observation_boundary_y_m=-0.13,
    )
    with pytest.raises(ValueError, match="missing selected striker"):
        uninitialized.reset(
            simulator_time_s=0.0,
            target_body_y_m=-0.14,
            joint_states={},
        )
