from __future__ import annotations

from pathlib import Path

import mujoco
import numpy as np
import pytest
from robosuite.models.arenas import TableArena
from robosuite.models.objects import MujocoXMLObject
from robosuite.models.tasks import ManipulationTask

from se3_wam_benchmark.envs.base import (
    _AxialSymmetry,
    _FiniteSymmetry,
    _IdentitySymmetry,
    _load_asset_catalog,
    _SphericalSymmetry,
)
from se3_wam_benchmark.scenarios._validation import _compiled_object_asset_facts


def _asset_root(tmp_path: Path) -> Path:
    assets = tmp_path / "assets"
    objects = assets / "objects"
    objects.mkdir(parents=True)
    for name in ("identity", "finite", "axial", "spherical"):
        (objects / f"{name}.xml").write_text("<mujoco/>", encoding="utf-8")
    return assets


def _record(name: str, symmetry: str) -> str:
    return f"""
  - asset_id: obj.{name}_v1
    kind: object
    path: assets/objects/{name}.xml
    functional_family: test_object
    physical_identity: {name}_physical_v1
    visual_equivalence_group: {name}_visual_v1
    symmetry: {symmetry}
    grasp_class: parallel_jaw
"""


def test_catalog_loads_all_four_closed_symmetry_variants(tmp_path: Path) -> None:
    assets = _asset_root(tmp_path)
    catalog = assets / "catalog.yaml"
    catalog.write_text(
        "schema_version: 1\nassets:\n"
        + _record("identity", "{type: identity}")
        + _record(
            "finite",
            "{type: finite, quaternions_xyzw: [[0, 0, 0, 1], [1, 0, 0, 0]]}",
        )
        + _record(
            "axial",
            "{type: axial, axis_local: [0, 0, 1], bidirectional: true}",
        )
        + _record("spherical", "{type: spherical}"),
        encoding="utf-8",
    )
    records = _load_asset_catalog(catalog)
    assert isinstance(records["obj.identity_v1"].symmetry, _IdentitySymmetry)
    assert isinstance(records["obj.finite_v1"].symmetry, _FiniteSymmetry)
    assert isinstance(records["obj.axial_v1"].symmetry, _AxialSymmetry)
    assert isinstance(records["obj.spherical_v1"].symmetry, _SphericalSymmetry)
    assert records["obj.identity_v1"].path == assets / "objects" / "identity.xml"


def test_catalog_rejects_unknown_fields_duplicate_ids_and_paths_outside_assets(
    tmp_path: Path,
) -> None:
    assets = _asset_root(tmp_path)
    catalog = assets / "catalog.yaml"
    record = _record("identity", "{type: identity}")
    catalog.write_text(
        "schema_version: 1\nassets:\n" + record + record,
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="duplicate asset_id"):
        _load_asset_catalog(catalog)

    catalog.write_text(
        "schema_version: 1\nassets:\n"
        + record.replace("    grasp_class:", "    arbitrary: 1\n    grasp_class:"),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="unknown fields"):
        _load_asset_catalog(catalog)

    catalog.write_text(
        "schema_version: 1\nassets:\n"
        + record.replace("assets/objects/identity.xml", "../identity.xml"),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="repository-relative"):
        _load_asset_catalog(catalog)


def test_catalog_rejects_invalid_finite_and_axial_symmetry(tmp_path: Path) -> None:
    assets = _asset_root(tmp_path)
    catalog = assets / "catalog.yaml"
    catalog.write_text(
        "schema_version: 1\nassets:\n"
        + _record("finite", "{type: finite, quaternions_xyzw: [[1, 0, 0, 0]]}"),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="identity quaternion"):
        _load_asset_catalog(catalog)

    catalog.write_text(
        "schema_version: 1\nassets:\n"
        + _record("axial", "{type: axial, axis_local: [0, 0, 2], bidirectional: true}"),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="unit length"):
        _load_asset_catalog(catalog)


_REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
_GRASP_ASSET_IDS = (
    "obj.cuboid_grasp_v1",
    "obj.bottle_v1",
    "obj.rod_v1",
    "obj.asym_t_t1_v1",
)
_EXPECTED_COLLISION_GEOMETRY = {
    "obj.cuboid_grasp_v1": (("box", (0.030, 0.018, 0.022), (0.0, 0.0, 0.0)),),
    "obj.bottle_v1": (
        ("cylinder", (0.022, 0.035), (0.0, 0.0, 0.035)),
        ("cylinder", (0.014, 0.012), (0.0, 0.0, 0.082)),
    ),
    "obj.rod_v1": (("cylinder", (0.014, 0.055), (0.0, 0.0, 0.0)),),
    "obj.asym_t_t1_v1": (
        ("box", (0.040, 0.020, 0.018), (0.0, 0.0, 0.0)),
        ("box", (0.012, 0.025, 0.018), (0.0, -0.025, 0.0)),
    ),
}


def _compile_robosuite_object(asset_id: str, path: Path) -> tuple[MujocoXMLObject, mujoco.MjModel]:
    object_model = MujocoXMLObject(
        str(path),
        name=asset_id.removeprefix("obj.").removesuffix("_v1"),
        joints="default",
        obj_type="all",
        duplicate_collision_geoms=False,
    )
    arena = TableArena(
        table_full_size=(0.8, 0.8, 0.05),
        table_offset=(0.0, 0.0, 0.8),
    )
    task = ManipulationTask(
        mujoco_arena=arena,
        mujoco_robots=[],
        mujoco_objects=[object_model],
    )
    task.root.find("compiler").set("inertiagrouprange", "0 0")
    return object_model, mujoco.MjModel.from_xml_string(task.get_xml())


def _collision_volume(geometry: tuple[str, tuple[float, ...], tuple[float, ...]]) -> float:
    kind, size, _ = geometry
    if kind == "box":
        return 8.0 * size[0] * size[1] * size[2]
    assert kind == "cylinder"
    return np.pi * size[0] ** 2 * (2.0 * size[1])


def test_t5_assets_compile_to_one_keyed_free_puck_and_two_native_strikers() -> None:
    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    arena_record = catalog["arena.replanning_conveyor_v1"]
    target_record = catalog["obj.keyed_puck_v1"]
    assert arena_record.kind == "arena"
    assert arena_record.physical_identity == "replanning_conveyor_560x800x040_dual_striker_v1"
    assert isinstance(arena_record.symmetry, _IdentitySymmetry)
    assert target_record.kind == "object" and target_record.grasp_class == "parallel_jaw"
    assert target_record.physical_identity == "keyed_puck_bar072x028x024_key024x048x024_v1"
    assert isinstance(target_record.symmetry, _IdentitySymmetry)

    from robosuite.models.base import MujocoXML

    arena = TableArena()
    arena.worldbody.remove(arena.table_body)
    for name in ("left_eef_target", "right_eef_target"):
        target_body = arena.worldbody.find(f"body[@name='{name}']")
        assert target_body is not None
        arena.worldbody.remove(target_body)
    arena.merge(MujocoXML(str(arena_record.path)))
    arena_task = ManipulationTask(mujoco_arena=arena, mujoco_robots=[], mujoco_objects=[])
    arena_task.root.find("compiler").set("inertiagrouprange", "0 0")
    arena_model = mujoco.MjModel.from_xml_string(arena_task.get_xml())
    arena_data = mujoco.MjData(arena_model)
    mujoco.mj_forward(arena_model, arena_data)
    belt_id = int(arena_model.geom("belt_collision").id)
    assert arena_model.flg_surfacevel
    assert arena_model.nu == 0  # DB0 drives the striker slide DOFs with generalized forces.
    np.testing.assert_array_equal(
        arena_model.geom_surfacevel[belt_id], (0.0, 0.13, 0.0, 0.0, 0.0, 0.0)
    )
    assert arena_model.geom_contype[belt_id] and arena_model.geom_conaffinity[belt_id]
    for branch, axis in (("left", (1.0, 0.0, 0.0)), ("right", (-1.0, 0.0, 0.0))):
        joint_id = int(arena_model.joint(f"{branch}_slide").id)
        geom_id = int(arena_model.geom(f"{branch}_striker_collision").id)
        assert arena_model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_SLIDE
        np.testing.assert_array_equal(arena_model.jnt_axis[joint_id], axis)
        np.testing.assert_array_equal(arena_model.jnt_range[joint_id], (0.0, 0.110))
        assert arena_model.dof_damping[arena_model.jnt_dofadr[joint_id]] == 4.0
        assert arena_model.geom_contype[geom_id] and arena_model.geom_conaffinity[geom_id]
        np.testing.assert_array_equal(arena_model.geom_size[geom_id], (0.018, 0.004, 0.014))

    target, target_model = _compile_robosuite_object("obj.keyed_puck_v1", target_record.path)
    target_data = mujoco.MjData(target_model)
    mujoco.mj_forward(target_model, target_data)
    body_id = int(target_model.body(target.root_body).id)
    joint_id = int(target_model.body_jntadr[body_id])
    assert target_model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE
    assert target_model.body_jntnum[body_id] == 1
    np.testing.assert_allclose(
        target_model.body_ipos[body_id], (0.0, -0.00909090909090909, 0.0), rtol=0.0, atol=1e-15
    )
    assert target_model.body_mass[body_id] == pytest.approx(0.04713984, abs=1e-15)
    np.testing.assert_allclose(
        target_model.body_inertia[body_id],
        (2.5850812974545456e-05, 1.604468736e-05, 1.4331550254545456e-05),
        rtol=0.0,
        atol=1e-15,
    )
    collision = {
        name.removeprefix(target.naming_prefix): int(target_model.geom(name).id)
        for name in target.contact_geoms
    }
    assert set(collision) == {"bar_collision", "key_collision"}
    np.testing.assert_array_equal(
        target_model.geom_size[collision["bar_collision"]], (0.036, 0.014, 0.012)
    )
    np.testing.assert_array_equal(
        target_model.geom_size[collision["key_collision"]], (0.012, 0.024, 0.012)
    )
    np.testing.assert_allclose(
        target_model.geom_pos[[collision["bar_collision"], collision["key_collision"]]],
        ((0.0, 0.0, 0.0), (0.0, -0.025, 0.0)),
        rtol=0.0,
        atol=1e-15,
    )
    assert all(
        target_model.geom_contype[geom_id] and target_model.geom_conaffinity[geom_id]
        for geom_id in collision.values()
    )


@pytest.mark.parametrize("asset_id", ["obj.cuboid_t2_handle_v1", "obj.asym_t_t2_handle_v1"])
def test_t2_payloads_compile_with_full_physical_handles_and_declared_symmetry(
    asset_id: str,
) -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")[asset_id]
    object_model, model = _compile_robosuite_object(asset_id, record.path)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    body_id = model.body(object_model.root_body).id
    geom_ids = [model.geom(name).id for name in object_model.contact_geoms]
    assert len(geom_ids) == (2 if asset_id == "obj.cuboid_t2_handle_v1" else 3)
    assert record.grasp_class == "handle"
    assert model.body_jntnum[body_id] == 1
    assert model.jnt_type[model.body_jntadr[body_id]] == mujoco.mjtJoint.mjJNT_FREE
    assert model.body_mass[body_id] > 0.0
    assert np.isfinite(model.body_inertia[body_id]).all()
    assert np.all(model.body_inertia[body_id] > 0.0)
    assert all(model.geom_type[index] == mujoco.mjtGeom.mjGEOM_BOX for index in geom_ids)
    assert all(model.geom_contype[index] and model.geom_conaffinity[index] for index in geom_ids)
    centers, sizes = model.geom_pos[geom_ids], model.geom_size[geom_ids]
    assert sum(name.endswith("_handle_collision") for name in object_model.contact_geoms) == 1
    signs = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)])
    corners = centers[:, None, :] + sizes[:, None, :] * signs
    bottom, top = float(corners[:, :, 2].min()), float(corners[:, :, 2].max())
    assert object_model.bottom_offset[2] == pytest.approx(bottom)
    assert object_model.top_offset[2] == pytest.approx(top)
    assert object_model.horizontal_radius >= np.linalg.norm(corners[:, :, :2], axis=2).max() - 1e-15
    if isinstance(record.symmetry, _FiniteSymmetry):
        np.testing.assert_array_equal(model.body_ipos[body_id, :2], 0.0)
        assert 0.0 < model.body_ipos[body_id, 2] < 0.052
        np.testing.assert_array_equal(centers, ((0.0, 0.0, 0.0), (0.0, 0.0, 0.052)))
        np.testing.assert_array_equal(sizes, ((0.022, 0.022, 0.022), (0.008, 0.008, 0.03)))
        assert len(record.symmetry.quaternions_xyzw) == 4
        original = sorted(tuple(np.round(point, 12)) for point in corners.reshape(-1, 3))
        for quaternion in record.symmetry.quaternions_xyzw:
            rotation = np.empty(9)
            mujoco.mju_quat2Mat(rotation, np.roll(np.asarray(quaternion), 1))
            transformed = corners.reshape(-1, 3) @ rotation.reshape(3, 3).T
            assert sorted(tuple(np.round(point, 12)) for point in transformed) == original
        # The square body and square top handle have four yaw symmetries, but no flip.
        flip = np.diag((1, -1, -1))
        assert (
            sorted(tuple(point) for point in np.round(corners.reshape(-1, 3) @ flip.T, 12))
            != original
        )
    else:
        assert isinstance(record.symmetry, _IdentitySymmetry)


@pytest.mark.parametrize(
    ("payload_id", "fixture_id", "clearance", "wall_height"),
    [
        ("obj.cuboid_t2_handle_v1", "fixture.open_tray_v1", 0.008, 0.050),
        ("obj.asym_t_t2_handle_v1", "fixture.t_slot_v1", 0.004, 0.040),
    ],
)
def test_t2_receptacles_compile_with_db0_wall_height_and_payload_body_clearance(
    payload_id: str, fixture_id: str, clearance: float, wall_height: float
) -> None:
    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    payload, payload_model = _compile_robosuite_object(payload_id, catalog[payload_id].path)
    fixture, model = _compile_robosuite_object(fixture_id, catalog[fixture_id].path)
    ids = [model.geom(name).id for name in fixture.contact_geoms]
    floor_id = next(index for index in ids if model.geom(index).name.endswith("floor_collision"))
    rims = [index for index in ids if index != floor_id]
    floor_top = model.geom_pos[floor_id, 2] + model.geom_size[floor_id, 2]
    entrance = min(model.geom_pos[index, 2] + model.geom_size[index, 2] for index in rims)
    assert entrance - floor_top == pytest.approx(wall_height)
    body_ids = [
        payload_model.geom(name).id
        for name in payload.contact_geoms
        if not name.endswith("_handle_collision")
    ]
    body_bottom = np.min(payload_model.geom_pos[body_ids, 2] - payload_model.geom_size[body_ids, 2])
    body_top = np.max(payload_model.geom_pos[body_ids, 2] + payload_model.geom_size[body_ids, 2])
    assert body_top - body_bottom < wall_height < payload.top_offset[2] - payload.bottom_offset[2]
    assert all(model.geom_priority[index] == 1 for index in ids)
    assert all(model.geom_contype[index] and model.geom_conaffinity[index] for index in ids)
    assert np.isfinite(model.body_inertia).all()
    body_geom = payload_model.geom(payload.contact_geoms[0]).id
    left = next(
        index
        for index in rims
        if model.geom(index).name.endswith(("left_collision", "bar_left_collision"))
    )
    inner_left = model.geom_pos[left, 0] + model.geom_size[left, 0]
    assert -inner_left - payload_model.geom_size[body_geom, 0] == pytest.approx(clearance)


def test_canopy_compiles_as_a_static_collision_enabled_fixture_without_a_target_driver() -> None:
    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    record = catalog["fixture.occlusion_canopy_v1"]
    assert record.kind == "fixture" and record.grasp_class == "none"
    assert isinstance(record.symmetry, _IdentitySymmetry)
    fixture = MujocoXMLObject(
        str(record.path),
        name="occluder",
        joints=None,
        obj_type="all",
        duplicate_collision_geoms=False,
    )
    position = (0.237, -0.255, 1.115)
    fixture.get_obj().set("pos", " ".join(map(str, position)))
    arena = TableArena(table_offset=(0.0, 0.0, 0.8))
    task = ManipulationTask(mujoco_arena=arena, mujoco_robots=[], mujoco_objects=[fixture])
    model = mujoco.MjModel.from_xml_string(task.get_xml())
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    body = model.body(fixture.root_body).id
    assert model.body_dofnum[body] == 0 and not fixture.joints
    assert model.body_jntnum[body] == 0
    np.testing.assert_array_equal(data.xpos[body], position)
    assert len(fixture.contact_geoms) == len(fixture.visual_geoms) == 2
    for name, size, offset in (
        ("screen", (0.12, 0.036, 0.006), (0.0, 0.0, 0.0)),
        ("far_support", (0.006, 0.036, 0.197), (0.12, 0.0, -0.203)),
    ):
        collision = model.geom(f"occluder_{name}").id
        visual = model.geom(f"occluder_{name}_visual").id
        assert model.geom_type[collision] == model.geom_type[visual] == mujoco.mjtGeom.mjGEOM_BOX
        np.testing.assert_array_equal(model.geom_size[[collision, visual]], [size] * 2)
        np.testing.assert_array_equal(
            data.geom_xpos[[collision, visual]], [np.asarray(position) + offset] * 2
        )
        assert model.geom_contype[collision] == model.geom_conaffinity[collision] == 1
        assert model.geom_contype[visual] == model.geom_conaffinity[visual] == 0
        np.testing.assert_array_equal(model.geom_surfacevel[[collision, visual]], 0.0)
    assert not model.flg_surfacevel
    assert fixture.horizontal_radius >= np.hypot(0.10, 0.045)
    assert np.isfinite(data.xpos).all() and np.isfinite(data.geom_xmat).all()


def test_frozen_grasp_catalog_identity_and_symmetry() -> None:
    records = _load_asset_catalog(_REPOSITORY_ROOT / "assets" / "catalog.yaml")
    assert tuple(records) == (
        *_GRASP_ASSET_IDS,
        "arena.conveyor_v1",
        "obj.cube_44_v1",
        "obj.cuboid_t2_handle_v1",
        "obj.asym_t_t2_handle_v1",
        "fixture.open_tray_v1",
        "fixture.t_slot_v1",
        "fixture.occlusion_canopy_v1",
        "arena.rotating_wire_v1",
        "obj.wand_loop_v1",
        "fixture.rotating_wire_v1",
        "fixture.wand_cradle_v1",
        "arena.unsupported_ramp_v1",
        "arena.supported_ramp_v1",
        "obj.sphere_r030_v1",
        "obj.slider_v1",
        "obj.can_v1",
        "arena.replanning_conveyor_v1",
        "obj.keyed_puck_v1",
    )
    assert all(records[key].functional_family == "grasp_target" for key in _GRASP_ASSET_IDS)
    assert all(records[key].grasp_class == "parallel_jaw" for key in _GRASP_ASSET_IDS)
    assert isinstance(records["obj.cuboid_grasp_v1"].symmetry, _FiniteSymmetry)
    assert records["obj.cuboid_grasp_v1"].symmetry.quaternions_xyzw == (
        (0.0, 0.0, 0.0, 1.0),
        (1.0, 0.0, 0.0, 0.0),
        (0.0, 1.0, 0.0, 0.0),
        (0.0, 0.0, 1.0, 0.0),
    )
    bottle = records["obj.bottle_v1"].symmetry
    rod = records["obj.rod_v1"].symmetry
    assert isinstance(bottle, _AxialSymmetry) and not bottle.bidirectional
    assert isinstance(rod, _AxialSymmetry) and rod.bidirectional
    assert bottle.axis_local == rod.axis_local == (0.0, 0.0, 1.0)
    assert isinstance(records["obj.asym_t_t1_v1"].symmetry, _IdentitySymmetry)
    for record in records.values():
        assert record.path.is_file()
        assert record.physical_identity
        assert record.visual_equivalence_group


def test_t4_assets_compile_with_frozen_geometry_and_logical_fixture_topology() -> None:
    from se3_wam_benchmark.envs.factory import make_env
    from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
    from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

    records = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    for asset_id, task_id, downstream, half_size, gate_half_size, post_count in (
        (
            "arena.unsupported_ramp_v1",
            "t4_sphere",
            "safety_tray",
            (0.12, 0.20, 0.010),
            (0.105, 0.004, 0.035),
            4,
        ),
        (
            "arena.supported_ramp_v1",
            "t4_can",
            "table",
            (0.105, 0.17, 0.004),
            (0.100, 0.004, 0.035),
            2,
        ),
    ):
        record = records[asset_id]
        assert record.kind == "arena" and isinstance(record.symmetry, _IdentitySymmetry)
        model = mujoco.MjModel.from_xml_path(str(record.path))
        ramp_body = int(model.body("ramp").id)
        gate_body = int(model.body("gate").id)
        assert model.body_jntnum[ramp_body] == model.body_jntnum[gate_body] == 0
        assert model.njnt == model.nu == model.nexclude == 0
        assert model.nbody == post_count + 3  # world, ramp, gate, and vertical supports
        for name, expected_size in (
            ("ramp_collision", half_size),
            ("gate_collision", gate_half_size),
        ):
            geom = model.geom(name).id
            assert model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_BOX
            np.testing.assert_array_equal(model.geom_size[geom], expected_size)
            assert model.geom_contype[geom] == model.geom_conaffinity[geom] == 1
            assert model.geom_condim[geom] == 3
        for index in range(post_count):
            body = int(model.body(f"ramp_support_{index}").id)
            geom = int(model.geom(f"ramp_support_{index}_collision").id)
            assert model.body_parentid[body] == ramp_body
            assert model.body_jntnum[body] == 0
            assert model.geom_contype[geom] == model.geom_conaffinity[geom] == 1

        # The arena asset contributes ramp/gate/supports. The production Family
        # supplies the DB0 downstream collision on its shared TableArena body.
        task = load_task(task_id)
        recipe = _select_recipe(
            load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml"),
            partition="train",
            factor=None,
            recipe_name="e7_agentview",
        )
        scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(17)))
        environment = make_env(task_id, scenario)
        try:
            composed = environment.sim.model._model
            assert composed.nq == 16 and composed.nv == 15
            body = int(composed.body(downstream).id)
            geom = int(composed.geom(f"{downstream}_collision").id)
            assert environment._fixture_body_ids[downstream] == body
            assert environment._fixture_geom_ids[downstream] == (geom,)
            assert composed.geom_bodyid[geom] == body
            assert composed.geom_bodyid[composed.geom("table_base_collision").id] == body
            assert composed.geom_bodyid[composed.geom("table_visual").id] == body
            assert composed.body_jntnum[body] == 0
            assert composed.body_jntnum[composed.body("gate").id] == 0
            np.testing.assert_array_equal(composed.geom_size[geom], (0.28, 0.4, 0.005))
            np.testing.assert_array_equal(composed.geom_pos[geom], (0.0, 0.0, 0.02))
            assert composed.geom_contype[geom] == composed.geom_conaffinity[geom] == 1
            assert composed.geom_condim[geom] == 3
        finally:
            environment.close()

    expected = {
        "obj.sphere_r030_v1": (mujoco.mjtGeom.mjGEOM_SPHERE, (0.030, 0.0, 0.0)),
        "obj.slider_v1": (mujoco.mjtGeom.mjGEOM_BOX, (0.025, 0.035, 0.020)),
        "obj.can_v1": (mujoco.mjtGeom.mjGEOM_CYLINDER, (0.024, 0.045, 0.0)),
    }
    for asset_id, (geom_type, size) in expected.items():
        record = records[asset_id]
        object_model, model = _compile_robosuite_object(asset_id, record.path)
        body = model.body(object_model.root_body).id
        geom = model.geom(object_model.contact_geoms[0]).id
        assert model.body_jntnum[body] == 1
        assert model.jnt_type[model.body_jntadr[body]] == mujoco.mjtJoint.mjJNT_FREE
        assert model.geom_type[geom] == geom_type
        np.testing.assert_array_equal(model.geom_size[geom], size)
        assert model.body_mass[body] > 0.0
        assert np.isfinite(model.body_inertia[body]).all()
        assert model.geom_priority[geom] == 0
        assert model.geom_condim[geom] == 3
    assert isinstance(records["obj.sphere_r030_v1"].symmetry, _SphericalSymmetry)
    assert isinstance(records["obj.slider_v1"].symmetry, _FiniteSymmetry)
    can = records["obj.can_v1"].symmetry
    assert isinstance(can, _AxialSymmetry) and can.bidirectional
    assert can.axis_local == (0.0, 0.0, 1.0)


def test_t3_assets_compile_to_the_complete_finite_wire_loop_and_gravity_cradle() -> None:
    from robosuite.models.base import MujocoXML

    records = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    for asset_id in (
        "arena.rotating_wire_v1",
        "obj.wand_loop_v1",
        "fixture.rotating_wire_v1",
        "fixture.wand_cradle_v1",
    ):
        assert isinstance(records[asset_id].symmetry, _IdentitySymmetry)
    arena = TableArena()
    arena.worldbody.remove(arena.table_body)
    for name in ("left_eef_target", "right_eef_target"):
        target = arena.worldbody.find(f"body[@name='{name}']")
        assert target is not None
        arena.worldbody.remove(target)
    arena.merge(MujocoXML(str(records["arena.rotating_wire_v1"].path)))
    assert mujoco.MjModel.from_xml_string(arena.get_xml()).opt.timestep == 0.002

    wand, model = _compile_robosuite_object("obj.wand_loop_v1", records["obj.wand_loop_v1"].path)
    body = int(model.body(wand.root_body).id)
    assert len(wand.contact_geoms) == 17
    assert model.body_mass[body] == pytest.approx(0.0672655092868625, rel=0.0, abs=1e-15)
    assert np.isfinite(model.body_inertia[body]).all() and np.all(model.body_inertia[body] > 0)
    assert wand.horizontal_radius == pytest.approx(0.037, rel=0.0, abs=1e-15)
    np.testing.assert_array_equal(wand.bottom_offset, [0.0, 0.0, -0.137])
    np.testing.assert_array_equal(wand.top_offset, [0.0, 0.0, 0.06])
    handle = int(model.geom(wand.naming_prefix + "handle").id)
    assert model.geom_type[handle] == mujoco.mjtGeom.mjGEOM_BOX
    np.testing.assert_array_equal(model.geom_size[handle], [0.022, 0.012, 0.06])
    loop_geoms = [
        int(model.geom(name).id)
        for name in wand.contact_geoms
        if name.removeprefix(wand.naming_prefix).startswith("loop_")
    ]
    assert len(loop_geoms) == 16
    assert all(model.geom_type[index] == mujoco.mjtGeom.mjGEOM_CAPSULE for index in loop_geoms)
    np.testing.assert_array_equal(model.geom_size[loop_geoms, 0], np.full(16, 0.003))

    wire, wire_model = _compile_robosuite_object(
        "fixture.rotating_wire_v1", records["fixture.rotating_wire_v1"].path
    )
    points = np.asarray(
        [
            [-0.15, 0.0, 0.0],
            [-0.125, 0.0, 0.0],
            [-0.1, 0.0, 0.038],
            [-0.075, 0.0, 0.01],
            [-0.05, 0.0, -0.025],
            [-0.025, 0.0, -0.04],
            [0.0, 0.0, 0.0],
            [0.025, 0.0, 0.035],
            [0.05, 0.0, 0.045],
            [0.075, 0.0, 0.005],
            [0.1, 0.0, -0.035],
            [0.125, 0.0, 0.0],
            [0.15, 0.0, 0.0],
        ]
    )
    assert len(wire.contact_geoms) == len(points) - 1
    for name, first, second in zip(wire.contact_geoms, points[:-1], points[1:], strict=True):
        geom = int(wire_model.geom(name).id)
        assert wire_model.geom_type[geom] == mujoco.mjtGeom.mjGEOM_CAPSULE
        assert wire_model.geom_contype[geom] == wire_model.geom_conaffinity[geom] == 1
        np.testing.assert_allclose(
            wire_model.geom_pos[geom], (first + second) / 2, rtol=0.0, atol=1e-15
        )
        np.testing.assert_allclose(
            wire_model.geom_size[geom, :2],
            [0.004, np.linalg.norm(second - first) / 2],
            rtol=0.0,
            atol=1e-15,
        )
    wire_body = int(wire_model.body(wire.root_body).id)
    assert wire_model.body_mass[wire_body] == pytest.approx(0.0263214238775837, rel=0.0, abs=1e-15)

    cradle, cradle_model = _compile_robosuite_object(
        "fixture.wand_cradle_v1", records["fixture.wand_cradle_v1"].path
    )
    assert len(cradle.contact_geoms) == 4
    assert all(
        cradle_model.geom_type[cradle_model.geom(name).id] == mujoco.mjtGeom.mjGEOM_BOX
        and cradle_model.geom_contype[cradle_model.geom(name).id] == 1
        and cradle_model.geom_conaffinity[cradle_model.geom(name).id] == 1
        for name in cradle.contact_geoms
    )
    cradle_body = int(cradle_model.body(cradle.root_body).id)
    assert cradle_model.body_mass[cradle_body] == pytest.approx(0.016064, rel=0.0, abs=1e-15)
    assert np.isfinite(cradle_model.body_inertia).all()


@pytest.mark.parametrize("asset_id", _GRASP_ASSET_IDS)
def test_grasp_asset_real_robosuite_merge_and_mujoco_compile(asset_id: str) -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets" / "catalog.yaml")[asset_id]
    object_model, model = _compile_robosuite_object(asset_id, record.path)
    expected = _EXPECTED_COLLISION_GEOMETRY[asset_id]

    assert len(object_model.joints) == 1
    joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, object_model.joints[0])
    assert joint_id >= 0
    assert model.jnt_type[joint_id] == mujoco.mjtJoint.mjJNT_FREE
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_model.root_body)
    assert body_id >= 0
    assert np.isfinite(model.body_mass[body_id]) and model.body_mass[body_id] > 0.0
    assert np.all(np.isfinite(model.body_inertia[body_id]))
    assert np.all(model.body_inertia[body_id] > 0.0)

    assert len(object_model.contact_geoms) == len(expected)
    expected_visual_count = 1 if asset_id == "obj.asym_t_t1_v1" else len(expected)
    assert len(object_model.visual_geoms) == expected_visual_count
    for geom_name, (kind, size, position) in zip(object_model.contact_geoms, expected, strict=True):
        geom_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, geom_name)
        assert geom_id >= 0
        expected_type = (
            mujoco.mjtGeom.mjGEOM_BOX if kind == "box" else mujoco.mjtGeom.mjGEOM_CYLINDER
        )
        assert model.geom_type[geom_id] == expected_type
        np.testing.assert_allclose(
            model.geom_size[geom_id, : len(size)], size, rtol=0.0, atol=1e-12
        )
        np.testing.assert_allclose(model.geom_pos[geom_id], position, rtol=0.0, atol=1e-12)
        assert model.geom_group[geom_id] == 0
        assert model.geom_contype[geom_id] == 1
        assert model.geom_conaffinity[geom_id] == 1

    for geom_name in object_model.visual_geoms:
        geom_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, geom_name)
        assert geom_id >= 0
        assert model.geom_group[geom_id] == 1
        assert model.geom_contype[geom_id] == 0
        assert model.geom_conaffinity[geom_id] == 0

    expected_collision_mass = 700.0 * sum(_collision_volume(item) for item in expected)
    assert model.body_mass[body_id] == pytest.approx(
        expected_collision_mass,
        rel=1e-10,
        abs=1e-12,
    )
    facts = _compiled_object_asset_facts(record)
    assert facts.mass_kg == pytest.approx(model.body_mass[body_id], rel=0.0, abs=1e-12)
    np.testing.assert_allclose(
        facts.diagonal_inertia_kg_m2, model.body_inertia[body_id], rtol=0.0, atol=1e-15
    )
    assert facts.bottom_offset_m == pytest.approx(object_model.bottom_offset[2], rel=0.0, abs=1e-12)


@pytest.mark.parametrize("asset_id", ["obj.cuboid_grasp_v1", "obj.rod_v1"])
def test_centered_asset_symmetry_preserves_compiled_occupancy_at_fixed_translation(
    asset_id: str,
) -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets" / "catalog.yaml")[asset_id]
    object_model, model = _compile_robosuite_object(asset_id, record.path)
    data = mujoco.MjData(model)
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_model.root_body)
    joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, object_model.joints[0])
    geom_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, object_model.contact_geoms[0])
    qpos_address = int(model.jnt_qposadr[joint_id])
    translation = np.asarray([0.12, -0.21, 0.9])
    data.qpos[qpos_address : qpos_address + 7] = [*translation, 1.0, 0.0, 0.0, 0.0]
    mujoco.mj_forward(model, data)
    center = data.geom_xpos[geom_id].copy()
    baseline_rotation = data.geom_xmat[geom_id].reshape(3, 3).copy()
    np.testing.assert_allclose(model.body_ipos[body_id], 0.0, rtol=0.0, atol=1e-15)
    np.testing.assert_allclose(center, translation, rtol=0.0, atol=1e-15)

    quaternions = (
        ((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))
        if asset_id == "obj.cuboid_grasp_v1"
        else (
            (np.cos(0.37), 0.0, 0.0, np.sin(0.37)),
            (0.0, 1.0, 0.0, 0.0),
            (0.0, np.cos(0.37), np.sin(0.37), 0.0),
        )
    )
    for quaternion_wxyz in quaternions:
        data.qpos[qpos_address + 3 : qpos_address + 7] = quaternion_wxyz
        mujoco.mj_forward(model, data)
        np.testing.assert_allclose(data.xpos[body_id], translation, rtol=0.0, atol=1e-15)
        np.testing.assert_allclose(data.geom_xpos[geom_id], center, rtol=0.0, atol=1e-15)
        rotation = data.geom_xmat[geom_id].reshape(3, 3)
        if asset_id == "obj.cuboid_grasp_v1":
            signs = np.asarray([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)])
            corners = signs * model.geom_size[geom_id]
            before = {tuple(row) for row in np.round(corners @ baseline_rotation.T, 12)}
            after = {tuple(row) for row in np.round(corners @ rotation.T, 12)}
            assert after == before
        else:
            np.testing.assert_allclose(
                np.outer(rotation[:, 2], rotation[:, 2]),
                np.outer(baseline_rotation[:, 2], baseline_rotation[:, 2]),
                rtol=0.0,
                atol=1e-15,
            )


def test_cube_asset_has_all_24_compiled_proper_rotation_symmetries() -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")["obj.cube_44_v1"]
    assert record.kind == "object" and record.grasp_class == "parallel_jaw"
    assert isinstance(record.symmetry, _FiniteSymmetry)
    assert len(record.symmetry.quaternions_xyzw) == 24
    object_model, model = _compile_robosuite_object(record.asset_id, record.path)
    data = mujoco.MjData(model)
    body_id = int(model.body(object_model.root_body).id)
    geom_id = int(model.geom(object_model.contact_geoms[0]).id)
    joint = int(model.joint(object_model.joints[0]).id)
    assert model.jnt_type[joint] == mujoco.mjtJoint.mjJNT_FREE
    np.testing.assert_array_equal(model.geom_size[geom_id], [0.022] * 3)
    np.testing.assert_array_equal(model.body_ipos[body_id], 0.0)
    assert model.body_mass[body_id] == pytest.approx(700.0 * 0.044**3, abs=1e-15)
    np.testing.assert_allclose(
        model.body_inertia[body_id],
        np.full(3, model.body_mass[body_id] * 0.044**2 / 6),
        rtol=0.0,
        atol=1e-18,
    )
    address = int(model.jnt_qposadr[joint])
    position = np.array([0.12, -0.21, 0.9])
    corners = np.asarray([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]) * 0.022
    expected_corners = {tuple(row) for row in np.round(corners, 12)}
    rotations = set()
    for x, y, z, w in record.symmetry.quaternions_xyzw:
        data.qpos[address : address + 7] = [*position, w, x, y, z]
        mujoco.mj_forward(model, data)
        rotation = data.geom_xmat[geom_id].reshape(3, 3)
        assert np.linalg.det(rotation) == pytest.approx(1.0, abs=1e-12)
        rotations.add(tuple(np.round(rotation, 12).ravel()))
        np.testing.assert_array_equal(data.xpos[body_id], position)
        np.testing.assert_array_equal(data.geom_xpos[geom_id], position)
        assert {tuple(row) for row in np.round(corners @ rotation.T, 12)} == expected_corners
    assert len(rotations) == 24


def test_conveyor_asset_drives_real_cube_only_through_native_surface_contact() -> None:
    from robosuite.models.base import MujocoXML

    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    arena_record, cube_record = catalog["arena.conveyor_v1"], catalog["obj.cube_44_v1"]
    assert arena_record.kind == "arena" and arena_record.grasp_class == "none"
    arena = TableArena(table_offset=(0.0, 0.0, 0.8))
    arena.set_origin((0.0, 0.0, 0.0))
    for name in ("left_eef_target", "right_eef_target"):
        target = arena.worldbody.find(f"body[@name='{name}']")
        assert target is not None
        arena.worldbody.remove(target)
    arena.worldbody.remove(arena.table_body)
    arena.merge(MujocoXML(str(arena_record.path)))
    geom = arena.worldbody.find(".//geom[@name='belt_collision']")
    assert geom is not None
    geom.set("surfacevel", "0 .07 0 0 0 0")
    cube = MujocoXMLObject(
        str(cube_record.path),
        name="target",
        joints="default",
        obj_type="all",
        duplicate_collision_geoms=False,
    )
    cube.get_obj().set("pos", "0 -.24 .822")
    scene = ManipulationTask(mujoco_arena=arena, mujoco_robots=[], mujoco_objects=[cube])
    model = mujoco.MjModel.from_xml_string(scene.get_xml())
    data = mujoco.MjData(model)
    belt_id = int(model.geom("belt_collision").id)
    target_id = int(model.body(cube.root_body).id)
    joint = int(model.joint(cube.joints[0]).id)
    dof = int(model.jnt_dofadr[joint])
    assert model.flg_surfacevel and model.nu == 0
    np.testing.assert_array_equal(model.geom_size[belt_id], [0.28, 0.40, 0.020])
    np.testing.assert_array_equal(model.geom_surfacevel[belt_id], [0.0, 0.07, 0.0, 0.0, 0.0, 0.0])
    force = np.empty(6)
    support_impulse = 0.0
    for _ in range(1000):
        mujoco.mj_step(model, data)
        for index in range(data.ncon):
            contact = data.contact[index]
            if belt_id in (contact.geom1, contact.geom2):
                mujoco.mj_contactForce(model, data, index, force)
                assert force[0] >= 0.0 and np.isfinite(force).all()
                support_impulse += force[0] * model.opt.timestep
        np.testing.assert_array_equal(data.xfrc_applied, 0.0)
        np.testing.assert_array_equal(data.qfrc_applied, 0.0)
    mujoco.mj_forward(model, data)
    assert support_impulse > 0.0
    assert data.qvel[dof + 1] == pytest.approx(0.07, abs=1e-4)
    assert data.xpos[target_id, 1] > -0.11
    assert data.xpos[target_id, 2] == pytest.approx(0.822, abs=1e-3)


def test_asymmetric_t_keeps_compiled_principal_inertia_frame() -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets" / "catalog.yaml")["obj.asym_t_t1_v1"]
    object_model, model = _compile_robosuite_object(record.asset_id, record.path)
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, object_model.root_body)
    np.testing.assert_allclose(
        model.body_iquat[body_id],
        [0.0, np.sqrt(0.5), 0.0, np.sqrt(0.5)],
        rtol=0.0,
        atol=1e-12,
    )
    np.testing.assert_allclose(
        _compiled_object_asset_facts(record).diagonal_inertia_kg_m2,
        [7.525697454545453e-5, 5.643456e-5, 4.2772494545454545e-5],
        rtol=0.0,
        atol=1e-15,
    )


def test_asymmetric_t_preserves_db0_bar_origin_and_displaced_center_of_mass() -> None:
    record = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")["obj.asym_t_t1_v1"]
    object_model, model = _compile_robosuite_object(record.asset_id, record.path)
    body = int(model.body(object_model.root_body).id)
    # DB0 adds the stem at y=-.025 while retaining the original bar body frame.
    com_offset = np.array([0.0, -0.006818181818181819, 0.0])
    np.testing.assert_allclose(model.body_ipos[body], com_offset, rtol=0.0, atol=1e-15)
    np.testing.assert_array_equal(object_model.bottom_offset, [0.0, 0.0, -0.018])
    np.testing.assert_array_equal(object_model.top_offset, [0.0, 0.0, 0.018])
    collisions = [int(model.geom(name).id) for name in object_model.contact_geoms]
    np.testing.assert_array_equal(model.geom_pos[collisions], [[0, 0, 0], [0, -0.025, 0]])
    assert len(object_model.visual_geoms) == 1
    visual = int(model.geom(object_model.visual_geoms[0]).id)
    assert model.geom_type[visual] == mujoco.mjtGeom.mjGEOM_MESH
    signs = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)])
    corners = np.concatenate(
        [model.geom_pos[geom] + signs * model.geom_size[geom] for geom in collisions]
    )
    expected_radius = np.linalg.norm([0.012, 0.05])
    assert object_model.horizontal_radius == pytest.approx(expected_radius, rel=0.0, abs=1e-15)
    assert object_model.horizontal_radius >= np.max(np.linalg.norm(corners[:, :2], axis=1)) - 1e-15
    assert np.all(object_model.get_bounding_box_half_size() >= np.max(np.abs(corners), axis=0))

    data = mujoco.MjData(model)
    joint = int(model.joint(object_model.joints[0]).id)
    address = int(model.jnt_qposadr[joint])
    position = np.array([0.012, -0.221, 0.8 + 0.018])
    for yaw in np.linspace(-1.1, 1.1, 13):
        quaternion = np.array([np.cos(yaw / 2), 0.0, 0.0, np.sin(yaw / 2)])
        data.qpos[address : address + 7] = [*position, *quaternion]
        mujoco.mj_forward(model, data)
        rotation = data.xmat[body].reshape(3, 3)
        np.testing.assert_array_equal(data.xpos[body], position)
        np.testing.assert_allclose(
            data.xipos[body], position + rotation @ com_offset, rtol=0.0, atol=1e-15
        )
        np.testing.assert_allclose(data.geom_xpos[collisions[0]], position, rtol=0.0, atol=1e-15)
        np.testing.assert_allclose(
            data.geom_xpos[collisions[1]],
            position + rotation @ np.array([0.0, -0.025, 0.0]),
            rtol=0.0,
            atol=1e-15,
        )
