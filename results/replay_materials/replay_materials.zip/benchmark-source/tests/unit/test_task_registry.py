from __future__ import annotations

from dataclasses import asdict, replace
from pathlib import Path

import pytest

from se3_wam_benchmark.evaluation.suite import (
    GROUP_FIELDS,
    SuiteMember,
    SuiteSpec,
    evaluate,
    load_suite,
)
from se3_wam_benchmark.tasks import registry
from se3_wam_benchmark.tasks.registry import (
    TASK_FAMILIES,
    TASK_IDS,
    load_task,
    load_tasks,
    load_yaml_strict,
)
from se3_wam_benchmark.tasks.spec import (
    DrivenInterceptionBindings,
    FreeDynamicsInterceptionBindings,
    MovingPlacementBindings,
    ReplanningBindings,
    RotatingInteractionBindings,
    parse_task_spec,
)

ROOT = Path(__file__).resolve().parents[2]
PROFILES = ("agentview", "agentview_wrist")
ACTION_MODES = ("E7", "J8")
METRICS = (
    "success_rate",
    "task_completion",
    "completion_time_s",
    "safety_failure_rate",
    "failure_rate",
)

TASK_CASES = {
    "grasp": (
        "grasp",
        "m0_m2",
        {"target_object_id": "target"},
        160,
        {
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t1_belt": (
        "driven_interception",
        "surface_driven",
        {
            "target_object_id": "target",
            "driver_entity_id": "belt",
            "occluder_fixture_ids": (),
        },
        160,
        {
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t1_xyz": (
        "driven_interception",
        "matched_xyz",
        {
            "target_object_id": "target",
            "driver_entity_id": "target",
            "occluder_fixture_ids": (),
        },
        160,
        {
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t1_so3": (
        "driven_interception",
        "matched_yaw",
        {
            "target_object_id": "target",
            "driver_entity_id": "target",
            "occluder_fixture_ids": (),
        },
        160,
        {
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t1_occ": (
        "driven_interception",
        "physical_occlusion",
        {
            "target_object_id": "target",
            "driver_entity_id": "belt",
            "occluder_fixture_ids": ("occluder",),
        },
        160,
        {
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t2_trans": (
        "moving_placement",
        "translation",
        {"payload_object_id": "payload", "goal_fixture_id": "goal"},
        200,
        {
            "maximum_relative_linear_speed_m_s": 0.08,
            "maximum_relative_angular_speed_rad_s": 0.8,
            "relative_motion_duration_s": 0.10,
            "stable_dwell_duration_s": 0.50,
            "maximum_rim_impulse_n_s": 0.10,
        },
    ),
    "t2_se3": (
        "moving_placement",
        "se3",
        {"payload_object_id": "payload", "goal_fixture_id": "goal"},
        200,
        {
            "maximum_relative_linear_speed_m_s": 0.02,
            "maximum_relative_angular_speed_rad_s": 0.04,
            "relative_motion_duration_s": 0.10,
            "stable_dwell_duration_s": 0.50,
            "maximum_rim_impulse_n_s": 0.10,
            "maximum_orientation_error_rad": 0.12,
            "minimum_planar_clearance_m": 0.002,
            "maximum_floor_gap_m": 0.002,
            "maximum_tilt_rad": 0.05,
        },
    ),
    "t3_phase": (
        "rotating_interaction",
        "phase",
        {"wand_object_id": "wand", "wire_fixture_id": "wire", "cradle_fixture_ids": ()},
        420,
        {
            "phase_alignment_distance_m": 0.090,
            "loop_entry_distance_m": 0.030,
            "path_progress_threshold": 0.60,
            "terminal_progress_threshold": 0.85,
            "terminal_distance_m": 0.055,
        },
    ),
    "t3_full": (
        "rotating_interaction",
        "full",
        {
            "wand_object_id": "wand",
            "wire_fixture_id": "wire",
            "cradle_fixture_ids": ("cradle",),
        },
        640,
        {
            "phase_alignment_distance_m": 0.090,
            "loop_entry_distance_m": 0.030,
            "path_progress_threshold": 0.60,
            "terminal_progress_threshold": 0.85,
            "terminal_distance_m": 0.055,
            "wire_exit_clearance_m": 0.045,
            "require_wand_release": True,
        },
    ),
    "t4_sphere": (
        "free_dynamics_interception",
        "unsupported_sphere",
        {
            "target_object_id": "target",
            "ramp_fixture_id": "ramp",
            "release_gate_fixture_id": "gate",
            "downstream_surface_fixture_id": "safety_tray",
        },
        120,
        {
            "require_contact_after_ramp_exit": True,
            "require_contact_before_tray": True,
            "bilateral_contact_duration_s": 0.025,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t4_sphere_tabletop": (
        "free_dynamics_interception",
        "supported_sphere",
        {
            "target_object_id": "target",
            "ramp_fixture_id": "ramp",
            "release_gate_fixture_id": "gate",
            "downstream_surface_fixture_id": "table",
        },
        120,
        {
            "require_supported_contact": True,
            "minimum_contact_speed_m_s": 0.08,
            "require_transverse_closing_axis": False,
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t4_slider": (
        "free_dynamics_interception",
        "supported_slider",
        {
            "target_object_id": "target",
            "ramp_fixture_id": "ramp",
            "release_gate_fixture_id": "gate",
            "downstream_surface_fixture_id": "table",
        },
        120,
        {
            "require_supported_contact": True,
            "minimum_contact_speed_m_s": 0.08,
            "require_transverse_closing_axis": False,
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t4_can": (
        "free_dynamics_interception",
        "supported_can",
        {
            "target_object_id": "target",
            "ramp_fixture_id": "ramp",
            "release_gate_fixture_id": "gate",
            "downstream_surface_fixture_id": "table",
        },
        120,
        {
            "require_supported_contact": True,
            "minimum_contact_speed_m_s": 0.08,
            "require_transverse_closing_axis": False,
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
    "t5_replan": (
        "replanning",
        "single_side_strike",
        {
            "target_object_id": "target",
            "belt_fixture_id": "belt",
            "left_striker_fixture_id": "left_striker",
            "right_striker_fixture_id": "right_striker",
        },
        120,
        {
            "require_exactly_one_selected_impact": True,
            "require_contact_after_impact": True,
            "maximum_grasp_axis_error_deg": 18.0,
            "bilateral_contact_duration_s": 0.05,
            "minimum_lift_or_clearance_m": 0.05,
            "stable_hold_duration_s": 0.50,
        },
    ),
}

OOD_TASKS = {
    "ood_object": ("grasp",),
    "ood_spatial": (
        "grasp",
        "t1_belt",
        "t1_xyz",
        "t1_so3",
        "t1_occ",
        "t2_trans",
        "t2_se3",
        "t3_phase",
        "t3_full",
        "t4_sphere_tabletop",
        "t4_slider",
        "t4_can",
    ),
    "ood_geometry": (
        "t2_trans",
        "t2_se3",
        "t3_phase",
        "t3_full",
        "t4_sphere",
        "t4_sphere_tabletop",
        "t4_slider",
        "t4_can",
    ),
    "ood_motion_parameters": (
        "grasp",
        "t1_belt",
        "t1_xyz",
        "t1_so3",
        "t1_occ",
        "t2_trans",
        "t2_se3",
        "t5_replan",
    ),
    "ood_motion_law": ("grasp", "t1_xyz", "t1_so3"),
    "ood_physics": TASK_IDS[:-1],
    "ood_appearance": TASK_IDS[:-1],
    "ood_camera": TASK_IDS[:-1],
    "ood_action_delay": TASK_IDS[:-1],
}


def test_registry_and_every_task_match_the_frozen_contract_table() -> None:
    registrations = {
        task_id: (family, f"{task_id}.yaml") for task_id, (family, *_rest) in TASK_CASES.items()
    }
    assert registry._TASK_REGISTRATIONS == registrations
    assert TASK_IDS == tuple(TASK_CASES)
    assert TASK_FAMILIES == {task_id: case[0] for task_id, case in TASK_CASES.items()}
    tasks = load_tasks(ROOT / "configs" / "tasks")
    for task, (family, variant, bindings, horizon, success) in zip(
        tasks, TASK_CASES.values(), strict=True
    ):
        assert (task.family, task.variant) == (family, variant)
        assert asdict(task.bindings) == bindings
        assert task.allowed_observation_profiles == PROFILES
        assert task.allowed_action_modes == ACTION_MODES
        assert task.episode_horizon_steps == horizon
        assert asdict(task.success) == success
        assert task.metrics == METRICS


def test_task_parser_and_direct_records_reject_closed_contract_violations() -> None:
    valid = load_yaml_strict(ROOT / "configs" / "tasks" / "grasp.yaml")
    with pytest.raises(ValueError, match="invalid task family"):
        parse_task_spec(valid, task_id="grasp", family="bad")  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="variant"):
        parse_task_spec({**valid, "variant": "bad"}, task_id="grasp", family="grasp")
    with pytest.raises(ValueError, match="ordered pair"):
        parse_task_spec(
            {**valid, "allowed_observation_profiles": ["agentview_wrist", "agentview"]},
            task_id="grasp",
            family="grasp",
        )
    with pytest.raises(ValueError, match="duplicates"):
        parse_task_spec(
            {**valid, "allowed_action_modes": ["E7", "E7"]},
            task_id="grasp",
            family="grasp",
        )
    with pytest.raises(ValueError, match="metric tuple"):
        parse_task_spec(
            {**valid, "metrics": list(reversed(METRICS))},
            task_id="grasp",
            family="grasp",
        )
    task = load_task("grasp", ROOT / "configs" / "tasks")
    with pytest.raises(ValueError, match="family"):
        replace(task, family="bad")  # type: ignore[arg-type]


@pytest.mark.parametrize("schema_version", [True, 1.0])
def test_task_parser_rejects_non_integer_schema_version(schema_version: object) -> None:
    valid = load_yaml_strict(ROOT / "configs" / "tasks" / "grasp.yaml")
    with pytest.raises(ValueError, match="schema_version"):
        parse_task_spec(
            {**valid, "schema_version": schema_version}, task_id="grasp", family="grasp"
        )


def test_binding_records_reject_illegal_role_aliasing() -> None:
    DrivenInterceptionBindings("target", "target", ())
    with pytest.raises(ValueError, match="occluder"):
        DrivenInterceptionBindings("target", "belt", ("target",))
    with pytest.raises(ValueError, match="distinct"):
        MovingPlacementBindings("same", "same")
    with pytest.raises(ValueError, match="cradle"):
        RotatingInteractionBindings("wand", "wire", ("wire",))
    with pytest.raises(ValueError, match="distinct"):
        FreeDynamicsInterceptionBindings("target", "ramp", "gate", "target")
    with pytest.raises(ValueError, match="distinct"):
        ReplanningBindings("target", "belt", "left", "target")


def test_unknown_task_fails_explicitly() -> None:
    with pytest.raises(ValueError, match="unknown task"):
        load_task("unknown", ROOT / "configs" / "tasks")
    with pytest.raises(ValueError, match="non-empty string"):
        load_task([], ROOT / "configs" / "tasks")  # type: ignore[arg-type]


@pytest.mark.parametrize("schema_version", ["true", "1.0"])
def test_suite_loader_rejects_non_integer_schema_version(
    tmp_path: Path, schema_version: str
) -> None:
    path = tmp_path / "bad_schema.yaml"
    path.write_text(
        f"""schema_version: {schema_version}
suite_id: bad_schema
protocol_version: v1
repeats: 1
members:
  - manifest: absent.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="schema_version"):
        load_suite(path)


def test_all_formal_suites_load_with_frozen_membership_and_order() -> None:
    suite_dir = ROOT / "configs" / "suites"
    single_members = {
        "validation": TASK_IDS,
        "test_id": TASK_IDS,
        **OOD_TASKS,
        "stress": TASK_IDS,
    }
    for suite_id, expected_tasks in single_members.items():
        suite = load_suite(suite_dir / f"{suite_id}.yaml")
        assert suite.repeats == 1
        assert suite.group_by == GROUP_FIELDS
        assert tuple(member.manifest.stem for member in suite.members) == (suite_id,)
        assert suite.members[0].task_ids == expected_tasks
    benchmark = load_suite(suite_dir / "benchmark_v1.yaml")
    expected_benchmark = {
        name: tasks for name, tasks in single_members.items() if name != "validation"
    }
    assert benchmark.repeats == 1
    assert benchmark.group_by == GROUP_FIELDS
    assert tuple(member.manifest.stem for member in benchmark.members) == tuple(expected_benchmark)
    assert {
        member.manifest.stem: member.task_ids for member in benchmark.members
    } == expected_benchmark
    assert "t5_replan" not in single_members["ood_action_delay"]


def test_suite_records_reject_unknown_duplicate_and_out_of_order_members() -> None:
    manifest = ROOT / "manifests" / "v1" / "test_id.jsonl"
    with pytest.raises(ValueError, match="unknown task"):
        SuiteMember(manifest, ("unknown",))
    with pytest.raises(ValueError, match="unique"):
        SuiteMember(manifest, ("grasp", "grasp"))
    with pytest.raises(ValueError, match="registry order"):
        SuiteMember(manifest, ("t1_belt", "grasp"))
    member = SuiteMember(manifest, ("grasp",))
    with pytest.raises(ValueError, match="manifests must be unique"):
        SuiteSpec("bad", "v1", 1, (member, member), GROUP_FIELDS)
    for formal_id in ("test_id", "ood_object", "stress", "benchmark_v1"):
        with pytest.raises(ValueError, match="formal v1 Suites require repeats=1"):
            SuiteSpec(formal_id, "v1", 2, (member,), GROUP_FIELDS)
    SuiteSpec("research_repeat_study", "v1", 2, (member,), GROUP_FIELDS)


def test_suite_loader_fails_before_b3_when_a_manifest_is_missing(tmp_path: Path) -> None:
    path = tmp_path / "missing.yaml"
    path.write_text(
        """schema_version: 1
suite_id: missing
protocol_version: v1
repeats: 1
members:
  - manifest: absent.jsonl
    task_ids: [grasp]
report:
  group_by:
    - task_id
    - partition
    - factor
    - action_mode
    - action_representation
    - observation_profile
""",
        encoding="utf-8",
    )
    with pytest.raises(FileNotFoundError, match="absent.jsonl"):
        load_suite(path)
    with pytest.raises(FileNotFoundError, match="absent.jsonl"):
        evaluate(None, path)  # type: ignore[arg-type]
    with pytest.raises(ValueError, match="shard"):
        evaluate(None, path, shard_index=True)  # type: ignore[arg-type]
