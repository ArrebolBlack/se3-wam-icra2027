from __future__ import annotations

import gc
import json
import logging
import math
import weakref
from collections.abc import Mapping
from pathlib import Path
from typing import Any, cast

import mujoco
import numpy as np
import numpy.typing as npt
import pytest
from robosuite.controllers.composite.composite_controller import (
    REGISTERED_COMPOSITE_CONTROLLERS_DICT,
)
from robosuite.controllers.parts.controller import Controller
from robosuite.models.arenas import TableArena
from robosuite.models.objects import BoxObject
from robosuite.models.tasks import ManipulationTask
from robosuite.robots import ROBOT_CLASS_MAPPING

from se3_wam_benchmark.control.action import (
    ActionMode,
    ActionRepresentation,
    ActionSpec,
    BenchmarkAction,
    _ActionDelayQueue,
    _controller_action,
    _quaternion_xyzw_to_principal_rotvec,
    _so3_exp,
    _so3_log,
)
from se3_wam_benchmark.envs.base import (
    DynamicManipulationEnv,
    _BenchmarkCompositeController,
    _BenchmarkFixedBaseRobot,
    _E7OperationalSpaceController,
    _J8JointPositionController,
    _MassMatrixUpdateMixin,
    _native_joint_address,
    _panda_controller_config,
    _validate_runtime_versions,
)
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios.spec import (
    CameraSetSpec,
    CameraSpec,
    DrivenMotionSpec,
    FixedRotation,
    FixedTranslation,
    FixtureStateSpec,
    GraspGeometrySpec,
    LightingSpec,
    ObjectStateSpec,
    PhysicsSpec,
    RobotInitialStateSpec,
    ScenarioSpec,
)
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict
from se3_wam_benchmark.tasks.spec import TaskSpec

_PANDA_INITIAL_QPOS = (
    0.0,
    math.pi / 16.0,
    0.0,
    -5.0 * math.pi / 6.0,
    0.0,
    2.941592653589793,
    math.pi / 4.0,
)
ROOT = Path(__file__).resolve().parents[2]


def _probe_scenario(
    action_mode: str,
    *,
    observation_profile: str = "agentview",
    action_delay_steps: int = 0,
) -> ScenarioSpec:
    views = [
        CameraSpec(
            "agentview",
            (0.0, 0.0, 1.45),
            (0.0, 0.0, 0.0, 1.0),
            47.0,
        )
    ]
    if observation_profile == "agentview_wrist":
        views.append(
            CameraSpec(
                "wrist",
                (0.05, 0.0, 0.0),
                (2.0**-0.5, 2.0**-0.5, 0.0, 0.0),
                63.0,
            )
        )
    return ScenarioSpec(
        action_mode=action_mode,  # type: ignore[arg-type]
        observation_profile=observation_profile,  # type: ignore[arg-type]
        physics_timestep_s=0.002,
        control_frequency_hz=20,
        sensor_frequency_hz=20,
        action_delay_steps=action_delay_steps,
        robot_initial_state=RobotInitialStateSpec(
            _PANDA_INITIAL_QPOS,
            (0.020833, -0.020833),
        ),
        object_states=(
            ObjectStateSpec(
                "target",
                "probe_cube",
                (0.0, 0.0, 0.83),
                (0.0, 0.0, 0.0, 1.0),
                (0.0, 0.0, 0.0),
                (0.0, 0.0, 0.0),
            ),
        ),
        fixture_states=(
            FixtureStateSpec(
                "table",
                "probe_table",
                (0.0, 0.0, 0.8),
                (0.0, 0.0, 0.0, 1.0),
            ),
        ),
        geometry=GraspGeometrySpec(
            0.8,
            ((-0.4, -0.4), (0.4, 0.4)),
            0.5,
        ),
        motion=(DrivenMotionSpec("target", FixedTranslation(), FixedRotation()),),
        physics=PhysicsSpec((0.0, 0.0, -9.81), (), (), ()),
        cameras=CameraSetSpec(224, 224, tuple(views)),
        lighting=LightingSpec(()),
        events=(),
    )


class _ControllerProbeEnv(DynamicManipulationEnv):
    def __init__(
        self,
        action_mode: str,
        *,
        observation_profile: str = "agentview",
        action_delay_steps: int = 0,
        execution_translation_limit_m: float = 0.05,
    ) -> None:
        self.table_full_size = (0.8, 0.8, 0.05)
        self.table_offset = np.asarray((0.0, 0.0, 0.8), dtype=np.float64)
        scenario = _probe_scenario(
            action_mode,
            observation_profile=observation_profile,
            action_delay_steps=action_delay_steps,
        )
        super().__init__(
            task_spec=load_task("grasp"),
            scenario_spec=scenario,
            seed=0,
            execution_translation_limit_m=execution_translation_limit_m,
        )

    def _load_model(self) -> None:
        super()._load_model()
        xpos = self.robots[0].robot_model.base_xpos_offset["table"](self.table_full_size[0])
        self.robots[0].robot_model.set_base_xpos(xpos)
        arena = TableArena(
            table_full_size=self.table_full_size,
            table_offset=self.table_offset,
        )
        arena.set_origin((0.0, 0.0, 0.0))
        self.cube = BoxObject(
            name="probe_cube",
            size=(0.02, 0.02, 0.02),
            rgba=(1.0, 0.0, 0.0, 1.0),
            rng=self.rng,
        )
        self.model = ManipulationTask(
            mujoco_arena=arena,
            mujoco_robots=[robot.robot_model for robot in self.robots],
            mujoco_objects=self.cube,
        )

    def _reset_internal(self) -> None:
        super()._reset_internal()
        self.sim.data.set_joint_qpos(
            self.cube.joints[0],
            np.asarray(
                (
                    *self._scenario_spec.object_states[0].position_world_m,
                    1.0,
                    0.0,
                    0.0,
                    0.0,
                ),
                dtype=np.float64,
            ),
        )
        self.sim.forward()

    def reward(self, action: npt.NDArray[np.float64] | None = None) -> float:
        del action
        return 0.0

    def _check_success(self) -> bool:
        return False


def _readonly(values: list[float]) -> npt.NDArray[np.float64]:
    value = np.asarray(values, dtype=np.float32).astype(np.float64)
    value.setflags(write=False)
    return value


def _e7(representation: str, values: list[float]) -> BenchmarkAction:
    return BenchmarkAction("E7", representation, _readonly(values))  # type: ignore[arg-type]


def _j8(representation: str, values: list[float]) -> BenchmarkAction:
    return BenchmarkAction("J8", representation, _readonly(values))  # type: ignore[arg-type]


def test_delta_limits_are_checked_before_delay_queue_mutation() -> None:
    command = _e7("delta", [0.1, -0.1, 0.1, 0.5, -0.5, 0.5, -1])
    default = _ActionDelayQueue(ActionSpec("E7", "delta", (0.05,) * 3 + (0.5,) * 3), 1)
    with pytest.raises(ValueError, match="execution-delta"):
        default.issue(command, issued_tick=0)
    assert not default._pending
    expanded = _ActionDelayQueue(ActionSpec("E7", "delta", (0.10,) * 3 + (0.5,) * 3), 1)
    warmup, fact = expanded.issue(command, issued_tick=0)
    np.testing.assert_array_equal(warmup, np.zeros(7))
    assert fact is None
    applied, fact = expanded.issue(command, issued_tick=1)
    np.testing.assert_array_equal(applied.astype(np.float32), [1, -1, 1, 1, -1, 1, -1])
    assert fact == (0, command)
    too_large = _e7(
        "delta", [float(np.nextafter(np.float32(0.1), np.float32(np.inf))), 0, 0, 0, 0, 0, 0]
    )
    with pytest.raises(ValueError, match="execution-delta"):
        expanded.issue(too_large, issued_tick=2)
    assert len(expanded._pending) == 1


def test_expanded_limit_rejects_j8_and_native_oracle_before_execution(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="require E7 delta"):
        _ControllerProbeEnv("J8", execution_translation_limit_m=0.10)
    with pytest.raises(ValueError, match="native oracle recording requires"):
        _rollout_episode(
            load_task("grasp"),
            _probe_scenario("E7"),
            None,
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            record_directory=tmp_path,
            execution_translation_limit_m=0.10,
            _native_oracle=True,
        )


@pytest.mark.parametrize("sign", [-1.0, 1.0])
def test_explicit_translation_limit_reaches_native_osc_goal(sign: float) -> None:
    environment = _ControllerProbeEnv("E7", execution_translation_limit_m=0.10)
    try:
        environment.reset()
        part = environment.robots[0].composite_controller.part_controllers["right"]
        environment._achieved_controller_state()
        before = part.ref_pos.copy()
        command = _e7("delta", [sign * 0.1, -sign * 0.1, sign * 0.1, 0, 0, 0, -1])
        environment.step(command)
        np.testing.assert_array_equal(part.output_max, [0.1, 0.1, 0.1, 0.5, 0.5, 0.5])
        np.testing.assert_allclose(
            part.goal_pos - before, [sign * 0.1, -sign * 0.1, sign * 0.1], rtol=0, atol=1e-12
        )
        assert environment._last_action_application == (0, 0, command)
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "source_seed"),
    [
        ("grasp", 0),
        ("t1_belt", 2),
        ("t2_trans", 6),
        ("t3_phase", 0),
        ("t4_sphere", 0),
        ("t5_replan", 0),
    ],
)
def test_execution_limit_preserves_preparation_and_repeated_reset(
    task_id: str, source_seed: int
) -> None:
    task = load_task(task_id)
    recipe = _select_recipe(
        load_yaml_strict(ROOT / f"configs/scenarios/{task_id}.yaml"),
        partition="test_id",
        factor=None,
        recipe_name="e7_agentview",
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(source_seed)))
    baseline = make_env(task_id, scenario)
    expanded = make_env(task_id, scenario, execution_translation_limit_m=0.10)
    try:
        baseline.reset()
        expected_state = baseline.sim.get_state().flatten()
        expected_ctrl = baseline.sim.data.ctrl.copy()
        expected_facts = baseline._recording_frame_facts()
        for _ in range(2):
            expanded.reset()
            np.testing.assert_array_equal(expanded.sim.get_state().flatten(), expected_state)
            np.testing.assert_array_equal(expanded.sim.data.ctrl, expected_ctrl)
            assert expanded._recording_frame_facts() == expected_facts
            part = expanded.robots[0].composite_controller.part_controllers["right"]
            np.testing.assert_array_equal(part.output_max, [0.05, 0.05, 0.05, 0.5, 0.5, 0.5])
            assert expanded._action_spec is None
            expanded.step(_e7("delta", [0, 0, 0.1, 0, 0, 0, -1]))
            np.testing.assert_array_equal(part.output_max, [0.1, 0.1, 0.1, 0.5, 0.5, 0.5])
    finally:
        expanded.close()
        baseline.close()


def _runtime_action(
    environment: _ControllerProbeEnv,
    *,
    representation: str,
    displacement: float,
    gripper: float,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "delta":
        values = [displacement, 0.0, 0.0, 0.0, 0.0, 0.0, gripper]
        if mode == "J8":
            values.insert(6, 0.0)
    else:
        eef_position, eef_rotation, joint_position = environment._achieved_controller_state()
        if mode == "E7":
            assert eef_position is not None and eef_rotation is not None
            goal_position = eef_position.copy()
            goal_position[0] += displacement
            values = [
                *goal_position.tolist(),
                *_so3_log(eef_rotation).tolist(),
                gripper,
            ]
        else:
            assert joint_position is not None
            goal_joints = joint_position.copy()
            goal_joints[0] += displacement
            values = [*goal_joints.tolist(), gripper]
    return _e7(representation, values) if mode == "E7" else _j8(representation, values)


def _assert_benchmark_observation(
    observation: BenchmarkObservation,
    *,
    expected_tick: int,
    expected_views: tuple[str, ...],
) -> None:
    assert observation.tick == expected_tick
    assert observation.timestamp_s == expected_tick / 20.0
    assert observation.view_names == expected_views
    view_count = len(expected_views)
    assert observation.rgb.shape == (view_count, 224, 224, 3)
    assert observation.depth_m.shape == (view_count, 224, 224)
    assert observation.camera_intrinsics.shape == (view_count, 3, 3)
    assert observation.world_from_camera_cv.shape == (view_count, 4, 4)
    arrays = (
        observation.rgb,
        observation.depth_m,
        observation.camera_intrinsics,
        observation.world_from_camera_cv,
        observation.T_robot_base_from_world,
        observation.joint_position,
        observation.joint_velocity,
        observation.eef_position,
        observation.eef_quaternion_xyzw,
        observation.gripper_position,
        observation.gripper_velocity,
    )
    assert all(array.flags.c_contiguous and not array.flags.writeable for array in arrays)
    assert observation.rgb.dtype == np.uint8
    assert observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.dtype == np.float64
    assert observation.world_from_camera_cv.dtype == np.float64
    assert observation.joint_position.dtype == np.float32
    assert observation.joint_velocity.dtype == np.float32
    assert np.all(np.isfinite(observation.depth_m))
    assert np.all(observation.depth_m > 0.0)
    assert np.all(np.isfinite(observation.camera_intrinsics))
    assert np.all(np.isfinite(observation.world_from_camera_cv))


def _assert_compiled_camera_contract(environment: _ControllerProbeEnv) -> None:
    sensor_names = (
        ("agentview",)
        if environment._scenario_spec.observation_profile == "agentview"
        else ("agentview", "robot0_eye_in_hand")
    )
    model = environment.sim.model._model
    for sensor_name, spec in zip(
        sensor_names,
        environment._scenario_spec.cameras.views,
        strict=True,
    ):
        camera_id = int(mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, sensor_name))
        assert camera_id >= 0
        assert float(model.cam_fovy[camera_id]) == pytest.approx(
            spec.vertical_fov_deg,
            abs=1e-12,
        )
        np.testing.assert_allclose(
            model.cam_pos[camera_id],
            spec.position_parent_m,
            rtol=0.0,
            atol=1e-12,
        )
        x, y, z, w = spec.quaternion_parent_xyzw
        compiled = np.asarray(model.cam_quat[camera_id], dtype=np.float64)
        expected = np.asarray((w, x, y, z), dtype=np.float64)
        assert abs(float(np.dot(compiled, expected))) == pytest.approx(1.0, abs=1e-7)


def _fake_policy_observation(tick: int) -> BenchmarkObservation:
    arrays = (
        np.zeros((1, 224, 224, 3), dtype=np.uint8),
        np.ones((1, 224, 224), dtype=np.float32),
        np.eye(3, dtype=np.float64)[None, ...],
        np.eye(4, dtype=np.float64)[None, ...],
        np.eye(4, dtype=np.float64),
        np.zeros(7, dtype=np.float32),
        np.zeros(7, dtype=np.float32),
        np.zeros(3, dtype=np.float32),
        np.asarray((0.0, 0.0, 0.0, 1.0), dtype=np.float32),
        np.zeros(2, dtype=np.float32),
        np.zeros(2, dtype=np.float32),
    )
    for array in arrays:
        array.setflags(write=False)
    return BenchmarkObservation(
        tick=tick,
        timestamp_s=tick / 20.0,
        view_names=("agentview",),
        rgb=arrays[0],
        depth_m=arrays[1],
        camera_intrinsics=arrays[2],
        world_from_camera_cv=arrays[3],
        T_robot_base_from_world=arrays[4],
        joint_position=arrays[5],
        joint_velocity=arrays[6],
        eef_position=arrays[7],
        eef_quaternion_xyzw=arrays[8],
        gripper_position=arrays[9],
        gripper_velocity=arrays[10],
    )


class _CountingPolicy:
    def __init__(
        self,
        mode: ActionMode = "E7",
        representation: ActionRepresentation = "delta",
    ) -> None:
        self.mode = mode
        self.representation = representation
        self.reset_count = 0
        self.observation_ticks: list[int] = []
        self.actions: list[BenchmarkAction] = []

    def reset(self) -> None:
        self.reset_count += 1

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
        self.observation_ticks.append(observation.tick)
        motion = np.zeros(6 if self.mode == "E7" else 7, dtype=np.float32)
        if self.representation == "delta":
            motion[0] = 0.001 * observation.tick
        values = np.ascontiguousarray(np.concatenate((motion, (0.0,))), dtype=np.float32)
        values = np.ascontiguousarray(values, dtype=np.float64)
        values.setflags(write=False)
        action = BenchmarkAction(self.mode, self.representation, values)
        self.actions.append(action)
        return action


class _FakeRolloutEnv:
    def __init__(self, task: TaskSpec, scenario: ScenarioSpec) -> None:
        self._task_spec = task
        self._scenario_spec = scenario
        self._action_spec: ActionSpec | None = None
        self._tick = 0
        self._issued: list[BenchmarkAction] = []
        self._last_application: tuple[int, int, BenchmarkAction] | None = None
        self.closed = False
        self.close_error: RuntimeError | None = None

    def reset(self) -> Mapping[str, object]:
        self._tick = 0
        self._issued.clear()
        self._last_application = None
        self._action_spec = None
        return {}

    def _benchmark_observation(self, raw_observation: Mapping[str, object]) -> BenchmarkObservation:
        assert raw_observation == {}
        return _fake_policy_observation(self._tick)

    def step(
        self, action: BenchmarkAction
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        if self._action_spec is None:
            limits = (0.05, 0.05, 0.05, 0.5, 0.5, 0.5) if action.mode == "E7" else (0.05,) * 7
            self._action_spec = ActionSpec(
                action.mode,
                action.representation,
                limits,
            )
        self._issued.append(action)
        self._last_application = None
        delay = self._scenario_spec.action_delay_steps
        if self._tick >= delay:
            issued_tick = self._tick - delay
            self._last_application = (issued_tick, self._tick, self._issued[issued_tick])
        done = self._tick == 2
        events = (
            {}
            if self._tick == 0
            else {"approach": 0.06}
            if self._tick == 1
            else {
                "approach": 0.06,
                "fingerpad_contact": 0.11,
                "bilateral_hold": 0.12,
                "clearance": 0.13,
                "stable_dwell": 0.14,
            }
        )
        stages = tuple(
            (
                name,
                done or (self._tick == 1 and index == 0),
                1.0
                if done or (self._tick == 1 and index == 0)
                else 0.2
                if index == (0 if self._tick == 0 else 1)
                else 0.0,
                1 if done else 0,
            )
            for index, name in enumerate(
                ("approach", "fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell")
            )
        )
        info: dict[str, object] = {
            "success": done,
            "failure_code": None,
            "terminal_time_s": 0.14 if done else None,
            "events": events,
            "stage_facts": stages,
        }
        self._tick += 1
        return {}, 1.0 if done else 0.0, done, info

    def _last_action_application_fact(self) -> tuple[int, int, BenchmarkAction] | None:
        return self._last_application

    def close(self) -> None:
        self.closed = True
        if self.close_error is not None:
            raise self.close_error


class _FailingRolloutEnv(_FakeRolloutEnv):
    def step(
        self, action: BenchmarkAction
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        raw, reward, done, info = super().step(action)
        if done:
            info.update(
                success=False,
                failure_code="unsafe_contact",
                events={"approach": 0.06, "diagnostic_contact": 0.12},
                stage_facts=(
                    ("approach", True, 1.0, 0),
                    ("fingerpad_contact", False, 0.4, 1),
                    ("bilateral_hold", False, 0.0, 0),
                    ("clearance", False, 0.0, 0),
                    ("stable_dwell", False, 0.0, 0),
                ),
            )
            reward = 0.0
        return raw, reward, done, info


def test_wall_control_pacer_uses_one_fixed_epoch_and_waits_through_early_wakeups(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    now_s = 10.0
    sleep_requests: list[float] = []

    def clock() -> float:
        return now_s

    def sleep(duration_s: float) -> None:
        nonlocal now_s
        sleep_requests.append(duration_s)
        now_s += duration_s / 2.0 if len(sleep_requests) == 1 else duration_s

    monkeypatch.setattr(rollout_module, "_WALL_CLOCK", clock)
    monkeypatch.setattr(rollout_module, "_WALL_SLEEP", sleep)
    pacer = rollout_module._WallControlPacer(0.1)
    pacer.start_after_first_action()

    now_s += 0.04
    pacer.complete_tick(0)
    pacer.wait_for_tick(1)
    assert now_s == pytest.approx(10.1, abs=1e-12)

    now_s += 0.03
    pacer.complete_tick(1)
    pacer.wait_for_tick(2)
    assert now_s == pytest.approx(10.2, abs=1e-12)

    now_s += 0.1
    pacer.complete_tick(2)
    assert sleep_requests == pytest.approx((0.06, 0.03, 0.07), abs=1e-12)


def test_wall_control_pacer_allows_one_period_lateness_but_rejects_overrun(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    now_s = 4.0

    def clock() -> float:
        return now_s

    def late_sleep(duration_s: float) -> None:
        nonlocal now_s
        now_s += duration_s + 0.04

    monkeypatch.setattr(rollout_module, "_WALL_CLOCK", clock)
    monkeypatch.setattr(rollout_module, "_WALL_SLEEP", late_sleep)
    pacer = rollout_module._WallControlPacer(0.1)
    pacer.start_after_first_action()
    now_s += 0.02
    pacer.complete_tick(0)
    pacer.wait_for_tick(1)
    assert now_s == pytest.approx(4.14, abs=1e-12)

    now_s = 4.2
    pacer.complete_tick(1)
    pacer.wait_for_tick(2)
    now_s = math.nextafter(4.3, math.inf)
    with pytest.raises(RuntimeError, match="exceeded its deadline"):
        pacer.complete_tick(2)


@pytest.mark.parametrize("period", [0.0, -0.1, math.nan, math.inf, -math.inf, True])
def test_rollout_rejects_invalid_wall_control_period_before_constructing_env(
    monkeypatch: pytest.MonkeyPatch,
    period: object,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7")

    def unexpected_env(*_args: object, **_kwargs: object) -> object:
        raise AssertionError("invalid wall period must fail before environment construction")

    monkeypatch.setattr(rollout_module, "make_env", unexpected_env)
    with pytest.raises(ValueError, match="wall_control_period_s"):
        _rollout_episode(
            task,
            scenario,
            _CountingPolicy(),
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            wall_control_period_s=cast(float, period),
        )


def test_rollout_epoch_starts_after_first_action_and_overrun_stops_before_next_tick(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7")
    environment = _FakeRolloutEnv(task, scenario)
    policy = _CountingPolicy()
    now_s = 2.0
    sleeps: list[float] = []
    original_act = policy.act
    original_step = environment.step

    def clock() -> float:
        return now_s

    def sleep(duration_s: float) -> None:
        nonlocal now_s
        sleeps.append(duration_s)
        now_s += duration_s

    def timed_act(observation: BenchmarkObservation) -> BenchmarkAction:
        nonlocal now_s
        action = original_act(observation)
        if observation.tick == 0:
            now_s += 20.0
        return action

    def timed_step(
        action: BenchmarkAction,
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        nonlocal now_s
        tick = environment._tick
        result = original_step(action)
        now_s += 0.02 if tick == 0 else 0.11
        return result

    monkeypatch.setattr(rollout_module, "_WALL_CLOCK", clock)
    monkeypatch.setattr(rollout_module, "_WALL_SLEEP", sleep)
    monkeypatch.setattr(policy, "act", timed_act)
    monkeypatch.setattr(environment, "step", timed_step)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )

    with pytest.raises(RuntimeError, match="exceeded its deadline"):
        _rollout_episode(
            task,
            scenario,
            policy,
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            wall_control_period_s=0.1,
        )

    assert environment.closed is True
    assert policy.observation_ticks == [0, 1]
    assert len(environment._issued) == 2
    assert sleeps == pytest.approx((0.08,), abs=1e-12)


def test_rollout_rejects_a_cross_tick_pause_before_calling_the_next_action(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7")
    environment = _FakeRolloutEnv(task, scenario)
    policy = _CountingPolicy()
    now_s = 7.0
    sleep_requests: list[float] = []
    original_step = environment.step

    def clock() -> float:
        return now_s

    def delayed_wakeup(duration_s: float) -> None:
        nonlocal now_s
        sleep_requests.append(duration_s)
        now_s += duration_s + 0.11

    def timed_step(
        action: BenchmarkAction,
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        nonlocal now_s
        result = original_step(action)
        now_s += 0.02
        return result

    monkeypatch.setattr(rollout_module, "_WALL_CLOCK", clock)
    monkeypatch.setattr(rollout_module, "_WALL_SLEEP", delayed_wakeup)
    monkeypatch.setattr(environment, "step", timed_step)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )

    with pytest.raises(RuntimeError, match="exceeded its deadline"):
        _rollout_episode(
            task,
            scenario,
            policy,
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            wall_control_period_s=0.1,
        )

    assert environment.closed is True
    assert policy.observation_ticks == [0]
    assert len(environment._issued) == 1
    assert sleep_requests == pytest.approx((0.08,), abs=1e-12)


@pytest.mark.parametrize("mode", ["E7", "J8"])
@pytest.mark.parametrize("representation", ["delta", "absolute"])
@pytest.mark.parametrize("delay", [0, 2])
def test_formal_rollout_uses_one_policy_action_per_observation_and_real_applied_facts(
    monkeypatch: pytest.MonkeyPatch,
    mode: ActionMode,
    representation: ActionRepresentation,
    delay: int,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario(mode, action_delay_steps=delay)
    environment = _FakeRolloutEnv(task, scenario)
    policy = _CountingPolicy(mode, representation)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )

    trace = _rollout_episode(
        task,
        scenario,
        policy,
        scenario_id="v1:test_id:grasp:000000",
        partition="test_id",
        factor=None,
        repeat_index=3,
    )

    assert environment.closed is True
    assert policy.reset_count == 1
    assert policy.observation_ticks == [0, 1, 2]
    assert all(step.action is policy.actions[step.tick] for step in trace.steps)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(
        tick + delay if tick + delay < len(trace.steps) else None
        for tick in range(len(trace.steps))
    )
    assert trace.event_names == (
        "approach",
        "fingerpad_contact",
        "bilateral_hold",
        "clearance",
        "stable_dwell",
    )
    assert trace.steps[0].event_flags == (False,) * 5
    assert trace.steps[1].event_flags == (True, False, False, False, False)
    assert trace.steps[2].event_flags == (True,) * 5
    assert trace.success is True
    assert trace.failure_code is None
    result = _evaluate_episode(trace)
    assert result.episode_steps == 3
    assert result.elapsed_s == 0.14
    assert result.metrics.success_rate == 1.0
    assert result.metrics.task_completion == 1.0


@pytest.mark.parametrize("level", [logging.WARNING, logging.INFO])
def test_optional_rollout_log_preserves_reset_and_final_application_facts(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
    level: int,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7", action_delay_steps=2)
    policy = _CountingPolicy()
    traces = []
    with caplog.at_level(level, logger="se3_wam_benchmark.evaluation.rollout"):
        for repeat_index in (3, 4):
            environment = _FakeRolloutEnv(task, scenario)
            monkeypatch.setattr(
                rollout_module,
                "make_env",
                lambda _task, _scenario, *, execution_translation_limit_m: environment,
            )
            traces.append(
                _rollout_episode(
                    task,
                    scenario,
                    policy,
                    scenario_id="v1:test_id:grasp:000000",
                    partition="test_id",
                    factor=None,
                    repeat_index=repeat_index,
                )
            )
    records = [
        record for record in caplog.records if record.name == "se3_wam_benchmark.evaluation.rollout"
    ]
    if level == logging.WARNING:
        assert records == []
        return
    assert len(records) == 8 and policy.reset_count == 2
    for index, trace in enumerate(traces):
        reset, *actions = [json.loads(record.message) for record in records[index * 4 :][:4]]
        assert reset["event"] == "benchmark_episode_reset"
        for record, entry in zip(records[index * 4 :][:4], (reset, *actions), strict=True):
            assert (entry["process_id"], entry["thread_id"]) == (record.process, record.thread)
            assert entry["scenario_id"] == trace.scenario_id
            assert entry["repeat_index"] == trace.repeat_index
        assert [entry["issued_tick"] for entry in actions] == [0, 1, 2]
        assert [entry["applied_tick"] for entry in actions] == [2, None, None]
        assert [entry["episode_done"] for entry in actions] == [False, False, True]
        for entry, step in zip(actions, trace.steps, strict=True):
            assert entry["event"] == "benchmark_action"
            assert entry["command"] == step.action.value.tolist()


def test_failed_rollout_keeps_unreached_task_events_false_and_ignores_diagnostics(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("t4_sphere")
    scenario = _probe_scenario("E7", action_delay_steps=2)
    environment = _FailingRolloutEnv(task, scenario)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )

    trace = _rollout_episode(
        task,
        scenario,
        _CountingPolicy(),
        scenario_id="v1:test_id:t4_sphere:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )

    assert trace.event_names == (
        "approach",
        "fingerpad_contact",
        "bilateral_hold",
        "clearance",
        "stable_dwell",
    )
    assert trace.steps[-1].event_flags == (True, False, False, False, False)
    assert trace.failure_code == "unsafe_contact"
    result = _evaluate_episode(trace)
    assert result.failure_class == "safety"
    assert result.metrics.safety_failure_rate == 1.0


def test_rollout_projects_formal_stages_independently_of_raw_event_names(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7", action_delay_steps=2)
    environment = _FakeRolloutEnv(task, scenario)
    original_step = environment.step

    def mismatched_step(
        action: BenchmarkAction,
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        raw, reward, done, info = original_step(action)
        if done:
            info["events"] = {"approach": 0.06}
        return raw, reward, done, info

    monkeypatch.setattr(environment, "step", mismatched_step)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )
    trace = _rollout_episode(
        task,
        scenario,
        _CountingPolicy(),
        scenario_id="v1:test_id:grasp:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert trace.steps[-1].event_flags == (True,) * 5
    assert all(stage.completed for stage in trace.steps[-1].stage_progress)
    assert environment.closed is True


def test_rollout_rejects_non_mapping_step_info_before_reading_family_facts(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7")
    environment = _FakeRolloutEnv(task, scenario)
    original_step = environment.step

    def invalid_info_step(
        action: BenchmarkAction,
    ) -> tuple[Mapping[str, object], float, bool, object]:
        raw, reward, done, _ = original_step(action)
        return raw, reward, done, 3

    monkeypatch.setattr(environment, "step", invalid_info_step)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )
    with pytest.raises(RuntimeError, match="step info must be a mapping"):
        _rollout_episode(
            task,
            scenario,
            _CountingPolicy(),
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
        )
    assert environment.closed is True


def test_formal_rollout_preserves_the_primary_error_when_close_also_fails(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _probe_scenario("E7")
    environment = _FakeRolloutEnv(task, scenario)
    primary = RuntimeError("policy reset failed")

    class _FailingPolicy:
        def reset(self) -> None:
            raise primary

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            raise AssertionError(observation)

    environment.close_error = RuntimeError("close failed")
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )
    with pytest.raises(RuntimeError, match="policy reset failed") as caught:
        _rollout_episode(
            task,
            scenario,
            _FailingPolicy(),
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
        )
    assert caught.value is primary
    assert environment.closed is True
    assert caught.value.__notes__ == ["Family Env close also failed: RuntimeError('close failed')"]


def test_rollout_closes_the_real_environment_when_recorder_construction_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    task = load_task("grasp")
    environment = _ControllerProbeEnv("E7")
    scenario = environment._scenario_spec
    original_close = environment.close
    close_calls = 0

    def tracked_close() -> None:
        nonlocal close_calls
        close_calls += 1
        original_close()

    monkeypatch.setattr(environment, "close", tracked_close)
    monkeypatch.setattr(
        rollout_module,
        "make_env",
        lambda _task_id, _scenario_spec, *, execution_translation_limit_m: environment,
    )
    with pytest.raises(ValueError, match="destination directory must already exist"):
        _rollout_episode(
            task,
            scenario,
            _CountingPolicy(),
            scenario_id="v1:test_id:grasp:000000",
            partition="test_id",
            factor=None,
            repeat_index=0,
            record_directory=tmp_path / "missing",
        )
    assert close_calls == 1


def test_e7_delta_maps_physical_uncoupled_base_frame_command_to_controller_input() -> None:
    queue = _ActionDelayQueue(
        ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        delay_steps=0,
    )
    command = _e7("delta", [0.01, -0.02, 0.05, 0.1, -0.25, 0.5, 1.0])

    controller, applied = queue.issue(command, issued_tick=0)

    np.testing.assert_allclose(
        controller,
        np.array([0.2, -0.4, 1.0, 0.2, -0.5, 1.0, 1.0]),
        rtol=0.0,
        atol=1e-7,
    )
    assert applied is not None
    assert applied[0] == 0
    assert applied[1] is command


def test_e7_absolute_is_converted_against_achieved_pose_at_actual_applied_tick() -> None:
    queue = _ActionDelayQueue(
        ActionSpec("E7", "absolute", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        delay_steps=1,
    )
    command = _e7("absolute", [0.42, -0.18, 0.81, 0.0, 0.0, 0.12, -1.0])

    neutral, applied = queue.issue(
        command,
        issued_tick=0,
        achieved_eef_position=np.array([0.40, -0.20, 0.80]),
        achieved_eef_rotation=_so3_exp(np.array([0.0, 0.0, 0.10])),
    )
    np.testing.assert_array_equal(neutral, np.zeros(7))
    assert applied is None

    later = _e7("absolute", [0.41, -0.20, 0.80, 0.0, 0.0, 0.20, 0.0])
    controller, applied = queue.issue(
        later,
        issued_tick=1,
        achieved_eef_position=np.array([0.40, -0.20, 0.80]),
        achieved_eef_rotation=_so3_exp(np.array([0.0, 0.0, 0.20])),
    )
    np.testing.assert_allclose(
        controller,
        np.array([0.4, 0.4, 0.2, 0.0, 0.0, -0.16, -1.0]),
        rtol=0.0,
        atol=2e-6,
    )
    assert applied is not None
    assert applied[0] == 0
    assert applied[1] is command


@pytest.mark.parametrize("representation", ["delta", "absolute"])
def test_j8_delta_and_absolute_use_canonical_seven_joint_order(
    representation: str,
) -> None:
    queue = _ActionDelayQueue(
        ActionSpec("J8", representation, (0.05,) * 7),
        delay_steps=0,
    )
    motion = [0.01, -0.02, 0.03, -0.04, 0.05, -0.01, 0.0]
    achieved = np.array([0.2, -0.3, 0.1, -1.4, 0.0, 1.2, 0.5])
    values = motion if representation == "delta" else (achieved + motion).tolist()
    action = _j8(representation, [*values, 0.0])

    controller, applied = queue.issue(
        action,
        issued_tick=0,
        achieved_joint_position=achieved,
    )

    np.testing.assert_allclose(
        controller,
        np.array([0.2, -0.4, 0.6, -0.8, 1.0, -0.2, 0.0, 0.0]),
        rtol=0.0,
        atol=2e-6,
    )
    assert applied is not None
    assert applied[0] == 0
    assert applied[1] is action


def test_delay_queue_is_atomic_fixed_length_and_resettable() -> None:
    queue = _ActionDelayQueue(
        ActionSpec("J8", "delta", (0.05,) * 7),
        delay_steps=2,
    )
    first = _j8("delta", [0.01, 0, 0, 0, 0, 0, 0, -1])
    second = _j8("delta", [0.02, 0, 0, 0, 0, 0, 0, 1])
    third = _j8("delta", [0.03, 0, 0, 0, 0, 0, 0, 0])

    for issued_tick, action in enumerate((first, second)):
        neutral, applied = queue.issue(action, issued_tick=issued_tick)
        np.testing.assert_array_equal(neutral, np.zeros(8))
        assert applied is None
    controller, applied = queue.issue(third, issued_tick=2)
    np.testing.assert_allclose(controller, [0.2, 0, 0, 0, 0, 0, 0, -1])
    assert applied is not None
    assert applied[0] == 0
    assert applied[1] is first

    queue.reset()
    neutral, applied = queue.issue(first, issued_tick=3)
    np.testing.assert_array_equal(neutral, np.zeros(8))
    assert applied is None


def test_queue_rejects_episode_action_spec_drift_without_mutating_pending_commands() -> None:
    queue = _ActionDelayQueue(
        ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        delay_steps=1,
    )
    first = _e7("delta", [0.01, 0, 0, 0, 0, 0, 0])
    queue.issue(first, issued_tick=0)
    mismatched = _e7("absolute", [0.0, 0, 0, 0, 0, 0, 0])
    with pytest.raises(ValueError, match="episode ActionSpec"):
        queue.issue(mismatched, issued_tick=1)
    controller, applied = queue.issue(first, issued_tick=2)
    np.testing.assert_allclose(controller, [0.2, 0, 0, 0, 0, 0, 0])
    assert applied is not None
    assert applied[0] == 0
    assert applied[1] is first


@pytest.mark.parametrize("issued_tick", [True, -1, 0.0])
def test_delay_queue_requires_an_explicit_non_negative_issued_tick(
    issued_tick: object,
) -> None:
    queue = _ActionDelayQueue(
        ActionSpec("E7", "delta", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        delay_steps=0,
    )
    with pytest.raises(ValueError, match="issued_tick"):
        queue.issue(
            _e7("delta", [0.0] * 7),
            issued_tick=cast(int, issued_tick),
        )


def test_absolute_conversion_rejects_missing_bad_or_out_of_bounds_achieved_state() -> None:
    e7_queue = _ActionDelayQueue(
        ActionSpec("E7", "absolute", (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
        delay_steps=0,
    )
    e7 = _e7("absolute", [0.1, 0, 0, 0, 0, 0, 0])
    with pytest.raises(ValueError, match="achieved EEF"):
        e7_queue.issue(e7, issued_tick=0)

    j8_queue = _ActionDelayQueue(ActionSpec("J8", "absolute", (0.05,) * 7), 0)
    j8 = _j8("absolute", [0.051, 0, 0, 0, 0, 0, 0, 0])
    with pytest.raises(ValueError, match="execution-delta"):
        j8_queue.issue(
            j8,
            issued_tick=0,
            achieved_joint_position=np.zeros(7),
        )


def test_quaternion_sign_canonicalization_has_one_principal_rotation_vector() -> None:
    q = np.array([0.0, 0.0, math.sin(0.4), math.cos(0.4)])
    expected = np.array([0.0, 0.0, 0.8])
    np.testing.assert_allclose(_quaternion_xyzw_to_principal_rotvec(q), expected, atol=1e-12)
    np.testing.assert_allclose(_quaternion_xyzw_to_principal_rotvec(-q), expected, atol=1e-12)

    half_turn = np.array([-1.0, 0.0, 0.0, 0.0])
    np.testing.assert_allclose(
        _quaternion_xyzw_to_principal_rotvec(half_turn),
        np.array([math.pi, 0.0, 0.0]),
        atol=1e-12,
    )


def _assert_finite_observation(observation: Mapping[str, Any]) -> None:
    assert observation
    for value in observation.values():
        array = np.asarray(value)
        assert np.issubdtype(array.dtype, np.number)
        assert np.all(np.isfinite(array))


def test_hard_reset_releases_the_replaced_native_offscreen_context() -> None:
    environment = _ControllerProbeEnv("E7")
    initial_context = environment.sim._render_context_offscreen
    assert initial_context is not None
    initial_context_reference = weakref.ref(initial_context)
    del initial_context
    try:
        observation = environment.reset()
        assert initial_context_reference() is None
        gc.collect()
        _assert_finite_observation(observation)

        value = np.zeros(7, dtype=np.float32)
        value = np.ascontiguousarray(value, dtype=np.float64)
        value.setflags(write=False)
        next_observation, _, _, _ = environment.step(BenchmarkAction("E7", "delta", value))
        _assert_finite_observation(next_observation)
    finally:
        environment.close()


def test_native_joint_address_uses_integer_joint_types_and_native_addresses() -> None:
    model = mujoco.MjModel.from_xml_string(
        """
        <mujoco>
          <worldbody>
            <body name="free_body">
              <freejoint name="free"/>
              <geom type="sphere" size=".01" mass="1"/>
            </body>
            <body name="ball_body">
              <joint name="ball" type="ball"/>
              <geom type="sphere" size=".01" mass="1"/>
            </body>
            <body name="slide_body">
              <joint name="slide" type="slide"/>
              <geom type="sphere" size=".01" mass="1"/>
            </body>
            <body name="hinge_body">
              <joint name="hinge" type="hinge"/>
              <geom type="sphere" size=".01" mass="1"/>
            </body>
          </worldbody>
        </mujoco>
        """
    )
    for joint_name, qpos_width, qvel_width in (
        ("free", 7, 6),
        ("ball", 4, 3),
        ("slide", 1, 1),
        ("hinge", 1, 1),
    ):
        joint_id = int(model.joint(joint_name).id)
        qpos_start = int(model.jnt_qposadr[joint_id])
        qvel_start = int(model.jnt_dofadr[joint_id])
        assert _native_joint_address(model, joint_name, state="qpos") == (
            qpos_start if qpos_width == 1 else (qpos_start, qpos_start + qpos_width)
        )
        assert _native_joint_address(model, joint_name, state="qvel") == (
            qvel_start if qvel_width == 1 else (qvel_start, qvel_start + qvel_width)
        )

    with pytest.raises(RuntimeError, match="compiled Panda joint 'missing' is missing"):
        _native_joint_address(model, "missing", state="qpos")
    hinge_id = int(model.joint("hinge").id)
    model.jnt_type[hinge_id] = 99
    with pytest.raises(RuntimeError, match="unknown native type 99"):
        _native_joint_address(model, "hinge", state="qvel")


def test_controller_bridge_versions_modes_and_j8_flattened_config_are_strict() -> None:
    _validate_runtime_versions("1.5.2", "3.11.0")
    with pytest.raises(RuntimeError, match="exactly robosuite==1.5.2"):
        _validate_runtime_versions("1.5.1", "3.11.0")
    with pytest.raises(RuntimeError, match="exactly robosuite==1.5.2"):
        _validate_runtime_versions("1.5.2", "3.12.0")
    with pytest.raises(ValueError, match="unsupported Benchmark action mode"):
        _panda_controller_config("E6")

    e7 = _panda_controller_config("E7")
    j8 = _panda_controller_config("J8")
    assert e7["type"] == j8["type"] == "BASIC"
    assert set(e7["body_parts"]) == set(j8["body_parts"]) == {"right"}
    assert e7["body_parts"]["right"] == {
        "type": "OSC_POSE",
        "input_max": 1,
        "input_min": -1,
        "output_max": [0.05, 0.05, 0.05, 0.5, 0.5, 0.5],
        "output_min": [-0.05, -0.05, -0.05, -0.5, -0.5, -0.5],
        "kp": 150,
        "damping_ratio": 1,
        "impedance_mode": "fixed",
        "kp_limits": [0, 300],
        "damping_ratio_limits": [0, 10],
        "position_limits": None,
        "orientation_limits": None,
        "uncouple_pos_ori": True,
        "input_type": "delta",
        "input_ref_frame": "world",
        "interpolation": None,
        "ramp_ratio": 0.2,
        "gripper": {"type": "GRIP"},
    }
    assert j8["body_parts"]["right"] == {
        "type": "JOINT_POSITION",
        "input_max": 1,
        "input_min": -1,
        "output_max": 0.05,
        "output_min": -0.05,
        "kp": 300,
        "damping_ratio": 1,
        "impedance_mode": "fixed",
        "kp_limits": [0, 300],
        "damping_ratio_limits": [0, 10],
        "qpos_limits": None,
        "interpolation": None,
        "ramp_ratio": 0.2,
        "input_type": "delta",
        "gripper": {"type": "GRIP"},
    }


def test_e7_zero_rotation_preserves_last_goal_through_real_translation() -> None:
    environment = _ControllerProbeEnv("E7")
    try:
        environment.reset()
        controller = environment.robots[0].part_controllers["right"]
        environment.step(_e7("delta", [0.0, 0.0, 0.0, 0.06, -0.04, 0.02, -1.0]))
        goal = controller.goal_ori.copy()
        for _ in range(3):
            environment.step(_e7("delta", [0.003, 0.0, 0.002, 0.0, 0.0, 0.0, -1.0]))
            np.testing.assert_array_equal(controller.goal_ori, goal)
        achieved = controller.ref_ori_mat.copy()
        delta = np.array((0.01, 0.02, -0.01))
        np.testing.assert_allclose(
            controller.compute_goal_ori(delta), _so3_exp(delta) @ achieved, rtol=0.0, atol=1e-8
        )
        assert environment.sim.model._model.geom("robot0_link6_collision").id >= 0
        with pytest.raises(KeyError):
            environment.sim.model._model.geom("robot0_link7_collision")
    finally:
        environment.close()


def test_panda_gripper_reaches_binary_target_within_one_control_tick() -> None:
    environment = _ControllerProbeEnv("E7")
    try:
        environment.reset()
        gripper = environment.robots[0].gripper["right"]
        environment.step(_e7("delta", [0.0] * 6 + [1.0]))
        np.testing.assert_allclose(gripper.current_action, [-0.25, 0.25], rtol=0.0, atol=1e-15)
        environment.step(_e7("delta", [0.0] * 6 + [-1.0]))
        np.testing.assert_allclose(gripper.current_action, [0.0, 0.0], rtol=0.0, atol=1e-15)
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("action_mode", "action_dim", "part_type"),
    [
        ("E7", 7, _E7OperationalSpaceController),
        ("J8", 8, _J8JointPositionController),
    ],
)
def test_private_controller_bridge_runs_real_panda_reset_and_steps(
    action_mode: str,
    action_dim: int,
    part_type: type[_E7OperationalSpaceController] | type[_J8JointPositionController],
) -> None:
    upstream_update = Controller.update
    composite_registry = dict(REGISTERED_COMPOSITE_CONTROLLERS_DICT)
    robot_registry = dict(ROBOT_CLASS_MAPPING)

    environment = _ControllerProbeEnv(action_mode)
    try:
        observation = environment.reset()
        _assert_finite_observation(observation)
        assert environment.action_dim == action_dim
        assert len(environment.robots) == 1
        robot = environment.robots[0]
        assert isinstance(robot, _BenchmarkFixedBaseRobot)
        assert isinstance(robot.composite_controller, _BenchmarkCompositeController)
        part = robot.composite_controller.part_controllers["right"]
        assert isinstance(part, part_type)
        assert isinstance(part, _MassMatrixUpdateMixin)

        model = environment.sim.model._model
        joint_ids = np.asarray(
            [model.joint(name).id for name in robot.robot_joints], dtype=np.int64
        )
        arm_qpos_indexes = [int(index) for index in model.jnt_qposadr[joint_ids]]
        arm_qvel_indexes = [int(index) for index in model.jnt_dofadr[joint_ids]]
        assert robot._ref_joint_pos_indexes == arm_qpos_indexes
        assert robot._ref_joint_vel_indexes == arm_qvel_indexes
        gripper_joint_ids = np.asarray(
            [model.joint(name).id for name in robot.gripper_joints["right"]],
            dtype=np.int64,
        )
        gripper_qpos_indexes = [int(index) for index in model.jnt_qposadr[gripper_joint_ids]]
        gripper_qvel_indexes = [int(index) for index in model.jnt_dofadr[gripper_joint_ids]]
        assert robot._ref_gripper_joint_pos_indexes["right"] == gripper_qpos_indexes
        assert robot._ref_gripper_joint_vel_indexes["right"] == gripper_qvel_indexes
        np.testing.assert_array_equal(
            observation["robot0_joint_pos"],
            environment.sim.data.qpos[arm_qpos_indexes],
        )
        np.testing.assert_array_equal(
            observation["robot0_joint_vel"],
            environment.sim.data.qvel[arm_qvel_indexes],
        )
        np.testing.assert_array_equal(
            observation["robot0_gripper_qpos"],
            environment.sim.data.qpos[gripper_qpos_indexes],
        )
        np.testing.assert_array_equal(
            observation["robot0_gripper_qvel"],
            environment.sim.data.qvel[gripper_qvel_indexes],
        )

        part.update(force=True)
        assert part.mass_matrix.shape == (7, 7)
        assert part.mass_matrix.dtype == np.float64
        assert np.all(np.isfinite(part.mass_matrix))
        assert part.input_type == "delta"
        if action_mode == "E7":
            assert part.input_ref_frame == "world"
            assert part.uncoupling is True
            np.testing.assert_array_equal(
                part.output_max,
                np.asarray((0.05, 0.05, 0.05, 0.5, 0.5, 0.5)),
            )
        else:
            assert part.interpolator is None
            np.testing.assert_array_equal(part.kp, np.full(7, 300.0))
            np.testing.assert_array_equal(part.output_max, np.full(7, 0.05))

        neutral_action = _e7("delta", [0.0] * 7) if action_mode == "E7" else _j8("delta", [0.0] * 8)
        for _ in range(3):
            observation, reward, done, info = environment.step(neutral_action)
            _assert_finite_observation(observation)
            assert math.isfinite(reward)
            assert done is False
            assert isinstance(info, dict)
            assert np.all(np.isfinite(environment.sim.data.qpos))
            assert np.all(np.isfinite(environment.sim.data.qvel))
        assert environment.sim.data.time == pytest.approx(0.15, abs=1e-12)
    finally:
        environment.close()

    assert Controller.update is upstream_update
    assert REGISTERED_COMPOSITE_CONTROLLERS_DICT == composite_registry
    assert ROBOT_CLASS_MAPPING == robot_registry


@pytest.mark.parametrize(
    ("action_mode", "representation", "observation_profile"),
    [
        ("E7", "delta", "agentview"),
        ("E7", "absolute", "agentview_wrist"),
        ("J8", "delta", "agentview_wrist"),
        ("J8", "absolute", "agentview"),
    ],
)
def test_runtime_plumbing_uses_real_applied_tick_state_and_dynamic_calibration(
    action_mode: str,
    representation: str,
    observation_profile: str,
) -> None:
    environment = _ControllerProbeEnv(
        action_mode,
        observation_profile=observation_profile,
        action_delay_steps=1,
    )
    expected_views = (
        ("agentview",) if observation_profile == "agentview" else ("agentview", "wrist")
    )
    try:
        raw_reset = environment.reset()
        assert isinstance(raw_reset, Mapping)
        assert not isinstance(raw_reset, BenchmarkObservation)
        assert environment.horizon == load_task("grasp").episode_horizon_steps
        assert environment.control_freq == 20
        assert environment.get_ep_meta() == environment._scenario_spec
        _assert_compiled_camera_contract(environment)

        robot = environment.robots[0]
        np.testing.assert_allclose(
            environment.sim.data.qpos[robot._ref_joint_pos_indexes],
            _PANDA_INITIAL_QPOS,
            rtol=0.0,
            atol=1e-12,
        )
        np.testing.assert_allclose(
            environment.sim.data.qpos[robot._ref_gripper_joint_pos_indexes["right"]],
            environment._scenario_spec.robot_initial_state.gripper_position_m,
            rtol=0.0,
            atol=1e-12,
        )
        observation_reset = environment._benchmark_observation(raw_reset)
        _assert_benchmark_observation(
            observation_reset,
            expected_tick=0,
            expected_views=expected_views,
        )

        wrong_mode = _j8("delta", [0.0] * 8) if action_mode == "E7" else _e7("delta", [0.0] * 7)
        with pytest.raises(ValueError, match="mode does not match ScenarioSpec"):
            environment.step(wrong_mode)
        assert environment._episode_tick == 0
        assert environment._action_spec is None
        assert environment._last_action_application_fact() is None

        first = _runtime_action(
            environment,
            representation=representation,
            displacement=0.002,
            gripper=1.0,
        )
        raw_one, reward, done, info = environment.step(first)
        assert isinstance(raw_one, Mapping)
        assert math.isfinite(reward)
        assert done is False
        assert isinstance(info, dict)
        assert environment._action_spec is not None
        assert environment._action_spec.mode == action_mode
        assert environment._action_spec.representation == representation
        assert environment._last_action_application_fact() is None
        np.testing.assert_array_equal(
            robot.recent_actions.current,
            np.zeros(environment.action_dim),
        )
        observation_one = environment._benchmark_observation(raw_one)
        _assert_benchmark_observation(
            observation_one,
            expected_tick=1,
            expected_views=expected_views,
        )

        opposite = "absolute" if representation == "delta" else "delta"
        drift = _runtime_action(
            environment,
            representation=opposite,
            displacement=0.0,
            gripper=0.0,
        )
        time_before_drift = float(environment.sim.data.time)
        with pytest.raises(ValueError, match="episode ActionSpec"):
            environment.step(drift)
        assert environment._episode_tick == 1
        assert float(environment.sim.data.time) == time_before_drift
        assert environment._last_action_application_fact() is None

        first_joint_index = robot._ref_joint_pos_indexes[0]
        environment.sim.data.qpos[first_joint_index] += 0.01
        environment.sim.forward()
        eef_position, eef_rotation, joint_position = environment._achieved_controller_state()
        assert environment._action_spec is not None
        expected_controller = _controller_action(
            first,
            environment._action_spec,
            achieved_eef_position=eef_position,
            achieved_eef_rotation=eef_rotation,
            achieved_joint_position=joint_position,
        )
        second = _runtime_action(
            environment,
            representation=representation,
            displacement=0.0,
            gripper=0.0,
        )
        raw_two, _, _, _ = environment.step(second)
        application = environment._last_action_application_fact()
        assert application is not None
        assert application[:2] == (0, 1)
        assert application[2] is first
        np.testing.assert_allclose(
            robot.recent_actions.current,
            expected_controller,
            rtol=0.0,
            atol=1e-7,
        )
        assert float(robot.recent_actions.current[-1]) == 1.0
        observation_two = environment._benchmark_observation(raw_two)
        _assert_benchmark_observation(
            observation_two,
            expected_tick=2,
            expected_views=expected_views,
        )
        assert (
            float(
                np.dot(
                    observation_one.eef_quaternion_xyzw,
                    observation_two.eef_quaternion_xyzw,
                )
            )
            >= 0.0
        )
        np.testing.assert_allclose(
            observation_reset.world_from_camera_cv[0],
            observation_two.world_from_camera_cv[0],
            rtol=0.0,
            atol=1e-12,
        )
        if observation_profile == "agentview_wrist":
            assert not np.allclose(
                observation_reset.world_from_camera_cv[1],
                observation_two.world_from_camera_cv[1],
                rtol=0.0,
                atol=1e-7,
            )
            wrist_id = environment.sim.model.camera_name2id("robot0_eye_in_hand")
            np.testing.assert_allclose(
                observation_two.world_from_camera_cv[1, :3, 3],
                environment.sim.data.cam_xpos[wrist_id],
                rtol=0.0,
                atol=1e-12,
            )

        raw_again = environment.reset()
        assert environment._episode_tick == 0
        assert environment._action_spec is None
        assert environment._action_delay_queue is None
        assert environment._last_action_application_fact() is None
        assert environment._previous_eef_quaternion_xyzw is None
        observation_again = environment._benchmark_observation(raw_again)
        _assert_benchmark_observation(
            observation_again,
            expected_tick=0,
            expected_views=expected_views,
        )
        replacement = _runtime_action(
            environment,
            representation=opposite,
            displacement=0.0,
            gripper=-1.0,
        )
        environment.step(replacement)
        assert environment._action_spec is not None
        assert environment._action_spec.representation == opposite
        np.testing.assert_array_equal(
            environment.robots[0].recent_actions.current,
            np.zeros(environment.action_dim),
        )
        assert environment._last_action_application_fact() is None
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("action_mode", "representation"),
    [("E7", "delta"), ("E7", "absolute"), ("J8", "delta"), ("J8", "absolute")],
)
def test_zero_delay_publishes_the_action_applied_at_the_current_real_tick(
    action_mode: str,
    representation: str,
) -> None:
    environment = _ControllerProbeEnv(action_mode, action_delay_steps=0)
    try:
        environment.reset()
        action = _runtime_action(
            environment,
            representation=representation,
            displacement=0.002,
            gripper=1.0,
        )
        achieved = environment._achieved_controller_state()
        environment.step(action)
        application = environment._last_action_application_fact()
        assert application is not None
        assert application[:2] == (0, 0)
        assert application[2] is action
        assert environment._action_spec is not None
        expected = _controller_action(
            action,
            environment._action_spec,
            achieved_eef_position=achieved[0],
            achieved_eef_rotation=achieved[1],
            achieved_joint_position=achieved[2],
        )
        np.testing.assert_allclose(
            environment.robots[0].recent_actions.current,
            expected,
            rtol=0.0,
            atol=1e-7,
        )
    finally:
        environment.close()


def test_runtime_plumbing_rejects_different_episode_metadata() -> None:
    environment = _ControllerProbeEnv("E7")
    try:
        with pytest.raises(ValueError, match="concrete ScenarioSpec"):
            environment.set_ep_meta({})
        with pytest.raises(ValueError, match="different ScenarioSpec"):
            environment.set_ep_meta(_probe_scenario("E7", action_delay_steps=1))
    finally:
        environment.close()


def test_dynamic_manipulation_env_rejects_non_panda_and_multiple_robots() -> None:
    with pytest.raises(ValueError, match="one explicit Panda"):
        DynamicManipulationEnv._check_robot_configuration(None, "Sawyer")
    with pytest.raises(ValueError, match="one explicit Panda"):
        DynamicManipulationEnv._check_robot_configuration(None, ["Panda", "Panda"])


@pytest.mark.parametrize(
    ("task_id", "source_seed", "gripper"),
    [
        ("grasp", 0, -1.0),
        ("t1_belt", 2, -1.0),
        ("t2_trans", 6, 0.0),
        ("t3_phase", 0, 0.0),
        ("t4_sphere", 0, 0.0),
        ("t5_replan", 0, -1.0),
    ],
)
def test_each_family_exposes_compiled_recording_bindings_and_outcome_owned_frame_facts(
    task_id: str,
    source_seed: int,
    gripper: float,
) -> None:
    task = load_task(task_id)
    recipe = _select_recipe(
        load_yaml_strict(ROOT / f"configs/scenarios/{task_id}.yaml"),
        partition="test_id",
        factor=None,
        recipe_name="e7_agentview",
    )
    scenario = _materialize_recipe(
        task,
        recipe,
        np.random.Generator(np.random.PCG64(source_seed)),
    )
    environment = make_env(task_id, scenario)
    try:
        environment.reset()
        target_body_id, geom_table = environment._recording_snapshot_inputs()
        model = environment.sim.model._model
        assert 0 < target_body_id < model.nbody
        assert tuple(item[0] for item in geom_table) == tuple(range(model.ngeom))
        assert len({item[1] for item in geom_table}) == model.ngeom
        concrete_instances = {
            item.instance_id for item in (*scenario.object_states, *scenario.fixture_states)
        }
        assert concrete_instances <= {item[3] for item in geom_table}
        before = environment._recording_frame_facts()
        assert before[0] is False and before[1] is None and before[2] is None
        values = np.zeros(7 if scenario.action_mode == "E7" else 8, dtype=np.float32)
        values[-1] = gripper
        values = np.ascontiguousarray(values, dtype=np.float64)
        values.setflags(write=False)
        _, _, _, info = environment.step(BenchmarkAction(scenario.action_mode, "delta", values))
        after = environment._recording_frame_facts()
        assert after[:3] == (
            info["success"],
            info["failure_code"],
            info["terminal_time_s"],
        )
        assert after[3] == info["stage_facts"]
        assert tuple(item[0] for item in before[3]) == tuple(item[0] for item in after[3])
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("stage_name", "source_event"),
    [
        ("full_containment", "containment_entry"),
        ("goal_approach", "goal_pose_alignment"),
        ("path_progress_0_60", "wire_path_progress"),
        ("valid_selected_impact", "postevent_state_validated"),
    ],
)
def test_rollout_preserves_stage_flags_when_original_event_names_differ(
    stage_name: str, source_event: str
) -> None:
    from dataclasses import replace

    from se3_wam_benchmark.evaluation.result import StageProgress

    action = _e7("delta", [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0])
    histories = ((("original_start", 0.0),), (("original_start", 0.0), (source_event, 0.08)))
    drafts = [
        rollout_module._StepDraft(
            tick=tick,
            timestamp_s=tick * 0.05,
            action=action,
            reward=0.0,
            done=False,
            success=False,
            failure_code=None,
            events=histories[tick],
            stage_progress=(StageProgress(stage_name, tick == 1, 1.0 if tick else 0.5, 0),),
        )
        for tick in range(2)
    ]
    names, traces = rollout_module._build_step_traces(drafts, [0, 1])
    assert names == (stage_name,)
    assert tuple(step.event_flags for step in traces) == ((False,), (True,))
    assert tuple(draft.events for draft in drafts) == histories

    drafts[1] = replace(drafts[1], events=((source_event, 0.08),))
    with pytest.raises(RuntimeError, match="append-only ordered history"):
        rollout_module._build_step_traces(drafts, [0, 1])
