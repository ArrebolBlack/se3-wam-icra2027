from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from se3_wam_benchmark.tasks.registry import load_yaml_strict


def test_strict_yaml_rejects_duplicate_keys(tmp_path: Path) -> None:
    path = tmp_path / "duplicate.yaml"
    path.write_text("schema_version: 1\nschema_version: 1\n", encoding="utf-8")
    with pytest.raises(yaml.YAMLError, match="duplicate mapping key") as caught:
        load_yaml_strict(path)
    assert str(path) in caught.value.__notes__


def test_strict_yaml_rejects_merge_keys(tmp_path: Path) -> None:
    path = tmp_path / "merge.yaml"
    path.write_text("schema_version: 1\nmerged:\n  <<: {value: 1}\n", encoding="utf-8")
    with pytest.raises(yaml.YAMLError, match="merge keys") as caught:
        load_yaml_strict(path)
    assert str(path) in caught.value.__notes__


@pytest.mark.parametrize(
    "text",
    [
        "value: &shared 1\n",
        "value: *missing\n",
    ],
)
def test_strict_yaml_rejects_anchors_and_aliases(tmp_path: Path, text: str) -> None:
    path = tmp_path / "reference.yaml"
    path.write_text(text, encoding="utf-8")
    with pytest.raises(ValueError, match=str(path).replace("\\", "\\\\")):
        load_yaml_strict(path)


def test_yaml_parse_errors_keep_path_context(tmp_path: Path) -> None:
    path = tmp_path / "syntax.yaml"
    path.write_text("value: [\n", encoding="utf-8")
    with pytest.raises(yaml.YAMLError) as caught:
        load_yaml_strict(path)
    assert str(path) in caught.value.__notes__
