from __future__ import annotations

import math

import numpy as np
import pytest

from se3_wam_benchmark.envs.components.motion import (
    _bounded_planar_wrench,
    _conveyor_surface_velocity,
    _motion_state_at_time,
    _validate_motion_initial_pose,
)
from se3_wam_benchmark.scenarios.spec import (
    CircularTranslation,
    ConstantAngularVelocityRotation,
    ConstantVelocityTranslation,
    DrivenMotionSpec,
    FixedRotation,
    FixedTranslation,
    HarmonicRotation,
    HarmonicTranslation,
)


@pytest.mark.parametrize("yaw", [0.0, math.pi / 4.0, math.pi / 2.0])
def test_conveyor_surface_field_is_geom_local_with_fixed_world_velocity(yaw: float) -> None:
    rotation = np.array(
        [
            [math.cos(yaw), -math.sin(yaw), 0.0],
            [math.sin(yaw), math.cos(yaw), 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    motion = DrivenMotionSpec(
        "belt", ConstantVelocityTranslation((0.0, 0.07, 0.0)), FixedRotation()
    )
    field = _conveyor_surface_velocity(motion, world_from_geom_rotation=rotation)
    assert field.shape == (6,) and field.dtype == np.float64 and field.flags.c_contiguous
    np.testing.assert_allclose(rotation @ field[:3], [0.0, 0.07, 0.0], rtol=0.0, atol=1e-14)
    np.testing.assert_array_equal(field[3:], 0.0)


def test_conveyor_surface_compilation_rejects_non_constant_law_and_bad_frames() -> None:
    for translation, rotation in (
        (FixedTranslation(), FixedRotation()),
        (
            ConstantVelocityTranslation((0.0, 0.07, 0.0)),
            ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 1.0),
        ),
    ):
        with pytest.raises(ValueError, match="constant translation and fixed rotation"):
            _conveyor_surface_velocity(
                DrivenMotionSpec("belt", translation, rotation), world_from_geom_rotation=np.eye(3)
            )
    motion = DrivenMotionSpec(
        "belt", ConstantVelocityTranslation((0.0, 0.07, 0.0)), FixedRotation()
    )
    for bad in (np.eye(4), np.eye(3) * 2, np.diag([1.0, 1.0, -1.0]), np.full((3, 3), np.nan)):
        with pytest.raises(ValueError, match="proper rotation"):
            _conveyor_surface_velocity(motion, world_from_geom_rotation=bad)


@pytest.mark.parametrize("error_scale", [0.01, 100.0])
def test_shared_planar_wrench_uses_com_pd_friction_compensation_and_physical_caps(
    error_scale: float,
) -> None:
    motion = DrivenMotionSpec(
        "target",
        ConstantVelocityTranslation((0.03, 0.04, 0.0)),
        ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 0.8),
    )
    reference = _motion_state_at_time(
        motion,
        initial_position_world_m=(error_scale, -error_scale, 0.8),
        initial_quaternion_world_xyzw=(0.0, 0.0, 0.0, 1.0),
        simulator_time_s=0.0,
    )
    linear_velocity = np.array([0.01, 0.02, 5.0])
    angular_velocity = np.array([0.02, -0.03, -error_scale])
    wrench = _bounded_planar_wrench(
        reference,
        position_world_m=np.array([0.0, 0.0, 0.95]),
        quaternion_world_wxyz=np.array([1.0, 0.0, 0.0, 0.0]),
        linear_velocity_world_m_s=linear_velocity,
        angular_velocity_world_rad_s=angular_velocity,
        mass_kg=0.1,
        translation_kp_n_m=60.0,
        translation_kd_n_s_m=6.0,
        friction_compensation_acceleration_m_s2=5.0,
        yaw_kp_nm_rad=0.36,
        yaw_kd_nm_s_rad=0.02,
        tilt_kp_nm_rad=0.60,
        tilt_kd_nm_s_rad=0.01,
        force_moment_arm_m=0.020,
        maximum_force_n=3.0,
        maximum_yaw_torque_nm=0.12,
        maximum_tilt_torque_nm=0.15,
    )
    force = np.array([60 * error_scale + 0.12 + 0.3, -60 * error_scale + 0.12 + 0.4])
    force *= min(1.0, 3.0 / np.linalg.norm(force))
    tilt = np.array([0.02 * force[1] - 0.0002, -0.02 * force[0] + 0.0003])
    expected = [*force, 0.0, *tilt, min(0.12, 0.02 * (0.8 + error_scale))]
    np.testing.assert_allclose(wrench, expected, rtol=0.0, atol=1e-15)
    assert wrench.dtype == np.float64 and wrench.shape == (6,)
    assert wrench.flags.c_contiguous
    assert np.linalg.norm(wrench[:2]) <= 3.0 + 1e-15
    assert abs(wrench[5]) <= 0.12


@pytest.mark.parametrize(
    ("time_s", "position", "quaternion_wxyz", "twist", "expected"),
    [
        (
            0.002,
            (-0.003243567737536278, -0.20025628523101804, 0.8179607600000001),
            (
                0.989719571228319,
                1.1427618341358102e-20,
                1.6513727703359161e-21,
                0.14302157294489645,
            ),
            (
                -0.020933094158376284,
                0.07605678682712126,
                -0.01962,
                7.146436328918335e-33,
                -2.4210571052623733e-32,
                -1.1546319456101627e-17,
            ),
            (
                -0.2280652985663071,
                0.8738943091401317,
                0.0,
                -1.3288746712605959e-20,
                -3.9225502804667524e-21,
                1.1546319456101627e-18,
            ),
        ),
        (
            0.004,
            (-0.0032791551383410385, -0.2001267890061277, 0.8179380305525489),
            (
                0.9897195735215334,
                -2.1953234822226027e-05,
                -2.85818481335426e-06,
                0.14302155536226135,
            ),
            (
                -0.01779381814398076,
                0.06474808465748141,
                -0.011213794214917848,
                -0.02131876406929645,
                -0.0059685876239552625,
                -1.772985718598608e-05,
            ),
            (
                -0.239372134719017,
                0.9306949157534081,
                0.0,
                0.0010915207204666062,
                0.00030559168589059483,
                1.7907224597854883e-06,
            ),
        ),
    ],
)
def test_planar_wrench_matches_observed_db0_xyz_before_contact(
    time_s: float,
    position: tuple[float, ...],
    quaternion_wxyz: tuple[float, ...],
    twist: tuple[float, ...],
    expected: tuple[float, ...],
) -> None:
    # Original f6a232b, d0-train-t1_xyz-00000-s1562891368, 500 Hz pre-action samples.
    # These measured rows expose quaternion normalization and yaw reconstruction ULPs.
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            center_world_m=(0.013840232633462131, -0.2004083988046723, 0.8180000000000001),
            drift_velocity_world_m_s=(0.0, 0.058714300224028126, 0.0),
            amplitude_m=(0.018288040336560823, 0.0, 0.0),
            frequency_hz=(0.39144155660619373, 0.0, 0.0),
            phase_rad=(-1.9420803977406422, 0.0, 0.0),
        ),
        ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 0.0),
    )
    reference = _motion_state_at_time(
        motion,
        initial_position_world_m=(-0.0032017015492195253, -0.2004083988046723, 0.8180000000000001),
        initial_quaternion_world_xyzw=(0.0, 0.0, 0.14302157294489645, 0.989719571228319),
        simulator_time_s=time_s,
    )
    wrench = _bounded_planar_wrench(
        reference,
        position_world_m=np.asarray(position),
        quaternion_world_wxyz=np.asarray(quaternion_wxyz),
        linear_velocity_world_m_s=np.asarray(twist[:3]),
        angular_velocity_world_rad_s=np.asarray(twist[3:]),
        mass_kg=0.11087999999999999,
        translation_kp_n_m=50.0,
        translation_kd_n_s_m=5.0,
        friction_compensation_acceleration_m_s2=9.0,
        yaw_kp_nm_rad=0.50,
        yaw_kd_nm_s_rad=0.10,
        tilt_kp_nm_rad=0.60,
        tilt_kd_nm_s_rad=0.05,
        force_moment_arm_m=0.0,
        maximum_force_n=3.0,
        maximum_yaw_torque_nm=0.25,
        maximum_tilt_torque_nm=0.15,
    )
    np.testing.assert_array_equal(wrench, expected)


def test_fixed_motion_retains_the_initial_pose_and_has_zero_twist() -> None:
    motion = DrivenMotionSpec("target", FixedTranslation(), FixedRotation())
    initial_position = np.array([0.1, -0.2, 0.3])
    initial_quaternion = np.array([0.0, 0.0, math.sin(0.2), math.cos(0.2)])
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=initial_position,
        initial_quaternion_world_xyzw=initial_quaternion,
        simulator_time_s=3.5,
    )
    np.testing.assert_array_equal(state.position_world_m, initial_position)
    np.testing.assert_array_equal(state.quaternion_world_xyzw, initial_quaternion)
    np.testing.assert_array_equal(state.linear_velocity_world_m_s, np.zeros(3))
    np.testing.assert_array_equal(state.angular_velocity_world_rad_s, np.zeros(3))


@pytest.mark.parametrize("rounded", [0.707106781, 0.707107])
@pytest.mark.parametrize("sign", [-1.0, 1.0])
def test_motion_initial_pose_compares_rounded_quaternions_as_unit_rotations(
    rounded: float, sign: float
) -> None:
    motion = DrivenMotionSpec("target", FixedTranslation(), FixedRotation())
    concrete_quaternion = np.array([0.0, 0.0, sign * rounded, sign * rounded])
    before = concrete_quaternion.copy()
    _validate_motion_initial_pose(
        motion,
        initial_position_world_m=(0.0, 0.0, 0.0),
        initial_quaternion_world_xyzw=concrete_quaternion,
    )
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=(0.0, 0.0, 0.0),
        initial_quaternion_world_xyzw=concrete_quaternion,
        simulator_time_s=0.0,
    )
    np.testing.assert_allclose(
        state.quaternion_world_xyzw, before / np.linalg.norm(before), rtol=0.0, atol=1e-15
    )
    np.testing.assert_array_equal(concrete_quaternion, before)
    with pytest.raises(ValueError, match="unit length"):
        _validate_motion_initial_pose(
            motion,
            initial_position_world_m=(0.0, 0.0, 0.0),
            initial_quaternion_world_xyzw=before * 1.00001,
        )


def test_constant_translation_and_world_axis_rotation_are_evaluated_at_sim_time() -> None:
    motion = DrivenMotionSpec(
        "target",
        ConstantVelocityTranslation((0.1, -0.2, 0.3)),
        ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 0.5),
    )
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=np.array([1.0, 2.0, 3.0]),
        initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, 1.0]),
        simulator_time_s=2.0,
    )
    np.testing.assert_allclose(state.position_world_m, [1.2, 1.6, 3.6], atol=1e-12)
    np.testing.assert_allclose(
        state.quaternion_world_xyzw,
        [0.0, 0.0, math.sin(0.5), math.cos(0.5)],
        atol=1e-12,
    )
    np.testing.assert_array_equal(state.linear_velocity_world_m_s, [0.1, -0.2, 0.3])
    np.testing.assert_array_equal(state.angular_velocity_world_rad_s, [0.0, 0.0, 0.5])


def test_harmonic_translation_and_rotation_return_analytic_pose_and_twist() -> None:
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            center_world_m=(0.0, 0.0, 0.2),
            drift_velocity_world_m_s=(0.0, 0.0, 0.0),
            amplitude_m=(0.2, 0.0, 0.0),
            frequency_hz=(0.5, 0.0, 0.0),
            phase_rad=(math.pi / 2.0, 0.0, 0.0),
        ),
        HarmonicRotation(
            base_quaternion_world_xyzw=(0.0, 0.0, 0.0, 1.0),
            axis_world=(0.0, 0.0, 1.0),
            amplitude_rad=0.4,
            frequency_hz=0.5,
            phase_rad=0.0,
        ),
    )
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=np.array([0.2, 0.0, 0.2]),
        initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, 1.0]),
        simulator_time_s=0.5,
    )
    np.testing.assert_allclose(state.position_world_m, [0.0, 0.0, 0.2], atol=1e-12)
    np.testing.assert_allclose(state.linear_velocity_world_m_s, [-0.2 * math.pi, 0.0, 0.0])
    np.testing.assert_allclose(
        state.quaternion_world_xyzw,
        [0.0, 0.0, math.sin(0.2), math.cos(0.2)],
        atol=1e-12,
    )
    np.testing.assert_allclose(state.angular_velocity_world_rad_s, np.zeros(3), atol=1e-12)


def test_circular_translation_uses_the_right_handed_axis_frame() -> None:
    motion = DrivenMotionSpec(
        "target",
        CircularTranslation(
            center_world_m=(1.0, 2.0, 3.0),
            axis_world=(0.0, 0.0, 1.0),
            radial_direction_world=(1.0, 0.0, 0.0),
            radius_m=0.5,
            angular_speed_rad_s=2.0,
            phase_rad=0.0,
        ),
        FixedRotation(),
    )
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=np.array([1.5, 2.0, 3.0]),
        initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, 1.0]),
        simulator_time_s=math.pi / 4.0,
    )
    np.testing.assert_allclose(state.position_world_m, [1.0, 2.5, 3.0], atol=1e-12)
    np.testing.assert_allclose(state.linear_velocity_world_m_s, [-1.0, 0.0, 0.0], atol=1e-12)


def test_motion_initial_pose_validation_accepts_quaternion_sign_but_rejects_pose_drift() -> None:
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            center_world_m=(0.0, 0.0, 0.0),
            drift_velocity_world_m_s=(0.0, 0.0, 0.0),
            amplitude_m=(0.1, 0.0, 0.0),
            frequency_hz=(1.0, 0.0, 0.0),
            phase_rad=(math.pi / 2.0, 0.0, 0.0),
        ),
        HarmonicRotation(
            base_quaternion_world_xyzw=(0.0, 0.0, 0.0, 1.0),
            axis_world=(0.0, 0.0, 1.0),
            amplitude_rad=0.0,
            frequency_hz=1.0,
            phase_rad=0.0,
        ),
    )
    _validate_motion_initial_pose(
        motion,
        initial_position_world_m=np.array([0.1, 0.0, 0.0]),
        initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, -1.0]),
    )
    with pytest.raises(ValueError, match="initial position"):
        _validate_motion_initial_pose(
            motion,
            initial_position_world_m=np.array([0.0, 0.0, 0.0]),
            initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, 1.0]),
        )


def test_motion_rejects_non_finite_or_negative_simulator_time() -> None:
    motion = DrivenMotionSpec("target", FixedTranslation(), FixedRotation())
    for invalid in (-0.001, math.inf, math.nan):
        with pytest.raises(ValueError, match="simulator_time_s"):
            _motion_state_at_time(
                motion,
                initial_position_world_m=np.zeros(3),
                initial_quaternion_world_xyzw=np.array([0.0, 0.0, 0.0, 1.0]),
                simulator_time_s=invalid,
            )


@pytest.mark.parametrize("time_s", [0.0, 0.002, 0.37, 1.7])
def test_harmonic_drift_has_exact_initial_pose_and_analytic_twist(time_s: float) -> None:
    initial = np.array([0.13, -0.22, 0.84])
    amplitude = np.array([0.02, 0.03, 0.01])
    frequency = np.array([0.4, 0.7, 1.1])
    phase = np.array([0.31, -0.72, 1.11])
    drift = np.array([-0.02, 0.06, 0.01])
    center = initial - amplitude * np.sin(phase)
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            center_world_m=tuple(center),
            drift_velocity_world_m_s=tuple(drift),
            amplitude_m=tuple(amplitude),
            frequency_hz=tuple(frequency),
            phase_rad=tuple(phase),
        ),
        FixedRotation(),
    )
    _validate_motion_initial_pose(
        motion,
        initial_position_world_m=initial,
        initial_quaternion_world_xyzw=[0.0, 0.0, 0.0, 1.0],
    )
    state = _motion_state_at_time(
        motion,
        initial_position_world_m=initial,
        initial_quaternion_world_xyzw=[0.0, 0.0, 0.0, 1.0],
        simulator_time_s=time_s,
    )
    expected_position = [
        c + v * time_s + a * math.sin(2.0 * math.pi * f * time_s + p)
        for c, v, a, f, p in zip(center, drift, amplitude, frequency, phase, strict=True)
    ]
    expected_velocity = [
        v + a * 2.0 * math.pi * f * math.cos(2.0 * math.pi * f * time_s + p)
        for v, a, f, p in zip(drift, amplitude, frequency, phase, strict=True)
    ]
    np.testing.assert_allclose(state.position_world_m, expected_position, rtol=0.0, atol=1e-15)
    np.testing.assert_allclose(
        state.linear_velocity_world_m_s, expected_velocity, rtol=0.0, atol=1e-15
    )


def test_matched_t1_translation_keeps_forward_drift_and_lateral_harmonic_independent() -> None:
    phase = 0.6
    amplitude = 0.025
    forward = 0.07
    frequency = 0.45
    initial = (0.01, -0.22, 0.818)
    translation = HarmonicTranslation(
        center_world_m=(initial[0] - amplitude * math.sin(phase), initial[1], initial[2]),
        drift_velocity_world_m_s=(0.0, forward, 0.0),
        amplitude_m=(amplitude, 0.0, 0.0),
        frequency_hz=(frequency, 0.0, 0.0),
        phase_rad=(phase, 0.0, 0.0),
    )
    xyz = DrivenMotionSpec("target", translation, FixedRotation())
    yaw = DrivenMotionSpec(
        "target", translation, ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 0.8)
    )
    for time_s in (0.0, 0.002, 0.85, 4.0):
        states = [
            _motion_state_at_time(
                motion,
                initial_position_world_m=initial,
                initial_quaternion_world_xyzw=[0.0, 0.0, 0.0, 1.0],
                simulator_time_s=time_s,
            )
            for motion in (xyz, yaw)
        ]
        np.testing.assert_array_equal(states[0].position_world_m, states[1].position_world_m)
        np.testing.assert_array_equal(
            states[0].linear_velocity_world_m_s, states[1].linear_velocity_world_m_s
        )
        np.testing.assert_allclose(
            states[0].position_world_m,
            [
                initial[0]
                + amplitude
                * (math.sin(2.0 * math.pi * frequency * time_s + phase) - math.sin(phase)),
                initial[1] + forward * time_s,
                initial[2],
            ],
            rtol=0.0,
            atol=1e-15,
        )
        assert states[0].linear_velocity_world_m_s[1] == forward
        assert states[0].linear_velocity_world_m_s[2] == 0.0
        np.testing.assert_array_equal(states[0].angular_velocity_world_rad_s, [0.0, 0.0, 0.0])
        np.testing.assert_array_equal(states[1].angular_velocity_world_rad_s, [0.0, 0.0, 0.8])


def test_zero_drift_harmonic_keeps_the_existing_pose_and_twist_bit_exact() -> None:
    center = np.array([0.11, -0.2, 0.822])
    amplitude = np.array([0.02, 0.0, 0.0])
    angular_frequency = 2.0 * math.pi * np.array([0.45, 0.0, 0.0])
    phase = np.array([0.6, 0.0, 0.0])
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            center_world_m=tuple(center),
            drift_velocity_world_m_s=(0.0, 0.0, 0.0),
            amplitude_m=tuple(amplitude),
            frequency_hz=(0.45, 0.0, 0.0),
            phase_rad=tuple(phase),
        ),
        FixedRotation(),
    )
    for time_s in (0.0, 0.002, 0.37, 1.7):
        state = _motion_state_at_time(
            motion,
            initial_position_world_m=center + amplitude * np.sin(phase),
            initial_quaternion_world_xyzw=[0.0, 0.0, 0.0, 1.0],
            simulator_time_s=time_s,
        )
        phase_vector = angular_frequency * time_s + phase
        np.testing.assert_array_equal(
            state.position_world_m, center + amplitude * np.sin(phase_vector)
        )
        np.testing.assert_array_equal(
            state.linear_velocity_world_m_s, amplitude * angular_frequency * np.cos(phase_vector)
        )
