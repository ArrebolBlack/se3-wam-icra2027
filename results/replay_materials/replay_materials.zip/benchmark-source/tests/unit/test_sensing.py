from __future__ import annotations

import math
import warnings
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from threading import Barrier, Event, current_thread

import mujoco
import numpy as np
import numpy.typing as npt
import pytest

from se3_wam_benchmark.evaluation.metrics.object_pose import _offline_object_pose_metrics
from se3_wam_benchmark.evaluation.metrics.optical_flow import _offline_optical_flow_metrics
from se3_wam_benchmark.sensing.camera import (
    _camera_intrinsics,
    _compiled_camera_calibration,
    _metric_depth,
    _robot_base_from_world,
    _world_from_camera_cv,
)
from se3_wam_benchmark.sensing.observation import (
    BenchmarkObservation,
    ObservationSpec,
    _build_benchmark_observation,
)
from se3_wam_benchmark.supervision import optical_flow as optical_flow_module
from se3_wam_benchmark.supervision.object_pose import (
    _continuous_object_quaternion_xyzw,
    _target_body_origin_pose_world,
)
from se3_wam_benchmark.supervision.optical_flow import _exact_dense_optical_flow
from se3_wam_benchmark.supervision.snapshot import (
    SupervisionSnapshot,
    _assemble_supervision_snapshot,
)

_COMPILED_CAMERA_XML = """
<mujoco model="compiled-camera-test">
  <statistic extent="2"/>
  <visual>
    <map znear="0.01" zfar="5"/>
  </visual>
  <worldbody>
    <camera name="agentview" pos="1 2 3" quat="1 0 0 0" fovy="40"/>
    <camera name="orthographic" pos="0 0 2" projection="orthographic" fovy="1"/>
    <body name="robot_base" pos="0.5 -0.25 0.1">
      <freejoint/>
      <geom type="sphere" size="0.05" mass="1"/>
      <camera name="robot0_eye_in_hand" pos="0.1 0 0.4" fovy="60"/>
    </body>
  </worldbody>
</mujoco>
"""


def _compiled_camera_model_and_data() -> tuple[mujoco.MjModel, mujoco.MjData]:
    model = mujoco.MjModel.from_xml_string(_COMPILED_CAMERA_XML)
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    return model, data


def _readonly(value: npt.ArrayLike, dtype: npt.DTypeLike) -> np.ndarray:
    result = np.ascontiguousarray(value, dtype=dtype)
    result.setflags(write=False)
    return result


def _supervision_observation(
    *,
    tick: int = 0,
    timestamp_s: float = 0.0,
    views: tuple[str, ...] = ("agentview",),
    world_from_camera_cv: npt.NDArray[np.float64] | None = None,
) -> BenchmarkObservation:
    count = len(views)
    cameras = (
        np.repeat(np.eye(4, dtype=np.float64)[None, ...], count, axis=0)
        if world_from_camera_cv is None
        else world_from_camera_cv
    )
    intrinsics = np.repeat(
        np.array(
            [[100.0, 0.0, 112.0], [0.0, 100.0, 112.0], [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )[None, ...],
        count,
        axis=0,
    )
    return BenchmarkObservation(
        tick=tick,
        timestamp_s=timestamp_s,
        view_names=views,
        rgb=_readonly(np.zeros((count, 224, 224, 3)), np.uint8),
        depth_m=_readonly(np.ones((count, 224, 224)), np.float32),
        camera_intrinsics=_readonly(intrinsics, np.float64),
        world_from_camera_cv=_readonly(cameras, np.float64),
        T_robot_base_from_world=_readonly(np.eye(4), np.float64),
        joint_position=_readonly(np.zeros(7), np.float32),
        joint_velocity=_readonly(np.zeros(7), np.float32),
        eef_position=_readonly(np.zeros(3), np.float32),
        eef_quaternion_xyzw=_readonly([0.0, 0.0, 0.0, 1.0], np.float32),
        gripper_position=_readonly(np.zeros(2), np.float32),
        gripper_velocity=_readonly(np.zeros(2), np.float32),
    )


def _supervision_snapshot(
    *,
    tick: int,
    timestamp_s: float,
    geom_id: npt.NDArray[np.int32] | None = None,
    depth_m: npt.NDArray[np.float32] | None = None,
    world_from_geom: npt.NDArray[np.float64] | None = None,
    world_from_camera_cv: npt.NDArray[np.float64] | None = None,
    views: tuple[str, ...] = ("agentview",),
    identities: tuple[str, ...] = ("target",),
) -> SupervisionSnapshot:
    count = len(views)
    observation = _supervision_observation(
        tick=tick,
        timestamp_s=timestamp_s,
        views=views,
        world_from_camera_cv=world_from_camera_cv,
    )
    return SupervisionSnapshot(
        tick=tick,
        timestamp_s=timestamp_s,
        view_names=views,
        depth_m=(observation.depth_m if depth_m is None else _readonly(depth_m, np.float32)),
        geom_id=_readonly(
            np.full((count, 224, 224), -1, dtype=np.int32) if geom_id is None else geom_id,
            np.int32,
        ),
        camera_intrinsics=observation.camera_intrinsics,
        world_from_camera_cv=observation.world_from_camera_cv,
        world_from_geom=_readonly(
            np.repeat(np.eye(4)[None, ...], len(identities), axis=0)
            if world_from_geom is None
            else world_from_geom,
            np.float64,
        ),
        target_object_pose_world=_readonly([0, 0, 0, 0, 0, 0, 1], np.float64),
        geom_semantic_identity=identities,
    )


def test_normalized_mujoco_depth_is_converted_to_metric_depth() -> None:
    raw = np.array([[0.0, 0.5, 1.0]], dtype=np.float32)
    depth = _metric_depth(raw, extent=2.0, znear=0.01, zfar=5.0)
    # Frozen DB0 float32 conversion retains source roundoff at the far plane.
    expected = np.array(
        [[0.019999999552965164, 0.03992015868425369, 10.000128746032715]],
        dtype=np.float32,
    )
    np.testing.assert_array_equal(depth, expected)
    assert depth.dtype == np.float32

    with pytest.raises(ValueError, match="normalized depth"):
        _metric_depth(np.array([1.01], dtype=np.float32), extent=2.0, znear=0.01, zfar=5.0)


def test_intrinsics_and_cv_extrinsics_match_the_frozen_raster_convention() -> None:
    intrinsics = _camera_intrinsics(40.0, 224, 224)
    focal = 112.0 / math.tan(math.radians(20.0))
    np.testing.assert_allclose(
        intrinsics,
        np.array([[focal, 0.0, 111.5], [0.0, focal, 111.5], [0.0, 0.0, 1.0]]),
    )
    # OpenGL samples at half-integer window coordinates. Integer CV pixel centers
    # must describe the same rays without shifting any downstream consumer.
    window_intrinsics = intrinsics.copy()
    window_intrinsics[:2, 2] += 0.5
    pixels = np.array([[0.0, 0.0, 1.0], [72.0, 154.0, 1.0], [223.0, 223.0, 1.0]])
    window_pixels = pixels + np.array([0.5, 0.5, 0.0])
    np.testing.assert_allclose(
        pixels @ np.linalg.inv(intrinsics).T,
        window_pixels @ np.linalg.inv(window_intrinsics).T,
        rtol=0.0,
        atol=1e-15,
    )

    world_from_camera = _world_from_camera_cv(np.array([1.0, 2.0, 3.0]), np.eye(3))
    np.testing.assert_array_equal(world_from_camera[:3, 3], [1.0, 2.0, 3.0])
    np.testing.assert_array_equal(world_from_camera[:3, :3], np.diag([1.0, -1.0, -1.0]))


def test_robot_base_inverse_transform_is_a_rigid_world_to_base_map() -> None:
    yaw = math.pi / 2.0
    rotation = np.array(
        [[math.cos(yaw), -math.sin(yaw), 0.0], [math.sin(yaw), math.cos(yaw), 0.0], [0, 0, 1]]
    )
    transform = _robot_base_from_world(np.array([1.0, 2.0, 0.0]), rotation)
    world_point = np.array([1.0, 3.0, 0.0, 1.0])
    np.testing.assert_allclose(transform @ world_point, [1.0, 0.0, 0.0, 1.0], atol=1e-12)


def test_compiled_mujoco_calibration_reads_ordered_views_and_recomputes_dynamic_poses() -> None:
    model, data = _compiled_camera_model_and_data()
    names = ("agentview", "robot0_eye_in_hand")
    first = _compiled_camera_calibration(
        model,
        data,
        camera_names=names,
        robot_base_body_name="robot_base",
        image_height_px=224,
        image_width_px=224,
    )

    assert first.camera_names == names
    arrays = {
        "camera_intrinsics": (first.camera_intrinsics, (2, 3, 3)),
        "world_from_camera_cv": (first.world_from_camera_cv, (2, 4, 4)),
        "T_robot_base_from_world": (first.T_robot_base_from_world, (4, 4)),
    }
    for array, shape in arrays.values():
        assert array.dtype == np.float64
        assert array.shape == shape
        assert array.flags.c_contiguous
        assert not array.flags.writeable
    np.testing.assert_allclose(
        first.camera_intrinsics,
        np.stack((_camera_intrinsics(40.0, 224, 224), _camera_intrinsics(60.0, 224, 224))),
    )
    camera_ids = tuple(mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, name) for name in names)
    expected_extrinsics = np.stack(
        tuple(
            _world_from_camera_cv(
                data.cam_xpos[camera_id],
                data.cam_xmat[camera_id].reshape((3, 3)),
            )
            for camera_id in camera_ids
        )
    )
    np.testing.assert_allclose(first.world_from_camera_cv, expected_extrinsics)
    base_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "robot_base")
    np.testing.assert_allclose(
        first.T_robot_base_from_world,
        _robot_base_from_world(data.xpos[base_id], data.xmat[base_id].reshape((3, 3))),
    )
    assert first.depth_extent == pytest.approx(2.0)
    assert first.depth_znear == pytest.approx(0.01)
    assert first.depth_zfar == pytest.approx(5.0)
    depth = _metric_depth(
        np.array([0.0, 1.0], dtype=np.float32),
        extent=first.depth_extent,
        znear=first.depth_znear,
        zfar=first.depth_zfar,
    )
    np.testing.assert_array_equal(
        depth, np.array([0.019999999552965164, 10.000128746032715], dtype=np.float32)
    )

    first_agentview = first.world_from_camera_cv[0].copy()
    first_wrist = first.world_from_camera_cv[1].copy()
    first_base = first.T_robot_base_from_world.copy()
    data.qpos[:3] += np.array([0.2, -0.1, 0.3])
    yaw = math.radians(30.0)
    data.qpos[3:7] = np.array([math.cos(yaw / 2.0), 0.0, 0.0, math.sin(yaw / 2.0)])
    mujoco.mj_forward(model, data)
    second = _compiled_camera_calibration(
        model,
        data,
        camera_names=names,
        robot_base_body_name="robot_base",
        image_height_px=224,
        image_width_px=224,
    )

    np.testing.assert_allclose(second.world_from_camera_cv[0], first_agentview)
    assert not np.allclose(second.world_from_camera_cv[1], first_wrist)
    assert not np.allclose(second.T_robot_base_from_world, first_base)
    np.testing.assert_allclose(
        second.world_from_camera_cv[1],
        _world_from_camera_cv(
            data.cam_xpos[camera_ids[1]],
            data.cam_xmat[camera_ids[1]].reshape((3, 3)),
        ),
    )
    np.testing.assert_allclose(
        second.T_robot_base_from_world,
        _robot_base_from_world(data.xpos[base_id], data.xmat[base_id].reshape((3, 3))),
    )


def test_compiled_mujoco_calibration_rejects_invalid_identities_projection_and_raster() -> None:
    model, data = _compiled_camera_model_and_data()
    common = {
        "model": model,
        "data": data,
        "robot_base_body_name": "robot_base",
        "image_height_px": 224,
        "image_width_px": 224,
    }
    with pytest.raises(ValueError, match="duplicates"):
        _compiled_camera_calibration(
            camera_names=("agentview", "agentview"),
            **common,  # type: ignore[arg-type]
        )
    with pytest.raises(ValueError, match="missing_camera"):
        _compiled_camera_calibration(
            camera_names=("missing_camera",),
            **common,  # type: ignore[arg-type]
        )
    with pytest.raises(ValueError, match="missing_base"):
        _compiled_camera_calibration(
            model,
            data,
            camera_names=("agentview",),
            robot_base_body_name="missing_base",
            image_height_px=224,
            image_width_px=224,
        )
    with pytest.raises(ValueError, match="perspective"):
        _compiled_camera_calibration(
            model,
            data,
            camera_names=("orthographic",),
            robot_base_body_name="robot_base",
            image_height_px=224,
            image_width_px=224,
        )
    with pytest.raises(ValueError, match="224x224"):
        _compiled_camera_calibration(
            model,
            data,
            camera_names=("agentview",),
            robot_base_body_name="robot_base",
            image_height_px=223,
            image_width_px=224,
        )

    other_model, _ = _compiled_camera_model_and_data()
    with pytest.raises(ValueError, match="belong"):
        _compiled_camera_calibration(
            other_model,
            data,
            camera_names=("agentview",),
            robot_base_body_name="robot_base",
            image_height_px=224,
            image_width_px=224,
        )


def test_compiled_mujoco_calibration_rejects_nonfinite_compiled_values() -> None:
    model, data = _compiled_camera_model_and_data()
    agentview_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_CAMERA, "agentview")
    model.cam_fovy[agentview_id] = math.nan
    with pytest.raises(ValueError, match="vertical_fov_deg"):
        _compiled_camera_calibration(
            model,
            data,
            camera_names=("agentview",),
            robot_base_body_name="robot_base",
            image_height_px=224,
            image_width_px=224,
        )


def test_observation_builder_selects_only_policy_visible_current_sensors() -> None:
    raw = {
        "agentview_image": np.zeros((224, 224, 3), dtype=np.uint8),
        "agentview_depth": np.zeros((224, 224, 1), dtype=np.float32),
        "robot0_joint_pos": np.arange(7, dtype=np.float64),
        "robot0_joint_vel": np.zeros(7, dtype=np.float64),
        "robot0_eef_pos": np.array([0.1, 0.2, 0.3]),
        "robot0_eef_quat_site": np.array([0.0, 0.0, 0.0, 1.0]),
        "robot0_gripper_qpos": np.array([0.01, -0.01]),
        "robot0_gripper_qvel": np.zeros(2),
        "scenario_id": "must-not-leak",
        "event_flags": np.array([1]),
        "geom_id": np.ones((224, 224), dtype=np.int32),
        "future_state": np.ones(3),
    }
    observation = _build_benchmark_observation(
        raw,
        observation_spec=ObservationSpec(("agentview",)),
        camera_sensor_names=("agentview",),
        depth_extent=1.0,
        depth_znear=0.01,
        depth_zfar=10.0,
        camera_intrinsics=np.eye(3, dtype=np.float64)[None, ...],
        world_from_camera_cv=np.eye(4, dtype=np.float64)[None, ...],
        T_robot_base_from_world=np.eye(4, dtype=np.float64),
        tick=3,
        timestamp_s=0.15,
        previous_eef_quaternion_xyzw=np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float32),
    )

    assert observation.tick == 3
    assert observation.view_names == ("agentview",)
    assert observation.rgb.shape == (1, 224, 224, 3)
    assert observation.depth_m.shape == (1, 224, 224)
    np.testing.assert_array_equal(observation.joint_position, np.arange(7, dtype=np.float32))
    assert all(not value.flags.writeable for value in (observation.rgb, observation.depth_m))


def test_eef_quaternion_sign_is_continuous_across_the_pi_crossing() -> None:
    raw = {
        "agentview_image": np.zeros((224, 224, 3), dtype=np.uint8),
        "agentview_depth": np.zeros((224, 224, 1), dtype=np.float32),
        "robot0_joint_pos": np.zeros(7),
        "robot0_joint_vel": np.zeros(7),
        "robot0_eef_pos": np.zeros(3),
        "robot0_eef_quat_site": np.array([0.0, 0.0, 0.0, 1.0]),
        "robot0_gripper_qpos": np.zeros(2),
        "robot0_gripper_qvel": np.zeros(2),
    }
    common = {
        "observation_spec": ObservationSpec(("agentview",)),
        "camera_sensor_names": ("agentview",),
        "depth_extent": 1.0,
        "depth_znear": 0.01,
        "depth_zfar": 10.0,
        "camera_intrinsics": np.eye(3, dtype=np.float64)[None, ...],
        "world_from_camera_cv": np.eye(4, dtype=np.float64)[None, ...],
        "T_robot_base_from_world": np.eye(4, dtype=np.float64),
        "timestamp_s": 0.0,
    }

    angle_0 = math.radians(179.0)
    raw["robot0_eef_quat_site"] = np.array(
        [0.0, 0.0, math.sin(angle_0 / 2.0), math.cos(angle_0 / 2.0)]
    )
    first = _build_benchmark_observation(raw, tick=0, **common)  # type: ignore[arg-type]
    angle_1 = math.radians(181.0)
    raw["robot0_eef_quat_site"] = np.array(
        [0.0, 0.0, math.sin(angle_1 / 2.0), math.cos(angle_1 / 2.0)]
    )
    second = _build_benchmark_observation(
        raw,
        tick=1,
        previous_eef_quaternion_xyzw=first.eef_quaternion_xyzw,
        **common,  # type: ignore[arg-type]
    )

    assert first.eef_quaternion_xyzw[3] >= 0.0
    assert second.eef_quaternion_xyzw[3] < 0.0
    assert float(np.dot(first.eef_quaternion_xyzw, second.eef_quaternion_xyzw)) >= 0.0


def test_observation_builder_fails_on_missing_or_misaligned_native_sensor_data() -> None:
    raw = {
        "agentview_image": np.zeros((224, 224, 3), dtype=np.uint8),
        "agentview_depth": np.zeros((224, 224, 1), dtype=np.float32),
        "robot0_joint_pos": np.zeros(7),
        "robot0_joint_vel": np.zeros(7),
        "robot0_eef_pos": np.zeros(3),
        "robot0_eef_quat_site": np.array([0.0, 0.0, 0.0, 1.0]),
        "robot0_gripper_qpos": np.zeros(2),
    }
    with pytest.raises(ValueError, match="robot0_gripper_qvel"):
        _build_benchmark_observation(
            raw,
            observation_spec=ObservationSpec(("agentview",)),
            camera_sensor_names=("agentview",),
            depth_extent=1.0,
            depth_znear=0.01,
            depth_zfar=10.0,
            camera_intrinsics=np.eye(3, dtype=np.float64)[None, ...],
            world_from_camera_cv=np.eye(4, dtype=np.float64)[None, ...],
            T_robot_base_from_world=np.eye(4, dtype=np.float64),
            tick=0,
            timestamp_s=0.0,
        )


def test_snapshot_assembly_flips_native_segmentation_and_uses_body_origin_pose() -> None:
    model, data = _compiled_camera_model_and_data()
    observation = _supervision_observation()
    segmentation = np.full((1, 224, 224, 2), -1, dtype=np.int32)
    segmentation[0, 223 - 17, 31] = (int(mujoco.mjtObj.mjOBJ_GEOM), 0)
    segmentation[0, 223 - 18, 31] = (int(mujoco.mjtObj.mjOBJ_BODY), 1)
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "robot_base")
    snapshot = _assemble_supervision_snapshot(
        observation,
        model,
        data,
        element_segmentation_opengl=segmentation,
        target_body_id=body_id,
        geom_semantic_identity=("robot",),
        previous_target_quaternion_xyzw=None,
    )

    assert snapshot.geom_id[0, 17, 31] == 0
    assert snapshot.geom_id[0, 18, 31] == -1
    np.testing.assert_array_equal(snapshot.target_object_pose_world[:3], data.xpos[body_id])
    np.testing.assert_array_equal(snapshot.world_from_geom[0, :3, 3], data.geom_xpos[0])
    assert all(
        not value.flags.writeable and value.flags.c_contiguous
        for value in (
            snapshot.depth_m,
            snapshot.geom_id,
            snapshot.world_from_geom,
            snapshot.target_object_pose_world,
        )
    )

    segmentation[0, 0, 0] = (int(mujoco.mjtObj.mjOBJ_GEOM), model.ngeom)
    with pytest.raises(ValueError, match="invalid compiled geom"):
        _assemble_supervision_snapshot(
            observation,
            model,
            data,
            element_segmentation_opengl=segmentation,
            target_body_id=body_id,
            geom_semantic_identity=("robot",),
            previous_target_quaternion_xyzw=None,
        )


def test_target_pose_uses_integrated_free_body_origin_and_continuous_xyzw_sign() -> None:
    model = mujoco.MjModel.from_xml_string(
        """
        <mujoco>
          <worldbody>
            <body name="target">
              <freejoint/>
              <inertial pos="0.1 0 0" mass="1" diaginertia="0.01 0.01 0.01"/>
              <geom type="sphere" size="0.02" contype="0" conaffinity="0" density="0"/>
            </body>
          </worldbody>
        </mujoco>
        """
    )
    data = mujoco.MjData(model)
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "target")
    data.qpos[:3] = (0.3, -0.2, 0.7)
    angle = math.radians(179.0)
    data.qpos[3:7] = (math.cos(angle / 2.0), 0.0, 0.0, math.sin(angle / 2.0))
    mujoco.mj_forward(model, data)
    first = _target_body_origin_pose_world(
        model,
        data,
        target_body_id=body_id,
        tick=0,
        previous_quaternion_xyzw=None,
    )
    np.testing.assert_array_equal(first[:3], data.xpos[body_id])
    assert not np.array_equal(first[:3], data.xipos[body_id])
    assert first[6] >= 0.0

    angle = math.radians(181.0)
    data.qpos[3:7] = (math.cos(angle / 2.0), 0.0, 0.0, math.sin(angle / 2.0))
    mujoco.mj_forward(model, data)
    second = _target_body_origin_pose_world(
        model,
        data,
        target_body_id=body_id,
        tick=1,
        previous_quaternion_xyzw=first[3:],
    )
    assert second[6] < 0.0
    assert float(np.dot(first[3:], second[3:])) >= 0.0
    canonical = _continuous_object_quaternion_xyzw(
        np.asarray((0.0, 0.0, 0.0, -1.0), dtype=np.float64),
        tick=0,
        previous_quaternion_xyzw=None,
    )
    np.testing.assert_array_equal(canonical, (0.0, 0.0, 0.0, 1.0))
    with pytest.raises(ValueError, match="cleared"):
        _continuous_object_quaternion_xyzw(
            first[3:].copy(), tick=0, previous_quaternion_xyzw=first[3:]
        )

    data.qvel[:3] = (0.1, -0.2, 0.3)
    mujoco.mj_step(model, data)
    cached_position = data.xpos.copy()
    integrated_position = data.qpos[:3].copy()
    assert not np.array_equal(integrated_position, cached_position[body_id])
    integrated = _target_body_origin_pose_world(
        model, data, target_body_id=body_id, tick=2, previous_quaternion_xyzw=second[3:]
    )
    np.testing.assert_array_equal(integrated[:3], integrated_position)
    np.testing.assert_array_equal(data.xpos, cached_position)


def test_exact_dense_flow_is_zero_for_a_static_visible_geom() -> None:
    geom_id = np.zeros((1, 224, 224), dtype=np.int32)
    source = _supervision_snapshot(tick=0, timestamp_s=0.0, geom_id=geom_id)
    target = _supervision_snapshot(tick=1, timestamp_s=0.05, geom_id=geom_id)
    flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    np.testing.assert_array_equal(flow, 0.0)
    assert np.all(valid) and np.all(future_visible)
    assert flow.dtype == np.float32 and valid.dtype == future_visible.dtype == np.bool_
    assert all(
        value.flags.c_contiguous and not value.flags.writeable
        for value in (flow, valid, future_visible)
    )


def test_exact_dense_flow_tracks_rigid_translation_visibility_and_frame_exit() -> None:
    source_geom = np.full((1, 224, 224), -1, dtype=np.int32)
    source_geom[0, 40, 50] = 0
    source_geom[0, 60, 100] = 0
    source_geom[0, 80, 220] = 0
    target_geom = np.full_like(source_geom, -1)
    target_geom[0, 40, 60] = 0
    transforms = np.eye(4, dtype=np.float64)[None, ...]
    moved = transforms.copy()
    moved[0, 0, 3] = 0.1
    source = _supervision_snapshot(
        tick=0,
        timestamp_s=0.0,
        geom_id=source_geom,
        world_from_geom=transforms,
    )
    target = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        geom_id=target_geom,
        world_from_geom=moved,
    )
    flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    np.testing.assert_allclose(flow[0, 40, 50], (10.0, 0.0), rtol=0.0, atol=1e-5)
    np.testing.assert_allclose(flow[0, 60, 100], (10.0, 0.0), rtol=0.0, atol=1e-5)
    np.testing.assert_allclose(flow[0, 80, 220], (10.0, 0.0), rtol=0.0, atol=1e-5)
    assert valid[0, 40, 50] and future_visible[0, 40, 50]
    assert valid[0, 60, 100] and not future_visible[0, 60, 100]
    assert valid[0, 80, 220] and not future_visible[0, 80, 220]
    assert not valid[0, 0, 0]
    np.testing.assert_array_equal(flow[0, 0, 0], 0.0)


def test_exact_dense_flow_uses_continuous_target_coordinates_at_frame_edges() -> None:
    cases = (
        (0, 0, 0, -0.004, 0.0, False),
        (223, 0, 1, 0.004, 0.0, False),
        (0, 1, 2, 0.004, 0.0, True),
        (223, 1, 3, -0.004, 0.0, True),
        (1, 0, 4, 0.0, -0.004, False),
        (1, 223, 5, 0.0, 0.004, False),
        (2, 0, 6, 0.0, 0.004, True),
        (2, 223, 7, 0.0, -0.004, True),
    )
    source_geom = np.full((1, 224, 224), -1, dtype=np.int32)
    target_geom = np.full_like(source_geom, -1)
    source_transforms = np.repeat(np.eye(4, dtype=np.float64)[None, ...], len(cases), axis=0)
    target_transforms = source_transforms.copy()
    for u, v, geom, delta_x, delta_y, _ in cases:
        source_geom[0, v, u] = geom
        target_geom[0, v, u] = geom
        target_transforms[geom, 0, 3] = delta_x
        target_transforms[geom, 1, 3] = delta_y
    identities = tuple(f"geom:{geom}" for geom in range(len(cases)))
    source = _supervision_snapshot(
        tick=0,
        timestamp_s=0.0,
        geom_id=source_geom,
        world_from_geom=source_transforms,
        identities=identities,
    )
    target = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        geom_id=target_geom,
        world_from_geom=target_transforms,
        identities=identities,
    )

    flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    for u, v, _, delta_x, delta_y, expected_visible in cases:
        assert valid[0, v, u]
        np.testing.assert_allclose(
            flow[0, v, u],
            (100.0 * delta_x, 100.0 * delta_y),
            rtol=0.0,
            atol=1e-6,
        )
        assert bool(future_visible[0, v, u]) is expected_visible


def test_exact_dense_flow_preserves_interleaved_geom_pixel_order_and_solver_layout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    source_geom = np.full((1, 224, 224), -1, dtype=np.int32)
    target_geom = np.full_like(source_geom, -1)
    depth = np.ones((1, 224, 224), dtype=np.float32)
    pixels = (((30, 40), (50, 40)), ((10, 70), (40, 80)), ((20, 20), (60, 20)))
    transforms = np.repeat(np.eye(4, dtype=np.float64)[None, ...], 3, axis=0)
    moved = transforms.copy()
    for geom, positions in enumerate(pixels):
        moved[geom, 0, 3] = 0.01 * (geom + 1)
        for v, u in positions:
            source_geom[0, v, u] = geom
            target_geom[0, v, u + geom + 1] = geom
    source_geom[0, 70, 90] = 1
    depth[0, 70, 90] = 0.0
    source = _supervision_snapshot(
        tick=0,
        timestamp_s=0.0,
        geom_id=source_geom,
        depth_m=depth,
        world_from_geom=transforms,
        identities=("first", "second", "third"),
    )
    target = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        geom_id=target_geom,
        world_from_geom=moved,
        identities=source.geom_semantic_identity,
    )
    solve = np.linalg.solve
    rays: list[npt.NDArray[np.float64]] = []

    def checked_solve(
        matrix: npt.NDArray[np.float64], values: npt.NDArray[np.float64]
    ) -> npt.NDArray[np.float64]:
        assert matrix.dtype == values.dtype == np.float64
        assert matrix.flags.c_contiguous and values.flags.f_contiguous
        assert values.shape == (3, 2) and values.strides == (8, 24)
        rays.append(values.copy())
        return solve(matrix, values)

    monkeypatch.setattr(np.linalg, "solve", checked_solve)
    flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    assert len(rays) == 3
    assert np.count_nonzero(valid) == np.count_nonzero(future_visible) == 6
    for geom, positions in enumerate(pixels):
        np.testing.assert_array_equal(rays[geom].T, [(u, v, 1.0) for v, u in positions])
        for v, u in positions:
            np.testing.assert_allclose(flow[0, v, u], (geom + 1, 0.0), rtol=0, atol=1e-5)
            assert valid[0, v, u] and future_visible[0, v, u]
    assert not valid[0, 70, 90] and not future_visible[0, 70, 90]
    np.testing.assert_array_equal(flow[0, 70, 90], 0.0)


def test_exact_dense_flow_excludes_nonfinite_or_float32_unrepresentable_projection() -> None:
    geom_id = np.full((1, 224, 224), -1, dtype=np.int32)
    geom_id[0, 100, 100] = 0
    geom_id[0, 101, 100] = 1
    source_transforms = np.repeat(np.eye(4, dtype=np.float64)[None, ...], 2, axis=0)
    target_transforms = source_transforms.copy()
    target_transforms[0, 0, 3] = 1e307
    target_transforms[1, 0, 3] = 1e37
    source = _supervision_snapshot(
        tick=0,
        timestamp_s=0.0,
        geom_id=geom_id,
        world_from_geom=source_transforms,
        identities=("nonfinite", "unrepresentable"),
    )
    target = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        geom_id=geom_id,
        world_from_geom=target_transforms,
        identities=("nonfinite", "unrepresentable"),
    )

    with warnings.catch_warnings():
        warnings.simplefilter("error", RuntimeWarning)
        flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    assert not np.any(valid)
    assert not np.any(future_visible)
    np.testing.assert_array_equal(flow, 0.0)


def test_exact_dense_flow_filters_mixed_projection_validity_within_one_geom() -> None:
    geom_id = np.full((1, 224, 224), -1, dtype=np.int32)
    geom_id[0, 112, [0, 112, 113]] = 0
    source = _supervision_snapshot(tick=0, timestamp_s=0.0, geom_id=geom_id)
    target = _supervision_snapshot(tick=1, timestamp_s=0.05, geom_id=geom_id)
    intrinsics = target.camera_intrinsics.copy()
    intrinsics[0, 0, 0] = 1.7e308
    target = replace(target, camera_intrinsics=_readonly(intrinsics, np.float64))

    # The same geom contains an infinite projection, a finite zero displacement,
    # and a finite projection whose displacement cannot be represented in float32.
    with warnings.catch_warnings():
        warnings.simplefilter("error", RuntimeWarning)
        flow, valid, future_visible = _exact_dense_optical_flow(source, target)

    expected = np.zeros_like(valid)
    expected[0, 112, 112] = True
    np.testing.assert_array_equal(valid, expected)
    np.testing.assert_array_equal(future_visible, expected)
    np.testing.assert_array_equal(flow, 0.0)


def _replace_snapshot_tick(snapshot: SupervisionSnapshot, tick: int) -> SupervisionSnapshot:
    return SupervisionSnapshot(
        tick=tick,
        timestamp_s=snapshot.timestamp_s,
        view_names=snapshot.view_names,
        depth_m=snapshot.depth_m,
        geom_id=snapshot.geom_id,
        camera_intrinsics=snapshot.camera_intrinsics,
        world_from_camera_cv=snapshot.world_from_camera_cv,
        world_from_geom=snapshot.world_from_geom,
        target_object_pose_world=snapshot.target_object_pose_world,
        geom_semantic_identity=snapshot.geom_semantic_identity,
    )


def test_exact_dense_flow_projects_rotation_and_keeps_views_independent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    geom_id = np.full((2, 224, 224), -1, dtype=np.int32)
    geom_id[:, 112, 122] = 0
    source_cameras = np.repeat(np.eye(4)[None, ...], 2, axis=0)
    target_cameras = source_cameras.copy()
    target_cameras[1, 0, 3] = 0.05
    rotation = np.array(
        [
            [0.0, -1.0, 0.0, 0.0],
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )[None, ...]
    source = _supervision_snapshot(
        tick=0,
        timestamp_s=0.0,
        geom_id=geom_id,
        world_from_camera_cv=source_cameras,
        views=("agentview", "wrist"),
    )
    target = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        geom_id=np.full_like(geom_id, -1),
        world_from_geom=rotation,
        world_from_camera_cv=target_cameras,
        views=("agentview", "wrist"),
    )

    def single_view(snapshot: SupervisionSnapshot, view: int) -> SupervisionSnapshot:
        # The single-view carrier requires this name; retain each view's numeric inputs.
        return replace(
            snapshot,
            view_names=("agentview",),
            depth_m=snapshot.depth_m[view : view + 1],
            geom_id=snapshot.geom_id[view : view + 1],
            camera_intrinsics=snapshot.camera_intrinsics[view : view + 1],
            world_from_camera_cv=snapshot.world_from_camera_cv[view : view + 1],
        )

    def unexpected_pool(*args: object, **kwargs: object) -> None:
        pytest.fail("single-view flow must execute directly")

    with monkeypatch.context() as patch:
        patch.setattr(optical_flow_module, "ThreadPoolExecutor", unexpected_pool)
        serial = [
            _exact_dense_optical_flow(single_view(source, view), single_view(target, view))
            for view in range(2)
        ]
    inputs = [
        value
        for snapshot in (source, target)
        for value in (
            snapshot.depth_m,
            snapshot.geom_id,
            snapshot.camera_intrinsics,
            snapshot.world_from_camera_cv,
            snapshot.world_from_geom,
        )
    ]
    before = [value.copy() for value in inputs]
    barrier = Barrier(2)
    solve = np.linalg.solve
    threads = []

    def concurrent_solve(
        matrix: npt.NDArray[np.float64], values: npt.NDArray[np.float64]
    ) -> npt.NDArray[np.float64]:
        threads.append(current_thread())
        barrier.wait(timeout=5.0)
        return solve(matrix, values)

    monkeypatch.setattr(np.linalg, "solve", concurrent_solve)
    flow, valid, visible = _exact_dense_optical_flow(source, target)

    np.testing.assert_allclose(flow[0, 112, 122], (-10.0, 10.0), atol=1e-5)
    np.testing.assert_allclose(flow[1, 112, 122], (-15.0, 10.0), atol=1e-5)
    assert valid[:, 112, 122].all()
    np.testing.assert_array_equal(
        flow.view(np.uint32), np.concatenate([result[0] for result in serial]).view(np.uint32)
    )
    np.testing.assert_array_equal(valid, np.concatenate([result[1] for result in serial]))
    np.testing.assert_array_equal(visible, np.concatenate([result[2] for result in serial]))
    assert len(set(threads)) == 2 and all(not thread.is_alive() for thread in threads)
    assert all(
        value.flags.c_contiguous and not value.flags.writeable for value in (flow, valid, visible)
    )
    for original, value in zip(before, inputs, strict=True):
        np.testing.assert_array_equal(original, value)
        assert not value.flags.writeable
    with pytest.raises(ValueError, match="adjacent"):
        _exact_dense_optical_flow(source, _replace_snapshot_tick(target, 2))


def test_exact_dense_flow_inherits_numpy_errors_and_joins_before_raising_in_view_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    geom_id = np.full((2, 224, 224), -1, dtype=np.int32)
    geom_id[:, 112, 122] = 0
    source = _supervision_snapshot(
        tick=0, timestamp_s=0.0, geom_id=geom_id, views=("agentview", "wrist")
    )
    intrinsics = source.camera_intrinsics.copy()
    intrinsics[1, 0, 0] = 200.0
    source = replace(source, camera_intrinsics=_readonly(intrinsics, np.float64))
    moved = source.world_from_geom.copy()
    moved[0, 0, 3] = 0.1
    target = replace(source, tick=1, timestamp_s=0.05, world_from_geom=_readonly(moved, np.float64))
    first_error = ValueError("first view")
    second_error = RuntimeError("second view")
    second_failed = Event()
    restored = []
    callbacks = []

    def error_callback(error: str, flag: int) -> None:
        callbacks.append((error, flag))

    class CheckedPool(ThreadPoolExecutor):
        def submit(self, function, /, *args, **kwargs):
            def checked():
                original_errors = np.geterr()
                original_callback = np.geterrcall()
                try:
                    return function(*args, **kwargs)
                finally:
                    assert np.geterr() == original_errors
                    assert np.geterrcall() is original_callback
                    restored.append(current_thread())

            future = super().submit(checked)
            if args[0] == 1:
                future.add_done_callback(lambda _: second_failed.set())
            return future

    def failing_solve(
        matrix: npt.NDArray[np.float64], values: npt.NDArray[np.float64]
    ) -> npt.NDArray[np.float64]:
        assert np.geterr() == expected_errors
        assert np.geterrcall() is error_callback
        np.divide(np.array([1.0]), np.array([0.0]))
        if matrix[0, 0] == 100.0:
            assert second_failed.wait(timeout=5.0)
            raise first_error
        raise second_error

    monkeypatch.setattr(optical_flow_module, "ThreadPoolExecutor", CheckedPool)
    monkeypatch.setattr(np.linalg, "solve", failing_solve)
    with np.errstate(
        divide="call", over="raise", invalid="raise", under="ignore", call=error_callback
    ):
        expected_errors = np.geterr()
        with pytest.raises(ValueError) as caught:
            _exact_dense_optical_flow(source, target)
        assert caught.value is first_error
        assert np.geterr() == expected_errors and np.geterrcall() is error_callback
    assert len(callbacks) == 2 and all(error == "divide by zero" for error, _ in callbacks)
    assert len(set(restored)) == 2 and all(not thread.is_alive() for thread in restored)


def test_snapshot_and_flow_reject_misaligned_dtype_views_and_geom_identity() -> None:
    model, data = _compiled_camera_model_and_data()
    body_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, "robot_base")
    with pytest.raises(ValueError, match="int32"):
        _assemble_supervision_snapshot(
            _supervision_observation(),
            model,
            data,
            element_segmentation_opengl=np.zeros((1, 224, 224, 2), dtype=np.int64),
            target_body_id=body_id,
            geom_semantic_identity=("robot",),
            previous_target_quaternion_xyzw=None,
        )

    source = _supervision_snapshot(tick=0, timestamp_s=0.0)
    changed_identity = _supervision_snapshot(tick=1, timestamp_s=0.05, identities=("different",))
    with pytest.raises(ValueError, match="geom identity"):
        _exact_dense_optical_flow(source, changed_identity)
    changed_views = _supervision_snapshot(
        tick=1,
        timestamp_s=0.05,
        views=("agentview", "wrist"),
    )
    with pytest.raises(ValueError, match="ordered views"):
        _exact_dense_optical_flow(source, changed_views)


def _pose(quaternion_xyzw: tuple[float, float, float, float]) -> npt.NDArray[np.float64]:
    return np.asarray([[0.0, 0.0, 0.0, *quaternion_xyzw]], dtype=np.float64)


def test_offline_pose_metrics_cover_all_frozen_symmetry_classes() -> None:
    identity = _pose((0.0, 0.0, 0.0, 1.0))
    half_turn_z = _pose((0.0, 0.0, 1.0, 0.0))
    half_turn_x = _pose((1.0, 0.0, 0.0, 0.0))
    valid = np.ones(1, dtype=np.bool_)
    finite = np.asarray((np.eye(3), np.diag((-1.0, -1.0, 1.0))), dtype=np.float64)
    axis = np.asarray((0.0, 0.0, 1.0), dtype=np.float64)

    identity_metric = _offline_object_pose_metrics(
        half_turn_z, identity, valid, symmetry="identity"
    )
    finite_metric = _offline_object_pose_metrics(
        half_turn_z,
        identity,
        valid,
        symmetry="finite",
        finite_symmetry_rotations=finite,
    )
    directed = _offline_object_pose_metrics(
        half_turn_x,
        identity,
        valid,
        symmetry="axial_directed",
        symmetry_axis_local=axis,
    )
    bidirectional = _offline_object_pose_metrics(
        half_turn_x,
        identity,
        valid,
        symmetry="axial_bidirectional",
        symmetry_axis_local=axis,
    )
    spherical = _offline_object_pose_metrics(half_turn_x, identity, valid, symmetry="spherical")

    assert identity_metric.se3_pose_ade == pytest.approx((0.0, math.pi))
    assert finite_metric.se3_pose_ade == pytest.approx((0.0, 0.0))
    assert directed.pose_rotation_ade_rad == pytest.approx(math.pi)
    assert bidirectional.pose_rotation_ade_rad == pytest.approx(0.0)
    assert spherical.se3_pose_fde == pytest.approx((0.0, 0.0))


def test_offline_pose_metrics_preserve_ordered_se3_and_missing_fde() -> None:
    truth = np.repeat(_pose((0.0, 0.0, 0.0, 1.0)), 2, axis=0)
    prediction = truth.copy()
    prediction[:, 0] = (1.0, 3.0)
    valid = np.asarray((True, False), dtype=np.bool_)
    metrics = _offline_object_pose_metrics(prediction, truth, valid, symmetry="identity")
    assert metrics.se3_pose_ade == (1.0, 0.0)
    assert metrics.se3_pose_fde is None
    assert metrics.valid_count == 1
    empty = _offline_object_pose_metrics(
        prediction, truth, np.zeros(2, dtype=np.bool_), symmetry="identity"
    )
    assert empty.se3_pose_ade is None
    assert empty.se3_pose_fde is None
    assert empty.valid_count == 0


def test_offline_pose_metrics_apply_finite_symmetry_in_object_local_frame() -> None:
    sine = math.sqrt(0.5)
    truth = np.repeat(_pose((sine, 0.0, 0.0, sine)), 8, axis=0)
    prediction = np.repeat(_pose((0.0, -sine, sine, 0.0)), 8, axis=0)
    prediction[:, 0] = (0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7)
    valid = np.asarray((True, True, False, True, False, True, True, True), dtype=np.bool_)
    finite = np.asarray((np.eye(3), np.diag((-1.0, -1.0, 1.0))), dtype=np.float64)

    metrics = _offline_object_pose_metrics(
        prediction, truth, valid, symmetry="finite", finite_symmetry_rotations=finite
    )

    assert metrics.se3_pose_ade == pytest.approx((2.2 / 6.0, 0.0))
    assert metrics.se3_pose_fde == pytest.approx((0.7, 0.0))
    assert metrics.valid_count == 6


@pytest.mark.parametrize(
    "rotations, message",
    (
        (None, "finite float64"),
        (np.empty((0, 3, 3), dtype=np.float64), "finite float64"),
        (np.eye(3, dtype=np.float64), "finite float64"),
        (np.eye(3, dtype=np.float32)[None], "finite float64"),
        (np.full((1, 3, 3), np.nan, dtype=np.float64), "finite float64"),
        (np.diag((1.0, 1.0, -1.0))[None], "proper rotations"),
        (2.0 * np.eye(3, dtype=np.float64)[None], "proper rotations"),
    ),
)
def test_offline_pose_metrics_validate_finite_symmetry_without_valid_horizons(
    rotations: npt.NDArray[np.float64] | None, message: str
) -> None:
    pose = _pose((0.0, 0.0, 0.0, 1.0))
    with pytest.raises(ValueError, match=message):
        _offline_object_pose_metrics(
            pose,
            pose,
            np.zeros(1, dtype=np.bool_),
            symmetry="finite",
            finite_symmetry_rotations=rotations,
        )


@pytest.mark.parametrize(
    "axis",
    (
        None,
        np.asarray(((0.0, 0.0, 1.0),), dtype=np.float64),
        np.asarray((0.0, 0.0, 1.0), dtype=np.float32),
        np.asarray((0.0, 0.0, np.nan), dtype=np.float64),
        np.zeros(3, dtype=np.float64),
        np.asarray((0.0, 0.0, 2.0), dtype=np.float64),
    ),
)
def test_offline_pose_metrics_validate_axial_symmetry_without_valid_horizons(
    axis: npt.NDArray[np.float64] | None,
) -> None:
    pose = _pose((0.0, 0.0, 0.0, 1.0))
    for bidirectional in (False, True):
        with pytest.raises(ValueError, match="finite unit float64"):
            _offline_object_pose_metrics(
                pose,
                pose,
                np.zeros(1, dtype=np.bool_),
                symmetry="axial_bidirectional" if bidirectional else "axial_directed",
                symmetry_axis_local=axis,
            )


def test_offline_flow_metrics_partition_visible_occluded_out_of_frame_and_empty() -> None:
    truth = np.zeros((1, 1, 1, 4, 2), dtype=np.float32)
    truth[0, 0, 0, 2, 0] = 2.0
    prediction = truth.copy()
    prediction[0, 0, 0, 0] = (3.0, 4.0)
    prediction[0, 0, 0, 1] = (0.0, 2.0)
    prediction[0, 0, 0, 2] = (3.0, 0.0)
    valid = np.asarray([[[[True, True, True, False]]]], dtype=np.bool_)
    visible = np.asarray([[[[True, False, False, False]]]], dtype=np.bool_)
    metrics = _offline_optical_flow_metrics(prediction, truth, valid, visible)
    assert metrics.epe2d_valid_px == pytest.approx(8.0 / 3.0)
    assert metrics.valid_count == 3
    assert (metrics.epe2d_visible_px, metrics.visible_count) == (5.0, 1)
    assert (metrics.epe2d_occluded_px, metrics.occluded_count) == (2.0, 1)
    assert (metrics.epe2d_out_of_frame_px, metrics.out_of_frame_count) == (1.0, 1)

    empty = _offline_optical_flow_metrics(
        np.zeros_like(truth),
        np.zeros_like(truth),
        np.zeros_like(valid),
        np.zeros_like(visible),
    )
    assert (
        empty.epe2d_valid_px,
        empty.epe2d_visible_px,
        empty.epe2d_occluded_px,
        empty.epe2d_out_of_frame_px,
    ) == (None, None, None, None)
    assert (
        empty.valid_count,
        empty.visible_count,
        empty.occluded_count,
        empty.out_of_frame_count,
    ) == (0, 0, 0, 0)
    with pytest.raises(ValueError, match="invalid ground-truth"):
        invalid_truth = truth.copy()
        invalid_truth[0, 0, 0, 3, 0] = 1.0
        _offline_optical_flow_metrics(prediction, invalid_truth, valid, visible)
    with pytest.raises(ValueError, match="subset"):
        invalid_visible = visible.copy()
        invalid_visible[0, 0, 0, 3] = True
        _offline_optical_flow_metrics(prediction, truth, valid, invalid_visible)


def test_offline_flow_metrics_classify_continuous_near_edge_coordinates() -> None:
    truth = np.zeros((1, 1, 4, 4, 2), dtype=np.float32)
    valid = np.zeros((1, 1, 4, 4), dtype=np.bool_)
    future_visible = np.zeros_like(valid)
    cases = (
        (0, 0, (-0.4, 0.0), False),
        (3, 0, (0.4, 0.0), False),
        (0, 1, (0.4, 0.0), True),
        (3, 1, (-0.4, 0.0), True),
        (1, 0, (0.0, -0.4), False),
        (1, 3, (0.0, 0.4), False),
        (2, 0, (0.0, 0.4), True),
        (2, 3, (0.0, -0.4), True),
    )
    for u, v, displacement, visible in cases:
        truth[0, 0, v, u] = displacement
        valid[0, 0, v, u] = True
        future_visible[0, 0, v, u] = visible

    metrics = _offline_optical_flow_metrics(truth.copy(), truth, valid, future_visible)

    assert metrics.epe2d_valid_px == 0.0 and metrics.valid_count == 8
    assert metrics.epe2d_visible_px == 0.0 and metrics.visible_count == 4
    assert metrics.epe2d_occluded_px is None and metrics.occluded_count == 0
    assert metrics.epe2d_out_of_frame_px == 0.0 and metrics.out_of_frame_count == 4
