from __future__ import annotations

import copy
import inspect
import math
from dataclasses import replace
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pytest

from se3_wam_benchmark.envs.base import _load_asset_catalog
from se3_wam_benchmark.envs.components.motion import _motion_state_at_time
from se3_wam_benchmark.scenarios import _native_oracle as native_oracle_module
from se3_wam_benchmark.scenarios._native_oracle import _mujoco_twist_to_spatial
from se3_wam_benchmark.scenarios._recipes import (
    _materialize_recipe,
    _sample_recipe_value,
    _select_recipe,
)
from se3_wam_benchmark.scenarios._validation import (
    _compiled_object_asset_facts,
    _validate_free_dynamics_declarative_scenario,
    _validate_grasp_declarative_scenario,
    _validate_matched_declarative_scenario,
    _validate_placement_declarative_scenario,
    _validate_replanning_declarative_scenario,
    _validate_rotating_declarative_scenario,
    _validate_surface_declarative_scenario,
)
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import OOD_FACTORS, Partition
from se3_wam_benchmark.scenarios.spec import (
    CircularTranslation,
    ConstantAngularVelocityRotation,
    ConstantVelocityTranslation,
    FixedRotation,
    FixedTranslation,
    HarmonicRotation,
    HarmonicTranslation,
    ScenarioSpec,
    scenario_from_dict,
    scenario_to_dict,
)
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

_RECIPE_NAMES = (
    "e7_agentview",
    "e7_agentview_wrist",
    "j8_agentview",
    "j8_agentview_wrist",
)
_REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
_GRASP_RECIPE_PATH = _REPOSITORY_ROOT / "configs" / "scenarios" / "grasp.yaml"
_GRASP_CATALOG_PATH = _REPOSITORY_ROOT / "assets" / "catalog.yaml"
_GRASP_OOD_FACTORS = (
    "object",
    "spatial",
    "motion_parameters",
    "motion_law",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_GRASP_RECIPE_CASES: tuple[tuple[Partition, str | None, int], ...] = (
    ("train", None, 17),
    ("validation", None, 17),
    ("test_id", None, 17),
    ("ood", "object", 0),
    ("ood", "spatial", 17),
    ("ood", "motion_parameters", 17),
    ("ood", "motion_law", 17),
    ("ood", "physics", 17),
    ("ood", "appearance", 17),
    ("ood", "camera", 17),
    ("ood", "action_delay", 17),
    ("stress", None, 1),
)
_COMPLETE_RECIPE_FIELDS = {
    "action_mode",
    "observation_profile",
    "physics_timestep_s",
    "control_frequency_hz",
    "sensor_frequency_hz",
    "action_delay",
    "robot_initial_state",
    "object_states",
    "fixture_states",
    "geometry",
    "motion",
    "physics",
    "cameras",
    "lighting",
    "events",
}


_BELT_RECIPE_PATH = _REPOSITORY_ROOT / "configs/scenarios/t1_belt.yaml"
_BELT_OOD_FACTORS = (
    "spatial",
    "motion_parameters",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_BELT_RECIPE_CASES = (
    ("train", None),
    ("validation", None),
    ("test_id", None),
    *(("ood", factor) for factor in _BELT_OOD_FACTORS),
    ("stress", None),
)

_MATCHED_OOD_FACTORS = (
    "spatial",
    "motion_parameters",
    "motion_law",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_MATCHED_RECIPE_CASES = (
    ("train", None),
    ("validation", None),
    ("test_id", None),
    *(("ood", factor) for factor in _MATCHED_OOD_FACTORS),
    ("stress", None),
)


def _matched_recipe(
    task_id: str,
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml"),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _matched_proposal(task_id: str, recipe: Any, seed: int = 17) -> ScenarioSpec:
    return _materialize_recipe(
        load_task(task_id), recipe, np.random.Generator(np.random.PCG64(seed))
    )


def _check_matched(
    task_id: str,
    scenario: ScenarioSpec,
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> None:
    _validate_matched_declarative_scenario(
        load_task(task_id),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
    )


def _assert_matched_initial_motion(scenario: ScenarioSpec) -> None:
    target, motion = scenario.object_states[0], scenario.motion[0]
    translation, rotation = motion.translation, motion.rotation
    # DB0 samples the oscillation center, then sets p(0) and its derivative.
    # The approved correlated recipe must encode those same physical values.
    if isinstance(translation, HarmonicTranslation):
        amplitude = np.asarray(translation.amplitude_m)
        frequency = np.asarray(translation.frequency_hz)
        phase = np.asarray(translation.phase_rad)
        np.testing.assert_allclose(
            target.position_world_m,
            np.asarray(translation.center_world_m) + amplitude * np.sin(phase),
            rtol=0.0,
            atol=1e-15,
        )
        velocity = np.asarray(translation.drift_velocity_world_m_s) + amplitude * (
            2.0 * math.pi * frequency
        ) * np.cos(phase)
    else:
        assert isinstance(translation, ConstantVelocityTranslation)
        velocity = np.asarray(translation.velocity_world_m_s)
    np.testing.assert_allclose(target.linear_velocity_world_m_s, velocity, rtol=0.0, atol=1e-15)
    assert isinstance(rotation, ConstantAngularVelocityRotation)
    np.testing.assert_array_equal(
        target.angular_velocity_world_rad_s,
        np.asarray(rotation.axis_world) * rotation.angular_speed_rad_s,
    )


def _reversed_mapping_keys(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _reversed_mapping_keys(item) for key, item in reversed(tuple(value.items()))}
    if isinstance(value, list):
        return [_reversed_mapping_keys(item) for item in value]
    return value


@pytest.mark.parametrize("success", [False, True])
def test_native_oracle_observes_each_step_before_returning_the_terminal_info(
    success: bool, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[object] = []
    action_value = object()
    terminal_info: dict[str, object] = {
        "success": success,
        "failure_code": None if success else "timeout",
    }
    steps = 0

    def action() -> object:
        calls.append("action")
        return action_value

    def step(value: object) -> tuple[dict[str, object], float, bool, dict[str, object]]:
        nonlocal steps
        assert value is action_value
        calls.append("step")
        steps += 1
        assert steps <= 2, "the oracle must stop at the native terminal step"
        return {}, 0.0, steps == 2, terminal_info if steps == 2 else {"success": False}

    def observe_step(*, done: bool, success: bool) -> None:
        calls.append(("observe", done, success))

    environment = SimpleNamespace(
        _task_spec=SimpleNamespace(family="grasp", episode_horizon_steps=3), step=step
    )
    oracle = SimpleNamespace(action=action, observe_step=observe_step)

    def make_oracle(value: object) -> SimpleNamespace:
        assert value is environment
        calls.append("make")
        return oracle

    monkeypatch.setattr(native_oracle_module, "_make_native_oracle", make_oracle)
    assert native_oracle_module._run_native_oracle(environment) is terminal_info
    assert calls == [
        "make",
        "action",
        "step",
        ("observe", False, False),
        "action",
        "step",
        ("observe", True, success),
    ]


def test_native_oracle_horizon_without_a_terminal_step_fails_with_its_family(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[object] = []

    def step(value: object) -> tuple[dict[str, object], float, bool, dict[str, object]]:
        assert value is None
        calls.append("step")
        return {}, 0.0, False, {"success": False}

    def observe_step(*, done: bool, success: bool) -> None:
        calls.append(("observe", done, success))

    environment = SimpleNamespace(
        _task_spec=SimpleNamespace(family="free_dynamics_interception", episode_horizon_steps=2),
        step=step,
    )
    oracle = SimpleNamespace(action=lambda: None, observe_step=observe_step)
    monkeypatch.setattr(native_oracle_module, "_make_native_oracle", lambda _: oracle)
    with pytest.raises(
        RuntimeError,
        match=(
            "free_dynamics_interception oracle reached horizon without its native terminal outcome"
        ),
    ):
        native_oracle_module._run_native_oracle(environment)
    assert calls == ["step", ("observe", False, False), "step", ("observe", False, False)]


@pytest.mark.parametrize(("partition", "factor"), _MATCHED_RECIPE_CASES)
def test_all_88_matched_named_recipes_keep_body_origin_reference_and_action_view_pairing(
    partition: Partition,
    factor: str | None,
) -> None:
    physical = {}
    references = {}
    for task_id in ("t1_xyz", "t1_so3"):
        for name in _RECIPE_NAMES:
            recipe = _matched_recipe(task_id, partition, factor, name)
            for branch in recipe.get("choices", [recipe]):
                assert set(branch) == _COMPLETE_RECIPE_FIELDS
                assert branch["action_mode"] == ("E7" if name.startswith("e7_") else "J8")
            # SO3 stress now samples fixed source cases; XYZ retains its stress recipe.
            pairing_group = task_id if partition == "stress" else "matched"
            scenario = _matched_proposal(task_id, recipe)
            _check_matched(task_id, scenario, partition=partition, factor=factor)
            assert _matched_proposal(task_id, recipe) == scenario
            assert _matched_proposal(task_id, _reversed_mapping_keys(recipe)) == scenario
            record = scenario_to_dict(scenario)
            assert scenario_from_dict(record, family="driven_interception") == scenario
            assert not {"recipe_name", "source_seed", "compiler", "yaw_rad"} & set(record)
            motion, target = scenario.motion[0], scenario.object_states[0]
            rotation = motion.rotation
            assert isinstance(rotation, ConstantAngularVelocityRotation)
            if task_id == "t1_xyz":
                assert rotation.angular_speed_rad_s == 0.0
            else:
                assert rotation.angular_speed_rad_s != 0.0
            _assert_motion_starts_at_object_pose(scenario)
            _assert_matched_initial_motion(scenario)
            reference = tuple(
                _motion_state_at_time(
                    motion,
                    initial_position_world_m=target.position_world_m,
                    initial_quaternion_world_xyzw=target.quaternion_world_xyzw,
                    simulator_time_s=t,
                ).position_world_m.tolist()
                for t in (0.0, 0.002, 0.65, 4.0)
            )
            translation = motion.translation
            speed = (
                translation.drift_velocity_world_m_s[1]
                if isinstance(translation, HarmonicTranslation)
                else translation.velocity_world_m_s[1]
            )
            references.setdefault(pairing_group, []).append(
                (
                    reference,
                    (scenario.geometry.downstream_exit_y_m - target.position_world_m[1]) / speed,
                )
            )
            record.pop("action_mode")
            record.pop("observation_profile")
            record["cameras"]["views"] = record["cameras"]["views"][:1]
            record["motion"][0].pop("rotation")
            # The XYZ counterfactual removes spin from both the law and t0 twist.
            record["object_states"][0].pop("angular_velocity_world_rad_s")
            physical.setdefault(pairing_group, []).append(record)
    for records in physical.values():
        assert all(item == records[0] for item in records)
    for trajectories in references.values():
        assert all(item == trajectories[0] for item in trajectories)
    for task_id in ("t1_xyz", "t1_so3"):
        document = load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml")
        assert set(document) == {"schema_version", "recipes"}
        assert set(document["recipes"]["ood"]) == set(_MATCHED_OOD_FACTORS)


@pytest.mark.parametrize("name", _RECIPE_NAMES)
@pytest.mark.parametrize(
    ("factor", "owned"),
    [
        ("spatial", "object_states"),
        ("motion_parameters", "motion"),
        ("motion_law", "motion"),
        ("physics", "physics"),
        ("appearance", "lighting"),
        ("camera", "cameras"),
        ("action_delay", "action_delay_steps"),
    ],
)
def test_matched_single_factor_ood_preserves_independent_blocks_and_derived_initial_state(
    name: str,
    factor: str,
    owned: str,
) -> None:
    for seed in (0, 17):
        baseline_scenario = _matched_proposal("t1_so3", _matched_recipe("t1_so3", name=name), seed)
        baseline = scenario_to_dict(baseline_scenario)
        scenario = _matched_proposal("t1_so3", _matched_recipe("t1_so3", "ood", factor, name), seed)
        _check_matched("t1_so3", scenario, partition="ood", factor=factor)
        _assert_matched_initial_motion(baseline_scenario)
        _assert_matched_initial_motion(scenario)
        altered = scenario_to_dict(scenario)
        assert baseline[owned] != altered[owned]
        if factor == "spatial":
            # Spatial intervention changes the sampled center; compare the law parameters.
            for record in (baseline, altered):
                record["motion"][0]["translation"].pop("center_world_m")
        elif factor in ("motion_parameters", "motion_law"):
            baseline_translation = baseline_scenario.motion[0].translation
            assert isinstance(baseline_translation, HarmonicTranslation)
            if factor == "motion_parameters":
                assert isinstance(scenario.motion[0].translation, HarmonicTranslation)
                assert (
                    scenario.motion[0].translation.center_world_m
                    == baseline_translation.center_world_m
                )
            else:
                assert isinstance(scenario.motion[0].translation, ConstantVelocityTranslation)
                assert (
                    scenario.object_states[0].position_world_m
                    == baseline_translation.center_world_m
                )
            # Only values derived from the changed law may differ in the initial state;
            # the asset, sampled center, initial orientation, and other blocks still match.
            for record in (baseline, altered):
                for field in (
                    "position_world_m",
                    "linear_velocity_world_m_s",
                    "angular_velocity_world_rad_s",
                ):
                    record["object_states"][0].pop(field)
        assert {key: value for key, value in baseline.items() if key != owned} == {
            key: value for key, value in altered.items() if key != owned
        }


def test_so3_declares_equal_signed_continuous_yaw_support_without_seed_inference() -> None:
    recipe = _matched_recipe("t1_so3")
    rotations = recipe["motion"][0]["rotation"]["choices"]
    assert [law["angular_speed_rad_s"] for law in rotations] == [
        {"min": -1.2, "max": -0.4},
        {"min": 0.4, "max": 1.2},
    ]
    rates = [
        _matched_proposal("t1_so3", recipe, seed).motion[0].rotation.angular_speed_rad_s
        for seed in range(20)
    ]
    assert min(rates) < 0.0 < max(rates)
    assert len(set(rates)) == 20


@pytest.mark.parametrize(
    "kind",
    [
        "unknown",
        "missing_target",
        "duplicate_motion",
        "asset_choice",
        "derived_center",
        "law_choice",
        "law_numeric_choice",
        "nonunit_axis",
        "zero_yaw_branch",
        "yaw_dsl",
        "body_choice",
        "camera_choice",
        "light_choice",
        "camera_quaternion",
        "camera_fov",
        "light_color",
        "light_direction",
        "light_attenuation",
        "light_cutoff",
        "contact_nonfinite",
        "gravity_nonfinite",
    ],
)
def test_matched_raw_recipes_reject_invalid_unselected_branches_before_consuming_rng(
    kind: str,
) -> None:
    recipe = _matched_recipe("t1_so3")
    if kind == "unknown":
        recipe["callback"] = "invalid"
    elif kind == "missing_target":
        recipe["object_states"] = []
    elif kind == "duplicate_motion":
        recipe["motion"].append(copy.deepcopy(recipe["motion"][0]))
    elif kind == "asset_choice":
        target = recipe["object_states"][0]
        recipe["object_states"] = [{"choices": [target, {**target, "asset_id": "obj.unknown"}]}]
    elif kind == "derived_center":
        recipe["motion"][0]["translation"]["center_world_m"] = [0.0, 0.0, 0.0]
    elif kind == "law_choice":
        law = recipe["motion"][0]["translation"]
        recipe["motion"][0]["translation"] = {"choices": [law, {**law, "callback": "invalid"}]}
    elif kind == "law_numeric_choice":
        recipe["motion"][0]["translation"]["amplitude_m"][0] = {
            "choices": [0.02, {"min": 0.04, "max": 0.01}]
        }
    elif kind == "nonunit_axis":
        recipe["motion"][0]["rotation"]["choices"][1]["axis_world"] = [0.0, 0.0, 2.0]
    elif kind == "zero_yaw_branch":
        recipe["motion"][0]["rotation"]["choices"][1]["angular_speed_rad_s"] = {
            "min": -0.4,
            "max": 0.4,
        }
    elif kind == "yaw_dsl":
        recipe["object_states"][0]["quaternion_world_xyzw"] = {"yaw_rad": {"ref": "yaw"}}
    elif kind == "body_choice":
        body = recipe["physics"]["bodies"][0]
        recipe["physics"]["bodies"] = [{"choices": [body, {**body, "mass_kg": -0.1}]}]
    elif kind == "camera_choice":
        view = recipe["cameras"]["views"][0]
        recipe["cameras"]["views"] = [{"choices": [view, {**view, "ref": "camera"}]}]
    elif kind == "light_choice":
        light = recipe["lighting"]["lights"][0]
        recipe["lighting"]["lights"] = [{"choices": [light, {**light, "callback": "light"}]}]
    elif kind in ("camera_quaternion", "camera_fov"):
        view = recipe["cameras"]["views"][0]
        invalid = {
            **view,
            **(
                {"quaternion_parent_xyzw": [0.0, 0.0, 0.0, 2.0]}
                if kind == "camera_quaternion"
                else {"vertical_fov_deg": 180.0}
            ),
        }
        recipe["cameras"]["views"] = [{"choices": [view, invalid]}]
    elif kind.startswith("light_"):
        light = recipe["lighting"]["lights"][0]
        invalid = {
            **light,
            **{
                "light_color": {"diffuse_rgb": [1.1, 0.8, 0.8]},
                "light_direction": {"direction_world": [0.0, 0.0, -2.0]},
                "light_attenuation": {"attenuation": [-1.0, 0.0, 0.0]},
                "light_cutoff": {"cutoff_deg": 0.0},
            }[kind],
        }
        recipe["lighting"]["lights"] = [{"choices": [light, invalid]}]
    elif kind == "contact_nonfinite":
        contact = recipe["physics"]["contacts"][0]
        recipe["physics"]["contacts"] = [
            {"choices": [contact, {**contact, "solref": [float("nan"), 1.0]}]}
        ]
    else:
        recipe["physics"]["gravity_world_m_s2"] = {
            "choices": [[0.0, 0.0, -9.81], [0.0, 0.0, float("inf")]]
        }
    for seed in (0, 1, 17):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t1_so3"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
@pytest.mark.parametrize("yaw", [-0.35, 0.35])
@pytest.mark.parametrize("sign", [-1.0, 1.0])
def test_matched_yaw_support_includes_exact_endpoints_and_equivalent_quaternion_signs(
    task_id: str, yaw: float, sign: float
) -> None:
    scenario = _matched_proposal(task_id, _matched_recipe(task_id))
    quaternion = (0.0, 0.0, sign * math.sin(yaw / 2), sign * math.cos(yaw / 2))
    target = replace(scenario.object_states[0], quaternion_world_xyzw=quaternion)
    scenario = replace(scenario, object_states=(target,))
    _check_matched(task_id, scenario)
    assert scenario.object_states[0].quaternion_world_xyzw == quaternion
    outside = yaw + math.copysign(1e-6, yaw)
    target = replace(
        target, quaternion_world_xyzw=(0.0, 0.0, math.sin(outside / 2), math.cos(outside / 2))
    )
    with pytest.raises(ValueError, match="spatial support"):
        _check_matched(task_id, replace(scenario, object_states=(target,)))


def _matched_recipe_with_values(task_id: str, **values: float) -> Any:
    recipe = _matched_recipe(task_id)
    paths = {
        "x": ("object_states", 0, "position_world_m", "harmonic_center_world_m", 0),
        "y": ("object_states", 0, "position_world_m", "harmonic_center_world_m", 1),
        "yaw": ("object_states", 0, "quaternion_world_xyzw", "yaw_rad"),
        "forward": ("motion", 0, "translation", "drift_velocity_world_m_s", 1),
        "amplitude": ("motion", 0, "translation", "amplitude_m", 0),
        "frequency": ("motion", 0, "translation", "frequency_hz", 0),
        "phase": ("motion", 0, "translation", "phase_rad", 0),
    }
    for parameter, value in values.items():
        if parameter == "yaw_speed":
            recipe["motion"][0]["rotation"] = {
                "type": "constant_angular_velocity",
                "axis_world": [0.0, 0.0, 1.0],
                "angular_speed_rad_s": value,
            }
        elif parameter == "density":
            body = recipe["physics"]["bodies"][0]
            body["mass_kg"] *= value
            body["diagonal_inertia_kg_m2"] = [
                component * value for component in body["diagonal_inertia_kg_m2"]
            ]
        elif parameter == "friction":
            contact = recipe["physics"]["contacts"][0]
            contact["friction_slide_spin_roll"] = [
                component * value for component in contact["friction_slide_spin_roll"]
            ]
        else:
            path = paths[parameter]
            node = recipe
            for key in path[:-1]:
                node = node[key]
            node[path[-1]] = value
    return recipe


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
@pytest.mark.parametrize("field", ["linear_velocity_world_m_s", "angular_velocity_world_rad_s"])
def test_matched_concrete_initial_twist_cannot_disagree_with_its_declared_motion(
    task_id: str, field: str
) -> None:
    scenario = _matched_proposal(task_id, _matched_recipe(task_id))
    _assert_matched_initial_motion(scenario)
    target = scenario.object_states[0]
    velocity = list(getattr(target, field))
    velocity[0] += 1e-4
    invalid = replace(scenario, object_states=(replace(target, **{field: tuple(velocity)}),))
    with pytest.raises(ValueError, match="initial physical twist"):
        _check_matched(task_id, invalid)


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
@pytest.mark.parametrize(
    ("factor", "parameter", "value"),
    [
        ("spatial", "x", -0.06),
        ("spatial", "x", 0.06),
        ("spatial", "y", -0.28),
        ("spatial", "y", -0.16),
        ("spatial", "yaw", -0.65),
        ("spatial", "yaw", 0.65),
        ("motion_parameters", "forward", 0.02),
        ("motion_parameters", "forward", 0.14),
        ("motion_parameters", "amplitude", 0.06),
        ("motion_parameters", "frequency", 0.10),
        ("motion_parameters", "frequency", 1.10),
        ("physics", "density", 0.5),
        ("physics", "density", 1.5),
        ("physics", "friction", 0.3),
        ("physics", "friction", 1.8),
    ],
)
def test_matched_factor_allows_legal_concrete_values_outside_packaged_recipe_support(
    task_id: str, factor: str, parameter: str, value: float
) -> None:
    scenario = _matched_proposal(
        task_id, _matched_recipe_with_values(task_id, **{parameter: value})
    )
    _check_matched(task_id, scenario, partition="ood", factor=factor)
    _assert_motion_starts_at_object_pose(scenario)
    for partition, wrong_factor in (("test_id", None), ("ood", "appearance")):
        with pytest.raises(ValueError, match="spatial support|ID motion|physics intervention"):
            _check_matched(task_id, scenario, partition=partition, factor=wrong_factor)


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
@pytest.mark.parametrize(
    "path",
    [
        ("gravity_world_m_s2", 2),
        ("bodies", 0, "mass_kg"),
        ("bodies", 0, "diagonal_inertia_kg_m2", 0),
        ("contacts", 0, "friction_slide_spin_roll", 0),
        ("contacts", 0, "friction_slide_spin_roll", 1),
        ("contacts", 0, "friction_slide_spin_roll", 2),
        ("contacts", 0, "solref", 0),
        ("contacts", 0, "solimp", 0),
    ],
)
def test_matched_native_physics_components_are_independent_but_owned_by_physics_factor(
    task_id: str, path: tuple[str | int, ...]
) -> None:
    baseline = _matched_proposal(task_id, _matched_recipe(task_id))
    record: Any = scenario_to_dict(baseline)
    node = record["physics"]
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] *= 1.01
    scenario = scenario_from_dict(record, family="driven_interception")
    _check_matched(task_id, scenario, partition="ood", factor="physics")
    _check_matched(task_id, scenario, partition="stress")
    for partition, factor in (("test_id", None), ("ood", "appearance")):
        with pytest.raises(ValueError, match="physics intervention"):
            _check_matched(task_id, scenario, partition=partition, factor=factor)
    assert scenario.physics != baseline.physics
    assert replace(scenario, physics=baseline.physics) == baseline


def test_matched_target_joint_physics_is_supported_only_outside_formal_v1_members() -> None:
    joint = {
        "entity_id": "target",
        "joint_name": "target_joint0",
        "damping_per_dof": [0.01] * 6,
        "friction_loss_per_dof": [0.0] * 6,
    }
    recipe = _matched_recipe("t1_xyz")
    baseline = _matched_proposal("t1_xyz", recipe)
    recipe["physics"]["joints"] = [joint]
    scenario = _matched_proposal("t1_xyz", recipe)
    _check_matched("t1_xyz", scenario, partition="stress")
    for partition, factor in (("test_id", None), ("ood", "physics")):
        with pytest.raises(ValueError, match="canonical joint physics"):
            _check_matched("t1_xyz", scenario, partition=partition, factor=factor)
    assert scenario.physics.joints[0].damping_per_dof == (0.01,) * 6
    assert replace(scenario, physics=baseline.physics) == baseline

    recipe["physics"]["joints"][0]["damping_per_dof"] = [0.01] * 7
    with pytest.raises(ValueError, match="must have length 6"):
        _matched_proposal("t1_xyz", recipe)
    recipe["physics"]["joints"][0]["damping_per_dof"] = [0.01] * 6
    recipe["physics"]["joints"][0]["joint_name"] = "another_joint"
    with pytest.raises(ValueError, match="unknown entity/joint binding"):
        _matched_proposal("t1_xyz", recipe)


@pytest.mark.parametrize("yaw_speed", [-2.0, -0.2, 0.2, 2.0])
def test_matched_so3_parameter_ood_is_not_limited_by_the_packaged_yaw_band(
    yaw_speed: float,
) -> None:
    scenario = _matched_proposal(
        "t1_so3", _matched_recipe_with_values("t1_so3", yaw_speed=yaw_speed)
    )
    _check_matched("t1_so3", scenario, partition="ood", factor="motion_parameters")
    with pytest.raises(ValueError, match="ID motion"):
        _check_matched("t1_so3", scenario)
    with pytest.raises(ValueError, match="ID motion"):
        _check_matched("t1_so3", scenario, partition="ood", factor="physics")


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
@pytest.mark.parametrize("periods", [-2, 2])
def test_matched_finite_phase_has_no_artificial_principal_interval(
    task_id: str, periods: int
) -> None:
    baseline = _matched_proposal(task_id, _matched_recipe(task_id))
    translation = baseline.motion[0].translation
    assert isinstance(translation, HarmonicTranslation)
    phase = translation.phase_rad[0] + periods * 2 * math.pi
    scenario = _matched_proposal(task_id, _matched_recipe_with_values(task_id, phase=phase))
    _check_matched(task_id, scenario)
    assert scenario.motion[0].translation.phase_rad[0] == phase
    for time in (0.0, 0.002, 0.45, 1.25):
        states = [
            _motion_state_at_time(
                item.motion[0],
                initial_position_world_m=item.object_states[0].position_world_m,
                initial_quaternion_world_xyzw=item.object_states[0].quaternion_world_xyzw,
                simulator_time_s=time,
            )
            for item in (baseline, scenario)
        ]
        np.testing.assert_allclose(
            states[0].position_world_m, states[1].position_world_m, rtol=0.0, atol=1e-14
        )
        np.testing.assert_allclose(
            states[0].linear_velocity_world_m_s,
            states[1].linear_velocity_world_m_s,
            rtol=0.0,
            atol=1e-14,
        )


@pytest.mark.parametrize(
    ("parameter", "lower", "upper"),
    [
        ("x", -0.025, 0.025),
        ("y", -0.24, -0.20),
        ("forward", 0.04, 0.09),
        ("amplitude", 0.0, 0.03),
        ("frequency", 0.25, 0.65),
        ("yaw_speed", 0.4, 1.2),
        ("yaw_speed", -1.2, -0.4),
    ],
)
def test_matched_id_numeric_support_keeps_both_exact_bounds(
    parameter: str, lower: float, upper: float
) -> None:
    for value in (lower, upper):
        scenario = _matched_proposal(
            "t1_so3", _matched_recipe_with_values("t1_so3", **{parameter: value})
        )
        _check_matched("t1_so3", scenario)
    for value in (lower - 1e-6, upper + 1e-6):
        with pytest.raises(ValueError):
            scenario = _matched_proposal(
                "t1_so3", _matched_recipe_with_values("t1_so3", **{parameter: value})
            )
            _check_matched("t1_so3", scenario)


@pytest.mark.parametrize("forward", [0.02, 0.14])
def test_matched_motion_law_ood_cannot_also_change_id_numeric_support(forward: float) -> None:
    recipe = _matched_recipe("t1_so3", "ood", "motion_law")
    recipe["motion"][0]["translation"]["velocity_world_m_s"][1] = forward
    scenario = _matched_proposal("t1_so3", recipe)
    with pytest.raises(ValueError, match="ID motion"):
        _check_matched("t1_so3", scenario, partition="ood", factor="motion_law")
    _check_matched("t1_so3", scenario, partition="stress")


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
def test_matched_stress_allows_joint_changes_beyond_packaged_sampling_ranges(task_id: str) -> None:
    recipe = _matched_recipe_with_values(
        task_id,
        x=0.06,
        y=-0.28,
        yaw=0.65,
        forward=0.14,
        amplitude=0.06,
        frequency=1.10,
        phase=7.0,
        yaw_speed=0.0 if task_id == "t1_xyz" else 2.0,
        density=1.5,
        friction=1.8,
    )
    scenario = _matched_proposal(task_id, recipe)
    _check_matched(task_id, scenario, partition="stress")
    with pytest.raises(ValueError, match="ID motion"):
        _check_matched(task_id, scenario, partition="ood", factor="spatial")
    _assert_motion_starts_at_object_pose(scenario)


@pytest.mark.parametrize(("parameter", "value"), [("x", 0.32), ("y", -0.41), ("y", 0.39)])
def test_matched_spatial_ood_still_respects_actual_geometry(parameter: str, value: float) -> None:
    scenario = _matched_proposal(
        # Zero phase makes the sampled center equal the actual boundary probe position.
        "t1_xyz",
        _matched_recipe_with_values("t1_xyz", phase=0.0, **{parameter: value}),
    )
    with pytest.raises(ValueError, match="inside workspace and upstream"):
        _check_matched("t1_xyz", scenario, partition="ood", factor="spatial")


def _belt_recipe(
    partition: Partition = "test_id", factor: str | None = None, name: str = "e7_agentview"
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_BELT_RECIPE_PATH),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _belt_proposal(recipe: Any, seed: int = 17) -> ScenarioSpec:
    return _materialize_recipe(
        load_task("t1_belt"), recipe, np.random.Generator(np.random.PCG64(seed))
    )


def _check_belt(
    scenario: ScenarioSpec, *, partition: Partition = "test_id", factor: str | None = None
) -> None:
    _validate_surface_declarative_scenario(
        load_task("t1_belt"),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml"),
    )


def _occ_recipe(
    partition: Partition = "test_id", factor: str | None = None, name: str = "e7_agentview"
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_REPOSITORY_ROOT / "configs/scenarios/t1_occ.yaml"),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


@pytest.mark.parametrize("branch", [0, 1, 2, 3])
def test_belt_stress_keeps_fixed_db0_nominal_tuples_and_checks_each_branch(branch: int) -> None:
    speed, xy = (
        (0.04, [-0.08, -0.26]),
        (0.10, [0.08, -0.18]),
        (0.16, [0.0, -0.22]),
        (0.07, [0.0, -0.22]),
    )[branch]
    for name in _RECIPE_NAMES:
        recipe = _belt_recipe("stress", name=name)
        expected = _belt_recipe("test_id", name=name)
        expected["object_states"][0]["position_world_m"] = [*xy, 0.8220000000000001]
        expected["motion"][0]["translation"]["velocity_world_m_s"] = [0.0, speed, 0.0]
        assert recipe["choices"][branch] == expected
        base = _belt_proposal(expected)
        _check_belt(base, partition="stress")
        for wrong_speed in (np.nextafter(speed, -np.inf), np.nextafter(speed, np.inf), 0.12):
            wrong = replace(
                base,
                motion=(
                    replace(
                        base.motion[0],
                        translation=ConstantVelocityTranslation((0.0, wrong_speed, 0.0)),
                    ),
                ),
            )
            with pytest.raises(ValueError, match="fixed DB0 QA tuple"):
                _check_belt(wrong, partition="stress")
        recipe["choices"][branch]["physics"]["bodies"][0]["mass_kg"] = -0.1
        rng = np.random.default_rng(0)
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t1_belt"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize(("partition", "factor"), _BELT_RECIPE_CASES)
def test_occ_all_40_full_recipes_preserve_same_seed_belt_physics_and_four_named_tracks(
    partition: Partition,
    factor: str | None,
) -> None:
    records = []
    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    if partition == "stress":
        expected = {
            (-0.08, -0.26, 0.04),
            (0.08, -0.18, 0.10),
            (0.0, -0.22, 0.16),
            (0.0, -0.22, 0.07),
        }
        for name in _RECIPE_NAMES:
            by_task = {}
            for task_id, recipe in (
                ("t1_occ", _occ_recipe(partition, factor, name)),
                ("t1_belt", _belt_recipe(partition, factor, name)),
            ):
                scenarios = {}
                for choice in recipe["choices"]:
                    assert set(choice) == _COMPLETE_RECIPE_FIELDS
                    scenario = _materialize_recipe(
                        load_task(task_id),
                        choice,
                        np.random.Generator(np.random.PCG64(17)),
                    )
                    _validate_surface_declarative_scenario(
                        load_task(task_id),
                        scenario,
                        partition=partition,
                        factor=factor,
                        catalog=catalog,
                    )
                    key = (
                        *scenario.object_states[0].position_world_m[:2],
                        scenario.motion[0].translation.velocity_world_m_s[1],
                    )
                    assert key not in scenarios
                    scenarios[key] = scenario
                assert set(scenarios) == expected
                by_task[task_id] = scenarios
            for key in sorted(expected):
                scenario = by_task["t1_occ"][key]
                record = scenario_to_dict(scenario)
                assert scenario_from_dict(record, family="driven_interception") == scenario
                record["fixture_states"] = record["fixture_states"][:-1]
                record["physics"]["contacts"] = record["physics"]["contacts"][:-1]
                record["geometry"]["occlusion_target_clearance_m"] = 0.0
                assert record == scenario_to_dict(by_task["t1_belt"][key])
        return
    for name in _RECIPE_NAMES:
        recipe = _occ_recipe(partition, factor, name)
        assert set(recipe) == _COMPLETE_RECIPE_FIELDS
        rng = np.random.Generator(np.random.PCG64(17))
        scenario = _materialize_recipe(load_task("t1_occ"), recipe, rng)
        _validate_surface_declarative_scenario(
            load_task("t1_occ"),
            scenario,
            partition=partition,
            factor=factor,
            catalog=catalog,
        )
        reordered = _materialize_recipe(
            load_task("t1_occ"),
            dict(reversed(tuple(recipe.items()))),
            np.random.Generator(np.random.PCG64(17)),
        )
        assert reordered == scenario
        belt_rng = np.random.Generator(np.random.PCG64(17))
        belt = _materialize_recipe(
            load_task("t1_belt"), _belt_recipe(partition, factor, name), belt_rng
        )
        assert rng.bit_generator.state == belt_rng.bit_generator.state
        record = scenario_to_dict(scenario)
        assert scenario_from_dict(record, family="driven_interception") == scenario
        assert "recipe_name" not in record
        assert record["fixture_states"][-1]["asset_id"] == "fixture.occlusion_canopy_v1"
        record["fixture_states"] = record["fixture_states"][:-1]
        record["physics"]["contacts"] = record["physics"]["contacts"][:-1]
        record["geometry"]["occlusion_target_clearance_m"] = 0.0
        assert record == scenario_to_dict(belt)
        record.pop("action_mode")
        record.pop("observation_profile")
        record["cameras"]["views"] = record["cameras"]["views"][:1]
        records.append(record)
    assert records[0] == records[1] == records[2] == records[3]


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_occ"])
@pytest.mark.parametrize(
    "change", ["x", "y", "mass", "inertia", "friction", "solref", "solimp", "gravity"]
)
def test_surface_native_values_beyond_yaml_support_belong_only_to_their_factor(
    task_id: str,
    change: str,
) -> None:
    recipe = _belt_recipe() if task_id == "t1_belt" else _occ_recipe()
    baseline = _materialize_recipe(
        load_task(task_id), recipe, np.random.Generator(np.random.PCG64(17))
    )
    if change in ("x", "y"):
        position = list(baseline.object_states[0].position_world_m)
        position[0 if change == "x" else 1] = 0.20 if change == "x" else -0.35
        altered = replace(
            baseline,
            object_states=(replace(baseline.object_states[0], position_world_m=tuple(position)),),
        )
        factor = "spatial"
    else:
        physics = baseline.physics
        body, contact = physics.bodies[0], physics.contacts[0]
        if change == "mass":
            physics = replace(physics, bodies=(replace(body, mass_kg=body.mass_kg * 1.25),))
        elif change == "inertia":
            inertia = list(body.diagonal_inertia_kg_m2)
            inertia[0] *= 1.01
            physics = replace(
                physics, bodies=(replace(body, diagonal_inertia_kg_m2=tuple(inertia)),)
            )
        elif change == "gravity":
            physics = replace(physics, gravity_world_m_s2=(0.0, 0.0, -9.7))
        else:
            kwargs = (
                {"friction_slide_spin_roll": (1.0, 0.006, 0.0001)}
                if change == "friction"
                else {change: (0.025, 1.0) if change == "solref" else (0.92, 0.95, 0.001, 0.5, 2.0)}
            )
            physics = replace(physics, contacts=(replace(contact, **kwargs), *physics.contacts[1:]))
        altered = replace(baseline, physics=physics)
        factor = "physics"
    catalog = _load_asset_catalog(_REPOSITORY_ROOT / "assets/catalog.yaml")
    _validate_surface_declarative_scenario(
        load_task(task_id), altered, partition="ood", factor=factor, catalog=catalog
    )
    stress = replace(
        altered,
        motion=(
            replace(altered.motion[0], translation=ConstantVelocityTranslation((0.0, 0.14, 0.0))),
        ),
    )
    with pytest.raises(ValueError, match="fixed DB0 QA tuple"):
        _validate_surface_declarative_scenario(
            load_task(task_id), stress, partition="stress", factor=None, catalog=catalog
        )
    with pytest.raises(ValueError):
        _validate_surface_declarative_scenario(
            load_task(task_id), altered, partition="test_id", factor=None, catalog=catalog
        )
    with pytest.raises(ValueError):
        _validate_surface_declarative_scenario(
            load_task(task_id),
            altered,
            partition="ood",
            factor="physics" if factor == "spatial" else "spatial",
            catalog=catalog,
        )


@pytest.mark.parametrize(
    "kind",
    [
        "missing",
        "unknown",
        "duplicate",
        "unknown_asset",
        "bad_quaternion",
        "callback",
        "negative_friction",
        "missing_contact",
        "duplicate_contact",
        "changing_contact_binding",
    ],
)
def test_occ_raw_fixture_choices_fail_before_any_rng_draw(kind: str) -> None:
    recipe = _occ_recipe()
    canopy = recipe["fixture_states"][1]
    if kind == "missing":
        recipe["fixture_states"].pop()
    elif kind == "duplicate":
        recipe["fixture_states"][1] = copy.deepcopy(recipe["fixture_states"][0])
    elif kind == "missing_contact":
        recipe["physics"]["contacts"].pop()
    elif kind == "duplicate_contact":
        recipe["physics"]["contacts"][-1] = copy.deepcopy(recipe["physics"]["contacts"][0])
    elif kind == "changing_contact_binding":
        contact = recipe["physics"]["contacts"][-1]
        recipe["physics"]["contacts"][-1] = {
            "choices": [contact, {**contact, "entity_id": "target"}]
        }
    elif kind == "negative_friction":
        contact = recipe["physics"]["contacts"][-1]
        recipe["physics"]["contacts"][-1] = {
            "choices": [contact, {**contact, "friction_slide_spin_roll": [-1.0, 0.005, 0.0001]}]
        }
    else:
        invalid = copy.deepcopy(canopy)
        field, value = {
            "unknown": ("instance_id", "unbound"),
            "unknown_asset": ("asset_id", "fixture.unknown"),
            "bad_quaternion": ("quaternion_world_xyzw", [0.0, 0.0, 0.0, 2.0]),
            "callback": ("callback", "invalid"),
        }[kind]
        invalid[field] = value
        recipe["fixture_states"][1] = {"choices": [canopy, invalid]}
    for seed in (0, 17):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t1_occ"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize(("partition", "factor"), _BELT_RECIPE_CASES)
def test_belt_all_40_named_recipes_materialize_deterministically_and_preserve_physical_pairing(
    partition: Partition, factor: str | None
) -> None:
    physical = []
    for name in _RECIPE_NAMES:
        recipe = _belt_recipe(partition, factor, name)
        if partition == "stress":
            assert set(recipe) == {"choices"} and len(recipe["choices"]) == 4
            assert all(set(row) == _COMPLETE_RECIPE_FIELDS for row in recipe["choices"])
        else:
            assert set(recipe) == _COMPLETE_RECIPE_FIELDS
        alternatives = recipe["choices"] if partition == "stress" else [recipe]
        assert all(
            row["action_mode"] == ("E7" if name.startswith("e7_") else "J8") for row in alternatives
        )
        scenario = _belt_proposal(recipe)
        _check_belt(scenario, partition=partition, factor=factor)
        assert _belt_proposal(recipe) == scenario
        assert _belt_proposal(dict(reversed(tuple(recipe.items())))) == scenario
        assert len(scenario.cameras.views) == (2 if name.endswith("_wrist") else 1)
        record = scenario_to_dict(scenario)
        assert "recipe_name" not in record and "seed" not in record
        assert scenario_from_dict(record, family="driven_interception") == scenario
        record.pop("action_mode")
        record.pop("observation_profile")
        record["cameras"]["views"] = record["cameras"]["views"][:1]
        physical.append(record)
    assert physical[0] == physical[1] == physical[2] == physical[3]
    document = load_yaml_strict(_BELT_RECIPE_PATH)
    assert set(document) == {"schema_version", "recipes"}
    assert set(document["recipes"]["ood"]) == set(_BELT_OOD_FACTORS)


@pytest.mark.parametrize(
    ("factor", "owned"),
    [
        ("spatial", "object_states"),
        ("motion_parameters", "motion"),
        ("physics", "physics"),
        ("appearance", "lighting"),
        ("camera", "cameras"),
        ("action_delay", "action_delay_steps"),
    ],
)
def test_belt_single_factor_ood_changes_only_its_owned_record(factor: str, owned: str) -> None:
    baseline_recipe = _belt_recipe()
    ood_recipe = _belt_recipe("ood", factor)
    if factor == "spatial":
        # The spatial selector consumes extra RNG draws. Compare the unowned
        # speed distribution, then hold speed fixed to isolate the owned record.
        assert baseline_recipe["motion"] == ood_recipe["motion"]
        speed = baseline_recipe["motion"][0]["translation"]["velocity_world_m_s"][1]
        assert speed == {"min": 0.04, "max": 0.10}
        for recipe in (baseline_recipe, ood_recipe):
            recipe["motion"][0]["translation"]["velocity_world_m_s"][1] = 0.07
    baseline = scenario_to_dict(_belt_proposal(baseline_recipe))
    altered = _belt_proposal(ood_recipe)
    _check_belt(altered, partition="ood", factor=factor)
    ood = scenario_to_dict(altered)
    assert baseline[owned] != ood[owned]
    assert {key: value for key, value in baseline.items() if key != owned} == {
        key: value for key, value in ood.items() if key != owned
    }


@pytest.mark.parametrize("xy", [(0.0, -0.22), (-0.08, -0.26), (0.08, -0.18)])
def test_belt_spatial_overlap_is_explicitly_rejected_identically_for_all_paired_recipes(
    xy: tuple[float, float],
) -> None:
    reasons = []
    for name in _RECIPE_NAMES:
        scenario = _belt_proposal(_belt_recipe("ood", "spatial", name), seed=2)
        target = scenario.object_states[0]
        scenario = replace(
            scenario,
            object_states=(replace(target, position_world_m=(*xy, target.position_world_m[2])),),
        )
        with pytest.raises(ValueError, match="outside ID pose support") as rejected:
            _check_belt(scenario, partition="ood", factor="spatial")
        reasons.append(str(rejected.value))
    assert len(set(reasons)) == 1


@pytest.mark.parametrize("axis", [0, 1])
@pytest.mark.parametrize("interval", [0, 1])
def test_belt_spatial_all_interval_branches_are_checked_before_rng(
    axis: int, interval: int
) -> None:
    for name in _RECIPE_NAMES:
        recipe = _belt_recipe("ood", "spatial", name)
        choices = recipe["object_states"][0]["position_world_m"]["choices"]
        choices[axis][axis]["uniform_intervals"][interval] = [0.1, -0.1]
        rng = np.random.default_rng(2)
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t1_belt"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize(
    "kind",
    [
        "root_unknown",
        "asset_choice",
        "law_choice",
        "law_numeric_choice",
        "law_missing",
        "body_choice",
        "camera_choice",
        "light_choice",
        "quaternion_dsl",
    ],
)
def test_belt_closed_raw_recipes_reject_invalid_unselected_branches_before_rng(kind: str) -> None:
    recipe = _belt_recipe()
    if kind == "root_unknown":
        recipe["callback"] = "invalid"
    elif kind == "asset_choice":
        recipe["object_states"][0]["asset_id"] = {"choices": ["obj.cube_44_v1", "obj.unknown"]}
    elif kind == "law_choice":
        law = recipe["motion"][0]["translation"]
        recipe["motion"][0]["translation"] = {"choices": [law, {**law, "callback": "invalid"}]}
    elif kind == "law_numeric_choice":
        recipe["motion"][0]["translation"]["velocity_world_m_s"][1] = {
            "choices": [0.07, {"min": 0.1, "max": 0.04}]
        }
    elif kind == "law_missing":
        del recipe["motion"][0]["translation"]["velocity_world_m_s"]
    elif kind == "body_choice":
        body = recipe["physics"]["bodies"][0]
        recipe["physics"]["bodies"] = [{"choices": [body, {**body, "mass_kg": -0.1}]}]
    elif kind == "camera_choice":
        view = recipe["cameras"]["views"][0]
        recipe["cameras"]["views"] = [{"choices": [view, {**view, "ref": "invalid"}]}]
    elif kind == "light_choice":
        light = recipe["lighting"]["lights"][0]
        recipe["lighting"]["lights"] = [{"choices": [light, {**light, "callback": "invalid"}]}]
    else:
        recipe["object_states"][0]["quaternion_world_xyzw"] = {"yaw_expression": "invalid"}
    for seed in range(4):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t1_belt"), recipe, rng)
        assert rng.bit_generator.state == before


def test_belt_declarative_bounds_and_references_are_strict() -> None:
    baseline = _belt_proposal(_belt_recipe())
    target = baseline.object_states[0]
    invalid_scenarios = [
        replace(baseline, object_states=(replace(target, asset_id="obj.cuboid_grasp_v1"),)),
        replace(baseline, object_states=(replace(target, position_world_m=(0.0, -0.20, 0.8)),)),
        replace(baseline, object_states=(replace(target, position_world_m=(0.20, -0.20, 0.822)),)),
        replace(
            baseline, object_states=(replace(target, linear_velocity_world_m_s=(0.0, 0.07, 0.0)),)
        ),
        replace(
            baseline,
            fixture_states=(replace(baseline.fixture_states[0], asset_id="arena.unknown"),),
        ),
        replace(baseline, motion=(replace(baseline.motion[0], entity_id="target"),)),
        replace(
            baseline,
            physics=replace(
                baseline.physics,
                bodies=(
                    replace(
                        baseline.physics.bodies[0], diagonal_inertia_kg_m2=(0.001, 0.001, 0.001)
                    ),
                ),
            ),
        ),
        replace(baseline, action_delay_steps=1),
    ]
    for invalid in invalid_scenarios:
        with pytest.raises(ValueError):
            _check_belt(invalid)
    for factor in ("object", "motion_law", "geometry", "unknown"):
        with pytest.raises(ValueError, match="inapplicable"):
            _check_belt(baseline, partition="ood", factor=factor)


@pytest.mark.parametrize(
    ("partition", "factor", "speeds"),
    [
        ("test_id", None, (0.04, 0.10)),
        ("ood", "motion_parameters", (0.105, 0.120)),
    ],
)
def test_belt_motion_support_has_exact_frozen_endpoints(
    partition: Partition, factor: str | None, speeds: tuple[float, float]
) -> None:
    base = _belt_proposal(_belt_recipe(partition, factor))
    for speed in speeds:
        scenario = replace(
            base,
            motion=(
                replace(base.motion[0], translation=ConstantVelocityTranslation((0.0, speed, 0.0))),
            ),
        )
        _check_belt(scenario, partition=partition, factor=factor)
    for speed in (speeds[0] - 1e-6, speeds[1] + 1e-6):
        scenario = replace(
            base,
            motion=(
                replace(base.motion[0], translation=ConstantVelocityTranslation((0.0, speed, 0.0))),
            ),
        )
        with pytest.raises(ValueError, match="motion support"):
            _check_belt(scenario, partition=partition, factor=factor)


def test_belt_camera_ood_requires_exactly_one_canonical_intervention() -> None:
    baseline = _belt_proposal(_belt_recipe())
    agent = baseline.cameras.views[0]
    for axis in range(3):
        for delta in (-0.05, 0.05):
            position = list(agent.position_parent_m)
            position[axis] += delta
            shifted = replace(agent, position_parent_m=tuple(position))
            scenario = replace(baseline, cameras=replace(baseline.cameras, views=(shifted,)))
            _check_belt(scenario, partition="ood", factor="camera")
            combined = replace(
                scenario,
                cameras=replace(scenario.cameras, views=(replace(shifted, vertical_fov_deg=35.0),)),
            )
            with pytest.raises(ValueError, match="exactly one"):
                _check_belt(combined, partition="ood", factor="camera")
    for fov in (35.0, 45.0):
        scenario = replace(
            baseline,
            cameras=replace(baseline.cameras, views=(replace(agent, vertical_fov_deg=fov),)),
        )
        _check_belt(scenario, partition="ood", factor="camera")


def _recipe(marker: str) -> dict[str, object]:
    return {
        "action_mode": "E7",
        "observation_profile": "agentview",
        "physics_timestep_s": 0.002,
        "control_frequency_hz": 20,
        "sensor_frequency_hz": 20,
        "action_delay": {"enabled": False, "delay_steps": 0},
        "robot_initial_state": {"marker": marker},
        "object_states": [],
        "fixture_states": [],
        "geometry": {},
        "motion": [],
        "physics": {},
        "cameras": {},
        "lighting": {},
        "events": [],
    }


def _named_recipes(marker: str) -> dict[str, dict[str, object]]:
    return {recipe_name: _recipe(f"{marker}.{recipe_name}") for recipe_name in _RECIPE_NAMES}


def _document() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "recipes": {
            "train": _named_recipes("train"),
            "validation": _named_recipes("validation"),
            "test_id": _named_recipes("test_id"),
            "ood": {factor: _named_recipes(f"ood.{factor}") for factor in sorted(OOD_FACTORS)},
            "stress": _named_recipes("stress"),
        },
    }


def _materializable_recipe(*, action_mode: str) -> dict[str, object]:
    return {
        "action_mode": action_mode,
        "observation_profile": "agentview",
        "physics_timestep_s": 0.002,
        "control_frequency_hz": 20,
        "sensor_frequency_hz": 20,
        "action_delay": {"enabled": False, "delay_steps": 0},
        "robot_initial_state": {
            "joint_position_rad": [0.0] * 7,
            "gripper_position_m": [0.0, 0.0],
        },
        "object_states": [
            {
                "instance_id": "target",
                "asset_id": "obj.cuboid_grasp_v1",
                "position_world_m": [
                    {"min": -0.1, "max": 0.1},
                    {"min": -0.1, "max": 0.1},
                    0.1,
                ],
                "quaternion_world_xyzw": {"yaw_rad": {"min": -0.8, "max": 0.8}},
                "linear_velocity_world_m_s": [0.0, 0.0, 0.0],
                "angular_velocity_world_rad_s": [0.0, 0.0, 0.0],
            }
        ],
        "fixture_states": [],
        "geometry": {
            "support_surface_z_m": 0.0,
            "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
            "downstream_exit_y_m": 0.6,
        },
        "motion": [
            {
                "entity_id": "target",
                "translation": {"type": "fixed"},
                "rotation": {"type": "fixed"},
            }
        ],
        "physics": {
            "gravity_world_m_s2": [0.0, 0.0, -9.81],
            "bodies": [],
            "contacts": [],
            "joints": [],
        },
        "cameras": {
            "image_height_px": 224,
            "image_width_px": 224,
            "views": [
                {
                    "view_name": "agentview",
                    "position_parent_m": [0.0, -1.0, 1.0],
                    "quaternion_parent_xyzw": [0.0, 0.0, 0.0, 1.0],
                    "vertical_fov_deg": 45.0,
                }
            ],
        },
        "lighting": {"lights": []},
        "events": [],
    }


def _materialize_grasp_laws(
    translation: dict[str, object],
    rotation: dict[str, object],
    *,
    position_world_m: object = (0.17, -0.11, 0.24),
    yaw_rad: object = 0.73,
    seed: int = 41,
) -> ScenarioSpec:
    recipe = _materializable_recipe(action_mode="E7")
    recipe["object_states"][0]["position_world_m"] = position_world_m  # type: ignore[index]
    recipe["object_states"][0]["quaternion_world_xyzw"] = {  # type: ignore[index]
        "yaw_rad": yaw_rad
    }
    recipe["motion"][0]["translation"] = translation  # type: ignore[index]
    recipe["motion"][0]["rotation"] = rotation  # type: ignore[index]
    return _materialize_recipe(
        load_task("grasp"),
        recipe,
        np.random.Generator(np.random.PCG64(seed)),
    )


def _assert_motion_starts_at_object_pose(scenario: ScenarioSpec) -> None:
    target = scenario.object_states[0]
    state = _motion_state_at_time(
        scenario.motion[0],
        initial_position_world_m=target.position_world_m,
        initial_quaternion_world_xyzw=target.quaternion_world_xyzw,
        simulator_time_s=0.0,
    )
    np.testing.assert_allclose(
        state.position_world_m,
        target.position_world_m,
        rtol=0.0,
        atol=1e-12,
    )
    assert math.isclose(
        abs(float(np.dot(state.quaternion_world_xyzw, target.quaternion_world_xyzw))),
        1.0,
        rel_tol=0.0,
        abs_tol=1e-12,
    )


def _generate_grasp(
    partition: Partition,
    factor: str | None,
    recipe_name: str,
    *,
    seed: int = 17,
) -> ScenarioSpec:
    task = load_task("grasp")
    recipe = _select_recipe(
        load_yaml_strict(_GRASP_RECIPE_PATH),
        partition=partition,
        factor=factor,
        recipe_name=recipe_name,
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_grasp_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
    )
    return scenario


def _scenario_payload(
    partition: Partition,
    factor: str | None,
    *,
    seed: int = 17,
) -> dict[str, object]:
    return scenario_to_dict(_generate_grasp(partition, factor, "e7_agentview", seed=seed))


def _without_profile_identity(scenario: ScenarioSpec) -> dict[str, object]:
    payload = scenario_to_dict(scenario)
    del payload["action_mode"]
    del payload["observation_profile"]
    del payload["cameras"]
    return payload


def test_grasp_m0_compiles_fixed_motion_from_atomic_initial_pose() -> None:
    position = (0.13, -0.09, 0.22)
    yaw = 0.61
    scenario = _materialize_grasp_laws(
        {"type": "fixed"},
        {"type": "fixed"},
        position_world_m=position,
        yaw_rad=yaw,
    )

    assert isinstance(scenario.motion[0].translation, FixedTranslation)
    assert isinstance(scenario.motion[0].rotation, FixedRotation)
    assert scenario.object_states[0].position_world_m == position
    np.testing.assert_allclose(
        scenario.object_states[0].quaternion_world_xyzw,
        (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)),
        rtol=0.0,
        atol=1e-15,
    )
    _assert_motion_starts_at_object_pose(scenario)


def test_grasp_m1_preserves_atomic_pose_for_constant_velocity_laws() -> None:
    scenario = _materialize_grasp_laws(
        {"type": "constant_velocity", "velocity_world_m_s": [0.12, -0.04, 0.03]},
        {
            "type": "constant_angular_velocity",
            "axis_world": [0.0, 1.0, 0.0],
            "angular_speed_rad_s": -0.8,
        },
    )

    assert isinstance(scenario.motion[0].translation, ConstantVelocityTranslation)
    assert isinstance(scenario.motion[0].rotation, ConstantAngularVelocityRotation)
    _assert_motion_starts_at_object_pose(scenario)


def test_grasp_m2_harmonic_translation_derives_center_for_nonzero_axis_phases() -> None:
    position = np.asarray([0.19, -0.08, 0.27], dtype=np.float64)
    amplitude = np.asarray([0.04, 0.07, 0.03], dtype=np.float64)
    phase = np.asarray([0.31, -0.72, 1.11], dtype=np.float64)
    raw_translation = {
        "type": "harmonic",
        "drift_velocity_world_m_s": [0.0, 0.0, 0.0],
        "amplitude_m": amplitude.tolist(),
        "frequency_hz": [0.7, 1.1, 1.4],
        "phase_rad": phase.tolist(),
    }
    raw_snapshot = copy.deepcopy(raw_translation)
    scenario = _materialize_grasp_laws(
        raw_translation,
        {"type": "fixed"},
        position_world_m=position.tolist(),
    )

    law = scenario.motion[0].translation
    assert isinstance(law, HarmonicTranslation)
    np.testing.assert_allclose(
        law.center_world_m,
        position - amplitude * np.sin(phase),
        rtol=0.0,
        atol=1e-15,
    )
    assert raw_translation == raw_snapshot
    assert "center_world_m" not in raw_translation
    _assert_motion_starts_at_object_pose(scenario)


def test_grasp_m2_circular_translation_derives_center_for_nontrivial_plane() -> None:
    root_half = math.sqrt(0.5)
    position = np.asarray([0.21, -0.13, 0.31], dtype=np.float64)
    axis = np.asarray([root_half, root_half, 0.0], dtype=np.float64)
    radial = np.asarray([0.0, 0.0, 1.0], dtype=np.float64)
    radius = 0.09
    phase = 0.67
    scenario = _materialize_grasp_laws(
        {
            "type": "circular",
            "axis_world": axis.tolist(),
            "radial_direction_world": radial.tolist(),
            "radius_m": radius,
            "angular_speed_rad_s": 1.3,
            "phase_rad": phase,
        },
        {"type": "fixed"},
        position_world_m=position.tolist(),
    )

    law = scenario.motion[0].translation
    assert isinstance(law, CircularTranslation)
    expected_center = position - radius * (
        math.cos(phase) * radial + math.sin(phase) * np.cross(axis, radial)
    )
    np.testing.assert_allclose(law.center_world_m, expected_center, rtol=0.0, atol=1e-15)
    _assert_motion_starts_at_object_pose(scenario)


def test_grasp_seeded_db0_pose_twist_and_rng_sequence_are_correlated() -> None:
    # DB0 p0_grasp_v0_1.yaml factors and p0_motion.py's sinusoidal reference.
    expected_rng = np.random.Generator(np.random.PCG64(5))
    center = (
        expected_rng.uniform(-0.08, 0.08),
        expected_rng.uniform(-0.26, -0.19),
        0.8 + 0.022,
    )
    yaw = expected_rng.uniform(-1.1, 1.1)
    forward_speed = expected_rng.uniform(0.025, 0.125)
    amplitude = expected_rng.uniform(0.015, 0.035)
    frequency = expected_rng.uniform(0.30, 0.70)
    phase = expected_rng.uniform(-math.pi, math.pi)
    yaw_rate = expected_rng.uniform(-1.2, 1.2)
    position = (center[0] + amplitude * math.sin(phase), center[1], center[2])
    velocity = (amplitude * (2.0 * math.pi * frequency) * math.cos(phase), forward_speed, 0.0)
    document = load_yaml_strict(_GRASP_RECIPE_PATH)
    for name in _RECIPE_NAMES:
        recipe = _select_recipe(document, partition="test_id", recipe_name=name, factor=None)
        rng = np.random.Generator(np.random.PCG64(5))
        scenario = _materialize_recipe(load_task("grasp"), recipe, rng)
        target = scenario.object_states[0]
        law = scenario.motion[0].translation
        assert isinstance(law, HarmonicTranslation)
        assert isinstance(scenario.motion[0].rotation, ConstantAngularVelocityRotation)
        np.testing.assert_allclose(target.position_world_m, position, rtol=0.0, atol=1e-15)
        assert target.quaternion_world_xyzw == (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))
        np.testing.assert_allclose(target.linear_velocity_world_m_s, velocity, rtol=0.0, atol=1e-15)
        assert target.angular_velocity_world_rad_s == (0.0, 0.0, yaw_rate)
        assert law.center_world_m == center
        assert law.drift_velocity_world_m_s == (0.0, forward_speed, 0.0)
        assert law.amplitude_m == (amplitude, 0.0, 0.0)
        assert law.frequency_hz == (frequency, 0.0, 0.0)
        assert law.phase_rad == (phase, 0.0, 0.0)
        assert scenario.motion[0].rotation.axis_world == (0.0, 0.0, 1.0)
        assert scenario.motion[0].rotation.angular_speed_rad_s == yaw_rate
        assert rng.bit_generator.state == expected_rng.bit_generator.state
        _assert_motion_starts_at_object_pose(scenario)


@pytest.mark.parametrize(
    ("drift", "match"),
    [
        (None, "missing fields.*drift_velocity_world_m_s"),
        ([True, 0.0, 0.0], "finite number"),
        ([float("nan"), 0.0, 0.0], "finite number"),
        ([0.0, 0.0], "length 3"),
        ({"ref": "forward"}, "exactly min/max or choices"),
    ],
)
def test_grasp_harmonic_drift_support_is_validated_before_selection(
    drift: object, match: str
) -> None:
    law = {
        "type": "harmonic",
        "amplitude_m": [0.02, 0.0, 0.0],
        "frequency_hz": [0.4, 0.0, 0.0],
        "phase_rad": [0.3, 0.0, 0.0],
    }
    if drift is not None:
        law["drift_velocity_world_m_s"] = drift
    recipe: Any = _materializable_recipe(action_mode="E7")
    recipe["motion"][0]["translation"] = {"choices": [{"type": "fixed"}, law]}
    for seed in (0, 1):
        rng = np.random.Generator(np.random.PCG64(seed))
        initial_rng = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match=match):
            _materialize_recipe(load_task("grasp"), recipe, rng)
        assert rng.bit_generator.state == initial_rng


@pytest.mark.parametrize(
    ("partition", "factor"),
    [("train", None), ("validation", None), ("test_id", None), ("ood", "motion_parameters")],
)
def test_grasp_declarative_harmonic_accepts_db0_forward_drift(
    partition: Partition,
    factor: str | None,
) -> None:
    scenario = _generate_grasp(partition, factor, "e7_agentview", seed=5)
    motion = scenario.motion[0]
    target = scenario.object_states[0]
    assert isinstance(motion.translation, HarmonicTranslation)
    changed = replace(
        scenario,
        object_states=(
            replace(
                target,
                linear_velocity_world_m_s=(target.linear_velocity_world_m_s[0], 0.06, 0.0),
            ),
        ),
        motion=(
            replace(
                motion,
                translation=replace(motion.translation, drift_velocity_world_m_s=(0.0, 0.06, 0.0)),
            ),
        ),
    )
    _validate_grasp_declarative_scenario(
        load_task("grasp"),
        changed,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
    )


def test_grasp_m2_harmonic_rotation_derives_base_for_nonidentity_yaw() -> None:
    root_half = math.sqrt(0.5)
    yaw = 0.83
    axis = np.asarray([root_half, 0.0, root_half], dtype=np.float64)
    amplitude = 0.74
    phase = -0.58
    scenario = _materialize_grasp_laws(
        {"type": "fixed"},
        {
            "type": "harmonic",
            "axis_world": axis.tolist(),
            "amplitude_rad": amplitude,
            "frequency_hz": 0.9,
            "phase_rad": phase,
        },
        yaw_rad=yaw,
    )

    law = scenario.motion[0].rotation
    assert isinstance(law, HarmonicRotation)
    initial_quaternion = np.asarray(
        [0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)], dtype=np.float64
    )
    initial_angle = amplitude * math.sin(phase)
    half_inverse = -0.5 * initial_angle
    inverse = np.concatenate((axis * math.sin(half_inverse), np.asarray([math.cos(half_inverse)])))
    expected_base = np.empty(4, dtype=np.float64)
    expected_base[:3] = (
        inverse[3] * initial_quaternion[:3]
        + initial_quaternion[3] * inverse[:3]
        + np.cross(inverse[:3], initial_quaternion[:3])
    )
    expected_base[3] = inverse[3] * initial_quaternion[3] - float(
        np.dot(inverse[:3], initial_quaternion[:3])
    )
    expected_base /= np.linalg.norm(expected_base)
    np.testing.assert_allclose(law.base_quaternion_world_xyzw, expected_base, rtol=0.0, atol=1e-15)
    assert not np.allclose(law.base_quaternion_world_xyzw, initial_quaternion)
    _assert_motion_starts_at_object_pose(scenario)


def test_grasp_atomic_sampler_is_deterministic_and_round_trips_without_markers() -> None:
    translation = {
        "type": "harmonic",
        "drift_velocity_world_m_s": [0.0, 0.0, 0.0],
        "amplitude_m": [
            {"min": 0.01, "max": 0.04},
            {"min": 0.02, "max": 0.05},
            {"min": 0.01, "max": 0.03},
        ],
        "frequency_hz": {"choices": [[0.7, 0.9, 1.1], [1.0, 1.2, 1.4]]},
        "phase_rad": [
            {"min": -1.0, "max": -0.2},
            {"min": 0.2, "max": 0.8},
            {"min": 0.9, "max": 1.4},
        ],
    }
    rotation = {
        "type": "harmonic",
        "axis_world": {"choices": [[0.0, 0.0, 1.0], [0.0, 1.0, 0.0]]},
        "amplitude_rad": {"min": 0.2, "max": 0.7},
        "frequency_hz": {"min": 0.5, "max": 1.3},
        "phase_rad": {"min": -0.9, "max": 0.9},
    }
    position = [
        {"min": 0.1, "max": 0.2},
        {"min": -0.2, "max": -0.1},
        {"min": 0.18, "max": 0.28},
    ]
    yaw = {"min": -1.2, "max": 1.2}
    first = _materialize_grasp_laws(
        translation, rotation, position_world_m=position, yaw_rad=yaw, seed=902
    )
    second = _materialize_grasp_laws(
        translation, rotation, position_world_m=position, yaw_rad=yaw, seed=902
    )

    assert first == second
    payload = scenario_to_dict(first)
    assert scenario_from_dict(payload, family="grasp") == first
    assert "yaw_rad" not in repr(payload)
    assert "compiler" not in repr(payload)
    assert "recipe_name" not in repr(payload)
    _assert_motion_starts_at_object_pose(first)


@pytest.mark.parametrize(
    ("translation", "rotation", "derived_field"),
    [
        (
            {
                "type": "harmonic",
                "center_world_m": [0.0, 0.0, 0.0],
                "drift_velocity_world_m_s": [0.0, 0.0, 0.0],
                "amplitude_m": [0.1, 0.1, 0.1],
                "frequency_hz": [1.0, 1.0, 1.0],
                "phase_rad": [0.1, 0.2, 0.3],
            },
            {"type": "fixed"},
            "center_world_m",
        ),
        (
            {
                "type": "circular",
                "center_world_m": [0.0, 0.0, 0.0],
                "axis_world": [0.0, 0.0, 1.0],
                "radial_direction_world": [1.0, 0.0, 0.0],
                "radius_m": 0.1,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.2,
            },
            {"type": "fixed"},
            "center_world_m",
        ),
        (
            {"type": "fixed"},
            {
                "type": "harmonic",
                "base_quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
                "axis_world": [0.0, 0.0, 1.0],
                "amplitude_rad": 0.4,
                "frequency_hz": 1.0,
                "phase_rad": 0.3,
            },
            "base_quaternion_world_xyzw",
        ),
    ],
)
def test_grasp_raw_laws_reject_compiler_owned_derived_fields(
    translation: dict[str, object],
    rotation: dict[str, object],
    derived_field: str,
) -> None:
    with pytest.raises(ValueError, match=derived_field):
        _materialize_grasp_laws(translation, rotation)


@pytest.mark.parametrize(
    ("translation", "match"),
    [
        (
            {
                "type": "circular",
                "axis_world": [2.0, 0.0, 0.0],
                "radial_direction_world": [0.0, 1.0, 0.0],
                "radius_m": 0.1,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.2,
            },
            "unit length",
        ),
        (
            {
                "type": "circular",
                "axis_world": [1.0, 0.0, 0.0],
                "radial_direction_world": [0.0, 2.0, 0.0],
                "radius_m": 0.1,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.2,
            },
            "unit length",
        ),
        (
            {
                "type": "circular",
                "axis_world": [1.0, 0.0, 0.0],
                "radial_direction_world": [1.0, 0.0, 0.0],
                "radius_m": 0.1,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.2,
            },
            "orthogonal",
        ),
        (
            {
                "type": "circular",
                "axis_world": [1.0, 0.0, 0.0],
                "radial_direction_world": [0.0, 1.0, 0.0],
                "radius_m": 0.0,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.2,
            },
            "positive",
        ),
    ],
)
def test_grasp_circular_recipe_rejects_invalid_typed_geometry(
    translation: dict[str, object], match: str
) -> None:
    with pytest.raises(ValueError, match=match):
        _materialize_grasp_laws(translation, {"type": "fixed"})


def test_grasp_rotation_recipe_rejects_nonunit_axis() -> None:
    with pytest.raises(ValueError, match="unit length"):
        _materialize_grasp_laws(
            {"type": "fixed"},
            {
                "type": "harmonic",
                "axis_world": [0.0, 0.0, 2.0],
                "amplitude_rad": 0.4,
                "frequency_hz": 1.0,
                "phase_rad": 0.3,
            },
        )


def test_grasp_raw_schema_rejects_dsl_callback_unknown_and_invalid_yaw_records() -> None:
    with pytest.raises(ValueError, match="exactly min/max or choices"):
        _materialize_grasp_laws({"type": "fixed"}, {"type": "fixed"}, yaw_rad={"ref": "yaw"})
    with pytest.raises(ValueError, match="exactly min/max or choices"):
        _materialize_grasp_laws(
            {"type": "fixed"},
            {"type": "fixed"},
            yaw_rad={"min": -1.0, "max": 1.0, "distribution": "uniform"},
        )
    with pytest.raises(ValueError, match="callback"):
        _materialize_grasp_laws({"type": "fixed", "callback": "move"}, {"type": "fixed"})


def test_grasp_recipe_requires_exactly_one_bound_target_and_motion() -> None:
    task = load_task("grasp")
    missing_target = _materializable_recipe(action_mode="E7")
    missing_target["object_states"] = []
    with pytest.raises(ValueError, match="exactly one bound target object_state"):
        _materialize_recipe(task, missing_target, np.random.default_rng(0))

    duplicate_target = _materializable_recipe(action_mode="E7")
    duplicate_target["object_states"].append(  # type: ignore[union-attr]
        copy.deepcopy(duplicate_target["object_states"][0])  # type: ignore[index]
    )
    with pytest.raises(ValueError, match="exactly one bound target object_state"):
        _materialize_recipe(task, duplicate_target, np.random.default_rng(0))

    missing_motion = _materializable_recipe(action_mode="E7")
    missing_motion["motion"] = []
    with pytest.raises(ValueError, match="exactly one bound target motion"):
        _materialize_recipe(task, missing_motion, np.random.default_rng(0))

    duplicate_motion = _materializable_recipe(action_mode="E7")
    duplicate_motion["motion"].append(  # type: ignore[union-attr]
        copy.deepcopy(duplicate_motion["motion"][0])  # type: ignore[index]
    )
    with pytest.raises(ValueError, match="exactly one bound target motion"):
        _materialize_recipe(task, duplicate_motion, np.random.default_rng(0))


def _materialize_recursive_sampler_fixture(
    recipe: dict[str, object], rng: np.random.Generator
) -> ScenarioSpec:
    concrete = copy.deepcopy(_sample_recipe_value(recipe, rng))
    delay = concrete.pop("action_delay")
    assert isinstance(delay, dict)
    concrete["action_delay_steps"] = delay["delay_steps"] if delay["enabled"] else 0
    return scenario_from_dict(concrete, family="replanning")


def test_recursive_sampler_keeps_generic_nested_record_materialization() -> None:
    recipe = _materializable_recipe(action_mode="E7")
    recipe["object_states"][0]["quaternion_world_xyzw"] = [  # type: ignore[index]
        0.0,
        0.0,
        0.0,
        1.0,
    ]
    recipe["fixture_states"] = [
        {
            "instance_id": name,
            "asset_id": f"{name}_asset",
            "position_world_m": [
                {"min": -0.05, "max": 0.05} if name == "ramp" else 0.0,
                0.0,
                0.0,
            ],
            "quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
        }
        for name in ("belt", "left_striker", "right_striker")
    ]
    recipe["geometry"] = {
        "support_surface_z_m": 0.0,
        "observation_boundary_y_m": 0.1,
        "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
        "striker_travel_m": 0.1,
    }
    recipe["events"] = [
        {
            "event_id": "strike",
            "trigger": {"type": "state"},
            "effect": {
                "type": "striker_pulse",
                "striker_entity_id": "left_striker",
                "joint_name": "slide",
                "strike_position_m": 0.1,
                "pulse_duration_s": 0.1,
                "kp_n_m": 100.0,
                "kd_n_s_m": 5.0,
                "maximum_force_n": 20.0,
                "actuator_scale": 1.0,
                "contact_cutoff_delay_s": 0.01,
                "contact_grouping_hysteresis_s": 0.01,
                "maximum_contact_duration_s": 0.2,
            },
        }
    ]
    recipe["motion"] = [
        {
            "entity_id": "target",
            "translation": {"type": "fixed"},
            "rotation": {"type": "fixed"},
        }
    ]

    scenario = _materialize_recursive_sampler_fixture(recipe, np.random.default_rng(71))
    assert -0.05 <= scenario.fixture_states[0].position_world_m[0] <= 0.05
    assert isinstance(scenario.motion[0].translation, FixedTranslation)


def test_non_grasp_harmonic_samples_explicit_drift_through_the_generic_path() -> None:
    recipe: Any = _materializable_recipe(action_mode="E7")
    recipe["object_states"][0]["position_world_m"] = [0.0, 0.0, 0.1]
    recipe["object_states"][0]["quaternion_world_xyzw"] = [0.0, 0.0, 0.0, 1.0]
    recipe["fixture_states"] = [
        {
            "instance_id": name,
            "asset_id": f"{name}_asset",
            "position_world_m": [0.0, 0.0, 0.0],
            "quaternion_world_xyzw": [0.0, 0.0, 0.0, 1.0],
        }
        for name in ("belt", "left_striker", "right_striker")
    ]
    recipe["geometry"] = {
        "support_surface_z_m": 0.0,
        "observation_boundary_y_m": 0.1,
        "workspace_bounds_xy_m": [[-0.5, -0.5], [0.5, 0.5]],
        "striker_travel_m": 0.1,
    }
    recipe["motion"][0]["translation"] = {
        "type": "harmonic",
        "center_world_m": [0.0, 0.0, 0.1],
        "drift_velocity_world_m_s": [0.0, {"min": 0.04, "max": 0.09}, 0.0],
        "amplitude_m": [0.02, 0.0, 0.0],
        "frequency_hz": [0.45, 0.0, 0.0],
        "phase_rad": [0.0, 0.0, 0.0],
    }
    recipe["events"] = [
        {
            "event_id": "strike",
            "trigger": {"type": "state"},
            "effect": {
                "type": "striker_pulse",
                "striker_entity_id": "left_striker",
                "joint_name": "slide",
                "strike_position_m": 0.1,
                "pulse_duration_s": 0.1,
                "kp_n_m": 100.0,
                "kd_n_s_m": 5.0,
                "maximum_force_n": 20.0,
                "actuator_scale": 1.0,
                "contact_cutoff_delay_s": 0.01,
                "contact_grouping_hysteresis_s": 0.01,
                "maximum_contact_duration_s": 0.2,
            },
        }
    ]
    rng = np.random.Generator(np.random.PCG64(71))
    expected_rng = np.random.Generator(np.random.PCG64(71))
    expected_forward = expected_rng.uniform(0.04, 0.09)
    scenario = _materialize_recursive_sampler_fixture(recipe, rng)
    law = scenario.motion[0].translation
    assert isinstance(law, HarmonicTranslation)
    assert law.drift_velocity_world_m_s == (0.0, expected_forward, 0.0)
    assert rng.bit_generator.state == expected_rng.bit_generator.state
    _assert_motion_starts_at_object_pose(scenario)
    assert scenario_from_dict(scenario_to_dict(scenario), family="replanning") == scenario


@pytest.mark.parametrize("partition", ["train", "validation", "test_id", "stress"])
@pytest.mark.parametrize("recipe_name", _RECIPE_NAMES)
def test_every_named_recipe_is_selectable_for_every_non_ood_partition(
    partition: str, recipe_name: str
) -> None:
    selected = _select_recipe(
        _document(),
        partition=partition,  # type: ignore[arg-type]
        factor=None,
        recipe_name=recipe_name,
    )
    assert selected["robot_initial_state"] == {"marker": f"{partition}.{recipe_name}"}


@pytest.mark.parametrize("factor", sorted(OOD_FACTORS))
def test_every_registered_ood_factor_has_explicit_named_selection(factor: str) -> None:
    selected = _select_recipe(
        _document(),
        partition="ood",
        factor=factor,
        recipe_name="j8_agentview_wrist",
    )
    assert selected["robot_initial_state"] == {"marker": f"ood.{factor}.j8_agentview_wrist"}


def test_recipe_sets_reject_missing_extra_and_unknown_names() -> None:
    missing = _document()
    del missing["recipes"]["train"]["j8_agentview_wrist"]
    with pytest.raises(ValueError, match="train missing fields"):
        _select_recipe(
            missing,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    extra = _document()
    extra["recipes"]["validation"]["implicit_default"] = _recipe("extra")
    with pytest.raises(ValueError, match="validation unknown fields"):
        _select_recipe(
            extra,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    with pytest.raises(ValueError, match="unknown recipe name"):
        _select_recipe(
            _document(),
            partition="test_id",
            factor=None,
            recipe_name="agentview",
        )


def test_every_named_recipe_is_self_contained_and_strict() -> None:
    invalid = _document()
    del invalid["recipes"]["validation"]["j8_agentview"]["physics"]
    with pytest.raises(ValueError, match=r"validation\.j8_agentview missing fields"):
        _select_recipe(
            invalid,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    invalid = _document()
    invalid["recipes"]["stress"]["e7_agentview"]["action_delay"] = {
        "enabled": False,
        "delay_steps": 1,
    }
    with pytest.raises(ValueError, match="disabled action delay"):
        _select_recipe(
            invalid,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    valid = _document()
    valid["recipes"]["ood"]["action_delay"]["j8_agentview_wrist"]["action_delay"] = {
        "enabled": True,
        "delay_steps": {"choices": [1, 2]},
    }
    _select_recipe(
        valid,
        partition="ood",
        factor="action_delay",
        recipe_name="j8_agentview_wrist",
    )


def test_recipe_file_and_factor_rules_remain_strict() -> None:
    missing_partition = _document()
    del missing_partition["recipes"]["stress"]
    with pytest.raises(ValueError, match="missing fields"):
        _select_recipe(
            missing_partition,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    unknown_root = _document()
    unknown_root["base"] = {}
    with pytest.raises(ValueError, match="unknown fields"):
        _select_recipe(
            unknown_root,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )

    with pytest.raises(ValueError, match="requires a known factor"):
        _select_recipe(
            _document(),
            partition="ood",
            factor=None,
            recipe_name="e7_agentview",
        )
    with pytest.raises(ValueError, match="must be None"):
        _select_recipe(
            _document(),
            partition="test_id",
            factor="camera",
            recipe_name="e7_agentview",
        )

    missing_factor = _document()
    del missing_factor["recipes"]["ood"]["camera"]
    with pytest.raises(ValueError, match=r"does not define ood\.camera"):
        _select_recipe(
            missing_factor,
            partition="ood",
            factor="camera",
            recipe_name="e7_agentview",
        )

    unknown_factor = _document()
    unknown_factor["recipes"]["ood"]["unregistered"] = _named_recipes("unknown")
    with pytest.raises(ValueError, match="unknown factors"):
        _select_recipe(
            unknown_factor,
            partition="ood",
            factor="camera",
            recipe_name="e7_agentview",
        )


def test_recipe_name_is_only_a_selector_and_is_not_injected_or_inferred() -> None:
    document = _document()
    document["recipes"]["train"]["e7_agentview"]["action_mode"] = "J8"
    document["recipes"]["train"]["e7_agentview"]["observation_profile"] = "agentview_wrist"
    selected = _select_recipe(
        document,
        partition="train",
        factor=None,
        recipe_name="e7_agentview",
    )
    assert selected["action_mode"] == "J8"
    assert selected["observation_profile"] == "agentview_wrist"
    assert "recipe_name" not in selected


def test_same_seed_named_pair_samples_identical_physical_fields() -> None:
    document = _document()
    e7_recipe = _materializable_recipe(action_mode="E7")
    j8_recipe = copy.deepcopy(e7_recipe)
    j8_recipe["action_mode"] = "J8"
    document["recipes"]["test_id"]["e7_agentview"] = e7_recipe
    document["recipes"]["test_id"]["j8_agentview"] = j8_recipe

    task = load_task("grasp")
    seed = 1024
    e7 = _materialize_recipe(
        task,
        _select_recipe(
            document,
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        ),
        np.random.Generator(np.random.PCG64(seed)),
    )
    j8 = _materialize_recipe(
        task,
        _select_recipe(
            document,
            partition="test_id",
            factor=None,
            recipe_name="j8_agentview",
        ),
        np.random.Generator(np.random.PCG64(seed)),
    )

    e7_concrete = scenario_to_dict(e7)
    j8_concrete = scenario_to_dict(j8)
    assert e7_concrete.pop("action_mode") == "E7"
    assert j8_concrete.pop("action_mode") == "J8"
    assert e7_concrete == j8_concrete
    assert "recipe_name" not in scenario_to_dict(e7)
    assert not hasattr(e7, "recipe_name")


def test_public_generator_requires_keyword_only_recipe_name() -> None:
    parameter = inspect.signature(generate_scenario).parameters["recipe_name"]
    assert parameter.kind is inspect.Parameter.KEYWORD_ONLY
    assert parameter.default is inspect.Parameter.empty


def test_single_rng_materialization_is_deterministic_and_supports_only_frozen_sampling() -> None:
    recipe_value = {
        "scalar": {"min": -1.0, "max": 2.0},
        "vector": {"min": [-2.0, 1.0], "max": [-1.0, 3.0]},
        "choice": {"choices": ["left", "right"]},
    }
    first = _sample_recipe_value(copy.deepcopy(recipe_value), np.random.default_rng(91))
    second = _sample_recipe_value(copy.deepcopy(recipe_value), np.random.default_rng(91))
    assert first == second
    assert isinstance(first, dict)
    assert -1.0 <= first["scalar"] <= 2.0
    assert first["choice"] in {"left", "right"}

    with pytest.raises(ValueError, match="exactly min/max or choices"):
        _sample_recipe_value(
            {"min": 0.0, "max": 1.0, "distribution": "uniform"},
            np.random.default_rng(0),
        )
    with pytest.raises(ValueError, match="at least two"):
        _sample_recipe_value({"choices": [1]}, np.random.default_rng(0))


def test_grasp_recipe_file_is_a_complete_self_contained_named_matrix() -> None:
    document = load_yaml_strict(_GRASP_RECIPE_PATH)
    assert set(document) == {"schema_version", "recipes"}
    assert document["schema_version"] == 1
    recipes = document["recipes"]
    assert isinstance(recipes, dict)
    assert set(recipes) == {"train", "validation", "test_id", "ood", "stress"}
    ood = recipes["ood"]
    assert isinstance(ood, dict)
    assert set(ood) == set(_GRASP_OOD_FACTORS)

    named_sets = [recipes[name] for name in ("train", "validation", "test_id", "stress")]
    named_sets.extend(ood[factor] for factor in _GRASP_OOD_FACTORS)
    for named in named_sets:
        assert isinstance(named, dict)
        assert tuple(named) == _RECIPE_NAMES
        for recipe in named.values():
            assert isinstance(recipe, dict)
            assert set(recipe) == _COMPLETE_RECIPE_FIELDS
            for entry in recipe["motion"]:
                motions = entry["choices"] if "choices" in entry else [entry]
                for motion in motions:
                    translation = motion["translation"]
                    if translation["type"] == "harmonic":
                        drift = translation["drift_velocity_world_m_s"]
                        assert drift[0::2] == [0, 0]
                        supports = [{"min": 0.025, "max": 0.125}]
                        if named is ood["motion_parameters"]:
                            supports.extend(
                                [
                                    {"min": 0.015, "max": math.nextafter(0.025, -math.inf)},
                                    {"min": math.nextafter(0.125, math.inf), "max": 0.16},
                                ]
                            )
                        assert drift[1] in supports


@pytest.mark.parametrize(("partition", "factor", "seed"), _GRASP_RECIPE_CASES)
@pytest.mark.parametrize("recipe_name", _RECIPE_NAMES)
def test_every_grasp_named_recipe_materializes_through_all_declarative_gates(
    partition: Partition,
    factor: str | None,
    seed: int,
    recipe_name: str,
) -> None:
    scenario = _generate_grasp(partition, factor, recipe_name, seed=seed)
    expected_mode = "E7" if recipe_name.startswith("e7_") else "J8"
    expected_profile = "agentview_wrist" if recipe_name.endswith("_wrist") else "agentview"
    expected_views = (
        ("agentview", "wrist") if expected_profile == "agentview_wrist" else ("agentview",)
    )

    assert scenario.action_mode == expected_mode
    assert scenario.observation_profile == expected_profile
    assert tuple(view.view_name for view in scenario.cameras.views) == expected_views
    assert scenario.physics_timestep_s == 0.002
    assert scenario.control_frequency_hz == scenario.sensor_frequency_hz == 20
    assert scenario.cameras.image_height_px == scenario.cameras.image_width_px == 224
    assert scenario.robot_initial_state.joint_position_rad == (
        0.0,
        0.19634954084936207,
        0.0,
        -2.617993877991494,
        0.0,
        2.941592653589793,
        0.7853981633974483,
    )
    assert scenario.robot_initial_state.gripper_position_m == (0.020833, -0.020833)
    assert scenario.object_states[0].asset_id in {
        "obj.cuboid_grasp_v1",
        "obj.bottle_v1",
        "obj.rod_v1",
        "obj.asym_t_t1_v1",
    }
    _assert_motion_starts_at_object_pose(scenario)
    payload = scenario_to_dict(scenario)
    assert scenario_from_dict(payload, family="grasp") == scenario
    assert "recipe_name" not in repr(payload)
    assert "yaw_rad" not in repr(payload)
    assert "compiler" not in repr(payload)


@pytest.mark.parametrize(("partition", "factor", "seed"), _GRASP_RECIPE_CASES)
def test_grasp_named_tracks_pair_only_action_view_and_camera_identity(
    partition: Partition, factor: str | None, seed: int
) -> None:
    scenarios = tuple(
        _generate_grasp(partition, factor, recipe_name, seed=seed) for recipe_name in _RECIPE_NAMES
    )
    physical_payload = _without_profile_identity(scenarios[0])
    assert all(
        _without_profile_identity(scenario) == physical_payload for scenario in scenarios[1:]
    )

    e7_agentview, e7_wrist, j8_agentview, j8_wrist = scenarios
    assert e7_agentview.action_mode == e7_wrist.action_mode == "E7"
    assert j8_agentview.action_mode == j8_wrist.action_mode == "J8"
    assert e7_agentview.cameras == j8_agentview.cameras
    assert e7_wrist.cameras == j8_wrist.cameras


@pytest.mark.parametrize(("partition", "factor", "seed"), _GRASP_RECIPE_CASES)
def test_grasp_materialization_is_deterministic_for_every_recipe_identity(
    partition: Partition, factor: str | None, seed: int
) -> None:
    first = _generate_grasp(partition, factor, "e7_agentview", seed=seed)
    second = _generate_grasp(partition, factor, "e7_agentview", seed=seed)
    assert first == second


@pytest.mark.parametrize("partition", ["train", "validation", "test_id"])
@pytest.mark.parametrize("seed", [0, 2, 5, 1])
def test_grasp_id_recipes_use_db0_harmonic_drift_and_yaw_spin(
    partition: Partition,
    seed: int,
) -> None:
    scenario = _generate_grasp(partition, None, "e7_agentview", seed=seed)
    translation = scenario.motion[0].translation
    rotation = scenario.motion[0].rotation
    assert isinstance(translation, HarmonicTranslation)
    assert isinstance(rotation, ConstantAngularVelocityRotation)
    assert -0.08 <= translation.center_world_m[0] <= 0.08
    assert -0.26 <= translation.center_world_m[1] <= -0.19
    assert translation.center_world_m[2] == 0.8 + 0.022
    assert translation.drift_velocity_world_m_s[0::2] == (0.0, 0.0)
    assert 0.025 <= translation.drift_velocity_world_m_s[1] <= 0.125
    assert 0.015 <= translation.amplitude_m[0] <= 0.035
    assert translation.amplitude_m[1:] == (0.0, 0.0)
    assert 0.30 <= translation.frequency_hz[0] <= 0.70
    assert translation.frequency_hz[1:] == (0.0, 0.0)
    assert -math.pi <= translation.phase_rad[0] <= math.pi
    assert translation.phase_rad[1:] == (0.0, 0.0)
    assert rotation.axis_world == (0.0, 0.0, 1.0)
    assert -1.2 <= rotation.angular_speed_rad_s <= 1.2
    _assert_motion_starts_at_object_pose(scenario)


@pytest.mark.parametrize(
    ("asset_id", "seed"),
    [("obj.asym_t_t1_v1", 0), ("obj.rod_v1", 12), ("obj.bottle_v1", 14)],
)
def test_grasp_object_ood_preserves_selected_asset_physics_and_paired_tracks(
    asset_id: str, seed: int
) -> None:
    catalog = _load_asset_catalog(_GRASP_CATALOG_PATH)
    facts = _compiled_object_asset_facts(catalog[asset_id])
    scenarios = tuple(
        _generate_grasp("ood", "object", recipe_name, seed=seed) for recipe_name in _RECIPE_NAMES
    )
    for scenario in scenarios:
        assert scenario.object_states[0].asset_id == asset_id
        assert scenario.physics.bodies[0].mass_kg == pytest.approx(facts.mass_kg, abs=1e-12)
        np.testing.assert_allclose(
            scenario.physics.bodies[0].diagonal_inertia_kg_m2,
            facts.diagonal_inertia_kg_m2,
            rtol=0.0,
            atol=1e-15,
        )
        assert scenario.object_states[0].position_world_m[2] + facts.bottom_offset_m == (
            pytest.approx(0.8, rel=0.0, abs=1e-12)
        )
        assert _without_profile_identity(scenario) == _without_profile_identity(scenarios[0])

    document = load_yaml_strict(_GRASP_RECIPE_PATH)
    baseline: Any = copy.deepcopy(
        _select_recipe(document, partition="test_id", factor=None, recipe_name="e7_agentview")
    )
    changed: Any = copy.deepcopy(
        _select_recipe(document, partition="ood", factor="object", recipe_name="e7_agentview")
    )
    del baseline["object_states"], changed["object_states"]
    del baseline["physics"]["bodies"], changed["physics"]["bodies"]
    assert changed == baseline


def test_grasp_t_candidates_explicitly_place_the_new_com_frame_on_the_support() -> None:
    document: Any = load_yaml_strict(_GRASP_RECIPE_PATH)
    records = 0
    for partition in (document["recipes"]["ood"]["object"], document["recipes"]["stress"]):
        for recipe in partition.values():
            for candidate in recipe["object_states"][0]["choices"]:
                if candidate["asset_id"] == "obj.asym_t_t1_v1":
                    position = candidate["position_world_m"]
                    if isinstance(position, dict):
                        assert position["harmonic_center_world_m"][2] == 0.8 + 0.018
                    else:
                        assert position[2] == 0.818
                    assert candidate["quaternion_world_xyzw"] == {
                        "yaw_rad": {"min": -1.1, "max": 1.1}
                    }
                    records += 1
    assert records == 8


@pytest.mark.parametrize(
    ("partition", "factor", "seed", "asset_id"),
    [
        ("ood", "object", 1, "obj.rod_v1"),
        ("ood", "object", 3, "obj.asym_t_t1_v1"),
        ("stress", None, 0, "obj.asym_t_t1_v1"),
    ],
)
def test_grasp_incorrect_asset_physics_rejects_identically_across_tracks(
    partition: Partition, factor: str | None, seed: int, asset_id: str
) -> None:
    task = load_task("grasp")
    catalog = _load_asset_catalog(_GRASP_CATALOG_PATH)
    facts = _compiled_object_asset_facts(catalog[asset_id])
    reasons = []
    for recipe_name in _RECIPE_NAMES:
        recipe = _select_recipe(
            load_yaml_strict(_GRASP_RECIPE_PATH),
            partition=partition,
            factor=factor,
            recipe_name=recipe_name,
        )
        scenario = _materialize_recipe(task, recipe, np.random.default_rng(seed))
        assert scenario.object_states[0].asset_id == asset_id
        invalid = replace(
            scenario,
            physics=replace(
                scenario.physics,
                bodies=(replace(scenario.physics.bodies[0], mass_kg=0.5 * facts.mass_kg),),
            ),
        )
        with pytest.raises(ValueError, match="body physics does not match selected asset") as error:
            _validate_grasp_declarative_scenario(
                task, invalid, partition=partition, factor=factor, catalog=catalog
            )
        reasons.append(str(error.value))
    assert reasons == [
        f"Grasp proposal rejected: body physics does not match selected asset {asset_id}"
    ] * len(_RECIPE_NAMES)


def _grasp_single_axis_ood_pair(
    factor: str,
    field: str,
    axis: int,
    side: int,
    recipe_name: str,
    paths: tuple[tuple[str | int, ...], ...],
    bounds: tuple[tuple[float, float, float, float], ...],
) -> tuple[Any, Any]:
    document = load_yaml_strict(_GRASP_RECIPE_PATH)
    baseline: Any = copy.deepcopy(
        _select_recipe(document, partition="test_id", factor=None, recipe_name=recipe_name)
    )
    recipe: Any = copy.deepcopy(
        _select_recipe(document, partition="ood", factor=factor, recipe_name=recipe_name)
    )
    choices = recipe[field][0]["choices"]
    assert len(choices) == 2 * len(paths)
    # Inspect each branch directly: selecting it removes the additional RNG draw.
    # Raw recipe equality below verifies every unowned distribution remains ID.
    recipe[field] = [copy.deepcopy(choices[2 * axis + side])]
    original_leaf, changed_leaf = baseline[field][0], recipe[field][0]
    for key in paths[axis][:-1]:
        original_leaf, changed_leaf = original_leaf[key], changed_leaf[key]
    key = paths[axis][-1]
    ood_low, id_low, id_high, ood_high = bounds[axis]
    assert original_leaf[key] == {"min": id_low, "max": id_high}
    expected = (
        {"min": ood_low, "max": math.nextafter(id_low, -math.inf)}
        if side == 0
        else {"min": math.nextafter(id_high, math.inf), "max": ood_high}
    )
    assert changed_leaf[key] == expected
    saved = changed_leaf[key]
    changed_leaf[key] = original_leaf[key]
    assert recipe == baseline
    changed_leaf[key] = saved
    task = load_task("grasp")
    normal = _materialize_recipe(task, baseline, np.random.default_rng(17))
    shifted = _materialize_recipe(task, recipe, np.random.default_rng(17))
    _validate_grasp_declarative_scenario(
        task,
        shifted,
        partition="ood",
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
    )
    _assert_motion_starts_at_object_pose(shifted)
    return scenario_to_dict(normal), scenario_to_dict(shifted)


@pytest.mark.parametrize("axis", range(3))
@pytest.mark.parametrize("side", range(2))
@pytest.mark.parametrize("recipe_name", _RECIPE_NAMES)
def test_grasp_spatial_ood_changes_only_motion_center_and_linked_pose(
    axis: int, side: int, recipe_name: str
) -> None:
    baseline, changed = _grasp_single_axis_ood_pair(
        "spatial",
        "object_states",
        axis,
        side,
        recipe_name,
        (
            ("position_world_m", "harmonic_center_world_m", 0),
            ("position_world_m", "harmonic_center_world_m", 1),
            ("quaternion_world_xyzw", "yaw_rad"),
        ),
        ((-0.12, -0.08, 0.08, 0.12), (-0.30, -0.26, -0.19, -0.16), (-1.5, -1.1, 1.1, 1.5)),
    )
    if axis < 2:
        assert (
            changed["motion"][0]["translation"]["center_world_m"][axis]
            != baseline["motion"][0]["translation"]["center_world_m"][axis]
        )
        changed["motion"][0]["translation"]["center_world_m"][axis] = baseline["motion"][0][
            "translation"
        ]["center_world_m"][axis]
        changed["object_states"][0]["position_world_m"][axis] = baseline["object_states"][0][
            "position_world_m"
        ][axis]
    else:
        assert (
            changed["object_states"][0]["quaternion_world_xyzw"]
            != baseline["object_states"][0]["quaternion_world_xyzw"]
        )
        changed["object_states"][0]["quaternion_world_xyzw"] = baseline["object_states"][0][
            "quaternion_world_xyzw"
        ]
    assert changed == baseline


@pytest.mark.parametrize("axis", range(4))
@pytest.mark.parametrize("side", range(2))
@pytest.mark.parametrize("recipe_name", _RECIPE_NAMES)
def test_grasp_motion_parameters_ood_keeps_known_law_and_only_changes_its_values(
    axis: int, side: int, recipe_name: str
) -> None:
    paths = (
        ("translation", "drift_velocity_world_m_s", 1),
        ("translation", "amplitude_m", 0),
        ("translation", "frequency_hz", 0),
        ("rotation", "angular_speed_rad_s"),
    )
    baseline, changed = _grasp_single_axis_ood_pair(
        "motion_parameters",
        "motion",
        axis,
        side,
        recipe_name,
        paths,
        (
            (0.015, 0.025, 0.125, 0.16),
            (0.005, 0.015, 0.035, 0.055),
            (0.2, 0.3, 0.7, 1.0),
            (-1.8, -1.2, 1.2, 1.8),
        ),
    )
    motion = changed["motion"][0]
    assert motion["translation"]["type"] == "harmonic"
    assert motion["rotation"]["type"] == "constant_angular_velocity"
    target = changed["object_states"][0]
    translation = motion["translation"]
    amplitude, frequency, phase = (
        translation[key][0] for key in ("amplitude_m", "frequency_hz", "phase_rad")
    )
    assert target["position_world_m"][0] == pytest.approx(
        translation["center_world_m"][0] + amplitude * math.sin(phase), rel=0, abs=1e-15
    )
    assert target["linear_velocity_world_m_s"] == pytest.approx(
        [
            amplitude * 2 * math.pi * frequency * math.cos(phase),
            translation["drift_velocity_world_m_s"][1],
            0,
        ],
        rel=0,
        abs=1e-15,
    )
    assert target["angular_velocity_world_rad_s"] == [
        0,
        0,
        motion["rotation"]["angular_speed_rad_s"],
    ]
    original_leaf, changed_leaf = baseline["motion"][0], motion
    for key in paths[axis][:-1]:
        original_leaf, changed_leaf = original_leaf[key], changed_leaf[key]
    key = paths[axis][-1]
    assert changed_leaf[key] != original_leaf[key]
    changed_leaf[key] = original_leaf[key]
    linked = (
        ("linear_velocity_world_m_s",),
        ("position_world_m", "linear_velocity_world_m_s"),
        ("linear_velocity_world_m_s",),
        ("angular_velocity_world_rad_s",),
    )[axis]
    for field in linked:
        target[field] = baseline["object_states"][0][field]
    assert changed == baseline


def test_grasp_motion_law_ood_changes_only_rotation_and_linked_initial_twist() -> None:
    baseline = _scenario_payload("test_id", None)
    changed = _scenario_payload("ood", "motion_law")
    baseline_data: Any = baseline
    changed_data: Any = changed
    baseline_motion = baseline_data["motion"][0]
    changed_motion = changed_data["motion"][0]
    assert changed_motion["translation"] == baseline_motion["translation"]
    assert baseline_motion["rotation"]["type"] == "constant_angular_velocity"
    assert changed_motion["rotation"]["type"] == "harmonic"
    rotation = changed_motion["rotation"]
    expected_yaw_rate = (
        rotation["amplitude_rad"]
        * (2.0 * math.pi * rotation["frequency_hz"])
        * math.cos(rotation["phase_rad"])
    )
    np.testing.assert_allclose(
        changed_data["object_states"][0]["angular_velocity_world_rad_s"],
        (0.0, 0.0, expected_yaw_rate),
        rtol=0.0,
        atol=1e-15,
    )
    changed_data["object_states"][0]["angular_velocity_world_rad_s"] = baseline_data[
        "object_states"
    ][0]["angular_velocity_world_rad_s"]
    changed_motion["rotation"] = baseline_motion["rotation"]
    assert changed == baseline


@pytest.mark.parametrize(
    ("factor", "owned_field"),
    [
        ("physics", "physics"),
        ("appearance", "lighting"),
        ("camera", "cameras"),
        ("action_delay", "action_delay_steps"),
    ],
)
def test_grasp_remaining_single_factor_ood_changes_only_its_owned_record(
    factor: str, owned_field: str
) -> None:
    baseline = _scenario_payload("test_id", None)
    changed = _scenario_payload("ood", factor)
    assert changed[owned_field] != baseline[owned_field]
    changed[owned_field] = baseline[owned_field]
    assert changed == baseline


@pytest.mark.parametrize(
    ("translation_delta", "fov"),
    [
        ((-0.05, 0.0, 0.0), 40.0),
        ((0.05, 0.0, 0.0), 40.0),
        ((0.0, -0.05, 0.0), 40.0),
        ((0.0, 0.05, 0.0), 40.0),
        ((0.0, 0.0, -0.05), 40.0),
        ((0.0, 0.0, 0.05), 40.0),
        ((0.0, 0.0, 0.0), 35.0),
        ((0.0, 0.0, 0.0), 45.0),
    ],
)
def test_grasp_camera_ood_accepts_exactly_one_frozen_intervention(
    translation_delta: tuple[float, float, float], fov: float
) -> None:
    payload: Any = _scenario_payload("test_id", None)
    agentview = payload["cameras"]["views"][0]
    agentview["position_parent_m"] = [
        position + delta
        for position, delta in zip(agentview["position_parent_m"], translation_delta, strict=True)
    ]
    agentview["vertical_fov_deg"] = fov
    _validate_grasp_declarative_scenario(
        load_task("grasp"),
        scenario_from_dict(payload, family="grasp"),
        partition="ood",
        factor="camera",
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
    )


@pytest.mark.parametrize(
    ("translation_delta", "fov", "change_rotation"),
    [
        ((0.05, 0.0, 0.0), 35.0, False),
        ((0.05, 0.0, 0.0), 45.0, False),
        ((0.05, 0.0, 0.0), 60.0, False),
        ((0.05, 0.05, 0.0), 40.0, False),
        ((0.0, 0.0, 0.0), 40.0, False),
        ((0.0, 0.0, 0.0), 60.0, False),
        ((0.0, 0.0, 0.0), 35.0, True),
    ],
)
def test_grasp_camera_ood_rejects_multiple_or_unregistered_interventions(
    translation_delta: tuple[float, float, float], fov: float, change_rotation: bool
) -> None:
    payload: Any = _scenario_payload("test_id", None)
    agentview = payload["cameras"]["views"][0]
    agentview["position_parent_m"] = [
        position + delta
        for position, delta in zip(agentview["position_parent_m"], translation_delta, strict=True)
    ]
    agentview["vertical_fov_deg"] = fov
    if change_rotation:
        agentview["quaternion_parent_xyzw"] = [0.0, 0.0, 0.0, 1.0]
    with pytest.raises(ValueError, match="exactly one frozen agentview intervention"):
        _validate_grasp_declarative_scenario(
            load_task("grasp"),
            scenario_from_dict(payload, family="grasp"),
            partition="ood",
            factor="camera",
            catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        )


def test_grasp_id_rejects_fixed_rotation_as_a_substitute_for_db0_yaw_spin() -> None:
    payload: Any = _scenario_payload("test_id", None, seed=2)
    assert payload["motion"][0]["translation"]["type"] == "harmonic"
    assert payload["motion"][0]["rotation"]["type"] == "constant_angular_velocity"
    payload["motion"][0]["rotation"] = {"type": "fixed"}
    with pytest.raises(ValueError, match="ID motion laws and parameters"):
        _validate_grasp_declarative_scenario(
            load_task("grasp"),
            scenario_from_dict(payload, family="grasp"),
            partition="test_id",
            factor=None,
            catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        )


@pytest.mark.parametrize(
    ("partition", "factor", "seed"),
    [("test_id", None, 0), ("ood", "object", 12)],
)
def test_grasp_centered_assets_require_their_actual_bottom_on_support(
    partition: Partition, factor: str | None, seed: int
) -> None:
    payload: Any = _scenario_payload(partition, factor, seed=seed)
    assert payload["object_states"][0]["position_world_m"][2] > 0.8
    payload["object_states"][0]["position_world_m"][2] = 0.8
    with pytest.raises(ValueError, match="initial pose must lie on support"):
        _validate_grasp_declarative_scenario(
            load_task("grasp"),
            scenario_from_dict(payload, family="grasp"),
            partition=partition,
            factor=factor,
            catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        )


def test_grasp_declarative_validator_rejects_asset_physics_and_support_mismatches() -> None:
    task = load_task("grasp")
    catalog = _load_asset_catalog(_GRASP_CATALOG_PATH)
    baseline = _generate_grasp("test_id", None, "e7_agentview")

    unknown_asset = scenario_to_dict(baseline)
    unknown_asset_data: Any = unknown_asset
    unknown_asset_data["object_states"][0]["asset_id"] = "obj.unknown_v1"
    with pytest.raises(ValueError, match="resolve through the frozen catalog"):
        _validate_grasp_declarative_scenario(
            task,
            scenario_from_dict(unknown_asset, family="grasp"),
            partition="test_id",
            factor=None,
            catalog=catalog,
        )

    wrong_physics_reference = scenario_to_dict(baseline)
    wrong_physics_data: Any = wrong_physics_reference
    wrong_physics_data["physics"]["bodies"][0]["entity_id"] = "other"
    with pytest.raises(ValueError, match="unknown entity references"):
        _validate_grasp_declarative_scenario(
            task,
            scenario_from_dict(wrong_physics_reference, family="grasp"),
            partition="test_id",
            factor=None,
            catalog=catalog,
        )

    off_support = scenario_to_dict(baseline)
    off_support_data: Any = off_support
    off_support_data["object_states"][0]["position_world_m"][2] += 0.01
    with pytest.raises(ValueError, match="initial pose must lie on support"):
        _validate_grasp_declarative_scenario(
            task,
            scenario_from_dict(off_support, family="grasp"),
            partition="test_id",
            factor=None,
            catalog=catalog,
        )

    wrong_robot = scenario_to_dict(baseline)
    wrong_robot_data: Any = wrong_robot
    wrong_robot_data["robot_initial_state"]["joint_position_rad"][0] = 0.01
    with pytest.raises(ValueError, match="frozen Panda initial state"):
        _validate_grasp_declarative_scenario(
            task,
            scenario_from_dict(wrong_robot, family="grasp"),
            partition="test_id",
            factor=None,
            catalog=catalog,
        )


def test_grasp_complete_law_choices_remain_closed_and_strict() -> None:
    with pytest.raises(ValueError, match="at least two"):
        _materialize_grasp_laws(
            {"choices": [{"type": "fixed"}]},
            {"type": "fixed"},
        )
    with pytest.raises(ValueError, match="callback"):
        _materialize_grasp_laws(
            {
                "choices": [
                    {"type": "fixed"},
                    {"type": "fixed", "callback": "move"},
                ]
            },
            {"type": "fixed"},
            seed=0,
        )


@pytest.mark.parametrize(
    ("field", "invalid_law", "match"),
    [
        ("translation", {"type": "fixed", "callback": "invalid"}, "callback"),
        (
            "translation",
            {
                "type": "constant_velocity",
                "velocity_world_m_s": {"choices": [[0.0, 0.0, 0.0], [0.0, float("nan"), 0.0]]},
            },
            "finite number",
        ),
        (
            "translation",
            {
                "type": "harmonic",
                "drift_velocity_world_m_s": [0.0, 0.0, 0.0],
                "amplitude_m": [{"min": -0.1, "max": 0.1}, 0.0, 0.0],
                "frequency_hz": [1.0, 0.0, 0.0],
                "phase_rad": [0.0, 0.0, 0.0],
            },
            "non-negative",
        ),
        (
            "translation",
            {
                "type": "circular",
                "axis_world": [0.0, 0.0, 1.0],
                "radial_direction_world": [1.0, 0.0, 0.0],
                "radius_m": {"choices": [0.1, 0.0]},
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.0,
            },
            "positive",
        ),
        (
            "translation",
            {
                "type": "circular",
                "axis_world": {"choices": [[0.0, 0.0, 1.0], [0.0, 0.0, 2.0]]},
                "radial_direction_world": [1.0, 0.0, 0.0],
                "radius_m": 0.1,
                "angular_speed_rad_s": 1.0,
                "phase_rad": 0.0,
            },
            "unit length",
        ),
        ("rotation", {"type": "fixed", "callback": "invalid"}, "callback"),
        (
            "rotation",
            {
                "type": "constant_angular_velocity",
                "axis_world": [0.0, 0.0, 1.0],
                "angular_speed_rad_s": {"choices": [0.4, float("inf")]},
            },
            "finite number",
        ),
        (
            "rotation",
            {
                "type": "harmonic",
                "axis_world": [0.0, 0.0, 1.0],
                "amplitude_rad": 0.3,
                "frequency_hz": {"min": 2.0, "max": 1.0},
                "phase_rad": 0.0,
            },
            "strictly less",
        ),
        (
            "rotation",
            {
                "type": "harmonic",
                "axis_world": [0.0, 0.0, 1.0],
                "amplitude_rad": 0.3,
                "frequency_hz": 1.0,
                "phase_rad": {"ref": "phase"},
            },
            "exactly min/max or choices",
        ),
    ],
)
def test_grasp_all_law_choices_are_validated_before_any_rng_draw(
    field: str, invalid_law: dict[str, object], match: str
) -> None:
    recipe: Any = _materializable_recipe(action_mode="E7")
    recipe["motion"][0][field] = {"choices": [{"type": "fixed"}, invalid_law]}
    for seed in range(4):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match=match):
            _materialize_recipe(load_task("grasp"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize("full_record_choice", [False, True])
def test_grasp_unknown_asset_choices_are_rejected_before_any_rng_draw(
    full_record_choice: bool,
) -> None:
    recipe: Any = _materializable_recipe(action_mode="E7")
    target = recipe["object_states"][0]
    if full_record_choice:
        invalid_target = copy.deepcopy(target)
        invalid_target["asset_id"] = "obj.unknown_v1"
        recipe["object_states"] = [{"choices": [target, invalid_target]}]
    else:
        target["asset_id"] = {"choices": ["obj.cuboid_grasp_v1", "obj.unknown_v1"]}
    for seed in range(4):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match="unknown grasp asset_id in recipe"):
            _materialize_recipe(load_task("grasp"), recipe, rng)
        assert rng.bit_generator.state == before


def test_grasp_full_motion_choice_branches_are_closed_before_any_rng_draw() -> None:
    recipe: Any = _materializable_recipe(action_mode="E7")
    valid_motion = recipe["motion"][0]
    invalid_motion = copy.deepcopy(valid_motion)
    invalid_motion["callback"] = "invalid"
    recipe["motion"] = [{"choices": [valid_motion, invalid_motion]}]
    for seed in range(4):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match="callback"):
            _materialize_recipe(load_task("grasp"), recipe, rng)
        assert rng.bit_generator.state == before


def test_grasp_full_body_physics_choices_validate_all_mass_support_before_sampling() -> None:
    recipe: Any = _materializable_recipe(action_mode="E7")
    valid_body = {
        "entity_id": "target",
        "mass_kg": 0.1,
        "diagonal_inertia_kg_m2": [0.001, 0.001, 0.001],
    }
    invalid_body = copy.deepcopy(valid_body)
    invalid_body["mass_kg"] = {"choices": [0.1, -0.1]}
    recipe["physics"]["bodies"] = [{"choices": [valid_body, invalid_body]}]
    for seed in range(4):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match="positive throughout its support"):
            _materialize_recipe(load_task("grasp"), recipe, rng)
        assert rng.bit_generator.state == before


_PLACEMENT_FACTORS = (
    "spatial",
    "geometry",
    "motion_parameters",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_PLACEMENT_CELLS = (
    ("train", None),
    ("validation", None),
    ("test_id", None),
    ("stress", None),
    *(("ood", factor) for factor in _PLACEMENT_FACTORS),
)


@lru_cache(maxsize=2)
def _placement_document(task_id: str) -> Any:
    return load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml")


def _placement_recipe(
    task_id: str,
    partition: str = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            _placement_document(task_id),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _placement_materialized(
    task_id: str,
    partition: str = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
    seed: int = 17,
) -> ScenarioSpec:
    return _materialize_recipe(
        load_task(task_id),
        _placement_recipe(task_id, partition, factor, name),
        np.random.Generator(np.random.PCG64(seed)),
    )


def _check_placement(
    task_id: str,
    scenario: ScenarioSpec,
    partition: str,
    factor: str | None,
    name: str = "e7_agentview",
) -> None:
    _validate_placement_declarative_scenario(
        load_task(task_id),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        id_recipe=_placement_recipe(task_id, name=name),
    )


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize(("partition", "factor"), _PLACEMENT_CELLS)
def test_t2_complete_recipes_materialize_deterministically_and_pair_physical_inputs(
    task_id: str,
    partition: str,
    factor: str | None,
) -> None:
    physical = []
    for name in _RECIPE_NAMES:
        recipe = _placement_recipe(task_id, partition, factor, name)
        leaves = recipe["choices"] if set(recipe) == {"choices"} else [recipe]
        assert len(leaves) == (4 if partition == "stress" else 1)
        selected = _placement_materialized(task_id, partition, factor, name)
        assert selected == _placement_materialized(task_id, partition, factor, name)
        scenarios = []
        leaf_physical = []
        for leaf in leaves:
            assert set(leaf) == _COMPLETE_RECIPE_FIELDS
            assert leaf["action_mode"] == ("E7" if name.startswith("e7_") else "J8")
            assert leaf["observation_profile"] == name.split("_", 1)[1]
            rng = np.random.Generator(np.random.PCG64(17))
            before = copy.deepcopy(rng.bit_generator.state)
            scenario = _materialize_recipe(load_task(task_id), leaf, rng)
            assert scenario == _materialize_recipe(
                load_task(task_id), leaf, np.random.Generator(np.random.PCG64(17))
            )
            if partition == "stress":
                assert rng.bit_generator.state == before
            _check_placement(task_id, scenario, partition, factor, name)
            value = scenario_to_dict(scenario)
            assert scenario_from_dict(value, family="moving_placement") == scenario
            assert "recipe_name" not in value
            state = scenario.fixture_states[0]
            reference = _motion_state_at_time(
                scenario.motion[0],
                initial_position_world_m=state.position_world_m,
                initial_quaternion_world_xyzw=state.quaternion_world_xyzw,
                simulator_time_s=0.0,
            )
            np.testing.assert_array_equal(reference.position_world_m, state.position_world_m)
            for key in ("action_mode", "observation_profile", "cameras"):
                del value[key]
            leaf_physical.append(value)
            scenarios.append(scenario)
        assert selected in scenarios
        physical.append(leaf_physical)
    assert all(value == physical[0] for value in physical)


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize("name", _RECIPE_NAMES)
def test_t2_single_factor_changes_only_its_concrete_block_and_not_rng_downstream_motion(
    task_id: str,
    name: str,
) -> None:
    owned = {
        "spatial": "fixture_states",
        "geometry": "geometry",
        "motion_parameters": "motion",
        "physics": "physics",
        "appearance": "lighting",
        "camera": "cameras",
        "action_delay": "action_delay_steps",
    }
    for seed in (0, 17, 29):
        identity = scenario_to_dict(_placement_materialized(task_id, name=name, seed=seed))
        for factor, block in owned.items():
            actual = scenario_to_dict(_placement_materialized(task_id, "ood", factor, name, seed))
            assert {key for key in identity if actual[key] != identity[key]} == {block}


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_key_order_does_not_change_draw_order(task_id: str) -> None:
    def reversed_keys(value: Any) -> Any:
        if isinstance(value, dict):
            return {key: reversed_keys(item) for key, item in reversed(tuple(value.items()))}
        if isinstance(value, list):
            return [reversed_keys(item) for item in value]
        return value

    recipe = _placement_recipe(task_id, "stress")
    rng, reordered_rng = (np.random.Generator(np.random.PCG64(12)) for _ in range(2))
    first = _materialize_recipe(load_task(task_id), recipe, rng)
    second = _materialize_recipe(load_task(task_id), reversed_keys(recipe), reordered_rng)
    assert first == second
    assert rng.bit_generator.state == reordered_rng.bit_generator.state


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize(
    "record_path",
    [
        ("object_states", 0),
        ("fixture_states", 0),
        ("motion", 0),
        ("physics", "bodies", 0),
        ("physics", "contacts", 0),
        ("cameras", "views", 0),
        ("lighting", "lights", 0),
    ],
)
def test_t2_rejects_unknown_fields_in_every_unselected_full_record_before_sampling(
    task_id: str,
    record_path: tuple[str | int, ...],
) -> None:
    recipe = _placement_recipe(task_id)
    parent = recipe
    for key in record_path[:-1]:
        parent = parent[key]
    valid = parent[record_path[-1]]
    invalid = {**copy.deepcopy(valid), "callback": "forbidden"}
    parent[record_path[-1]] = {"choices": [valid, invalid]}
    for seed in (0, 1):
        rng = np.random.Generator(np.random.PCG64(seed))
        original = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError, match="callback"):
            _materialize_recipe(load_task(task_id), recipe, rng)
        assert rng.bit_generator.state == original


@pytest.mark.parametrize(
    "mutation", ["asset", "mass", "contact_reference", "missing_motion", "clock"]
)
def test_t2_raw_invalid_alternatives_and_references_are_not_seed_dependent(mutation: str) -> None:
    recipe = _placement_recipe("t2_se3")
    if mutation == "asset":
        valid = recipe["object_states"][0]
        recipe["object_states"][0] = {"choices": [valid, {**valid, "asset_id": "unknown"}]}
    elif mutation == "mass":
        recipe["physics"]["bodies"][0]["mass_kg"] = {"choices": [0.1, -0.1]}
    elif mutation == "contact_reference":
        recipe["physics"]["contacts"][1]["entity_id"] = "payload"
    elif mutation == "missing_motion":
        del recipe["motion"][0]["rotation"]
    else:
        recipe["control_frequency_hz"] = {"choices": [20, 10]}
    for seed in (0, 1):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t2_se3"), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize(
    ("factor", "field"),
    [
        ("spatial", "position"),
        ("geometry", "clearance"),
        ("physics", "mass"),
        ("physics", "inertia"),
        ("physics", "friction"),
        ("physics", "solref"),
        ("physics", "solimp"),
        ("physics", "gravity"),
    ],
)
def test_t2_recipe_support_does_not_become_a_global_ood_physical_bound(
    task_id: str,
    factor: str,
    field: str,
) -> None:
    value: Any = scenario_to_dict(_placement_materialized(task_id))
    if field == "position":
        value["fixture_states"][0]["position_world_m"][1] = -0.28
    elif field == "clearance":
        value["geometry"]["goal_planar_clearance_m"] = 0.014
    elif field == "mass":
        value["physics"]["bodies"][0]["mass_kg"] *= 1.12
    elif field == "inertia":
        value["physics"]["bodies"][0]["diagonal_inertia_kg_m2"][0] *= 1.02
    elif field == "friction":
        value["physics"]["contacts"][0]["friction_slide_spin_roll"][1] *= 1.2
    elif field == "solref":
        value["physics"]["contacts"][0]["solref"][0] = 0.018
    elif field == "solimp":
        value["physics"]["contacts"][0]["solimp"][0] = 0.88
    else:
        value["physics"]["gravity_world_m_s2"][2] = -9.6
    scenario = scenario_from_dict(value, family="moving_placement")
    _check_placement(task_id, scenario, "ood", factor)
    with pytest.raises(ValueError):
        _check_placement(task_id, scenario, "ood", "appearance")


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize("forward", [0.029999, 0.03, 0.06, 0.060001])
def test_t2_frozen_id_speed_boundaries_remain_exact(task_id: str, forward: float) -> None:
    value: Any = scenario_to_dict(_placement_materialized(task_id))
    value["motion"][0]["translation"]["velocity_world_m_s"][1] = forward
    scenario = scenario_from_dict(value, family="moving_placement")
    if 0.03 <= forward <= 0.06:
        _check_placement(task_id, scenario, "test_id", None)
    else:
        with pytest.raises(ValueError, match="frozen ID motion"):
            _check_placement(task_id, scenario, "test_id", None)


def test_t2_se3_nonzero_initial_twist_is_not_a_new_global_rejection_rule() -> None:
    recipe = _placement_recipe("t2_se3")
    recipe["object_states"][0]["linear_velocity_world_m_s"] = [0.001, -0.002, 0.003]
    recipe["object_states"][0]["angular_velocity_world_rad_s"] = [0.004, 0.005, -0.006]
    scenario = _materialize_recipe(load_task("t2_se3"), recipe, np.random.default_rng(2))
    _check_placement("t2_se3", scenario, "ood", "motion_parameters")
    assert scenario.object_states[0].linear_velocity_world_m_s == (0.001, -0.002, 0.003)
    assert scenario_from_dict(scenario_to_dict(scenario), family="moving_placement") == scenario


def test_t2_rejects_a_label_only_ood_and_inapplicable_factor() -> None:
    scenario = _placement_materialized("t2_trans")
    with pytest.raises(ValueError, match="leave test-ID support"):
        _check_placement("t2_trans", scenario, "ood", "geometry")
    with pytest.raises(ValueError, match="inapplicable"):
        _check_placement("t2_trans", scenario, "ood", "object")


_ROTATING_FACTORS = (
    "spatial",
    "geometry",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_ROTATING_CELLS = (
    ("train", None),
    ("validation", None),
    ("test_id", None),
    ("stress", None),
    *(("ood", factor) for factor in _ROTATING_FACTORS),
)


@lru_cache(maxsize=2)
def _rotating_document(task_id: str) -> Any:
    return load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml")


def _rotating_recipe(
    task_id: str,
    partition: str = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            _rotating_document(task_id),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _rotating_materialized(
    task_id: str,
    partition: str = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
    seed: int = 17,
) -> ScenarioSpec:
    return _materialize_recipe(
        load_task(task_id),
        _rotating_recipe(task_id, partition, factor, name),
        np.random.Generator(np.random.PCG64(seed)),
    )


def _check_rotating(
    task_id: str,
    scenario: ScenarioSpec,
    partition: str,
    factor: str | None,
    name: str = "e7_agentview",
) -> None:
    _validate_rotating_declarative_scenario(
        load_task(task_id),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        id_recipe=_rotating_recipe(task_id, name=name),
    )


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize(("partition", "factor"), _ROTATING_CELLS)
def test_t3_complete_recipes_materialize_deterministically_and_pair_physical_inputs(
    task_id: str,
    partition: str,
    factor: str | None,
) -> None:
    physical = []
    for name in _RECIPE_NAMES:
        recipe = _rotating_recipe(task_id, partition, factor, name)
        alternatives = recipe["choices"] if set(recipe) == {"choices"} else [recipe]
        assert all(set(alternative) == _COMPLETE_RECIPE_FIELDS for alternative in alternatives)
        scenario = _rotating_materialized(task_id, partition, factor, name)
        assert scenario == _rotating_materialized(task_id, partition, factor, name)
        _check_rotating(task_id, scenario, partition, factor, name)
        value = scenario_to_dict(scenario)
        assert scenario_from_dict(value, family="rotating_interaction") == scenario
        assert "recipe_name" not in value
        phase = _motion_state_at_time(
            scenario.motion[0],
            initial_position_world_m=scenario.fixture_states[0].position_world_m,
            initial_quaternion_world_xyzw=scenario.fixture_states[0].quaternion_world_xyzw,
            simulator_time_s=0.0,
        )
        np.testing.assert_allclose(
            phase.quaternion_world_xyzw,
            scenario.fixture_states[0].quaternion_world_xyzw,
            rtol=0.0,
            atol=1e-12,
        )
        for key in ("action_mode", "observation_profile", "cameras"):
            del value[key]
        physical.append(value)
    assert all(value == physical[0] for value in physical)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize("name", _RECIPE_NAMES)
def test_t3_single_factor_changes_only_its_owned_recipe_block(
    task_id: str,
    name: str,
) -> None:
    owned = {
        "spatial": {"fixture_states"},
        "geometry": {"geometry"},
        "physics": {"physics"},
        "appearance": {"lighting"},
        "camera": {"cameras"},
        "action_delay": {"action_delay"},
    }
    identity = _rotating_recipe(task_id, name=name)
    for factor, blocks in owned.items():
        actual = _rotating_recipe(task_id, "ood", factor, name)
        assert {key for key in identity if actual[key] != identity[key]} == blocks
        for seed in (0, 17, 29):
            # An excluded-interval draw consumes a branch draw before uniform;
            # later draws may differ while their declared ID support stays fixed.
            scenario = _rotating_materialized(task_id, "ood", factor, name, seed)
            _check_rotating(task_id, scenario, "ood", factor, name)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_mapping_key_order_never_changes_the_single_rng_draw_order(task_id: str) -> None:
    recipe = _rotating_recipe(task_id, "stress")
    first_rng, second_rng = (np.random.Generator(np.random.PCG64(12)) for _ in range(2))
    first = _materialize_recipe(load_task(task_id), recipe, first_rng)
    second = _materialize_recipe(load_task(task_id), _reversed_mapping_keys(recipe), second_rng)
    assert first == second
    assert first_rng.bit_generator.state == second_rng.bit_generator.state


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize(
    "mutation",
    [
        "phase_branch",
        "phase_interval",
        "zero_speed_branch",
        "asset",
        "mass",
        "unknown_motion",
        "clock",
    ],
)
def test_t3_invalid_unselected_branches_and_references_fail_before_rng(
    task_id: str,
    mutation: str,
) -> None:
    recipe = _rotating_recipe(task_id)
    if mutation == "phase_branch":
        recipe["fixture_states"][0]["quaternion_world_xyzw"] = {
            "phase_x_rad": {"choices": [0.0, {"callback": "forbidden"}]}
        }
    elif mutation == "phase_interval":
        recipe["fixture_states"][0]["quaternion_world_xyzw"] = {
            "phase_x_rad": {"uniform_intervals": [[-0.30, -0.25], [0.45, 0.35]]}
        }
    elif mutation == "zero_speed_branch":
        recipe["motion"][0]["rotation"]["angular_speed_rad_s"] = {
            "choices": [-math.radians(5.0), 0.0]
        }
    elif mutation == "asset":
        recipe["object_states"][0]["asset_id"] = {"choices": ["obj.wand_loop_v1", "obj.unknown"]}
    elif mutation == "mass":
        recipe["physics"]["bodies"][0]["mass_kg"] = {"choices": [0.01, -0.01]}
    elif mutation == "unknown_motion":
        recipe["motion"][0]["callback"] = "forbidden"
    else:
        recipe["control_frequency_hz"] = {"choices": [20, 10]}
    for seed in (0, 1):
        rng = np.random.Generator(np.random.PCG64(seed))
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task(task_id), recipe, rng)
        assert rng.bit_generator.state == before


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize(
    "phase",
    [
        float(np.nextafter(-0.25, -np.inf)),
        -0.25,
        float(np.nextafter(-0.25, np.inf)),
        float(np.nextafter(0.35, -np.inf)),
        0.35,
        float(np.nextafter(0.35, np.inf)),
    ],
)
def test_t3_frozen_id_phase_boundaries_remain_exact(task_id: str, phase: float) -> None:
    value: Any = scenario_to_dict(_rotating_materialized(task_id))
    quaternion = [math.sin(phase / 2.0), 0.0, 0.0, math.cos(phase / 2.0)]
    value["fixture_states"][0]["quaternion_world_xyzw"] = quaternion
    scenario = scenario_from_dict(value, family="rotating_interaction")
    if -0.25 <= phase <= 0.35:
        _check_rotating(task_id, scenario, "test_id", None)
    else:
        with pytest.raises(ValueError, match="frozen ID phase"):
            _check_rotating(task_id, scenario, "test_id", None)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_spatial_uses_source_length_weighted_excluded_phase_intervals(task_id: str) -> None:
    outer_low = -0.35 if task_id == "t3_phase" else -0.30
    intervals = np.asarray(
        [
            [outer_low, np.nextafter(-0.25, -np.inf)],
            [np.nextafter(0.35, np.inf), 0.45],
        ],
        dtype=np.float64,
    )
    lengths = intervals[:, 1] - intervals[:, 0]
    for name in _RECIPE_NAMES:
        recipe = _rotating_recipe(task_id, "ood", "spatial", name)
        phase_recipe = recipe["fixture_states"][0]["quaternion_world_xyzw"]["phase_x_rad"]
        assert phase_recipe == {"uniform_intervals": intervals.tolist()}
        source_rng, recipe_rng = (np.random.Generator(np.random.PCG64(17)) for _ in range(2))
        for _ in range(32):
            # Fixed DB0 dataset_manifest.py:151-156 selects by interval length.
            index = int(source_rng.choice(len(intervals), p=lengths / lengths.sum()))
            expected = float(source_rng.uniform(*intervals[index]))
            assert _sample_recipe_value(phase_recipe, recipe_rng) == expected
        assert recipe_rng.bit_generator.state == source_rng.bit_generator.state


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize("speed_deg_s", [-2.5, -5.0, -7.5])
def test_t3_frozen_id_speed_grid_remains_exact(task_id: str, speed_deg_s: float) -> None:
    scenario = _rotating_materialized(task_id)
    scenario = replace(
        scenario,
        motion=(
            replace(
                scenario.motion[0],
                rotation=ConstantAngularVelocityRotation(
                    (1.0, 0.0, 0.0), math.radians(speed_deg_s)
                ),
            ),
        ),
    )
    _check_rotating(task_id, scenario, "test_id", None)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_owned_geometry_and_native_physics_are_not_bounded_by_packaged_choices(
    task_id: str,
) -> None:
    baseline = _rotating_materialized(task_id)
    geometry = replace(baseline.geometry, wire_radius_m=0.003)
    geometry_ood = replace(baseline, geometry=geometry)
    _check_rotating(task_id, geometry_ood, "ood", "geometry")
    with pytest.raises(ValueError):
        _check_rotating(task_id, geometry_ood, "ood", "appearance")

    bodies = list(baseline.physics.bodies)
    contacts = list(baseline.physics.contacts)
    bodies[0] = replace(
        bodies[0],
        mass_kg=bodies[0].mass_kg * 1.08,
        diagonal_inertia_kg_m2=(
            bodies[0].diagonal_inertia_kg_m2[0] * 1.02,
            *bodies[0].diagonal_inertia_kg_m2[1:],
        ),
    )
    contacts[0] = replace(
        contacts[0],
        friction_slide_spin_roll=(
            contacts[0].friction_slide_spin_roll[0],
            contacts[0].friction_slide_spin_roll[1] * 1.1,
            contacts[0].friction_slide_spin_roll[2],
        ),
        solref=(0.018, contacts[0].solref[1]),
        solimp=(0.88, *contacts[0].solimp[1:]),
    )
    physics_ood = replace(
        baseline,
        physics=replace(
            baseline.physics,
            gravity_world_m_s2=(0.0, 0.0, -9.6),
            bodies=tuple(bodies),
            contacts=tuple(contacts),
        ),
    )
    _check_rotating(task_id, physics_ood, "ood", "physics")
    with pytest.raises(ValueError):
        _check_rotating(task_id, physics_ood, "ood", "appearance")


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_rejects_label_only_and_inapplicable_ood_factors(task_id: str) -> None:
    scenario = _rotating_materialized(task_id)
    with pytest.raises(ValueError, match="leave test-ID support"):
        _check_rotating(task_id, scenario, "ood", "geometry")
    with pytest.raises(ValueError, match="inapplicable"):
        _check_rotating(task_id, scenario, "ood", "object")


_FREE_DYNAMICS_TASKS = (
    "t4_sphere",
    "t4_sphere_tabletop",
    "t4_slider",
    "t4_can",
)
_FREE_DYNAMICS_COMMON_FACTORS = (
    "geometry",
    "physics",
    "appearance",
    "camera",
    "action_delay",
)
_FREE_DYNAMICS_CELLS = tuple(
    (task_id, partition, factor)
    for task_id in _FREE_DYNAMICS_TASKS
    for partition, factor in (
        ("train", None),
        ("validation", None),
        ("test_id", None),
        ("stress", None),
        *(
            ("ood", item)
            for item in (
                *_FREE_DYNAMICS_COMMON_FACTORS,
                *(("spatial",) if task_id != "t4_sphere" else ()),
            )
        ),
    )
)


@lru_cache(maxsize=4)
def _free_dynamics_document(task_id: str) -> Any:
    return load_yaml_strict(_REPOSITORY_ROOT / f"configs/scenarios/{task_id}.yaml")


def _free_dynamics_recipe(
    task_id: str,
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            _free_dynamics_document(task_id),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _free_dynamics_materialized(
    task_id: str,
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
    seed: int = 17,
) -> ScenarioSpec:
    return _materialize_recipe(
        load_task(task_id),
        _free_dynamics_recipe(task_id, partition, factor, name),
        np.random.Generator(np.random.PCG64(seed)),
    )


def _check_free_dynamics(
    task_id: str,
    scenario: ScenarioSpec,
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> None:
    _validate_free_dynamics_declarative_scenario(
        load_task(task_id),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        id_recipe=_free_dynamics_recipe(
            task_id,
            partition=partition if partition in ("train", "validation") else "test_id",
            name=name,
        ),
    )


@pytest.mark.parametrize(("task_id", "partition", "factor"), _FREE_DYNAMICS_CELLS)
def test_all_156_t4_named_recipes_are_complete_deterministic_and_action_view_paired(
    task_id: str,
    partition: Partition,
    factor: str | None,
) -> None:
    physical: list[dict[str, object]] = []
    robot_states = []
    for name in _RECIPE_NAMES:
        recipe = _free_dynamics_recipe(task_id, partition, factor, name)
        alternatives = recipe["choices"] if partition == "stress" else [recipe]
        assert len(alternatives) == (4 if partition == "stress" else 1)
        for alternative in alternatives:
            assert set(alternative) == _COMPLETE_RECIPE_FIELDS | {"preparation_object_states"}
            assert alternative["action_mode"] == ("E7" if name.startswith("e7_") else "J8")
        scenario = _free_dynamics_materialized(task_id, partition, factor, name)
        assert scenario == _free_dynamics_materialized(task_id, partition, factor, name)
        assert scenario == _materialize_recipe(
            load_task(task_id),
            _reversed_mapping_keys(recipe),
            np.random.Generator(np.random.PCG64(17)),
        )
        _check_free_dynamics(task_id, scenario, partition, factor, name)
        record = scenario_to_dict(scenario)
        assert scenario_from_dict(record, family="free_dynamics_interception") == scenario
        assert "recipe_name" not in record
        robot_states.append(scenario.robot_initial_state)
        record.pop("action_mode")
        record.pop("observation_profile")
        record["cameras"]["views"] = record["cameras"]["views"][:1]
        physical.append(record)
    assert all(item == physical[0] for item in physical)
    assert all(item == robot_states[0] for item in robot_states)


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
def test_t4_stress_preserves_four_old_qa_tuples_and_nominal_fields(task_id: str) -> None:
    nominal_mu = {"t4_sphere": 0.8, "t4_sphere_tabletop": 0.8, "t4_slider": 0.035, "t4_can": 0.35}[
        task_id
    ]
    lateral = 0.01 if task_id == "t4_can" else 0.015
    tuples = (
        (5.0, -lateral, nominal_mu, -4.0 if task_id == "t4_can" else 0.0),
        (15.0, lateral, nominal_mu, 4.0 if task_id == "t4_can" else 0.0),
        (18.0, 0.0, 0.07 if task_id == "t4_slider" else 0.02, 12.0 if task_id == "t4_can" else 0.0),
        (10.0, 0.0, nominal_mu, 0.0),
    )
    for name in _RECIPE_NAMES:
        alternatives = _free_dynamics_recipe(task_id, "stress", name=name)["choices"]
        assert len(alternatives) == 4
        for recipe, (angle, offset, friction, yaw) in zip(alternatives, tuples, strict=True):
            expected = _free_dynamics_recipe(task_id, name=name)
            expected["geometry"]["ramp_angle_rad"] = {"degrees": angle}
            expected["object_states"][0]["position_world_m"]["ramp_center_offset_m"][0] = offset
            if task_id == "t4_can":
                expected["object_states"][0]["quaternion_world_xyzw"] = {
                    "axis_yaw_rad": {"degrees": yaw}
                }
            for contact in expected["physics"]["contacts"]:
                if contact["entity_id"] == "target":
                    contact["friction_slide_spin_roll"] = [friction, 0.005, 0.0001]
                elif contact["entity_id"] == "table":
                    contact["friction_slide_spin_roll"] = [
                        {"t4_can": 0.12, "t4_slider": 0.015, "t4_sphere_tabletop": 0.35}[task_id],
                        0.005,
                        0.0001,
                    ]
            assert recipe == expected
            scenario = _materialize_recipe(load_task(task_id), recipe, np.random.default_rng(0))
            _check_free_dynamics(task_id, scenario, "stress", name=name)
            invalid = copy.deepcopy(recipe)
            invalid["physics"]["contacts"][0]["friction_slide_spin_roll"][0] = 0.123
            bad = _materialize_recipe(load_task(task_id), invalid, np.random.default_rng(0))
            with pytest.raises(ValueError, match="complete old factor or nominal QA tuple"):
                _check_free_dynamics(task_id, bad, "stress", name=name)


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
@pytest.mark.parametrize("name", _RECIPE_NAMES)
def test_t4_ood_changes_owned_support_and_preserves_the_fixed_protocol(
    task_id: str,
    name: str,
) -> None:
    owned = {
        "geometry": "geometry",
        "physics": "physics",
        "appearance": "lighting",
        "camera": "cameras",
        "action_delay": "action_delay_steps",
        **({"spatial": "object_states"} if task_id != "t4_sphere" else {}),
    }
    # DB0 draws slope, lateral position, friction, and then can yaw. Changing
    # a distribution may consume a different number of draws. Non-owning
    # random values retain ID support; they need not equal the same-seed ID row.
    sampled_physics = {
        "geometry",
        "object_states",
        "fixture_states",
        "physics",
        "preparation_object_states",
    }
    for seed in (0, 17):
        identity = scenario_to_dict(_free_dynamics_materialized(task_id, name=name, seed=seed))
        for factor, field in owned.items():
            scenario = _free_dynamics_materialized(task_id, "ood", factor, name, seed)
            _check_free_dynamics(task_id, scenario, "ood", factor, name)
            actual = scenario_to_dict(scenario)
            assert actual[field] != identity[field]
            for key in identity.keys() - sampled_physics - {field}:
                assert actual[key] == identity[key], (task_id, factor, key)


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
@pytest.mark.parametrize("partition", ["train", "validation"])
def test_t4_training_draws_follow_the_source_manifest_order(
    task_id: str, partition: Partition
) -> None:
    recipe = _free_dynamics_recipe(task_id, partition)
    rng = np.random.Generator(np.random.PCG64(17))
    source_rng = np.random.Generator(np.random.PCG64(17))
    angle = math.radians(float(source_rng.uniform(5.0, 15.0)))
    lateral_bound = 0.01 if task_id == "t4_can" else 0.015
    lateral = float(source_rng.uniform(-lateral_bound, lateral_bound))
    friction_bounds = {
        "t4_sphere": (0.7, 0.9),
        "t4_sphere_tabletop": (0.7, 0.9),
        "t4_slider": (0.025, 0.045),
        "t4_can": (0.25, 0.45),
    }
    friction = float(source_rng.uniform(*friction_bounds[task_id]))
    table = None
    if task_id in {"t4_slider", "t4_can"}:
        bounds = (0.012, 0.018) if task_id == "t4_slider" else (0.09, 0.15)
        table = float(source_rng.uniform(*bounds))
    yaw = math.radians(float(source_rng.uniform(-4.0, 4.0))) if task_id == "t4_can" else 0.0
    scenario = _materialize_recipe(load_task(task_id), recipe, rng)
    record = scenario_to_dict(scenario)
    assert record["geometry"]["ramp_angle_rad"] == angle
    assert angle not in tuple(map(math.radians, (5.0, 10.0, 15.0)))
    contacts = {item.entity_id: item for item in scenario.physics.contacts}
    assert contacts["target"].friction_slide_spin_roll == (friction, 0.005, 0.0001)
    assert contacts["ramp"].friction_slide_spin_roll == contacts["target"].friction_slide_spin_roll
    if table is not None:
        assert contacts["table"].friction_slide_spin_roll[0] == table
    # Preparation has its own explicit draws after the existing manifest factors.
    preparation_x = float(source_rng.uniform(-0.03, 0.03))
    preparation_y = float(source_rng.uniform(-0.03, 0.03))
    preparation_yaw = float(source_rng.uniform(0.0, 2.0 * math.pi))
    preparation = scenario.preparation_object_states[0]
    assert preparation.position_world_m[:2] == (preparation_x, preparation_y)
    assert preparation.quaternion_world_xyzw == (
        0.0,
        0.0,
        math.sin(preparation_yaw / 2.0),
        math.cos(preparation_yaw / 2.0),
    )
    assert rng.bit_generator.state == source_rng.bit_generator.state

    # The old reset installs the gate and target in the same sampled ramp frame.
    rotation = np.asarray(
        (
            (1.0, 0.0, 0.0),
            (0.0, math.cos(angle), math.sin(angle)),
            (0.0, -math.sin(angle), math.cos(angle)),
        ),
        dtype=np.float64,
    )
    supported = task_id != "t4_sphere"
    lip = np.asarray((0.0, -0.06, 0.808) if supported else (0.06, -0.02, 1.1))
    center = lip - rotation @ np.asarray((0.0, 0.17, 0.004) if supported else (0.0, 0.2, 0.0))
    gate_local = np.asarray((0.0, -0.09, 0.004 + 0.035) if supported else (0.0, -0.11, 0.035))
    gate_world = center + rotation @ gate_local
    fixtures = {item.instance_id: item for item in scenario.fixture_states}
    np.testing.assert_allclose(fixtures["gate"].position_world_m, gate_world, rtol=0.0, atol=1e-15)
    if task_id == "t4_can":
        local_gate = rotation.T @ (gate_world - center)
        along = local_gate[1] - 0.004 - (0.045 * abs(math.sin(yaw)) + 0.024 * abs(math.cos(yaw)))
        height = 0.028
    else:
        along, height = {
            "t4_sphere": (-0.145, 0.03),
            "t4_sphere_tabletop": (-0.124, 0.034),
            "t4_slider": (-0.129, 0.024),
        }[task_id]
    np.testing.assert_allclose(
        scenario.object_states[0].position_world_m,
        center + rotation @ np.asarray((lateral, along, height)),
        rtol=0.0,
        atol=1e-15,
    )


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
def test_t4_literal_coordinates_validate_after_the_ramp_frame_roundtrip(task_id: str) -> None:
    recipe = _free_dynamics_recipe(task_id, "train")
    recipe["geometry"]["ramp_angle_rad"] = {"degrees": 9.372845290100503}
    target = recipe["object_states"][0]
    target["position_world_m"]["ramp_center_offset_m"][0] = 0.0019311906583214938
    if task_id == "t4_can":
        target["quaternion_world_xyzw"]["axis_yaw_rad"] = {"degrees": 0.25326340800214986}
    scenario = _materialize_recipe(
        load_task(task_id), recipe, np.random.Generator(np.random.PCG64(17))
    )
    _validate_free_dynamics_declarative_scenario(
        load_task(task_id),
        scenario,
        partition="train",
        factor=None,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        id_recipe=recipe,
    )


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
@pytest.mark.parametrize("source_id", ["missing", "ramp"])
def test_t4_rejects_unknown_and_self_referencing_friction_before_sampling(
    task_id: str, source_id: str
) -> None:
    recipe = _free_dynamics_recipe(task_id)
    ramp = next(item for item in recipe["physics"]["contacts"] if item["entity_id"] == "ramp")
    ramp["friction_slide_spin_roll"] = {"from_entity_id": source_id}
    rng = np.random.Generator(np.random.PCG64(17))
    before = copy.deepcopy(rng.bit_generator.state)
    with pytest.raises(ValueError, match="declared contact entity"):
        _materialize_recipe(load_task(task_id), recipe, rng)
    assert rng.bit_generator.state == before


@pytest.mark.parametrize("task_id", _FREE_DYNAMICS_TASKS)
def test_t4_invalid_unselected_choices_fail_before_the_rng_is_consumed(task_id: str) -> None:
    recipe = _free_dynamics_recipe(task_id)
    recipe["geometry"]["ramp_angle_rad"] = {
        "choices": [math.radians(5.0), {"callback": "not-allowed"}]
    }
    for seed in range(4):
        with pytest.raises(ValueError):
            _materialize_recipe(
                load_task(task_id), recipe, np.random.Generator(np.random.PCG64(seed))
            )

    recipe = _free_dynamics_recipe(task_id)
    recipe["object_states"][0] = {
        "choices": [
            recipe["object_states"][0],
            {**recipe["object_states"][0], "asset_id": "obj.not_registered"},
        ]
    }
    for seed in range(4):
        with pytest.raises(ValueError, match="functional asset"):
            _materialize_recipe(
                load_task(task_id), recipe, np.random.Generator(np.random.PCG64(seed))
            )

    recipe = _free_dynamics_recipe(task_id, "stress")
    recipe["choices"][-1]["object_states"][0]["linear_velocity_world_m_s"] = [0.0, 0.0]
    rng = np.random.Generator(np.random.PCG64(0))
    before = copy.deepcopy(rng.bit_generator.state)
    with pytest.raises(ValueError):
        _materialize_recipe(load_task(task_id), recipe, rng)
    assert rng.bit_generator.state == before


def test_mujoco_angular_linear_twist_is_reordered_for_the_linear_angular_dls_jacobian() -> None:
    source = np.asarray((1.0, 2.0, 3.0, 4.0, 5.0, 6.0), dtype=np.float64)
    actual = _mujoco_twist_to_spatial(source)
    np.testing.assert_array_equal(actual, (4.0, 5.0, 6.0, 1.0, 2.0, 3.0))
    assert actual.dtype == np.float64 and actual.flags.c_contiguous
    np.testing.assert_array_equal(source, (1.0, 2.0, 3.0, 4.0, 5.0, 6.0))
    with pytest.raises(ValueError, match="angular-linear"):
        _mujoco_twist_to_spatial(np.zeros(5, dtype=np.float64))
    with pytest.raises(ValueError, match="angular-linear"):
        _mujoco_twist_to_spatial(np.asarray((0.0, 0.0, 0.0, 0.0, math.nan, 0.0)))


def _with_t4_slide_frictions(scenario: ScenarioSpec, *, ramp: float, table: float) -> ScenarioSpec:
    contacts = tuple(
        replace(
            contact,
            friction_slide_spin_roll=(
                ramp if contact.entity_id in {"target", "ramp"} else table,
                *contact.friction_slide_spin_roll[1:],
            ),
        )
        if contact.entity_id in {"target", "ramp", "table"}
        else contact
        for contact in scenario.physics.contacts
    )
    return replace(scenario, physics=replace(scenario.physics, contacts=contacts))


@pytest.mark.parametrize(
    ("task_id", "ramp_bounds", "table_bounds"),
    [
        ("t4_slider", (0.025, 0.045), (0.012, 0.018)),
        ("t4_can", (0.25, 0.45), (0.09, 0.15)),
    ],
)
def test_t4_training_friction_retains_exact_inclusive_source_bounds(
    task_id: str, ramp_bounds: tuple[float, float], table_bounds: tuple[float, float]
) -> None:
    baseline = _free_dynamics_materialized(task_id, "train")
    for ramp, table in (
        (ramp_bounds[0], table_bounds[0]),
        (ramp_bounds[1], table_bounds[1]),
        (math.nextafter(ramp_bounds[0], math.inf), math.nextafter(table_bounds[1], -math.inf)),
    ):
        _check_free_dynamics(
            task_id, _with_t4_slide_frictions(baseline, ramp=ramp, table=table), "train"
        )
    for ramp, table in (
        (math.nextafter(ramp_bounds[0], -math.inf), table_bounds[0]),
        (math.nextafter(ramp_bounds[1], math.inf), table_bounds[1]),
        (ramp_bounds[0], math.nextafter(table_bounds[0], -math.inf)),
        (ramp_bounds[1], math.nextafter(table_bounds[1], math.inf)),
    ):
        with pytest.raises(ValueError):
            _check_free_dynamics(
                task_id, _with_t4_slide_frictions(baseline, ramp=ramp, table=table), "train"
            )


@pytest.mark.parametrize(
    ("task_id", "ramp_value", "table_value"),
    [("t4_slider", 0.035, 0.015), ("t4_can", 0.35, 0.12)],
)
def test_t4_slider_and_can_test_id_friction_is_the_source_point_support(
    task_id: str, ramp_value: float, table_value: float
) -> None:
    baseline = _free_dynamics_materialized(task_id)
    _check_free_dynamics(
        task_id, _with_t4_slide_frictions(baseline, ramp=ramp_value, table=table_value)
    )
    outside = (
        (math.nextafter(ramp_value, -math.inf), table_value),
        (math.nextafter(ramp_value, math.inf), table_value),
        (ramp_value, math.nextafter(table_value, -math.inf)),
        (ramp_value, math.nextafter(table_value, math.inf)),
    )
    for ramp, table in outside:
        intervention = _with_t4_slide_frictions(baseline, ramp=ramp, table=table)
        _check_free_dynamics(task_id, intervention, "ood", "physics")
        with pytest.raises(ValueError):
            _check_free_dynamics(task_id, intervention)


@pytest.mark.parametrize("task_id", ["t4_slider", "t4_can"])
def test_t4_physics_ood_recipe_friction_is_entirely_outside_id_support(task_id: str) -> None:
    document = _free_dynamics_document(task_id)
    points = (
        {"target": 0.035, "table": 0.015}
        if task_id == "t4_slider"
        else {"target": 0.35, "table": 0.12}
    )
    for recipe in document["recipes"]["ood"]["physics"].values():
        contacts = {item["entity_id"]: item for item in recipe["physics"]["contacts"]}
        assert contacts["ramp"]["friction_slide_spin_roll"] == {"from_entity_id": "target"}
        for entity_id, point in points.items():
            support = contacts[entity_id]["friction_slide_spin_roll"][0]
            intervals = support["uniform_intervals"]
            assert len(intervals) == 2
            assert all(upper < point or lower > point for lower, upper in intervals)
            assert intervals[0][1] == math.nextafter(point, -math.inf)
            assert intervals[1][0] == math.nextafter(point, math.inf)


_REPLANNING_RECIPE_PATH = _REPOSITORY_ROOT / "configs/scenarios/t5_replan.yaml"
_REPLANNING_CELLS: tuple[tuple[Partition, str | None], ...] = (
    ("train", None),
    ("validation", None),
    ("test_id", None),
    ("ood", "motion_parameters"),
    ("stress", None),
)


@lru_cache(maxsize=1)
def _replanning_document() -> Any:
    return load_yaml_strict(_REPLANNING_RECIPE_PATH)


def _replanning_recipe(
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> Any:
    return copy.deepcopy(
        _select_recipe(
            _replanning_document(),
            partition=partition,
            factor=factor,
            recipe_name=name,
        )
    )


def _replanning_materialized(
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
    seed: int = 17,
) -> ScenarioSpec:
    return _materialize_recipe(
        load_task("t5_replan"),
        _replanning_recipe(partition, factor, name),
        np.random.Generator(np.random.PCG64(seed)),
    )


def _check_replanning(
    scenario: ScenarioSpec,
    partition: Partition = "test_id",
    factor: str | None = None,
    name: str = "e7_agentview",
) -> None:
    _validate_replanning_declarative_scenario(
        load_task("t5_replan"),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(_GRASP_CATALOG_PATH),
        id_recipe=_replanning_recipe(name=name),
    )


@pytest.mark.parametrize(("partition", "factor"), _REPLANNING_CELLS)
def test_all_20_t5_named_recipes_are_complete_deterministic_and_action_view_paired(
    partition: Partition, factor: str | None
) -> None:
    physical: list[dict[str, object]] = []
    robot_states = []
    for name in _RECIPE_NAMES:
        recipe = _replanning_recipe(partition, factor, name)
        alternatives = recipe["choices"] if partition == "stress" else [recipe]
        assert len(alternatives) == (5 if partition == "stress" else 1)
        for alternative in alternatives:
            assert set(alternative) == _COMPLETE_RECIPE_FIELDS
            assert alternative["action_mode"] == ("E7" if name.startswith("e7_") else "J8")
        scenario = _replanning_materialized(partition, factor, name)
        assert scenario == _replanning_materialized(partition, factor, name)
        assert scenario == _materialize_recipe(
            load_task("t5_replan"),
            _reversed_mapping_keys(recipe),
            np.random.Generator(np.random.PCG64(17)),
        )
        _check_replanning(scenario, partition, factor, name)
        record = scenario_to_dict(scenario)
        assert scenario_from_dict(record, family="replanning") == scenario
        assert "recipe_name" not in record
        robot_states.append(scenario.robot_initial_state)
        record.pop("action_mode")
        record.pop("observation_profile")
        record["cameras"]["views"] = record["cameras"]["views"][:1]
        physical.append(record)
    assert all(item == physical[0] for item in physical)
    assert all(item == robot_states[0] for item in robot_states)


@pytest.mark.parametrize("name", _RECIPE_NAMES)
def test_t5_motion_parameter_ood_changes_only_its_owned_concrete_fields(name: str) -> None:
    for seed in (0, 17):
        identity = scenario_to_dict(_replanning_materialized(name=name, seed=seed))
        intervention = scenario_to_dict(
            _replanning_materialized("ood", "motion_parameters", name, seed)
        )
        changed = {key for key in identity if intervention[key] != identity[key]}
        assert changed <= {"motion", "events"}
        assert changed


def test_t5_invalid_unselected_records_fail_before_rng_consumption() -> None:
    recipe = _replanning_recipe()
    valid_event = recipe["events"][0]["choices"][0]
    recipe["events"][0]["choices"].append(
        {
            **valid_event,
            "effect": {**valid_event["effect"], "callback": "invalid"},
        }
    )
    for seed in range(4):
        with pytest.raises(ValueError):
            _materialize_recipe(
                load_task("t5_replan"), recipe, np.random.Generator(np.random.PCG64(seed))
            )

    recipe = _replanning_recipe()
    recipe["object_states"][0] = {
        "choices": [
            recipe["object_states"][0],
            {**recipe["object_states"][0], "asset_id": "obj.not_registered"},
        ]
    }
    for seed in range(4):
        with pytest.raises(ValueError, match="keyed-puck"):
            _materialize_recipe(
                load_task("t5_replan"), recipe, np.random.Generator(np.random.PCG64(seed))
            )

    for name in _RECIPE_NAMES:
        recipe = _replanning_recipe("stress", name=name)
        recipe["choices"][-1]["action_mode"] = "INVALID"
        rng = np.random.Generator(np.random.PCG64(17))
        state = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task("t5_replan"), recipe, rng)
        assert rng.bit_generator.state == state


def _with_t5_motion_parameters(
    scenario: ScenarioSpec, *, belt_speed: float, actuator_scale: float
) -> ScenarioSpec:
    motion = scenario.motion[0]
    assert isinstance(motion.translation, ConstantVelocityTranslation)
    effect = scenario.events[0].effect
    return replace(
        scenario,
        motion=(
            replace(
                motion,
                translation=replace(
                    motion.translation,
                    velocity_world_m_s=(0.0, belt_speed, 0.0),
                ),
            ),
        ),
        events=(
            replace(
                scenario.events[0],
                effect=replace(effect, actuator_scale=actuator_scale),
            ),
        ),
    )


def test_t5_motion_parameter_supports_have_exact_inclusive_boundaries() -> None:
    baseline = _replanning_materialized()
    for belt_speed in (0.12, 0.14):
        for actuator_scale in (1.0, 1.1):
            _check_replanning(
                _with_t5_motion_parameters(
                    baseline, belt_speed=belt_speed, actuator_scale=actuator_scale
                )
            )
    for belt_speed, actuator_scale in (
        (0.09, 1.0),
        (0.17, 1.0),
        (0.13, 0.8),
        (0.13, 1.2),
    ):
        _check_replanning(
            _with_t5_motion_parameters(
                baseline, belt_speed=belt_speed, actuator_scale=actuator_scale
            ),
            "ood",
            "motion_parameters",
        )
    for belt_speed, actuator_scale in (
        (math.nextafter(0.12, -math.inf), 1.0),
        (math.nextafter(0.14, math.inf), 1.0),
        (0.13, math.nextafter(1.0, -math.inf)),
        (0.13, math.nextafter(1.1, math.inf)),
    ):
        with pytest.raises(ValueError, match="outside its frozen supports"):
            _check_replanning(
                _with_t5_motion_parameters(
                    baseline, belt_speed=belt_speed, actuator_scale=actuator_scale
                ),
                "ood",
                "motion_parameters",
            )


def test_t5_stress_covers_both_branches_and_only_frozen_delay_values() -> None:
    # Old stress.py has four factor cases plus the cross-seed smoke nominal.
    # Atomic choices preserves this support, not the historical seed schedule.
    source_cases = (
        (0.12, -0.005, -0.08),
        (0.14, 0.005, 0.08),
        (0.09, 0.0, 0.0),
        (0.17, 0.0, 0.0),
        (0.13, 0.0, 0.0),
    )
    for name in _RECIPE_NAMES:
        nominal = _replanning_recipe("train", name=name)
        alternatives = _replanning_recipe("stress", name=name)["choices"]
        assert len(alternatives) == len(source_cases)
        for recipe, (speed, x, yaw) in zip(alternatives, source_cases, strict=True):
            assert recipe["motion"][0]["translation"]["velocity_world_m_s"] == [0, speed, 0]
            assert recipe["object_states"][0]["position_world_m"] == {"x_m": x}
            assert recipe["object_states"][0]["quaternion_world_xyzw"] == {"yaw_rad": yaw}
            assert recipe["action_delay"] == {"enabled": True, "delay_steps": 1}
            for field in ("physics", "lighting", "cameras", "events"):
                assert recipe[field] == nominal[field]
            for event in recipe["events"][0]["choices"]:
                assert event["effect"]["actuator_scale"] == {"min": 1, "max": 1.1}
            scenario = _materialize_recipe(
                load_task("t5_replan"), recipe, np.random.Generator(np.random.PCG64(17))
            )
            _check_replanning(scenario, "stress", name=name)
    branches: set[str] = set()
    scales: set[float] = set()
    nominal_scenario = _replanning_materialized()
    for seed in range(16):
        scenario = _replanning_materialized("stress", seed=seed)
        effect = scenario.events[0].effect
        branches.add(effect.striker_entity_id)
        scales.add(effect.actuator_scale)
        assert scenario.action_delay_steps == 1
        assert scenario.physics == nominal_scenario.physics
        assert scenario.lighting == nominal_scenario.lighting
        _check_replanning(scenario, "stress")
    assert branches == {"left_striker", "right_striker"}
    assert all(1.0 <= scale <= 1.1 for scale in scales)
    assert scales - {1.0, 1.05, 1.1}
    with pytest.raises(ValueError, match="does not define ood.action_delay"):
        _select_recipe(
            _replanning_document(),
            partition="ood",
            factor="action_delay",
            recipe_name="e7_agentview",
        )


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_stress_preserves_source_factor_and_nominal_cross_seed_conditions(task_id: str) -> None:
    # Fixed DB0 factor stress plus suite.py nominal cross-seed input. Choices
    # provide coverage and do not establish a source sampling probability.
    source_cases = ((-0.25, -2.5), (0.35, -7.5), (0.70, 25.0), (0.05, -5.0))
    for name in _RECIPE_NAMES:
        nominal = _rotating_recipe(task_id, name=name)
        alternatives = _rotating_recipe(task_id, "stress", name=name)["choices"]
        assert len(alternatives) == len(source_cases)
        for recipe, (phase, speed_deg_s) in zip(alternatives, source_cases, strict=True):
            assert recipe["fixture_states"][0]["quaternion_world_xyzw"] == {"phase_x_rad": phase}
            assert recipe["motion"][0]["rotation"]["angular_speed_rad_s"] == math.radians(
                speed_deg_s
            )
            assert recipe["action_delay"] == {"enabled": False, "delay_steps": 0}
            ordinary = copy.deepcopy(recipe)
            ordinary["fixture_states"][0]["quaternion_world_xyzw"] = nominal["fixture_states"][0][
                "quaternion_world_xyzw"
            ]
            ordinary["motion"][0]["rotation"]["angular_speed_rad_s"] = nominal["motion"][0][
                "rotation"
            ]["angular_speed_rad_s"]
            assert ordinary == nominal
            scenario = _materialize_recipe(load_task(task_id), recipe, np.random.default_rng(0))
            _check_rotating(task_id, scenario, "stress", None, name)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
@pytest.mark.parametrize(
    ("phase", "speed_deg_s", "delay"),
    [
        (0.05, -2.5, 0),
        (-0.25, -5.0, 0),
        (-0.25, -7.5, 0),
        (0.35, -2.5, 0),
        (0.70, -25.0, 0),
        (-0.5, -2.5, 0),
        (0.8, 25.0, 0),
        (0.70, 25.1, 0),
        (-0.25, -2.5, 1),
        (-0.25, -2.5, 3),
    ],
)
def test_t3_stress_rejects_mismatched_or_outside_qa_inputs_and_delay(
    task_id: str, phase: float, speed_deg_s: float, delay: int
) -> None:
    recipe = _rotating_recipe(task_id, "stress")["choices"][0]
    recipe["fixture_states"][0]["quaternion_world_xyzw"] = {"phase_x_rad": phase}
    recipe["motion"][0]["rotation"]["angular_speed_rad_s"] = math.radians(speed_deg_s)
    recipe["action_delay"] = {"enabled": delay > 0, "delay_steps": delay}
    scenario = _materialize_recipe(load_task(task_id), recipe, np.random.default_rng(0))
    with pytest.raises(
        ValueError, match="paired DB0 factor or nominal cross-seed condition|zero action delay"
    ):
        _check_rotating(task_id, scenario, "stress", None)


@pytest.mark.parametrize("task_id", ["t3_phase", "t3_full"])
def test_t3_invalid_unselected_whole_recipe_fails_before_rng(task_id: str) -> None:
    recipe = _rotating_recipe(task_id, "stress")
    recipe["choices"][-1]["motion"][0]["rotation"]["angular_speed_rad_s"] = 0.0
    for seed in (0, 1):
        rng = np.random.default_rng(seed)
        before = copy.deepcopy(rng.bit_generator.state)
        with pytest.raises(ValueError):
            _materialize_recipe(load_task(task_id), recipe, rng)
        assert rng.bit_generator.state == before


def test_full_recipe_rejects_bad_unselected_branch_before_rng() -> None:
    task = load_task("t2_trans")
    document = load_yaml_strict(Path("configs/scenarios/t2_trans.yaml"))
    recipe = copy.deepcopy(
        _select_recipe(document, partition="stress", factor=None, recipe_name="e7_agentview_wrist")
    )
    assert len(recipe["choices"]) == 4
    # Seed 11 would select the intact first branch; corrupt only the third branch.
    assert int(np.random.default_rng(11).integers(0, 4)) == 0
    recipe["choices"][2]["motion"][0]["translation"]["velocity_world_m_s"][0] = 0.01
    rng = np.random.default_rng(11)
    before = copy.deepcopy(rng.bit_generator.state)
    with pytest.raises(ValueError):
        _materialize_recipe(task, recipe, rng)
    assert rng.bit_generator.state == before
