from __future__ import annotations

import subprocess
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

EXPECTED_ROOT_FILES = {
    ".gitignore",
    "AGENTS.md",
    "LICENSE",
    "README.md",
    "pyproject.toml",
}

EXPECTED_MODULES = {
    "api.py",
    "tasks/spec.py",
    "tasks/registry.py",
    "scenarios/spec.py",
    "scenarios/generator.py",
    "scenarios/_recipes.py",
    "scenarios/_validation.py",
    "scenarios/_feasibility.py",
    "scenarios/_native_oracle.py",
    "scenarios/_family_parameters.py",
    "scenarios/_rejection.py",
    "scenarios/manifest.py",
    "envs/base.py",
    "envs/factory.py",
    "envs/families/grasp.py",
    "envs/families/driven_interception.py",
    "envs/families/moving_placement.py",
    "envs/families/rotating_interaction.py",
    "envs/families/free_dynamics_interception.py",
    "envs/families/replanning.py",
    "envs/components/motion.py",
    "envs/components/events.py",
    "envs/components/occlusion.py",
    "sensing/observation.py",
    "sensing/camera.py",
    "control/action.py",
    "supervision/snapshot.py",
    "supervision/optical_flow.py",
    "supervision/object_pose.py",
    "evaluation/policy.py",
    "evaluation/rollout.py",
    "evaluation/result.py",
    "evaluation/evaluator.py",
    "evaluation/suite.py",
    "evaluation/metrics/manipulation.py",
    "evaluation/metrics/object_pose.py",
    "evaluation/metrics/optical_flow.py",
    "data/schema.py",
    "data/recorder.py",
    "integrations/se3_wam.py",
    "cli/generate_scenarios.py",
    "cli/evaluate.py",
    "cli/record.py",
}

TASK_IDS = {
    "grasp",
    "t1_belt",
    "t1_xyz",
    "t1_so3",
    "t1_occ",
    "t2_trans",
    "t2_se3",
    "t3_phase",
    "t3_full",
    "t4_sphere",
    "t4_sphere_tabletop",
    "t4_slider",
    "t4_can",
    "t5_replan",
}

SUITES = {
    "validation",
    "test_id",
    "ood_object",
    "ood_spatial",
    "ood_geometry",
    "ood_motion_parameters",
    "ood_motion_law",
    "ood_physics",
    "ood_appearance",
    "ood_camera",
    "ood_action_delay",
    "stress",
    "benchmark_v1",
}


def test_root_matches_the_frozen_product_shell() -> None:
    package = Path("src/se3_wam_benchmark")
    package_files = {package / "py.typed"}
    package_files |= {package / module for module in EXPECTED_MODULES}
    package_directories = {Path(module).parent for module in EXPECTED_MODULES} | {Path(".")}
    package_files |= {package / directory / "__init__.py" for directory in package_directories}
    config_files = {Path("configs/tasks") / f"{task_id}.yaml" for task_id in TASK_IDS}
    config_files |= {Path("configs/scenarios") / f"{task_id}.yaml" for task_id in TASK_IDS}
    config_files |= {Path("configs/suites") / f"{suite}.yaml" for suite in SUITES}
    manifest_files = {
        Path("manifests/v1") / f"{name}.jsonl"
        for name in {
            "validation",
            "test_id",
            "ood_object",
            "ood_spatial",
            "ood_geometry",
            "ood_motion_parameters",
            "ood_motion_law",
            "ood_physics",
            "ood_appearance",
            "ood_camera",
            "ood_action_delay",
            "stress",
        }
    }
    expected = {Path(path) for path in EXPECTED_ROOT_FILES}
    expected |= {
        Path("assets/README.md"),
        Path("assets/catalog.yaml"),
        Path("assets/textures/INDEX.md"),
        Path("assets/textures/red-wood.png"),
        Path("assets/arenas/conveyor_v1.xml"),
        Path("assets/arenas/occlusion_canopy_v1.xml"),
        Path("assets/arenas/open_tray_v1.xml"),
        Path("assets/arenas/replanning_conveyor_v1.xml"),
        Path("assets/arenas/rotating_wire_fixture_v1.xml"),
        Path("assets/arenas/rotating_wire_v1.xml"),
        Path("assets/arenas/supported_ramp_v1.xml"),
        Path("assets/arenas/t_slot_v1.xml"),
        Path("assets/arenas/unsupported_ramp_v1.xml"),
        Path("assets/arenas/wand_cradle_v1.xml"),
        Path("assets/objects/asym_t_t1_v1.xml"),
        Path("assets/objects/asym_t_t2_handle_v1.xml"),
        Path("assets/objects/bottle_v1.xml"),
        Path("assets/objects/can_v1.xml"),
        Path("assets/objects/cuboid_grasp_v1.xml"),
        Path("assets/objects/cuboid_t2_handle_v1.xml"),
        Path("assets/objects/cube_44_v1.xml"),
        Path("assets/objects/keyed_puck_v1.xml"),
        Path("assets/objects/rod_v1.xml"),
        Path("assets/objects/slider_v1.xml"),
        Path("assets/objects/sphere_r030_v1.xml"),
        Path("assets/objects/wand_loop_v1.xml"),
        Path("docs/architecture.md"),
        Path("docs/tasks.md"),
        Path("docs/interfaces.md"),
        Path("docs/data.md"),
        Path("docs/evaluation.md"),
        Path("tests/architecture/test_import_boundaries.py"),
        Path("tests/architecture/test_public_api.py"),
        Path("tests/architecture/test_repository_structure.py"),
        Path("tests/integration/test_grasp.py"),
        Path("tests/integration/test_t1_belt.py"),
        Path("tests/integration/test_t1_matched.py"),
        Path("tests/integration/test_t1_occ.py"),
        Path("tests/integration/test_t2.py"),
        Path("tests/integration/test_t3.py"),
        Path("tests/integration/test_t4.py"),
        Path("tests/integration/test_t5.py"),
        Path("tests/integration/se3_wam_adapter_gate.py"),
        Path("tests/unit/test_action_control.py"),
        Path("tests/unit/test_asset_catalog.py"),
        Path("tests/unit/test_events.py"),
        Path("tests/unit/test_manifest.py"),
        Path("tests/unit/test_motion.py"),
        Path("tests/unit/test_occlusion.py"),
        Path("tests/unit/test_public_records.py"),
        Path("tests/unit/test_scenario_generator.py"),
        Path("tests/unit/test_scenario_spec.py"),
        Path("tests/unit/test_sensing.py"),
        Path("tests/unit/test_strict_loading.py"),
        Path("tests/unit/test_task_registry.py"),
    }
    expected |= package_files | config_files | manifest_files
    result = subprocess.run(
        ["git", "ls-files"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    tracked = {Path(line) for line in result.stdout.splitlines()}
    assert tracked == expected


def test_single_package_contains_the_frozen_module_tree() -> None:
    src = ROOT / "src"
    assert [path.name for path in src.iterdir() if path.is_dir()] == ["se3_wam_benchmark"]
    package = src / "se3_wam_benchmark"
    assert (package / "py.typed").is_file()
    for module in EXPECTED_MODULES:
        assert (package / module).is_file(), module
    for directory in {Path(module).parent for module in EXPECTED_MODULES} | {Path(".")}:
        assert (package / directory / "__init__.py").is_file(), directory


def test_config_and_manifest_shell_is_complete() -> None:
    assert {path.stem for path in (ROOT / "configs" / "tasks").glob("*.yaml")} == TASK_IDS
    assert {path.stem for path in (ROOT / "configs" / "scenarios").glob("*.yaml")} == TASK_IDS
    assert {path.stem for path in (ROOT / "configs" / "suites").glob("*.yaml")} == SUITES
    expected_manifests = {
        "validation",
        "test_id",
        "ood_object",
        "ood_spatial",
        "ood_geometry",
        "ood_motion_parameters",
        "ood_motion_law",
        "ood_physics",
        "ood_appearance",
        "ood_camera",
        "ood_action_delay",
        "stress",
    }
    assert {path.stem for path in (ROOT / "manifests" / "v1").glob("*.jsonl")} == expected_manifests


def test_runtime_dependency_contract_is_installable_and_frozen() -> None:
    with (ROOT / "pyproject.toml").open("rb") as stream:
        project = tomllib.load(stream)["project"]
    assert project["dependencies"] == [
        "h5py==3.16.0",
        "mujoco==3.11.0",
        "numpy>=1.26.4,<2.0",
        "PyYAML>=6.0",
        "robosuite==1.5.2",
    ]
