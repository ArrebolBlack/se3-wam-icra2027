from __future__ import annotations

import ast
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[2] / "src" / "se3_wam_benchmark"


def _imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module)
            names.update(f"{node.module}.{alias.name}" for alias in node.names)
    return names


def test_internal_modules_do_not_import_public_facade() -> None:
    for path in PACKAGE.rglob("*.py"):
        if path.name == "api.py":
            continue
        imports = _imports(path)
        assert "se3_wam_benchmark.api" not in imports, path
        assert not any(
            name.endswith(".api") and name.startswith("se3_wam_benchmark") for name in imports
        ), path


def test_model_dependency_is_isolated_to_the_explicit_adapter() -> None:
    consumers = []
    for path in PACKAGE.rglob("*.py"):
        if any(
            name == root or name.startswith(f"{root}.")
            for name in _imports(path)
            for root in ("se3_wam", "torch")
        ):
            consumers.append(path.relative_to(PACKAGE).as_posix())
    assert consumers == ["integrations/se3_wam.py"]


def test_scenario_spec_is_a_dependency_leaf() -> None:
    imports = _imports(PACKAGE / "scenarios" / "spec.py")
    banned = (
        "se3_wam_benchmark.envs",
        "se3_wam_benchmark.evaluation",
        "se3_wam_benchmark.scenarios.",
    )
    assert not any(name.startswith(banned) for name in imports)


def test_task_spec_does_not_reverse_import_its_registry() -> None:
    imports = _imports(PACKAGE / "tasks" / "spec.py")
    assert "se3_wam_benchmark.tasks.registry" not in imports


def test_environment_modules_do_not_reverse_import_scenario_generation() -> None:
    for path in (PACKAGE / "envs").rglob("*.py"):
        assert not any(
            name.startswith("se3_wam_benchmark.scenarios.")
            and not (
                name == "se3_wam_benchmark.scenarios.spec"
                or name.startswith("se3_wam_benchmark.scenarios.spec.")
            )
            for name in _imports(path)
        ), path


def test_environment_modules_do_not_reverse_import_evaluation() -> None:
    for path in (PACKAGE / "envs").rglob("*.py"):
        assert not any(
            name.startswith("se3_wam_benchmark.evaluation") for name in _imports(path)
        ), path


def test_family_modules_do_not_depend_on_another_family() -> None:
    for path in (PACKAGE / "envs" / "families").glob("*.py"):
        assert not any(
            name.startswith("se3_wam_benchmark.envs.families") for name in _imports(path)
        ), path


def test_offline_metric_modules_depend_only_on_pure_numeric_code() -> None:
    banned = ("mujoco", "robosuite", "se3_wam_benchmark.supervision", "se3_wam_benchmark.envs")
    for path in (PACKAGE / "evaluation" / "metrics").glob("*.py"):
        assert not any(name.startswith(banned) for name in _imports(path)), path


def test_formal_rollout_is_the_only_evaluation_module_that_imports_environments() -> None:
    consumers = []
    for path in (PACKAGE / "evaluation").rglob("*.py"):
        if any(name.startswith("se3_wam_benchmark.envs") for name in _imports(path)):
            consumers.append(path.relative_to(PACKAGE / "evaluation").as_posix())
    assert consumers == ["rollout.py"]


def test_single_episode_evaluator_does_not_import_environments_or_suite() -> None:
    imports = _imports(PACKAGE / "evaluation" / "evaluator.py")
    assert not any(name.startswith("se3_wam_benchmark.envs") for name in imports)
    assert "se3_wam_benchmark.evaluation.suite" not in imports


def test_offline_oracle_dependency_is_owned_only_by_formal_rollout() -> None:
    consumers = []
    for path in (PACKAGE / "evaluation").rglob("*.py"):
        imports = _imports(path)
        assert not imports & {
            f"se3_wam_benchmark.scenarios.{module}"
            for module in ("generator", "_recipes", "_validation", "_feasibility")
        }, path
        if "se3_wam_benchmark.scenarios._native_oracle" in imports:
            consumers.append(path.relative_to(PACKAGE / "evaluation").as_posix())
    assert consumers == ["rollout.py"]


def test_generation_stages_do_not_reverse_import_their_consumers() -> None:
    downstream = {
        "_recipes": {"generator", "_validation", "_feasibility", "_native_oracle"},
        "_validation": {"generator", "_feasibility", "_native_oracle"},
        "_feasibility": {"generator", "_recipes", "_validation"},
        "_native_oracle": {"generator", "_recipes", "_validation", "_feasibility"},
        "_family_parameters": {
            "generator",
            "_recipes",
            "_validation",
            "_feasibility",
            "_native_oracle",
        },
        "_rejection": {"generator", "_recipes", "_validation", "_feasibility", "_native_oracle"},
    }
    for module, consumers in downstream.items():
        imports = _imports(PACKAGE / "scenarios" / f"{module}.py")
        assert not imports & {
            f"se3_wam_benchmark.scenarios.{consumer}" for consumer in consumers
        }, module
        assert not any(name.startswith("se3_wam_benchmark.evaluation") for name in imports)
    oracle_imports = _imports(PACKAGE / "scenarios" / "_native_oracle.py")
    assert "se3_wam_benchmark.envs.factory" not in oracle_imports


def test_removed_products_have_no_import_surface() -> None:
    banned = (
        "se3wam_benchmark_contracts",
        "se3wam_benchmark_runtime",
        "se3wam_benchmark_rlinf",
        "robomimic",
    )
    for path in PACKAGE.rglob("*.py"):
        assert not any(name.startswith(banned) for name in _imports(path)), path
