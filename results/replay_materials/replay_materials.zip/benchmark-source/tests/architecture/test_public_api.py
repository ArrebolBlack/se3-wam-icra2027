from __future__ import annotations

import dataclasses
import inspect
from typing import get_type_hints

from se3_wam_benchmark import api
from se3_wam_benchmark.control import action
from se3_wam_benchmark.control.action import ActionMode, BenchmarkAction
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy
from se3_wam_benchmark.evaluation.result import EpisodeResult, EvaluationSummary
from se3_wam_benchmark.scenarios.spec import ScenarioSpec
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.spec import TaskSpec

PUBLIC = [
    "ScenarioSpec",
    "BenchmarkObservation",
    "BenchmarkAction",
    "BenchmarkPolicy",
    "EpisodeResult",
    "EvaluationSummary",
    "make_env",
    "evaluate",
]


def test_public_api_is_exact_and_owner_backed() -> None:
    assert api.__all__ == PUBLIC
    assert api.ScenarioSpec is ScenarioSpec
    assert api.BenchmarkObservation is BenchmarkObservation
    assert api.BenchmarkAction is BenchmarkAction
    assert api.BenchmarkPolicy is BenchmarkPolicy
    assert api.EpisodeResult is EpisodeResult
    assert api.EvaluationSummary is EvaluationSummary


def test_public_functions_have_frozen_signatures() -> None:
    assert (
        str(inspect.signature(api.make_env))
        == "(task_id: 'str', scenario_spec: 'ScenarioSpec', *, "
        "execution_translation_limit_m: 'float' = 0.05) -> 'DynamicManipulationEnv'"
    )
    assert (
        str(inspect.signature(api.evaluate))
        == "(policy: 'BenchmarkPolicy', suite: 'str | Path', *, shard_index: 'int' = 0, "
        "shard_count: 'int' = 1, wall_control_period_s: 'float | None' = None, "
        "execution_translation_limit_m: 'float' = 0.05) -> "
        "'EvaluationSummary'"
    )


def test_public_records_are_frozen_slotted_dataclasses() -> None:
    for record in (
        ScenarioSpec,
        BenchmarkObservation,
        BenchmarkAction,
        EpisodeResult,
        EvaluationSummary,
    ):
        assert dataclasses.is_dataclass(record)
        assert getattr(record, "__dataclass_params__").frozen
        assert "__slots__" in record.__dict__


def test_action_mode_is_owned_by_action_and_reused_without_expanding_the_facade() -> None:
    assert action.__all__ == ["ActionMode", "ActionSpec", "BenchmarkAction"]
    assert get_type_hints(action.ActionSpec)["mode"] == ActionMode
    assert get_type_hints(TaskSpec)["allowed_action_modes"] == tuple[ActionMode, ...]
    assert get_type_hints(ScenarioSpec)["action_mode"] == ActionMode
    assert api.__all__ == PUBLIC
