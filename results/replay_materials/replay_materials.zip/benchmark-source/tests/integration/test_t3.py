from __future__ import annotations

import math
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import fields, replace
from functools import lru_cache
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest
import yaml

import se3_wam_benchmark.scenarios._feasibility as scenario_feasibility
from se3_wam_benchmark.control.action import BenchmarkAction, _controller_action, _so3_log
from se3_wam_benchmark.envs.base import _load_asset_catalog, _ScenarioResetRejected
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.rotating_interaction import (
    RotatingInteractionEnv,
    _PathFacts,
    _RotatingOutcome,
)
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios._native_oracle import _RotatingOracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_rotating_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import JointPhysicsSpec, ScenarioSpec
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]


@lru_cache(maxsize=2)
def _document(task_id: str) -> Any:
    return load_yaml_strict(ROOT / f"configs/scenarios/{task_id}.yaml")


def _proposal(
    task_id: str,
    seed: int = 0,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task(task_id)
    recipe = _select_recipe(
        _document(task_id), partition=partition, factor=factor, recipe_name=name
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_rotating_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
        id_recipe=_select_recipe(
            _document(task_id),
            partition="test_id",
            factor=None,
            recipe_name=name,
        ),
    )
    return scenario


def test_t3_applies_free_and_hinge_joint_physics_without_cross_writes() -> None:
    baseline = _proposal("t3_phase")
    native_environment = make_env("t3_phase", baseline)
    try:
        assert isinstance(native_environment, RotatingInteractionEnv)
        native_environment.reset()
        for address, count in (
            (native_environment._wand_qvel_address, 6),
            (native_environment._wire_qvel_address, 1),
        ):
            np.testing.assert_array_equal(
                native_environment.sim.model._model.dof_damping[address : address + count],
                np.zeros(count),
            )
            np.testing.assert_array_equal(
                native_environment.sim.model._model.dof_frictionloss[address : address + count],
                np.zeros(count),
            )
    finally:
        native_environment.close()
    wand_id = baseline.object_states[0].instance_id
    wire_id = baseline.fixture_states[0].instance_id
    free_damping = tuple((index + 1) * 1e-6 for index in range(6))
    free_friction = tuple((index + 1) * 1e-7 for index in range(6))
    joints = (
        JointPhysicsSpec(
            wand_id,
            f"{wand_id}_joint0",
            free_damping,
            free_friction,
        ),
        JointPhysicsSpec(wire_id, f"{wire_id}_hinge", (0.000007,), (0.0000007,)),
    )
    scenario = replace(baseline, physics=replace(baseline.physics, joints=joints))
    environment = make_env("t3_phase", scenario)
    try:
        assert isinstance(environment, RotatingInteractionEnv)
        expected_addresses = {
            f"{wand_id}_joint0": environment._wand_qvel_address,
            f"{wire_id}_hinge": environment._wire_qvel_address,
        }
        for _ in range(2):
            environment.reset()
            assert {
                binding.spec.joint_name: binding.dof_address
                for binding in environment._compiled_joint_physics
            } == expected_addresses
            for binding in environment._compiled_joint_physics:
                stop = binding.dof_address + binding.dof_count
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_damping[binding.dof_address : stop],
                    binding.spec.damping_per_dof,
                )
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_frictionloss[binding.dof_address : stop],
                    binding.spec.friction_loss_per_dof,
                )
        _, _, done, info = environment.step(_neutral(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _neutral(environment: RotatingInteractionEnv, grip: float = 0.0) -> BenchmarkAction:
    width = 6 if environment._scenario_spec.action_mode == "E7" else 7
    value = np.ascontiguousarray([*np.zeros(width), grip], dtype=np.float32)
    value = np.ascontiguousarray(value, dtype=np.float64)
    value.setflags(write=False)
    return BenchmarkAction(environment._scenario_spec.action_mode, "delta", value)


def _action(
    environment: RotatingInteractionEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = 0.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    values = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _state(environment: RotatingInteractionEnv) -> dict[str, Any]:
    data = environment.sim.data._data
    return {
        "time": float(data.time),
        **{
            name: np.asarray(getattr(data, name)).copy()
            for name in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "eq_active",
                "xfrc_applied",
                "qfrc_applied",
            )
        },
    }


def _assert_state_equal(first: Mapping[str, Any], second: Mapping[str, Any]) -> None:
    assert first.keys() == second.keys()
    for name in first:
        np.testing.assert_array_equal(first[name], second[name], err_msg=name)


def _assert_observation(observation: BenchmarkObservation, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.rgb.dtype == np.uint8
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert np.isfinite(value).all()
            assert value.flags.c_contiguous and not value.flags.writeable


def test_phase_real_reset_export_attachment_and_native_wire_motion() -> None:
    scenario = _proposal("t3_phase")
    environment = make_env("t3_phase", scenario)
    try:
        assert isinstance(environment, RotatingInteractionEnv)
        observation = environment.reset()
        assert environment.export_scenario() == scenario
        assert environment._attachment_active
        assert environment._attachment_constraint_residual < 1e-12
        model = environment.sim.model._model
        equality = environment._attachment_eq_id
        assert model.eq_data[equality, 10] == 1.0
        np.testing.assert_array_equal(model.eq_solref[equality], (0.002, 1.0))
        np.testing.assert_array_equal(model.eq_solimp[equality], (0.95, 0.99, 0.001, 0.5, 2.0))
        assert len(environment._path_points) == 13
        assert len(environment._wire_geom_ids) == 12
        assert observation["agentview_image"].shape == (224, 224, 3)
        initial_angle = float(environment.sim.data.qpos[environment._wire_qpos_address])
        for _ in range(4):
            observation, reward, done, info = environment.step(_neutral(environment, grip=1.0))
            assert not done and reward == 0.0 and info["failure_code"] is None
        assert float(environment.sim.data.qpos[environment._wire_qpos_address]) < initial_angle
        assert environment.sim.data.eq_active[environment._attachment_eq_id]
    finally:
        environment.close()


def test_full_real_scored_t0_is_gravity_supported_without_pregrasp_or_attachment() -> None:
    scenario = _proposal("t3_full")
    environment = make_env("t3_full", scenario)
    try:
        assert isinstance(environment, RotatingInteractionEnv)
        observation = environment.reset()
        assert environment.export_scenario() == scenario
        steps, supported, pregrasp, attached = environment._preparation_diagnostics
        assert steps == 28 * 25 and supported >= 20 * 25
        assert pregrasp == 0 and not attached
        assert not environment._attachment_active
        assert not environment.sim.data.eq_active[environment._attachment_eq_id]
        assert environment._path_facts().path_distance_m > 0.0
        assert observation["agentview_image"].shape == (224, 224, 3)
    finally:
        environment.close()


def test_full_actual_bilateral_hold_activates_current_pose_weld_without_a_jump() -> None:
    environment = make_env("t3_full", _proposal("t3_full"))
    try:
        environment.reset()
        oracle = _RotatingOracle(environment)
        for _ in range(100):
            _, _, done, info = environment.step(oracle.action(environment))
            if environment._attachment_active:
                break
        assert not done and info["failure_code"] is None
        assert environment._attachment_active
        assert 0.0 < info["events"]["wand_acquisition"] <= environment.sim.data.time
        assert environment._outcome.bilateral_steps >= 25
        assert math.isfinite(environment._attachment_constraint_residual)
        qpos = environment.sim.data.qpos.copy()
        qvel = environment.sim.data.qvel.copy()
        environment._set_attachment(False)
        np.testing.assert_array_equal(environment.sim.data.qpos, qpos)
        np.testing.assert_array_equal(environment.sim.data.qvel, qvel)
        assert not environment.sim.data.eq_active[environment._attachment_eq_id]
    finally:
        environment.close()


def test_phase_then_full_preparation_is_repeatable_in_one_process() -> None:
    for repetition in range(2):
        for task_id in ("t3_phase", "t3_full"):
            environment = make_env(task_id, _proposal(task_id))
            try:
                assert isinstance(environment, RotatingInteractionEnv)
                try:
                    environment.reset()
                except _ScenarioResetRejected as error:
                    raise AssertionError(
                        f"{task_id} preparation {repetition} failed with "
                        f"{environment._preparation_diagnostics}"
                    ) from error
                initial = _state(environment)
                for _ in range(3):
                    environment.step(_neutral(environment, grip=1.0))
                environment.reset()
                _assert_state_equal(initial, _state(environment))
                steps, supported, pregrasp, _ = environment._preparation_diagnostics
                if task_id == "t3_full":
                    assert steps == 28 * 25 and supported >= 20 * 25 and pregrasp == 0
                    assert not environment._attachment_active
                else:
                    assert 38 * 25 <= steps <= (140 + 38) * 25 and pregrasp > 0
                    assert environment._attachment_active
            finally:
                environment.close()


def test_native_wire_driver_sets_original_phase_before_each_physics_step(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal("t3_phase")
    bodies = tuple(
        replace(
            body,
            mass_kg=1.35 * body.mass_kg,
            diagonal_inertia_kg_m2=tuple(1.35 * value for value in body.diagonal_inertia_kg_m2),
        )
        if body.entity_id == "wire"
        else body
        for body in scenario.physics.bodies
    )
    scenario = replace(scenario, physics=replace(scenario.physics, bodies=bodies))
    environment = make_env("t3_phase", scenario)
    try:
        environment.reset()
        initial = environment._wire_initial_phase()
        speed = environment._motion.rotation.angular_speed_rad_s
        native_pre_action = environment._pre_action
        samples = []

        def observe_driver(action: Any, policy_step: bool = False) -> None:
            native_pre_action(action, policy_step)
            data = environment.sim.data
            samples.append(
                (
                    float(data.time),
                    float(data.qpos[environment._wire_qpos_address]),
                    float(data.qvel[environment._wire_qvel_address]),
                )
            )

        monkeypatch.setattr(environment, "_pre_action", observe_driver)
        for _ in range(20):
            _, _, done, info = environment.step(_neutral(environment, grip=1.0))
            assert not done and info["failure_code"] is None
        assert len(samples) == 500
        for time_s, phase, actual_speed in samples:
            assert phase == initial + speed * time_s
            assert actual_speed == speed
    finally:
        environment.close()


@pytest.mark.parametrize("radial_offset_m", [0.028, 0.040])
def test_t3_initial_threading_rejects_native_clearance_and_entry_violations(
    radial_offset_m: float,
) -> None:
    environment = make_env("t3_phase", _proposal("t3_phase"))
    try:
        environment.reset()
        environment._set_attachment(False)
        environment.sim.data.qpos[environment._wand_qpos_address + 1] += radial_offset_m
        with pytest.raises(_ScenarioResetRejected):
            environment._verify_initial_threading()
    finally:
        environment.close()


def test_t3_native_bad_qpos_is_not_disguised_by_mujoco_recovery(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment = make_env("t3_phase", _proposal("t3_phase"))
    try:
        environment.reset()
        data = environment.sim.data._data
        monkeypatch.chdir(tmp_path)
        data.qpos[environment._wand_qpos_address] = math.nan
        _, reward, done, info = environment.step(_neutral(environment, grip=1.0))
        assert done and reward == 0.0 and not info["success"]
        assert info["failure_code"] == "invalid_state" and info["terminal_time_s"] == 0.0
        assert data.warning[mujoco.mjtWarning.mjWARN_BADQPOS].number > 0
        assert np.isfinite(data.qpos).all()
        assert environment._episode_tick == 1
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


def _outcome_update(
    outcome: _RotatingOutcome,
    *,
    path: _PathFacts | None = None,
    finite: bool = True,
    attachment_active: bool = True,
    bilateral_contact: bool = True,
    any_finger_contact: bool = True,
    loop_orientation_error_rad: float = 0.0,
    unsafe_stage_contact: bool = False,
    release_requested: bool = False,
    wire_impulse_n_s: float = 0.0,
    penetration_m: float = 0.0,
    bottom_z_m: float = 0.90,
    workspace_radius_m: float = 0.10,
) -> None:
    outcome.update(
        time_s=(outcome.physics_step + 1) * 0.002,
        finite=finite,
        path=path or _PathFacts(0.0, 0.0, 0.18, 0.02),
        attachment_active=attachment_active,
        bilateral_contact=bilateral_contact,
        any_finger_contact=any_finger_contact,
        loop_orientation_error_rad=loop_orientation_error_rad,
        unsafe_stage_contact=unsafe_stage_contact,
        release_requested=release_requested,
        wire_impulse_n_s=wire_impulse_n_s,
        penetration_m=penetration_m,
        bottom_z_m=bottom_z_m,
        workspace_radius_m=workspace_radius_m,
    )


def _phase_outcome(path: _PathFacts | None = None) -> _RotatingOutcome:
    outcome = _RotatingOutcome(load_task("t3_phase"), _proposal("t3_phase").geometry, 0.002)
    outcome.begin(path or _PathFacts(0.0, 0.0, 0.18, 0.02))
    return outcome


def test_t3_phase_outcome_requires_explicit_scored_start_initialization() -> None:
    outcome = _RotatingOutcome(load_task("t3_phase"), _proposal("t3_phase").geometry, 0.002)
    for invalid_distance in (math.nan, math.inf, math.nextafter(0.0, -math.inf)):
        with pytest.raises(ValueError, match="finite non-negative"):
            outcome.begin(_PathFacts(0.0, 0.0, 0.18, invalid_distance))
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        _outcome_update(outcome)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        outcome.invalidate(0.0)
    outcome.begin(_PathFacts(0.0, 0.0, 0.18, 0.02))
    outcome.invalidate(0.0)
    assert outcome.failure_code == "invalid_state"
    assert outcome.events == {"scored_phase_sample": 0.0}


@pytest.mark.parametrize(
    ("safe", "failing", "failure_code"),
    [
        ({"unsafe_stage_contact": False}, {"unsafe_stage_contact": True}, "stage_block"),
        (
            {"finite": True},
            {
                "finite": False,
                "path": _PathFacts(0.90, 0.0, 0.01, 0.01),
                "wire_impulse_n_s": math.nextafter(0.020, math.inf),
                "bottom_z_m": math.nextafter(0.75, -math.inf),
                "workspace_radius_m": math.nextafter(0.50, math.inf),
            },
            "invalid_state",
        ),
        (
            {"wire_impulse_n_s": 0.020},
            {
                "path": _PathFacts(0.90, 0.0, 0.01, 0.01),
                "wire_impulse_n_s": math.nextafter(0.020, math.inf),
            },
            "wire_contact",
        ),
        (
            {"workspace_radius_m": 0.50},
            {
                "path": _PathFacts(0.90, 0.0, 0.01, 0.01),
                "workspace_radius_m": math.nextafter(0.50, math.inf),
            },
            "workspace_exit",
        ),
        (
            {"bottom_z_m": 0.75},
            {
                "path": _PathFacts(0.90, 0.0, 0.01, 0.01),
                "bottom_z_m": math.nextafter(0.75, -math.inf),
            },
            "drop",
        ),
    ],
)
def test_rotating_outcome_immediate_boundaries_and_invalid_priority(
    safe: dict[str, Any], failing: dict[str, Any], failure_code: str
) -> None:
    task = load_task("t3_phase")
    geometry = _proposal("t3_phase").geometry
    safe_outcome = _RotatingOutcome(task, geometry, 0.002)
    safe_outcome.begin(_PathFacts(0.0, 0.0, 0.18, 0.02))
    _outcome_update(safe_outcome, **safe)
    assert safe_outcome.failure_code is None and not safe_outcome.success

    failing_outcome = _RotatingOutcome(task, geometry, 0.002)
    failing_outcome.begin(_PathFacts(0.0, 0.0, 0.18, 0.02))
    _outcome_update(failing_outcome, **failing)
    assert failing_outcome.failure_code == failure_code
    assert not failing_outcome.success and failing_outcome.terminal_time_s == 0.002
    if failure_code == "invalid_state":
        assert failing_outcome.events == {"scored_phase_sample": 0.0}
    else:
        assert failing_outcome.events[failure_code] == 0.002


def test_rotating_outcome_counter_backtrack_and_timeout_boundaries_are_exact() -> None:
    outcome = _phase_outcome()

    above_penetration = math.nextafter(0.004, math.inf)
    for _ in range(2):
        _outcome_update(outcome, penetration_m=above_penetration)
    _outcome_update(outcome, penetration_m=0.004)
    assert outcome.penetration_steps == 0 and outcome.failure_code is None
    for _ in range(2):
        _outcome_update(outcome, penetration_m=above_penetration)
    _outcome_update(outcome, penetration_m=above_penetration)
    assert outcome.failure_code == "wire_contact"
    assert outcome.events["wire_contact"] == outcome.terminal_time_s

    outcome.reset()
    exact_deviation = _PathFacts(0.10, 0.030, 0.16, 0.02)
    outcome.begin(exact_deviation)
    above_deviation = replace(exact_deviation, path_distance_m=math.nextafter(0.030, math.inf))
    for _ in range(25):
        _outcome_update(outcome, path=exact_deviation)
    assert outcome.deviation_steps == 0 and outcome.failure_code is None
    for _ in range(24):
        _outcome_update(outcome, path=above_deviation)
    _outcome_update(outcome, path=exact_deviation)
    assert outcome.deviation_steps == 0 and outcome.failure_code is None
    for _ in range(24):
        _outcome_update(outcome, path=above_deviation)
    assert outcome.failure_code is None
    _outcome_update(outcome, path=above_deviation)
    assert outcome.failure_code == "path_deviation"
    assert outcome.events["path_deviation"] == outcome.terminal_time_s

    outcome.reset()
    maximum = 0.30
    exact_backtrack = 0.25
    maximum_path = _PathFacts(maximum, 0.0, 0.18, 0.20)
    outcome.begin(maximum_path)
    _outcome_update(outcome, path=_PathFacts(0.0, 0.0, 0.30, 0.0))
    _outcome_update(outcome, path=maximum_path)
    _outcome_update(outcome, path=_PathFacts(exact_backtrack, 0.0, 0.18, 0.20))
    assert outcome.failure_code is None
    outcome.reset()
    outcome.begin(maximum_path)
    _outcome_update(outcome, path=_PathFacts(0.0, 0.0, 0.30, 0.0))
    _outcome_update(outcome, path=maximum_path)
    _outcome_update(
        outcome,
        path=_PathFacts(math.nextafter(exact_backtrack, -math.inf), 0.0, 0.18, 0.20),
    )
    assert outcome.failure_code == "path_backtrack"
    assert outcome.events["path_backtrack"] == outcome.terminal_time_s

    outcome.reset()
    outcome.begin(_PathFacts(0.0, 0.0, 0.18, 0.02))
    terminal_step = round(outcome.horizon_s / outcome.timestep_s)
    outcome.physics_step = terminal_step - 2
    _outcome_update(outcome)
    assert outcome.failure_code is None
    _outcome_update(outcome)
    assert outcome.failure_code == "timeout"
    assert outcome.terminal_time_s == outcome.horizon_s
    assert outcome.events["timeout"] == outcome.horizon_s


def test_phase_and_full_outcomes_require_the_frozen_physical_sequence() -> None:
    terminal_path = _PathFacts(0.85, 0.0, 0.055, 0.09)
    phase = _phase_outcome(terminal_path)
    _outcome_update(phase, path=terminal_path)
    assert not phase.success and "loop_entry" not in phase.events
    _outcome_update(phase, path=_PathFacts(0.0, 0.0, 0.30, 0.0))
    _outcome_update(phase, path=terminal_path)
    assert phase.success and phase.failure_code is None
    assert tuple(phase.events) == (
        "scored_phase_sample",
        "phase_alignment",
        "loop_entry",
        "path_progress_0_60",
        "terminal_arrival",
        "success",
    )

    full = _RotatingOutcome(load_task("t3_full"), _proposal("t3_full").geometry, 0.002)
    for _ in range(25):
        _outcome_update(full, path=_PathFacts(0.10, 0.0, 0.16, 0.02))
    assert full.events["wand_acquisition"] == pytest.approx(0.050)
    _outcome_update(full, path=_PathFacts(0.85, 0.0, 0.02, 0.01))
    assert "terminal_arrival" in full.events and not full.success
    _outcome_update(full, path=_PathFacts(1.0, 0.046, 0.046, 0.18))
    assert "wire_exit" in full.events and not full.success
    _outcome_update(full, path=_PathFacts(0.80, 0.046, 0.046, 0.18))
    assert full.failure_code is None and not full.success
    _outcome_update(
        full,
        path=_PathFacts(1.0, 0.046, 0.046, 0.18),
        attachment_active=False,
        bilateral_contact=False,
        any_finger_contact=False,
        release_requested=True,
    )
    assert full.success and full.failure_code is None
    assert full.events["wand_release"] == full.terminal_time_s
    assert full.events["success"] == full.terminal_time_s

    full.reset()
    _outcome_update(full, release_requested=True, bilateral_contact=False)
    assert full.failure_code is None
    for _ in range(25):
        _outcome_update(full)
    _outcome_update(
        full,
        release_requested=True,
        attachment_active=False,
        bilateral_contact=False,
    )
    assert full.failure_code == "premature_release"
    assert full.events["premature_release"] == full.terminal_time_s


def test_t3_stage_facts_use_monotonic_accepted_path_progress_and_freeze_on_failure() -> None:
    outcome = _RotatingOutcome(load_task("t3_phase"), _proposal("t3_phase").geometry, 0.002)
    outcome.begin(_PathFacts(0.0, 0.02, 0.18, 0.18))
    _outcome_update(outcome, path=_PathFacts(0.0, 0.020, 0.18, 0.020))
    _outcome_update(outcome, path=_PathFacts(0.30, 0.030, 0.12, 0.090))
    facts = outcome._stage_facts()
    assert facts[:2] == (
        ("phase_alignment", True, 1.0, 0),
        ("loop_entry", True, 1.0, 0),
    )
    assert facts[2] == ("path_progress_0_60", False, pytest.approx(0.5), 0)

    _outcome_update(outcome, path=_PathFacts(0.25, 0.030, 0.13, 0.090))
    assert outcome.failure_code is None
    assert outcome._stage_facts()[2] == (
        "path_progress_0_60",
        False,
        pytest.approx(0.5),
        0,
    )

    before_failure = outcome._stage_facts()
    _outcome_update(
        outcome,
        path=_PathFacts(0.60, 0.0, 0.055, 0.0),
        wire_impulse_n_s=math.nextafter(0.020, math.inf),
    )
    assert outcome.failure_code == "wire_contact"
    assert outcome._stage_facts() == before_failure


def test_t3_full_stage_facts_use_compound_terminal_and_wire_exit_distance() -> None:
    outcome = _RotatingOutcome(load_task("t3_full"), _proposal("t3_full").geometry, 0.002)
    for _ in range(25):
        _outcome_update(outcome, path=_PathFacts(0.0, 0.030, 0.15, 0.020))
    assert tuple(item[:2] for item in outcome._stage_facts()[:3]) == (
        ("wand_acquisition", True),
        ("phase_alignment", True),
        ("loop_entry", True),
    )

    _outcome_update(outcome, path=_PathFacts(0.60, 0.020, 0.110, 0.0))
    assert outcome._stage_facts()[3] == ("path_progress_0_60", True, 1.0, 0)
    assert outcome._stage_facts()[4] == ("terminal_arrival", False, 0.0, 0)
    _outcome_update(outcome, path=_PathFacts(0.70, 0.020, 0.0825, 0.0))
    assert outcome._stage_facts()[4] == (
        "terminal_arrival",
        False,
        pytest.approx(0.5),
        0,
    )
    _outcome_update(outcome, path=_PathFacts(0.67, 0.020, 0.090, 0.0))
    assert outcome._stage_facts()[4] == (
        "terminal_arrival",
        False,
        pytest.approx(0.5),
        0,
    )

    _outcome_update(outcome, path=_PathFacts(0.85, 0.020, 0.055, 0.020))
    assert outcome._stage_facts()[4] == ("terminal_arrival", True, 1.0, 0)
    assert outcome._stage_facts()[5] == ("wire_exit", False, 0.0, 0)
    _outcome_update(outcome, path=_PathFacts(0.86, 0.030, 0.055, 0.030))
    assert outcome._stage_facts()[5] == (
        "wire_exit",
        False,
        pytest.approx(0.4),
        0,
    )
    _outcome_update(outcome, path=_PathFacts(0.86, 0.045, 0.055, 0.045))
    assert outcome._stage_facts()[5] == ("wire_exit", True, 1.0, 0)
    assert outcome._stage_facts()[6] == ("wand_release", False, 0.0, 0)


@pytest.mark.parametrize(
    ("task_id", "name", "representation", "partition", "factor"),
    [
        ("t3_phase", "e7_agentview", "delta", "test_id", None),
        ("t3_phase", "j8_agentview_wrist", "absolute", "ood", "action_delay"),
        ("t3_full", "e7_agentview_wrist", "absolute", "ood", "action_delay"),
        ("t3_full", "j8_agentview", "delta", "test_id", None),
    ],
)
def test_t3_native_action_paths_start_at_scored_zero_with_exact_delay_and_rgbd(
    task_id: str,
    name: str,
    representation: str,
    partition: Partition,
    factor: str | None,
) -> None:
    scenario = _proposal(task_id, name=name, partition=partition, factor=factor)
    environment = make_env(task_id, scenario)
    try:
        raw = environment.reset()
        assert environment.export_scenario() == scenario
        assert environment.timestep == environment._episode_tick == 0
        assert environment._outcome.physics_step == 0
        assert environment.sim.data.time == environment.cur_time == 0.0
        assert environment._action_spec is environment._action_delay_queue is None
        assert environment._previous_eef_quaternion_xyzw is None
        views = 2 if name.endswith("wrist") else 1
        _assert_observation(environment._benchmark_observation(raw), 0, views)

        applied: list[np.ndarray] = []
        native_pre_action = environment._pre_action

        def observe_action(action: np.ndarray, policy_step: bool = False) -> None:
            if policy_step:
                applied.append(np.asarray(action).copy())
            native_pre_action(action, policy_step)

        environment._pre_action = observe_action
        issued = []
        for tick in range(4):
            action = _action(
                environment,
                representation,
                displacement=0.0001 * ((tick % 3) - 1),
                gripper=1.0 if task_id == "t3_phase" else 0.0,
            )
            issued.append(action)
            position, rotation, joints = environment._achieved_controller_state()
            raw, reward, done, info = environment.step(action)
            assert not done and reward == 0.0 and info["failure_code"] is None
            if tick < scenario.action_delay_steps:
                np.testing.assert_array_equal(applied[-1], np.zeros(environment.action_dim))
            else:
                expected = _controller_action(
                    issued[tick - scenario.action_delay_steps],
                    environment._action_spec,
                    achieved_eef_position=position,
                    achieved_eef_rotation=rotation,
                    achieved_joint_position=joints,
                )
                if scenario.action_mode == "E7":
                    expected = expected.astype(np.float32).astype(np.float64)
                np.testing.assert_array_equal(applied[-1], expected)
            assert environment._outcome.physics_step == (tick + 1) * 25
            assert environment.sim.data.time == pytest.approx((tick + 1) / 20.0)
            _assert_observation(environment._benchmark_observation(raw), tick + 1, views)
            np.testing.assert_array_equal(
                raw["robot0_eef_pos"],
                environment.sim.data.site_xpos[environment.robots[0].eef_site_id["right"]],
            )
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "name"),
    [
        ("t3_phase", "e7_agentview"),
        ("t3_phase", "j8_agentview"),
        ("t3_full", "e7_agentview"),
        ("t3_full", "j8_agentview"),
    ],
)
def test_t3_public_generator_runs_the_exact_real_oracle_and_full_native_release(
    task_id: str,
    name: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}
    native_oracle = scenario_feasibility._run_native_oracle

    def observe_oracle(environment: RotatingInteractionEnv) -> dict[str, Any]:
        transitions: list[dict[str, Any]] = []
        native_attachment = environment._set_attachment

        def observe_attachment(active: bool) -> None:
            if active == environment._attachment_active:
                native_attachment(active)
                return
            before_qpos = environment.sim.data.qpos.copy()
            before_qvel = environment.sim.data.qvel.copy()
            before_active = bool(environment.sim.data.eq_active[environment._attachment_eq_id])
            native_attachment(active)
            transitions.append(
                {
                    "requested": active,
                    "qpos_equal": np.array_equal(before_qpos, environment.sim.data.qpos),
                    "qvel_equal": np.array_equal(before_qvel, environment.sim.data.qvel),
                    "before_active": before_active,
                    "after_active": bool(
                        environment.sim.data.eq_active[environment._attachment_eq_id]
                    ),
                }
            )

        environment._set_attachment = observe_attachment
        result = native_oracle(environment)
        assert result["success"], result
        first_transitions = list(transitions)
        terminal_state = _state(environment)
        repeat_verified = False
        if task_id == "t3_full" and name == "j8_agentview":
            environment.reset()
            transitions.clear()
            repeated = native_oracle(environment)
            assert repeated == result
            _assert_state_equal(terminal_state, _state(environment))
            assert [item["requested"] for item in transitions] == [True, False]
            repeat_verified = True
        captured.update(
            result=result,
            transitions=first_transitions,
            tick=environment.timestep,
            physics_step=environment._outcome.physics_step,
            attachment_active=environment._attachment_active,
            pending=tuple(environment._action_delay_queue._pending),
            repeat_verified=repeat_verified,
        )
        return result

    monkeypatch.setattr(scenario_feasibility, "_run_native_oracle", observe_oracle)
    generated = generate_scenario(
        load_task(task_id),
        ROOT / f"configs/scenarios/{task_id}.yaml",
        0,
        partition="test_id",
        recipe_name=name,
    )
    assert generated == _proposal(task_id, name=name)
    result = captured["result"]
    assert result["success"] is True and result["failure_code"] is None
    expected_stages = (
        (
            "phase_alignment",
            "loop_entry",
            "path_progress_0_60",
            "terminal_arrival",
        )
        if task_id == "t3_phase"
        else (
            "wand_acquisition",
            "phase_alignment",
            "loop_entry",
            "path_progress_0_60",
            "terminal_arrival",
            "wire_exit",
            "wand_release",
        )
    )
    assert tuple(item[0] for item in result["stage_facts"]) == expected_stages
    assert all(item[1] and item[2] == 1.0 for item in result["stage_facts"])
    assert result["terminal_time_s"] == pytest.approx(captured["physics_step"] * 0.002, abs=1e-9)
    assert captured["tick"] == (captured["physics_step"] + 24) // 25
    assert captured["pending"] == ()
    if task_id == "t3_phase":
        assert list(result["events"]) == [
            "scored_phase_sample",
            "phase_alignment",
            "loop_entry",
            "wire_path_progress",
            "terminal_arrival",
            "success",
        ]
        assert captured["transitions"] == []
        assert captured["attachment_active"] is True
    else:
        assert list(result["events"]) == [
            "scored_phase_sample",
            "wand_acquisition",
            "phase_alignment",
            "loop_entry",
            "wire_path_progress",
            "terminal_arrival",
            "wire_exit",
            "wand_release",
            "success",
        ]
        transitions = captured["transitions"]
        assert [item["requested"] for item in transitions] == [True, False]
        assert all(item["qpos_equal"] and item["qvel_equal"] for item in transitions)
        assert [(item["before_active"], item["after_active"]) for item in transitions] == [
            (False, True),
            (True, False),
        ]
        assert captured["attachment_active"] is False
        if task_id == "t3_full" and name == "j8_agentview":
            assert captured["repeat_verified"] is True


def test_rotating_real_oracle_runs_through_the_single_formal_rollout(tmp_path: Path) -> None:
    task = load_task("t3_phase")
    scenario = _proposal(task.task_id, 0, "e7_agentview")
    trace = _rollout_episode(
        task,
        scenario,
        None,
        scenario_id="v1:test_id:t3_phase:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
        _native_oracle=True,
        record_directory=tmp_path,
    )
    assert trace.success and trace.failure_code is None
    assert trace.steps[-1].event_flags == (True,) * len(trace.event_names)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(range(len(trace.steps)))
    assert _evaluate_episode(trace).success


def test_t3_public_generator_preserves_a_deterministic_structured_rejection(tmp_path: Path) -> None:
    document = deepcopy(_document("t3_full"))
    recipe = document["recipes"]["stress"]["e7_agentview"]["choices"][0]
    assert recipe["fixture_states"][0]["quaternion_world_xyzw"]["phase_x_rad"] == -0.25
    recipe["physics"]["gravity_world_m_s2"] = [0.0, 0.0, 9.81]
    document["recipes"]["stress"]["e7_agentview"] = recipe
    recipe_path = tmp_path / "upward_gravity.yaml"
    recipe_path.write_text(yaml.safe_dump(document), encoding="utf-8")
    facts = []
    for _ in range(2):
        with pytest.raises(_CaptureProposalRejected) as caught:
            generate_scenario(
                load_task("t3_full"),
                recipe_path,
                0,
                partition="stress",
                recipe_name="e7_agentview",
            )
        failure = caught.value
        assert failure.stage == "oracle" and failure.failure_code == "timeout"
        assert failure.terminal_time_s == pytest.approx(32.0, abs=1e-9)
        assert list(failure.events) == [
            "scored_phase_sample",
            "wand_acquisition",
            "phase_alignment",
            "loop_entry",
            "timeout",
        ]
        facts.append((failure.terminal_time_s, failure.events))
    assert facts[0] == facts[1]


@pytest.mark.parametrize(
    ("task_id", "name", "representation", "partition", "factor"),
    [
        ("t3_phase", "j8_agentview", "absolute", "test_id", None),
        ("t3_full", "e7_agentview_wrist", "delta", "ood", "action_delay"),
    ],
)
def test_t3_repeat_reset_manifest_and_fixed_action_replay_are_exact(
    task_id: str,
    name: str,
    representation: str,
    partition: Partition,
    factor: str | None,
    tmp_path: Path,
) -> None:
    scenario = generate_scenario(
        load_task(task_id),
        ROOT / f"configs/scenarios/{task_id}.yaml",
        0,
        partition=partition,
        factor=factor,
        recipe_name=name,
    )
    assert scenario == _proposal(task_id, name=name, partition=partition, factor=factor)
    first = make_env(task_id, scenario)
    second: RotatingInteractionEnv | None = None
    try:
        raw = first.reset()
        initial_state = _state(first)
        initial_observation = first._benchmark_observation(raw)
        for _ in range(3):
            first.step(
                _action(
                    first,
                    representation,
                    displacement=0.0001,
                    gripper=1.0 if task_id == "t3_phase" else -1.0,
                )
            )
        raw = first.reset()
        _assert_state_equal(initial_state, _state(first))
        assert first._action_spec is first._action_delay_queue is None
        assert first._previous_eef_quaternion_xyzw is None
        assert first._outcome.events == {"scored_phase_sample": 0.0}
        assert first._outcome.physics_step == 0
        observed = first._benchmark_observation(raw)
        for field in fields(observed):
            np.testing.assert_array_equal(
                getattr(observed, field.name), getattr(initial_observation, field.name)
            )

        exported = first.export_scenario()
        manifest = ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    f"v1:{partition}:{factor + ':' if factor else ''}{task_id}:000000",
                    task_id,
                    partition,
                    factor,
                    0,
                    exported,
                ),
            )
        )
        path = tmp_path / "rotating.jsonl"
        write_manifest(manifest, path)
        assert load_manifest(path) == manifest
        second = make_env(task_id, load_manifest(path).rows[0].scenario)
        second_raw = second.reset()
        second_observed = second._benchmark_observation(second_raw)
        assert second.export_scenario() == scenario
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "jnt_type",
            "jnt_axis",
            "actuator_gear",
            "actuator_ctrlrange",
            "eq_type",
            "eq_data",
            "eq_solref",
            "eq_solimp",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_type",
            "light_pos",
            "light_dir",
            "light_diffuse",
            "light_specular",
        ):
            np.testing.assert_array_equal(
                getattr(first.sim.model._model, field),
                getattr(second.sim.model._model, field),
                err_msg=field,
            )
        for tick in range(7):
            _assert_state_equal(_state(first), _state(second))
            left = observed if tick == 0 else first._benchmark_observation(raw)
            right = second_observed if tick == 0 else second._benchmark_observation(second_raw)
            for field in fields(left):
                np.testing.assert_array_equal(
                    getattr(left, field.name), getattr(right, field.name), err_msg=field.name
                )
            if tick < 6:
                action = _action(
                    first,
                    representation,
                    displacement=0.0001 * ((tick % 3) - 1),
                    gripper=1.0 if task_id == "t3_phase" else 0.0,
                )
                raw, first_reward, first_done, first_info = first.step(action)
                second_raw, second_reward, second_done, second_info = second.step(action)
                assert (first_reward, first_done, first_info) == (
                    second_reward,
                    second_done,
                    second_info,
                )
    finally:
        first.close()
        if second is not None:
            second.close()


def test_t3_native_wire_contact_uses_the_maximum_single_wand_wire_impulse() -> None:
    environment = make_env("t3_phase", _proposal("t3_phase"))
    try:
        environment.reset()
        environment._set_attachment(False)
        model, data = environment.sim.model._model, environment.sim.data._data
        # Controlled native negative-path initial state; the oracle never writes wand state.
        data.qpos[environment._wand_qpos_address + 1] += 0.024
        data.qvel[environment._wand_qvel_address + 1] = 4.0
        environment.sim.forward()
        samples: list[tuple[float, float, int]] = []
        native_update = environment._outcome.update

        def observe_update(**sample: Any) -> None:
            force = np.empty(6, dtype=np.float64)
            direct_impulse = 0.0
            direct_penetration = 0.0
            count = 0
            for index in range(data.ncon):
                contact = data.contact[index]
                pair = {int(contact.geom1), int(contact.geom2)}
                if not (
                    pair.intersection(environment._wire_geom_ids)
                    and pair.intersection(environment._wand_geom_ids)
                ):
                    continue
                mujoco.mj_contactForce(model, data, index, force)
                assert np.isfinite(force).all() and force[0] >= 0.0
                direct_impulse = max(direct_impulse, float(np.linalg.norm(force[:3])) * 0.002)
                direct_penetration = max(direct_penetration, max(0.0, -float(contact.dist)))
                count += 1
            assert sample["wire_impulse_n_s"] == pytest.approx(direct_impulse, rel=0.0, abs=1e-12)
            assert sample["penetration_m"] == pytest.approx(direct_penetration, rel=0.0, abs=1e-12)
            native_update(**sample)
            samples.append((direct_impulse, direct_penetration, count))

        environment._outcome.update = observe_update
        _, _, done, info = environment.step(_neutral(environment, grip=1.0))
        assert done and not info["success"]
        assert info["failure_code"] == "wire_contact"
        assert any(count > 0 for _, _, count in samples)
        assert max(impulse for impulse, _, _ in samples) > 0.020
    finally:
        environment.close()
