from __future__ import annotations

import ast
import copy
import inspect
import math
from collections.abc import Mapping
from dataclasses import fields, replace
from functools import lru_cache
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest
import robosuite.macros as robosuite_macros
import yaml

from se3_wam_benchmark.control.action import BenchmarkAction, _controller_action, _so3_log
from se3_wam_benchmark.envs.base import (
    _fingerpad_contacts,
    _load_asset_catalog,
    _resolve_joint_physics,
)
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.moving_placement import (
    MovingPlacementEnv,
    _PlacementGeometryFacts,
    _PlacementOutcome,
)
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios._feasibility import _validate_capture_reset
from se3_wam_benchmark.scenarios._native_oracle import _PlacementOracle, _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_placement_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import JointPhysicsSpec, ScenarioSpec
from se3_wam_benchmark.sensing.camera import _metric_depth
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]


@lru_cache(maxsize=2)
def _document(task_id: str) -> Any:
    return load_yaml_strict(ROOT / f"configs/scenarios/{task_id}.yaml")


def _proposal(
    task_id: str,
    seed: int = 6,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    recipe = _select_recipe(
        _document(task_id), partition=partition, factor=factor, recipe_name=name
    )
    scenario = _materialize_recipe(
        load_task(task_id), recipe, np.random.Generator(np.random.PCG64(seed))
    )
    _validate_placement_declarative_scenario(
        load_task(task_id),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
        id_recipe=_select_recipe(
            _document(task_id), partition="test_id", factor=None, recipe_name=name
        ),
    )
    return scenario


@pytest.mark.parametrize(
    "name", ("e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist")
)
def test_t2_trans_spatial_recipe_shifts_exactly_one_old_db0_axis(name: str) -> None:
    shifted_axes = set()
    for seed in range(16):
        scenario = _proposal("t2_trans", seed, name, partition="ood", factor="spatial")
        goal = scenario.fixture_states[0]
        x, y, z = goal.position_world_m
        x_shifted = not -0.13 <= x <= -0.08
        y_shifted = not -0.18 <= y <= -0.12
        assert x_shifted != y_shifted
        assert -0.16 <= x <= -0.05 and -0.22 <= y <= -0.08
        assert z == 0.825 and goal.quaternion_world_xyzw == (0.0, 0.0, 0.0, 1.0)
        velocity = scenario.motion[0].translation.velocity_world_m_s
        assert velocity[0] == velocity[2] == 0.0 and 0.03 <= velocity[1] <= 0.06
        shifted_axes.add("x" if x_shifted else "y")
    assert shifted_axes == {"x", "y"}


def test_t2_applies_free_travel_and_yaw_joint_physics_without_cross_writes() -> None:
    baseline = _proposal("t2_trans")
    native_environment = make_env("t2_trans", baseline)
    try:
        assert isinstance(native_environment, MovingPlacementEnv)
        native_environment.reset()
        addresses = (
            (native_environment._payload_qvel_address, 6),
            *((int(address), 1) for address in native_environment._goal_qvel_indexes),
        )
        for address, count in addresses:
            np.testing.assert_array_equal(
                native_environment.sim.model._model.dof_damping[address : address + count],
                np.zeros(count),
            )
            np.testing.assert_array_equal(
                native_environment.sim.model._model.dof_frictionloss[address : address + count],
                np.zeros(count),
            )
    finally:
        native_environment.close()
    payload_id = baseline.object_states[0].instance_id
    goal_id = baseline.fixture_states[0].instance_id
    free_damping = tuple((index + 1) * 1e-6 for index in range(6))
    free_friction = tuple((index + 1) * 1e-7 for index in range(6))
    joints = (
        JointPhysicsSpec(
            payload_id,
            f"{payload_id}_joint0",
            free_damping,
            free_friction,
        ),
        JointPhysicsSpec(goal_id, f"{goal_id}_travel", (0.000007,), (0.0000007,)),
        JointPhysicsSpec(goal_id, f"{goal_id}_yaw", (0.000008,), (0.0000008,)),
        JointPhysicsSpec(goal_id, f"{goal_id}_x", (0.000009,), (0.0000009,)),
        JointPhysicsSpec(goal_id, f"{goal_id}_z", (0.000010,), (0.0000010,)),
    )
    scenario = replace(baseline, physics=replace(baseline.physics, joints=joints))
    environment = make_env("t2_trans", scenario)
    try:
        assert isinstance(environment, MovingPlacementEnv)
        expected_addresses = {
            f"{payload_id}_joint0": environment._payload_qvel_address,
            f"{goal_id}_x": int(environment._goal_qvel_indexes[0]),
            f"{goal_id}_travel": int(environment._goal_qvel_indexes[1]),
            f"{goal_id}_z": int(environment._goal_qvel_indexes[2]),
            f"{goal_id}_yaw": int(environment._goal_qvel_indexes[3]),
        }
        for _ in range(2):
            environment.reset()
            assert {
                binding.spec.joint_name: binding.dof_address
                for binding in environment._compiled_joint_physics
            } == expected_addresses
            for binding in environment._compiled_joint_physics:
                stop = binding.dof_address + binding.dof_count
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_damping[binding.dof_address : stop],
                    binding.spec.damping_per_dof,
                )
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_frictionloss[binding.dof_address : stop],
                    binding.spec.friction_loss_per_dof,
                )

        with pytest.raises(ValueError, match="does not belong to its declared entity"):
            _resolve_joint_physics(
                environment.sim.model._model,
                (
                    JointPhysicsSpec(
                        goal_id,
                        f"{payload_id}_joint0",
                        free_damping,
                        free_friction,
                    ),
                ),
                entity_body_ids=environment._entity_bodies,
            )
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _action(
    environment: MovingPlacementEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = 0.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    value = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    value = np.ascontiguousarray(value, dtype=np.float64)
    value.setflags(write=False)
    return BenchmarkAction(mode, representation, value)


def _assert_observation(observation: BenchmarkObservation, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3) and observation.rgb.dtype == np.uint8
    assert (
        observation.depth_m.shape == (views, 224, 224) and observation.depth_m.dtype == np.float32
    )
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert (
                np.isfinite(value).all() and value.flags.c_contiguous and not value.flags.writeable
            )
    assert np.all(observation.depth_m > 0.0)
    assert not {"task", "events", "payload_pose", "goal_pose", "future"} & {
        field.name for field in fields(observation)
    }


def _state(environment: MovingPlacementEnv) -> dict[str, Any]:
    data = environment.sim.data._data
    return {
        "time": float(data.time),
        **{
            name: np.asarray(getattr(data, name)).copy()
            for name in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            )
        },
    }


def _assert_state_equal(first: Mapping[str, Any], second: Mapping[str, Any]) -> None:
    assert first.keys() == second.keys()
    for name in first:
        np.testing.assert_array_equal(first[name], second[name], err_msg=name)


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize("mode", ["e7", "j8"])
@pytest.mark.parametrize("representation", ["delta", "absolute"])
def test_t2_native_preparation_and_all_action_paths_start_at_scored_zero(
    task_id: str,
    mode: str,
    representation: str,
) -> None:
    delayed = representation == "absolute"
    name = f"{mode}_agentview_wrist" if delayed else f"{mode}_agentview"
    scenario = _proposal(
        task_id,
        name=name,
        partition="ood" if delayed else "test_id",
        factor="action_delay" if delayed else None,
    )
    environment = make_env(task_id, scenario)
    try:
        assert isinstance(environment, MovingPlacementEnv)
        preparation_input = environment.sim.data.qpos.copy()
        raw = environment.reset()
        assert environment._preparation_steps == 500
        model, data = environment.sim.model._model, environment.sim.data._data
        assert all(
            _fingerpad_contacts(
                model,
                data,
                environment._payload_geom_ids,
                environment._left_pad_ids,
                environment._right_pad_ids,
            )[:2]
        )
        assert (
            environment.timestep
            == environment._episode_tick
            == environment._placement.physics_step
            == 0
        )
        assert data.time == environment.cur_time == 0.0
        assert environment._action_spec is environment._action_delay_queue is None
        assert environment._previous_eef_quaternion_xyzw is None
        assert environment._placement.events == {"goal_enters_observation_region": 0.0}
        assert not environment.done
        assert not np.array_equal(data.qpos, preparation_input)
        assert np.any(
            data.qvel != 0.0
        )  # Hidden physical state was retained, not replaced by an input snapshot.
        assert environment.export_scenario() == scenario
        _validate_capture_reset(environment)
        _assert_observation(environment._benchmark_observation(raw), 0, 2 if delayed else 1)
        observed_controls = []
        native_pre_action = environment._pre_action

        def observe_control(action: Any, policy_step: bool = False) -> None:
            if policy_step:
                observed_controls.append(np.asarray(action).copy())
            native_pre_action(action, policy_step)

        environment._pre_action = observe_control
        issued = []
        for tick in range(5):
            action = _action(environment, representation, displacement=0.0001 * ((tick % 3) - 1))
            issued.append(action)
            position, rotation, joints = environment._achieved_controller_state()
            raw, reward, done, info = environment.step(action)
            assert not done and reward == 0.0 and not info["success"]
            if tick < scenario.action_delay_steps:
                np.testing.assert_array_equal(
                    observed_controls[-1], np.zeros(environment.action_dim)
                )
            else:
                expected = _controller_action(
                    issued[tick - scenario.action_delay_steps],
                    environment._action_spec,
                    achieved_eef_position=position,
                    achieved_eef_rotation=rotation,
                    achieved_joint_position=joints,
                )
                if mode == "e7":
                    base = int(model.body(environment._robot_base_body_name).id)
                    world_from_base = data.xmat[base].reshape(3, 3)
                    expected[:3] = world_from_base @ expected[:3]
                    expected[3:6] = world_from_base @ expected[3:6]
                    expected = expected.astype(np.float32).astype(np.float64)
                np.testing.assert_array_equal(observed_controls[-1], expected)
            assert environment._placement.physics_step == (tick + 1) * 25
            assert data.time == pytest.approx((tick + 1) / 20.0, abs=1e-12)
            _assert_observation(
                environment._benchmark_observation(raw), tick + 1, 2 if delayed else 1
            )
            np.testing.assert_array_equal(
                raw["robot0_eef_pos"], data.site_xpos[environment.robots[0].eef_site_id["right"]]
            )
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "name", "representation", "delay"),
    [
        ("t2_trans", "e7_agentview", "delta", False),
        ("t2_trans", "j8_agentview_wrist", "absolute", True),
        ("t2_se3", "e7_agentview_wrist", "absolute", True),
        ("t2_se3", "j8_agentview", "delta", False),
    ],
)
def test_t2_repeat_reset_and_manifest_replay_reapply_preparation_without_settle_drift(
    task_id: str,
    name: str,
    representation: str,
    delay: bool,
    tmp_path: Path,
) -> None:
    partition: Partition = "ood" if delay else "test_id"
    factor = "action_delay" if delay else None
    scenario = _proposal(task_id, name=name, partition=partition, factor=factor)
    first, second = make_env(task_id, scenario), None
    try:
        raw = first.reset()
        initial = _state(first)
        initial_observation = first._benchmark_observation(raw)
        for _ in range(4):
            first.step(_action(first, representation, displacement=0.0001))
        raw = first.reset()
        _assert_state_equal(initial, _state(first))
        assert first._action_spec is first._action_delay_queue is None
        assert first._previous_eef_quaternion_xyzw is None
        assert first._preparation_steps == 500
        assert first._placement.events == {"goal_enters_observation_region": 0.0}
        observed = first._benchmark_observation(raw)
        for field in fields(observed):
            np.testing.assert_array_equal(
                getattr(observed, field.name), getattr(initial_observation, field.name)
            )
        exported = first.export_scenario()
        assert exported == scenario
        identity = f"v1:{partition}:{factor + ':' if factor else ''}{task_id}:000000"
        manifest = ScenarioManifest(
            (ScenarioManifestRow(1, "v1", identity, task_id, partition, factor, 6, exported),)
        )
        path = tmp_path / "placement.jsonl"
        write_manifest(manifest, path)
        assert load_manifest(path) == manifest
        second = make_env(task_id, load_manifest(path).rows[0].scenario)
        second_raw = second.reset()
        assert second.export_scenario() == scenario
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "body_pos",
            "body_quat",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_contype",
            "geom_conaffinity",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "geom_margin",
            "jnt_type",
            "jnt_range",
            "jnt_axis",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_type",
            "light_castshadow",
            "light_pos",
            "light_dir",
            "light_diffuse",
            "light_specular",
            "light_active",
        ):
            np.testing.assert_array_equal(
                getattr(first.sim.model._model, field), getattr(second.sim.model._model, field)
            )
        for tick in range(7):
            _assert_state_equal(_state(first), _state(second))
            left = observed if tick == 0 else first._benchmark_observation(raw)
            right = second._benchmark_observation(second_raw)
            for field in fields(left):
                np.testing.assert_array_equal(getattr(left, field.name), getattr(right, field.name))
            if tick < 6:
                action = _action(first, representation, displacement=0.0001 * ((tick % 3) - 1))
                raw, r1, d1, i1 = first.step(action)
                second_raw, r2, d2, i2 = second.step(action)
                assert (r1, d1, i1) == (r2, d2, i2)
    finally:
        first.close()
        if second is not None:
            second.close()


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_t2_real_oracle_uses_native_full_containment_release_and_relative_dwell(
    task_id: str,
    name: str,
) -> None:
    scenario = _proposal(task_id, name=name)
    environment = make_env(task_id, scenario)
    try:
        environment.reset()
        data, model = environment.sim.data._data, environment.sim.model._model
        samples: list[dict[str, Any]] = []
        native_update = environment._placement.update

        def observe_physics(**sample: Any) -> None:
            assert np.all(data.xfrc_applied == 0.0) and np.all(data.qfrc_applied == 0.0)
            assert len(environment._goal_qpos_indexes) == 4
            goal_joint_ids = {int(model.joint(name).id) for name in environment._goal_model.joints}
            assert not goal_joint_ids & set(model.actuator_trnid[:, 0])
            assert sample["time_s"] == float(data.time)
            native_update(**sample)
            samples.append(
                {
                    **sample,
                    "goal_y": float(data.xpos[environment._goal_body_id, 1]),
                    "events": dict(environment._placement.events),
                }
            )

        environment._placement.update = observe_physics
        info = _run_native_oracle(environment)
        assert info["success"] and info["failure_code"] is None
        assert list(info["events"]) == [
            "goal_enters_observation_region",
            "goal_pose_alignment" if task_id == "t2_se3" else "goal_approach",
            "containment_entry",
            "release",
            "low_relative_motion",
            "stable_dwell",
            "success",
        ]
        assert tuple(item[0] for item in info["stage_facts"]) == (
            "goal_approach",
            "full_containment",
            "release",
            "low_relative_motion",
            "stable_dwell",
        )
        assert all(item[1] and item[2] == 1.0 for item in info["stage_facts"])
        assert (
            environment._placement.relative_steps == 50
            and environment._placement.dwell_steps == 250
        )
        assert info["events"]["stable_dwell"] - info["events"][
            "low_relative_motion"
        ] == pytest.approx(0.498, abs=1e-12)
        assert info["terminal_time_s"] == info["events"]["stable_dwell"]
        assert len(samples) == environment.timestep * 25
        assert samples[-1]["time_s"] >= info["terminal_time_s"]
        assert environment._action_delay_queue is not None
        assert not environment._action_delay_queue._pending
        after_release = [s for s in samples if "release" in s["events"]]
        assert after_release
        terminal_index = round(info["terminal_time_s"] / 0.002) - 1
        stable_window = samples[terminal_index - 298 : terminal_index + 1]
        assert len(stable_window) == 299
        assert all(s["geometry"].contained and not s["gripper_contact"] for s in stable_window)
        assert any(s["goal_y"] > after_release[0]["goal_y"] for s in after_release)
        assert all(s["rim_impulse_n_s"] <= 0.10 for s in samples)
        assert environment.export_scenario() == scenario
        with pytest.raises(ValueError, match="terminated"):
            environment.step(_action(environment))
        if task_id == "t2_se3" and name == "j8_agentview":
            terminal_state = _state(environment)
            environment._placement.update = native_update
            environment.reset()
            repeated = _run_native_oracle(environment)
            assert repeated == info
            _assert_state_equal(terminal_state, _state(environment))
    finally:
        environment.close()


def test_placement_real_oracle_runs_through_the_single_formal_rollout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("t2_trans")
    scenario = _proposal(task.task_id, 6, "e7_agentview")
    environment = make_env(task.task_id, scenario)

    class OraclePolicy:
        oracle: _PlacementOracle | None = None

        def reset(self) -> None:
            self.oracle = _PlacementOracle(environment)

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            assert self.oracle is not None
            return self.oracle.action(environment)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> MovingPlacementEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        assert isinstance(environment, MovingPlacementEnv)
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        OraclePolicy(),
        scenario_id="v1:test_id:t2_trans:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert trace.success and trace.failure_code is None
    assert trace.steps[-1].event_flags == (True,) * len(trace.event_names)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(range(len(trace.steps)))
    assert _evaluate_episode(trace).success


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_t2_public_generator_really_accepts_the_same_seed_through_both_controllers(
    task_id: str,
    name: str,
) -> None:
    generated = generate_scenario(
        load_task(task_id),
        ROOT / f"configs/scenarios/{task_id}.yaml",
        6,
        partition="test_id",
        recipe_name=name,
    )
    assert generated == _proposal(task_id, 6, name)


def test_t2_public_generator_preserves_deterministic_real_oracle_acceptance() -> None:
    scenarios = [
        generate_scenario(
            load_task("t2_se3"),
            ROOT / "configs/scenarios/t2_se3.yaml",
            0,
            partition="test_id",
            recipe_name="j8_agentview",
        )
        for _ in range(2)
    ]
    assert scenarios[0] == scenarios[1]


def test_t2_nonzero_initial_twist_uses_world_body_origin_and_survives_export_replay(
    tmp_path: Path,
) -> None:
    scenario = _proposal("t2_se3")
    yaw = 0.2
    joints = list(scenario.robot_initial_state.joint_position_rad)
    joints[-1] -= yaw
    payload = replace(
        scenario.object_states[0],
        quaternion_world_xyzw=(0.0, 0.0, math.sin(yaw / 2), math.cos(yaw / 2)),
        linear_velocity_world_m_s=(0.001, -0.002, 0.003),
        angular_velocity_world_rad_s=(0.004, 0.005, -0.006),
    )
    scenario = replace(
        scenario,
        object_states=(payload,),
        robot_initial_state=replace(scenario.robot_initial_state, joint_position_rad=tuple(joints)),
    )
    first, second = make_env("t2_se3", scenario), None
    try:
        model, data = first.sim.model._model, first.sim.data._data
        body = first._payload_body_id
        assert np.linalg.norm(model.body_ipos[body]) > 0.005
        origin_velocity, com_velocity = np.empty(6), np.empty(6)
        mujoco.mj_objectVelocity(model, data, mujoco.mjtObj.mjOBJ_XBODY, body, origin_velocity, 0)
        mujoco.mj_objectVelocity(model, data, mujoco.mjtObj.mjOBJ_BODY, body, com_velocity, 0)
        np.testing.assert_allclose(
            origin_velocity,
            (*payload.angular_velocity_world_rad_s, *payload.linear_velocity_world_m_s),
            rtol=0.0,
            atol=1e-12,
        )
        np.testing.assert_allclose(
            com_velocity[3:] - origin_velocity[3:],
            np.cross(origin_velocity[:3], data.xipos[body] - data.xpos[body]),
            rtol=0.0,
            atol=1e-12,
        )
        local_angular = data.qvel[first._payload_qvel_address + 3 : first._payload_qvel_address + 6]
        assert not np.array_equal(local_angular, origin_velocity[:3])
        first.reset()
        assert first._preparation_steps == 500
        assert first.export_scenario() == scenario
        scored = _state(first)
        first.reset()
        _assert_state_equal(scored, _state(first))
        row = ScenarioManifestRow(
            1, "v1", "v1:stress:t2_se3:000000", "t2_se3", "stress", None, 6, first.export_scenario()
        )
        path = tmp_path / "twist.jsonl"
        write_manifest(ScenarioManifest((row,)), path)
        second = make_env("t2_se3", load_manifest(path).rows[0].scenario)
        second.reset()
        _assert_state_equal(scored, _state(second))
    finally:
        first.close()
        if second is not None:
            second.close()


def test_t2_cv_rgbd_projects_native_visible_surface_in_agentview_and_wrist() -> None:
    environment = make_env("t2_se3", _proposal("t2_se3", name="e7_agentview_wrist"))
    try:
        raw = environment.reset()
        observation = environment._benchmark_observation(raw)
        model, data = environment.sim.model._model, environment.sim.data._data
        target_geoms = np.flatnonzero(model.geom_bodyid == environment._payload_body_id)
        groups = environment.sim._render_context_offscreen.vopt.geomgroup.copy()
        for view, camera in enumerate(("agentview", "robot0_eye_in_hand")):
            rendered, normalized_depth = environment._render_single_sample(
                camera, segmentation=True
            )
            segmentation = rendered[::-1]
            mask = (segmentation[:, :, 0] == int(mujoco.mjtObj.mjOBJ_GEOM)) & np.isin(
                segmentation[:, :, 1], target_geoms
            )
            interior = mask.copy()
            for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                interior &= np.roll(mask, (dy, dx), axis=(0, 1))
            ys, xs = np.nonzero(interior)
            assert len(xs) >= 4
            K, transform = (
                observation.camera_intrinsics[view],
                observation.world_from_camera_cv[view],
            )
            origin = transform[:3, 3].copy()
            verified = False
            for index in np.linspace(0, len(xs) - 1, min(20, len(xs)), dtype=int):
                u, v = int(xs[index]), int(ys[index])
                camera_ray = np.linalg.solve(K, np.array([u, v, 1.0]))
                ray = transform[:3, :3] @ camera_ray
                ray /= np.linalg.norm(ray)
                geom_id = np.empty(1, dtype=np.int32)
                distance = mujoco.mj_ray(model, data, origin, ray, groups, 1, -1, geom_id)
                if distance < 0.0 or geom_id[0] != segmentation[v, u, 1]:
                    continue
                point_cv = transform[:3, :3].T @ (distance * ray)
                pixel = K @ point_cv
                np.testing.assert_allclose(pixel[:2] / pixel[2], (u, v), rtol=0.0, atol=1e-9)
                # The single-sample depth is the integer pixel's center ray, with
                # float32 normalized-depth conversion roundoff.
                np.testing.assert_allclose(
                    observation.depth_m[view, v, u], point_cv[2], rtol=0.0, atol=1e-4
                )
                verified = True
                break
            assert verified, camera
            np.testing.assert_array_equal(
                observation.rgb[view], np.asarray(raw[f"{camera}_image"])[::-1]
            )
            expected = _metric_depth(
                normalized_depth[::-1],
                extent=float(model.stat.extent),
                znear=float(model.vis.map.znear),
                zfar=float(model.vis.map.zfar),
            )
            np.testing.assert_array_equal(observation.depth_m[view], expected)
            assert np.max(observation.rgb[view][mask]) > 0
    finally:
        environment.close()


def test_t2_image_adapter_rejects_changed_native_convention_without_global_override(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    environment = make_env("t2_trans", _proposal("t2_trans"))
    try:
        raw = environment.reset()
        monkeypatch.setattr(robosuite_macros, "IMAGE_CONVENTION", "opencv")
        with pytest.raises(ValueError, match="native OpenGL"):
            environment._benchmark_observation(raw)
    finally:
        environment.close()


def test_t2_payload_writes_are_reset_only_and_scored_driver_writes_only_goal_joints() -> None:
    module = ast.parse(inspect.getsource(inspect.getmodule(MovingPlacementEnv)))
    for function in ast.walk(module):
        if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)) or function.name in {
            "_reset_internal",
            "reset",
        }:
            continue
        for node in ast.walk(function):
            if isinstance(node, ast.Attribute) and node.attr in {
                "qpos",
                "qvel",
                "xfrc_applied",
                "qfrc_applied",
            }:
                assert not isinstance(node.ctx, ast.Store)
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Attribute):
                if node.value.attr in {"qpos", "qvel", "xfrc_applied", "qfrc_applied"}:
                    if not isinstance(node.ctx, ast.Store):
                        continue
                    assert function.name == "_set_goal_reference"
                    assert isinstance(node.slice, ast.Attribute)
                    assert (
                        node.slice.attr
                        == {"qpos": "_goal_qpos_indexes", "qvel": "_goal_qvel_indexes"}[
                            node.value.attr
                        ]
                    )


def _outcome_sample(outcome: _PlacementOutcome, **changes: Any) -> None:
    sample = {
        "time_s": (outcome.physics_step + 1) * 0.002,
        "finite": True,
        "geometry": _PlacementGeometryFacts(True, 0.004, 0.001, 0.004, 0.0, 0.0),
        "approach_distance_m": 0.0,
        "gripper_contact": False,
        "release_requested": True,
        "relative_linear_speed_m_s": 0.0,
        "relative_angular_speed_rad_s": 0.0,
        "bottom_z_m": 0.82,
        "goal_y_m": 0.0,
        "rim_impulse_n_s": 0.0,
    }
    outcome.update(**(sample | changes))


def _outcome(task_id: str = "t2_trans") -> _PlacementOutcome:
    outcome = _PlacementOutcome(load_task(task_id), _proposal(task_id).geometry, 0.002)
    outcome.begin(approach_distance_m=0.30)
    return outcome


def test_t2_outcome_requires_explicit_scored_start_initialization() -> None:
    outcome = _PlacementOutcome(load_task("t2_trans"), _proposal("t2_trans").geometry, 0.002)
    for invalid_distance in (math.nan, math.inf, math.nextafter(0.0, -math.inf)):
        with pytest.raises(ValueError, match="finite non-negative"):
            outcome.begin(approach_distance_m=invalid_distance)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        _outcome_sample(outcome)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        outcome.invalidate(0.0)


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_outcome_progress_uses_current_distance_and_terminal_sample(task_id: str) -> None:
    outcome = _outcome(task_id)
    threshold = 0.05 if task_id == "t2_se3" else 0.10
    assert outcome._stage_facts()[0][2] == 0.0
    for distance, expected in ((2.0 * threshold, 1.0 / 3.0), (2.7 * threshold, 0.1)):
        _outcome_sample(outcome, approach_distance_m=distance)
        assert outcome.events == {"goal_enters_observation_region": 0.0}
        assert outcome._stage_facts()[0][2] == pytest.approx(expected)
    _outcome_sample(outcome, approach_distance_m=1.5 * threshold, rim_impulse_n_s=0.11)
    assert outcome.failure_code == "rim_impulse_exceeded"
    assert outcome.events == {"goal_enters_observation_region": 0.0, "rim_impulse_exceeded": 0.006}
    assert outcome._stage_facts()[0][2] == pytest.approx(0.5)


def test_t2_outcome_se3_progress_uses_orientation_and_current_entrance_plane() -> None:
    outcome = _outcome("t2_se3")
    geometry = _PlacementGeometryFacts(False, -0.01, 0.0, 0.0, 0.24, 0.0)
    for angle, expected in ((0.24, 1.0 / 3.0), (0.30, 1.0 / 6.0)):
        _outcome_sample(
            outcome,
            geometry=replace(geometry, orientation_error_rad=angle),
            approach_distance_m=0.01,
            gripper_contact=True,
            release_requested=False,
        )
        assert outcome.events == {"goal_enters_observation_region": 0.0}
        assert outcome._stage_facts()[0][2] == pytest.approx(expected)
    for entrance_gap, expected in ((0.0, 1.0), (-1e-6, 0.0)):
        _outcome_sample(
            outcome,
            geometry=replace(geometry, orientation_error_rad=0.0, entrance_gap_m=entrance_gap),
            gripper_contact=True,
            release_requested=False,
        )
        assert set(outcome.events) == {"goal_enters_observation_region", "goal_approach"}
        # The current public StageProgress maps unfinished raw 1.0 one ULP below completion.
        mapped = math.nextafter(1.0, 0.0) if expected == 1.0 else expected
        assert outcome._stage_facts()[1] == ("full_containment", False, mapped, 0)


def test_t2_outcome_release_progress_uses_pad_absence_before_release_command() -> None:
    outcome = _outcome()
    for contact, expected in ((True, 0.0), (False, 1.0), (True, 0.0)):
        _outcome_sample(outcome, gripper_contact=contact, release_requested=False)
        assert set(outcome.events) == {
            "goal_enters_observation_region",
            "goal_approach",
            "full_containment",
        }
        mapped = math.nextafter(1.0, 0.0) if expected == 1.0 else expected
        assert outcome._stage_facts()[2] == ("release", False, mapped, 0)


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_outcome_requires_full_consecutive_relative_hold_then_dwell(task_id: str) -> None:
    outcome = _outcome(task_id)
    for _ in range(24):
        _outcome_sample(outcome)
    assert outcome.relative_steps == 24
    _outcome_sample(outcome, gripper_contact=True)
    assert outcome.relative_steps == 0
    for _ in range(49):
        _outcome_sample(outcome, release_requested=False)
    assert "low_relative_motion" not in outcome.events
    assert outcome.relative_steps == 0
    for _ in range(50):
        _outcome_sample(outcome)
    assert outcome.relative_steps == 50 and outcome.dwell_steps == 1
    for _ in range(248):
        _outcome_sample(outcome)
    assert not outcome.success
    _outcome_sample(outcome)
    assert outcome.success and outcome.dwell_steps == 250
    terminal, events = outcome.terminal_time_s, dict(outcome.events)
    _outcome_sample(outcome, finite=False)
    assert outcome.success and outcome.terminal_time_s == terminal and outcome.events == events
    outcome.reset()
    assert outcome.physics_step == outcome.relative_steps == outcome.dwell_steps == 0
    assert outcome.events == {} and outcome.terminal_time_s is None


@pytest.mark.parametrize(
    ("facts", "expected"),
    [
        ({"finite": False, "rim_impulse_n_s": 0.11, "bottom_z_m": 0.70}, "invalid_state"),
        ({"rim_impulse_n_s": 0.100001, "bottom_z_m": 0.70}, "rim_impulse_exceeded"),
        (
            {
                "geometry": _PlacementGeometryFacts(False, -0.01, 0.0, 0.0, 0.0, 0.0),
                "bottom_z_m": 0.82,
            },
            "release_outside_goal",
        ),
        ({"bottom_z_m": 0.719999, "goal_y_m": 0.31}, "drop"),
        ({"goal_y_m": 0.300001}, "goal_window_expired"),
        ({"relative_linear_speed_m_s": math.nan}, "invalid_state"),
    ],
)
def test_t2_first_failure_priority_beats_a_same_step_success(facts: Any, expected: str) -> None:
    outcome = _outcome()
    if expected == "release_outside_goal":
        # Establish only the valid prerequisites: the first release itself is outside.
        _outcome_sample(outcome, gripper_contact=True, release_requested=False)
    else:
        for _ in range(298):
            _outcome_sample(outcome)
    before = outcome._stage_facts()
    _outcome_sample(outcome, **facts)
    assert outcome.failure_code == expected and not outcome.success
    expected_time_s = 0.004 if expected == "release_outside_goal" else 0.598
    assert outcome.terminal_time_s == pytest.approx(expected_time_s)
    if expected == "release_outside_goal":
        assert outcome._stage_facts()[:2] == before[:2]
        assert outcome._stage_facts()[2] == ("release", False, math.nextafter(1.0, 0.0), 0)
    else:
        assert outcome._stage_facts() == before
    _outcome_sample(outcome)
    assert outcome.failure_code == expected


def test_t2_exact_closed_thresholds_and_same_step_success_precedes_horizon() -> None:
    outcome = _outcome()
    _outcome_sample(
        outcome,
        rim_impulse_n_s=0.10,
        bottom_z_m=0.72,
        goal_y_m=0.30,
        relative_linear_speed_m_s=0.08,
        relative_angular_speed_rad_s=0.8,
    )
    assert outcome.failure_code is None and outcome.relative_steps == 1
    outcome.physics_step = 4999
    outcome.events["low_relative_motion"] = 9.5
    outcome.dwell_steps = 249
    _outcome_sample(outcome)
    assert outcome.failure_code is None and outcome.terminal_time_s == 10.0
    assert outcome.success
    timeout = _outcome()
    timeout.physics_step = 4999
    _outcome_sample(timeout, gripper_contact=True, release_requested=False)
    assert timeout.failure_code == "timeout" and not timeout.success


def test_t2_first_approach_and_release_outside_share_one_physics_step() -> None:
    outcome = _outcome()
    outside = _PlacementGeometryFacts(False, -0.01, 0.0, 0.0, 0.0, 0.0)
    _outcome_sample(outcome, geometry=outside)
    assert outcome.events == {
        "goal_enters_observation_region": 0.0,
        "goal_approach": 0.002,
        "release_outside_goal": 0.002,
    }
    assert outcome.failure_code == "release_outside_goal"
    assert outcome.terminal_time_s == 0.002
    assert outcome._stage_facts()[0][1]
    drop = _outcome()
    _outcome_sample(drop, geometry=outside, bottom_z_m=0.70, goal_y_m=0.31)
    assert drop.failure_code == "drop"
    assert drop.events == {"goal_enters_observation_region": 0.0, "drop": 0.002}


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_native_goal_motion_has_real_contact_frame_velocity(task_id: str) -> None:
    scenario = _proposal(task_id)
    environment = make_env(task_id, scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        for _ in range(20):
            environment.step(_action(environment))
        velocity = np.empty(6)
        mujoco.mj_objectVelocity(
            model, data, mujoco.mjtObj.mjOBJ_XBODY, environment._goal_body_id, velocity, 0
        )
        forward = scenario.motion[0].translation.velocity_world_m_s[1]
        yaw = scenario.motion[0].rotation.angular_speed_rad_s if task_id == "t2_se3" else 0.0
        assert velocity[4] == pytest.approx(forward, abs=1e-4)
        assert velocity[2] == pytest.approx(yaw, abs=1e-4)
        assert data.xpos[environment._goal_body_id, 1] - scenario.fixture_states[
            0
        ].position_world_m[1] == pytest.approx(forward, abs=2e-4)
        assert np.all(data.xfrc_applied == 0.0) and np.all(data.qfrc_applied == 0.0)
    finally:
        environment.close()


def _pose_for_geometry(
    environment: MovingPlacementEnv,
    *,
    gap: float = 0.001,
    xy: tuple[float, float] = (0.0, 0.0),
    relative_rotation: Any = None,
) -> None:
    """Set controlled native geometry only for geometric/negative-path tests, never the oracle."""
    model, data = environment.sim.model._model, environment.sim.data._data
    rotation = np.eye(3) if relative_rotation is None else relative_rotation
    corners = np.concatenate(
        [
            (
                np.array([(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)])
                * model.geom_size[index]
                + model.geom_pos[index]
            )
            @ rotation.T
            for index in environment._scored_payload_geom_ids
        ]
    )
    floor = (
        model.geom_pos[environment._floor_geom_id, 2]
        + model.geom_size[environment._floor_geom_id, 2]
    )
    relative = np.array([*xy, floor - np.min(corners[:, 2]) + gap])
    goal_rotation = data.xmat[environment._goal_body_id].reshape(3, 3)
    position = data.xpos[environment._goal_body_id] + goal_rotation @ relative
    quaternion = np.empty(4)
    mujoco.mju_mat2Quat(quaternion, np.ascontiguousarray(goal_rotation @ rotation).reshape(9))
    address = environment._payload_qpos_address
    data.qpos[address : address + 7] = (*position, *quaternion)
    data.qvel[environment._payload_qvel_address : environment._payload_qvel_address + 6] = 0.0
    mujoco.mj_forward(model, data)


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_compiled_containment_excludes_handle_and_allows_original_floor_penetration(
    task_id: str,
) -> None:
    environment = make_env(task_id, _proposal(task_id))
    try:
        environment.reset()
        _pose_for_geometry(environment)
        facts = environment._geometry_facts()
        assert facts.contained and facts.floor_gap_m == pytest.approx(0.001, abs=1e-12)
        assert facts.planar_clearance_m == pytest.approx(
            0.004 if task_id == "t2_se3" else 0.008, abs=1e-12
        )
        model, data = environment.sim.model._model, environment.sim.data._data
        handle = model.geom(environment._payload_model.naming_prefix + "handle_collision").id
        entrance = max(
            data.geom_xpos[g, 2] + model.geom_size[g, 2] for g in environment._rim_geom_ids
        )
        assert data.geom_xpos[handle, 2] + model.geom_size[handle, 2] > entrance
        _pose_for_geometry(environment, gap=-0.002 + 1e-6)
        assert environment._geometry_facts().contained
        _pose_for_geometry(environment, gap=-0.002 - 1e-6)
        assert not environment._geometry_facts().contained
        _pose_for_geometry(environment, gap=0.02 if task_id == "t2_trans" else 0.06)
        body_name = "bar_collision" if task_id == "t2_se3" else "body_collision"
        main = model.geom(environment._payload_model.naming_prefix + body_name).id
        entrance = max(
            data.geom_xpos[g, 2] + model.geom_size[g, 2] for g in environment._rim_geom_ids
        )
        assert data.geom_xpos[main, 2] + model.geom_size[main, 2] > entrance
        assert not environment._geometry_facts().contained
        assert model.geom_margin[environment._floor_geom_id] == 0.0
        assert all(model.geom_margin[g] == 0.0 for g in environment._rim_geom_ids)
    finally:
        environment.close()


@pytest.mark.parametrize(("delta", "contained"), [(-1e-6, True), (1e-6, False)])
def test_t2_se3_planar_clearance_and_floor_gap_use_compiled_geometry(
    delta: float, contained: bool
) -> None:
    environment = make_env("t2_se3", _proposal("t2_se3"))
    try:
        environment.reset()
        _pose_for_geometry(environment, gap=0.002 + delta)
        assert environment._geometry_facts().contained == contained
        _pose_for_geometry(environment, xy=(0.002 + delta, 0.0))
        assert environment._geometry_facts().contained == contained
    finally:
        environment.close()


@pytest.mark.parametrize("dy", [-0.0015, 0.0015])
def test_t2_se3_planar_clearance_uses_yaw_only_with_real_tilt_vertical_envelope(dy: float) -> None:
    environment = make_env("t2_se3", _proposal("t2_se3"))
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        angle = 0.04
        c, s = math.cos(angle), math.sin(angle)
        relative_rotation = np.asarray(((1, 0, 0), (0, c, -s), (0, s, c)))
        reference = environment._goal_reference(0.0)
        goal_rotation = np.empty(9)
        mujoco.mju_quat2Mat(goal_rotation, reference.quaternion_world_xyzw[[3, 0, 1, 2]])
        goal_rotation = goal_rotation.reshape(3, 3)
        position = reference.position_world_m + goal_rotation @ np.asarray((0.0, dy, 0.023))
        quaternion = np.empty(4)
        mujoco.mju_mat2Quat(
            quaternion, np.ascontiguousarray(goal_rotation @ relative_rotation).reshape(9)
        )
        address = environment._payload_qpos_address
        data.qpos[address : address + 7] = (*position, *quaternion)
        mujoco.mj_forward(model, data)
        facts = environment._geometry_facts()
        assert facts.contained
        assert facts.planar_clearance_m == pytest.approx(0.0025, abs=1e-12)
        assert facts.floor_gap_m == pytest.approx(-0.0006651539557362349, abs=1e-12)
        assert facts.entrance_gap_m == pytest.approx(0.0025345260698627914, abs=1e-12)
    finally:
        environment.close()


@pytest.mark.parametrize(("axis", "limit"), [("yaw", 0.12), ("tilt", 0.05)])
@pytest.mark.parametrize(("side", "contained"), [(-1.0, True), (1.0, False)])
def test_t2_se3_tilt_limits_containment_while_yaw_threshold_only_gates_approach(
    axis: str,
    limit: float,
    side: float,
    contained: bool,
) -> None:
    scenario = _proposal("t2_se3")
    scenario = replace(scenario, geometry=replace(scenario.geometry, goal_planar_clearance_m=0.02))
    environment = make_env("t2_se3", scenario)
    try:
        environment.reset()
        angle = limit + side * 1e-6
        c, s = math.cos(angle), math.sin(angle)
        rotation = (
            np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
            if axis == "yaw"
            else np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])
        )
        _pose_for_geometry(environment, relative_rotation=rotation)
        facts = environment._geometry_facts()
        assert facts.planar_clearance_m > 0.002 and 0.0 <= facts.floor_gap_m <= 0.002
        assert facts.entrance_gap_m > 0.0
        measured = facts.orientation_error_rad if axis == "yaw" else facts.tilt_rad
        assert measured == pytest.approx(angle, abs=1e-12)
        assert facts.contained == (contained if axis == "tilt" else True)
        if axis == "yaw":
            outcome = _outcome("t2_se3")
            _outcome_sample(outcome, geometry=facts, gripper_contact=True, release_requested=False)
            assert ("goal_approach" in outcome.events) == contained
    finally:
        environment.close()


def test_t2_native_rim_collision_latches_first_real_impact_from_clear_geometry() -> None:
    environment = make_env("t2_trans", _proposal("t2_trans"))
    try:
        environment.reset()
        # A free payload starts inside the opening and hits the rim through native motion.
        # This controlled negative-path initial velocity is never used by the oracle.
        _pose_for_geometry(environment)
        assert environment._geometry_facts().contained
        model, data = environment.sim.model._model, environment.sim.data._data
        data.qvel[environment._payload_qvel_address] = 8.0
        mujoco.mj_forward(model, data)
        assert not any(
            {int(contact.geom1), int(contact.geom2)} & set(environment._payload_geom_ids)
            and {int(contact.geom1), int(contact.geom2)} & set(environment._rim_geom_ids)
            for contact in data.contact[: data.ncon]
        )
        evidence = []
        native = environment._placement.update

        def observe(**sample: Any) -> None:
            impulse = 0.0
            force = np.empty(6)
            contacts = 0
            for index in range(data.ncon):
                contact = data.contact[index]
                pair = {int(contact.geom1), int(contact.geom2)}
                if pair & set(environment._payload_geom_ids) and pair & set(
                    environment._rim_geom_ids
                ):
                    mujoco.mj_contactForce(model, data, index, force)
                    impulse = max(impulse, float(np.linalg.norm(force[:3])) * model.opt.timestep)
                    contacts += 1
            assert sample["rim_impulse_n_s"] == pytest.approx(impulse, abs=1e-12)
            evidence.append((float(data.time), impulse, contacts))
            native(**sample)

        environment._placement.update = observe
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "rim_impulse_exceeded" and not info["success"]
        first = next(row for row in evidence if row[1] > 0.10)
        assert first[2] > 0 and info["terminal_time_s"] == first[0]
        assert evidence[0][2] == 0 and first[0] > evidence[0][0]
        assert len(evidence) == 25 and evidence[-1][0] == pytest.approx(0.05, abs=1e-12)
        assert all(np.isfinite(row[1]) for row in evidence)
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


def test_t2_native_drop_uses_actual_collision_bottom() -> None:
    environment = make_env("t2_trans", _proposal("t2_trans"))
    try:
        environment.reset()
        environment.sim.data.qpos[environment._payload_qpos_address + 2] = 0.60
        environment.sim.forward()
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "drop" and info["terminal_time_s"] == 0.002
    finally:
        environment.close()


def test_t2_relative_velocity_uses_object_com_minus_analytic_goal_twist() -> None:
    environment = make_env("t2_se3", _proposal("t2_se3"))
    try:
        environment.reset()
        _pose_for_geometry(environment)
        model, data = environment.sim.model._model, environment.sim.data._data
        reference = environment._goal_reference(float(data.time))
        omega = reference.angular_velocity_world_rad_s
        address = environment._payload_qvel_address
        data.qvel[address : address + 3] = reference.linear_velocity_world_m_s
        data.qvel[address + 3 : address + 6] = (
            data.xmat[environment._payload_body_id].reshape(3, 3).T @ omega
        )
        mujoco.mj_forward(model, data)
        captured = []
        environment._placement.update = lambda **sample: captured.append(sample)
        environment._update_observables()
        assert len(captured) == 1
        assert captured[0]["relative_angular_speed_rad_s"] < 1e-12
        com_velocity, origin_velocity = np.empty(6), np.empty(6)
        mujoco.mj_objectVelocity(
            model, data, mujoco.mjtObj.mjOBJ_BODY, environment._payload_body_id, com_velocity, 0
        )
        mujoco.mj_objectVelocity(
            model, data, mujoco.mjtObj.mjOBJ_XBODY, environment._payload_body_id, origin_velocity, 0
        )
        assert np.linalg.norm(com_velocity[3:] - origin_velocity[3:]) > 1e-4
        assert captured[0]["relative_linear_speed_m_s"] == pytest.approx(
            np.linalg.norm(com_velocity[3:] - reference.linear_velocity_world_m_s), abs=1e-12
        )
        assert captured[0]["relative_linear_speed_m_s"] > 1e-4
    finally:
        environment.close()


def test_t2_actual_moving_goal_window_crossing_uses_current_native_state_and_time() -> None:
    scenario = _proposal("t2_trans")
    goal = replace(scenario.fixture_states[0], position_world_m=(-0.12, 0.2995, 0.825))
    scenario = replace(scenario, fixture_states=(goal,), action_delay_steps=2)
    environment = make_env("t2_trans", scenario)
    try:
        environment.reset()
        samples = []
        native = environment._placement.update

        def observe(**sample: Any) -> None:
            data = environment.sim.data._data
            expected_y = (
                goal.position_world_m[1]
                + data.time * scenario.motion[0].translation.velocity_world_m_s[1]
            )
            assert sample["goal_y_m"] == pytest.approx(expected_y, abs=1e-12)
            samples.append((sample["time_s"], sample["goal_y_m"]))
            native(**sample)

        environment._placement.update = observe
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "goal_window_expired"
        assert len(samples) == 25
        first = next(i for i, (_, y) in enumerate(samples) if y > 0.30)
        assert first > 0 and samples[first - 1][1] <= 0.30
        assert info["terminal_time_s"] == samples[first][0]
        assert environment.sim.data.time == pytest.approx(0.05, abs=1e-12)
        assert samples[-1][1] > samples[first][1]
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


@pytest.mark.parametrize(("bad_qpos", "terminal_time_s"), [(math.nan, 0.0), (1e11, 0.002)])
def test_t2_native_bad_state_is_not_disguised_by_mujoco_recovery(
    bad_qpos: float,
    terminal_time_s: float,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    environment = make_env("t2_trans", _proposal("t2_trans"))
    try:
        environment.reset()
        monkeypatch.chdir(tmp_path)
        environment.sim.data.qpos[environment._payload_qpos_address] = bad_qpos
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "invalid_state" and not info["success"]
        assert info["terminal_time_s"] == terminal_time_s
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


def test_t2_real_open_gripper_outside_goal_is_release_failure() -> None:
    environment = make_env("t2_trans", _proposal("t2_trans"))
    try:
        environment.reset()
        for _ in range(environment._task_spec.episode_horizon_steps):
            _, _, done, info = environment.step(_action(environment, gripper=-1.0))
            if done:
                break
        assert done and info["failure_code"] == "release_outside_goal"
        assert not info["success"] and "release" not in info["events"]
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("mutation", "stage", "reason"),
    [
        ("pregrasp", "reset", "pregrasp_not_stable"),
        ("window", "oracle", "goal_window_expired"),
        ("joint", "reset", "joint_out_of_range"),
    ],
)
def test_t2_public_generator_preserves_native_preparation_and_window_rejections(
    mutation: str,
    stage: str,
    reason: str,
    tmp_path: Path,
) -> None:
    document = copy.deepcopy(_document("t2_trans"))
    recipe = document["recipes"]["ood"]["spatial"]["e7_agentview"]
    if mutation == "pregrasp":
        recipe["object_states"][0]["position_world_m"][0] = 0.10
    elif mutation == "window":
        recipe["fixture_states"][0]["position_world_m"] = [-0.12, 0.31, 0.825]
    else:
        recipe["robot_initial_state"]["joint_position_rad"][0] = 3.0
    path = tmp_path / "external.yaml"
    path.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    with pytest.raises(_CaptureProposalRejected) as caught:
        generate_scenario(
            load_task("t2_trans"),
            path,
            6,
            partition="ood",
            factor="spatial",
            recipe_name="e7_agentview",
        )
    assert caught.value.stage == stage and caught.value.failure_code == reason


def test_t2_public_physics_intervention_outside_packaged_choices_reaches_real_oracle(
    tmp_path: Path,
) -> None:
    document = copy.deepcopy(_document("t2_trans"))
    identity = document["recipes"]["test_id"]["e7_agentview"]
    physics = copy.deepcopy(identity["physics"])
    physics["bodies"][0]["diagonal_inertia_kg_m2"][0] *= 1.02
    recipe = document["recipes"]["ood"]["physics"]["e7_agentview"]
    recipe["physics"] = physics
    path = tmp_path / "independent_inertia.yaml"
    path.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    scenario = generate_scenario(
        load_task("t2_trans"),
        path,
        6,
        partition="ood",
        factor="physics",
        recipe_name="e7_agentview",
    )
    assert scenario.physics.bodies[0].mass_kg == identity["physics"]["bodies"][0]["mass_kg"]
    assert (
        scenario.physics.bodies[0].diagonal_inertia_kg_m2[0]
        == physics["bodies"][0]["diagonal_inertia_kg_m2"][0]
    )


@pytest.mark.parametrize("task_id", ["t2_trans", "t2_se3"])
def test_t2_timeout_records_old_integer_clock_after_accumulated_simulation_time(
    task_id: str,
) -> None:
    outcome = _outcome(task_id)
    time_s = 0.0
    for _ in range(5000):
        time_s += 0.002
        _outcome_sample(outcome, time_s=time_s, gripper_contact=True, release_requested=False)
    assert time_s != outcome.horizon_s
    assert outcome.physics_step == 5000 and outcome.failure_code == "timeout"
    assert outcome.events["timeout"] == outcome.terminal_time_s == 10.0
    assert "success" not in outcome.events
