from __future__ import annotations

import copy
import json
import math
from collections.abc import Mapping
from dataclasses import fields, replace
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest
import yaml

from se3_wam_benchmark.control.action import BenchmarkAction, _controller_action, _so3_log
from se3_wam_benchmark.envs.base import (
    _collision_bottom_z,
    _fingerpad_contacts,
    _load_asset_catalog,
)
from se3_wam_benchmark.envs.components.motion import _motion_state_at_time
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.driven_interception import DrivenInterceptionEnv
from se3_wam_benchmark.scenarios._feasibility import _validate_capture_reset
from se3_wam_benchmark.scenarios._native_oracle import _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_matched_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import (
    ConstantAngularVelocityRotation,
    DrivenMotionSpec,
    HarmonicTranslation,
    ScenarioSpec,
    scenario_to_dict,
)
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
TASKS = ("t1_xyz", "t1_so3")


def _recipe_path(task_id: str) -> Path:
    return ROOT / "configs/scenarios" / f"{task_id}.yaml"


def _proposal(
    task_id: str,
    seed: int = 17,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task(task_id)
    recipe = _select_recipe(
        load_yaml_strict(_recipe_path(task_id)),
        partition=partition,
        factor=factor,
        recipe_name=name,
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_matched_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    return scenario


def _action(
    environment: DrivenInterceptionEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = -1.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    values = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _assert_observation(observation: BenchmarkObservation, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.rgb.dtype == np.uint8 and observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    assert observation.camera_intrinsics.dtype == np.float64
    assert observation.world_from_camera_cv.dtype == np.float64
    assert observation.T_robot_base_from_world.dtype == np.float64
    assert np.all(observation.depth_m > 0.0)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert value.flags.c_contiguous and not value.flags.writeable
            assert np.isfinite(value).all()
    assert not {"task", "events", "target_pose", "future"} & {
        field.name for field in fields(observation)
    }


def _assert_wrench(environment: DrivenInterceptionEnv) -> None:
    model, data = environment.sim.model._model, environment.sim.data._data
    wrench = data.xfrc_applied[environment._target_body_id]
    np.testing.assert_array_equal(wrench, environment._last_wrench)
    assert np.isfinite(wrench).all() and wrench[2] == 0.0
    assert np.linalg.norm(wrench[:2]) <= 3.0 + 1e-12
    assert np.linalg.norm(wrench[3:5]) <= 0.15 + 1e-12
    assert abs(wrench[5]) <= 0.25 + 1e-12
    np.testing.assert_array_equal(np.delete(data.xfrc_applied, environment._target_body_id, 0), 0.0)
    np.testing.assert_array_equal(data.qfrc_applied, 0.0)
    np.testing.assert_array_equal(model.geom_surfacevel, 0.0)
    assert not model.flg_surfacevel


@pytest.mark.parametrize("task_id", TASKS)
@pytest.mark.parametrize(
    ("name", "representation", "delay"),
    [
        ("e7_agentview", "delta", 0),
        ("e7_agentview_wrist", "absolute", 1),
        ("j8_agentview", "absolute", 0),
        ("j8_agentview_wrist", "delta", 2),
    ],
)
def test_registered_matched_reset_step_rgbd_applied_ticks_and_episode_reset(
    task_id: str, name: str, representation: str, delay: int
) -> None:
    scenario = replace(_proposal(task_id, name=name), action_delay_steps=delay)
    environment = make_env(task_id, scenario)
    assert isinstance(environment, DrivenInterceptionEnv)
    try:
        raw = environment.reset()
        assert isinstance(raw, Mapping)
        assert environment.get_ep_meta() == environment.export_scenario() == scenario
        assert environment.export_scenario() is not scenario
        model, data = environment.sim.model._model, environment.sim.data._data
        initial_qpos = data.qpos.copy()
        initial_qvel = data.qvel.copy()
        # DB0's body frame remains at the bar center; the stem displaces the COM.
        np.testing.assert_allclose(
            model.body_ipos[environment._target_body_id],
            (0.0, -0.006818181818181819, 0.0),
            rtol=0.0,
            atol=1e-15,
        )
        target_velocity = environment._target_qvel_address
        np.testing.assert_array_equal(data.qvel[:target_velocity], 0.0)
        np.testing.assert_array_equal(
            data.qvel[target_velocity : target_velocity + 3],
            scenario.object_states[0].linear_velocity_world_m_s,
        )
        np.testing.assert_array_equal(
            data.qvel[target_velocity + 3 : target_velocity + 6],
            scenario.object_states[0].angular_velocity_world_rad_s,
        )
        assert model.nlight == 1 and model.light(0).name == "table_key"
        assert model.vis.headlight.active
        assert _collision_bottom_z(model, data, environment._target_geom_ids) == pytest.approx(0.8)
        _validate_capture_reset(environment)
        initial = previous = environment._benchmark_observation(raw)
        _assert_observation(initial, 0, len(scenario.cameras.views))
        first = _action(environment, representation, displacement=0.002, gripper=1.0)
        for tick in range(1, delay + 3):
            action = first if tick == 1 else _action(environment, representation)
            position, rotation, joints = environment._achieved_controller_state()
            raw, reward, done, _ = environment.step(action)
            assert math.isfinite(reward) and not done
            if tick <= delay:
                np.testing.assert_array_equal(environment.robots[0].recent_actions.current, 0.0)
            elif tick == delay + 1:
                expected = _controller_action(
                    first,
                    environment._action_spec,
                    achieved_eef_position=position,
                    achieved_eef_rotation=rotation,
                    achieved_joint_position=joints,
                )
                np.testing.assert_allclose(
                    environment.robots[0].recent_actions.current, expected, rtol=0.0, atol=1e-7
                )
            observation = environment._benchmark_observation(raw)
            _assert_observation(observation, tick, len(scenario.cameras.views))
            assert np.dot(previous.eef_quaternion_xyzw, observation.eef_quaternion_xyzw) >= 0.0
            previous = observation
            np.testing.assert_array_equal(
                raw["robot0_eef_pos"], data.site_xpos[environment.robots[0].eef_site_id["right"]]
            )
            assert environment._capture.physics_step == 25 * tick
            assert data.time == pytest.approx(tick / 20.0, abs=1e-12)
            _assert_wrench(environment)
        np.testing.assert_array_equal(
            initial.world_from_camera_cv[0], observation.world_from_camera_cv[0]
        )
        if len(scenario.cameras.views) == 2:
            assert not np.array_equal(
                initial.world_from_camera_cv[1], observation.world_from_camera_cv[1]
            )
            wrist = model.camera("robot0_eye_in_hand").id
            np.testing.assert_array_equal(
                observation.world_from_camera_cv[1, :3, 3], data.cam_xpos[wrist]
            )
        assert environment._action_spec is not None
        assert environment._previous_eef_quaternion_xyzw is not None
        environment.reset()
        assert environment._episode_tick == environment._capture.physics_step == 0
        assert environment._capture.bilateral_steps == environment._capture.stable_steps == 0
        assert environment._capture.events == {"target_enters_observation_region": 0.0}
        assert environment._capture.terminal_time_s is None
        assert environment._action_spec is environment._action_delay_queue is None
        assert environment._previous_eef_quaternion_xyzw is None
        np.testing.assert_array_equal(environment.sim.data._data.qpos, initial_qpos)
        np.testing.assert_array_equal(environment.sim.data._data.qvel, initial_qvel)
        assert environment.export_scenario() == scenario
        opposite = "absolute" if representation == "delta" else "delta"
        environment.step(_action(environment, opposite))
        assert environment._action_spec.representation == opposite
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "seed", "name"),
    [
        ("t1_xyz", 17, "e7_agentview"),
        ("t1_so3", 17, "e7_agentview"),
        ("t1_xyz", 36, "j8_agentview"),
        ("t1_so3", 36, "j8_agentview"),
        ("t1_xyz", 17, "j8_agentview"),
    ],
)
def test_real_matched_oracle_capture_keeps_wrench_at_every_physics_step_and_terminal_tail(
    task_id: str, seed: int, name: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    scenario = _proposal(task_id, seed, name)
    environment = make_env(task_id, scenario)
    try:
        environment.reset()
        data = environment.sim.data._data
        driver_times = []
        physical_times = []
        observed_stages = set()
        terminal_tail_calls = 0
        original_drive, original_update = (
            environment._apply_target_wrench,
            environment._capture.update,
        )

        def drive() -> None:
            driver_times.append(float(data.time))
            original_drive()

        def observe(**state: Any) -> None:
            nonlocal terminal_tail_calls
            _assert_wrench(environment)
            physical_times.append(float(data.time))
            assert len(driver_times) == len(physical_times)
            assert physical_times[-1] - driver_times[-1] == pytest.approx(0.002, abs=1e-12)
            if environment._capture.terminal_time_s is not None:
                terminal_tail_calls += 1
            np.testing.assert_array_equal(state["position"], data.xpos[environment._target_body_id])
            original_update(**state)
            observed_stages.update(environment._capture.events)

        monkeypatch.setattr(environment, "_apply_target_wrench", drive)
        monkeypatch.setattr(environment._capture, "update", observe)
        outcome = _run_native_oracle(environment)
        assert outcome["success"] and outcome["failure_code"] is None, outcome
        terminal_s = outcome["terminal_time_s"]
        assert 0.0 < terminal_s <= 8.0
        assert tuple(outcome["events"]) == (
            "target_enters_observation_region",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
            "success",
        )
        assert observed_stages == set(outcome["events"])
        assert outcome["terminal_time_s"] == outcome["events"]["stable_dwell"]
        assert environment._capture.bilateral_steps >= environment._capture.hold_steps == 25
        assert environment._capture.stable_steps == environment._capture.dwell_steps == 250
        assert outcome["events"]["stable_dwell"] - outcome["events"]["clearance"] == pytest.approx(
            249 * 0.002, abs=1e-9
        )
        assert _fingerpad_contacts(
            environment.sim.model._model,
            data,
            environment._target_geom_ids,
            environment._left_pad_ids,
            environment._right_pad_ids,
        )[:2] == (True, True)
        assert data.xpos[environment._target_body_id, 2] - 0.018 >= (
            scenario.geometry.support_surface_z_m
            + environment._task_spec.success.minimum_lift_or_clearance_m
        )
        assert np.linalg.norm(environment._last_wrench) > 0.01
        assert environment._episode_tick == math.ceil(terminal_s * 20)
        assert len(physical_times) == environment._episode_tick * 25
        assert terminal_tail_calls > 0
        assert outcome["terminal_time_s"] <= data.time < outcome["terminal_time_s"] + 0.05
        assert not any(warning.number for warning in data.warning)
        assert not environment._action_delay_queue._pending
        time_before = float(data.time)
        with pytest.raises(ValueError, match="terminated episode"):
            environment.step(_action(environment))
        assert data.time == time_before
    finally:
        environment.close()


@pytest.mark.parametrize(("seed", "name"), [(17, "e7_agentview"), (36, "j8_agentview")])
def test_public_generator_accepts_a_same_seed_same_track_xyz_so3_pair(seed: int, name: str) -> None:
    payloads = []
    for task_id in TASKS:
        generated = generate_scenario(
            load_task(task_id), _recipe_path(task_id), seed, partition="test_id", recipe_name=name
        )
        assert generated == _proposal(task_id, seed, name)
        payload: Any = scenario_to_dict(generated)
        rotation = payload["motion"][0].pop("rotation")
        angular_velocity = payload["object_states"][0].pop("angular_velocity_world_rad_s")
        assert angular_velocity == [0.0, 0.0, rotation["angular_speed_rad_s"]]
        assert (angular_velocity[2] == 0.0) == (task_id == "t1_xyz")
        payloads.append(payload)
    assert payloads[0] == payloads[1]


def test_public_matched_generator_accepts_xyz_j8_seed17() -> None:
    generated = generate_scenario(
        load_task("t1_xyz"),
        _recipe_path("t1_xyz"),
        17,
        partition="test_id",
        recipe_name="j8_agentview",
    )
    assert generated == _proposal("t1_xyz", 17, "j8_agentview")


@pytest.mark.parametrize("factor", ["spatial", "physics"])
def test_public_matched_generator_physically_checks_external_recipe_support(
    factor: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    task = load_task("t1_xyz")
    document = load_yaml_strict(_recipe_path(task.task_id))
    for name, recipe in document["recipes"]["ood"][factor].items():
        if factor == "spatial":
            recipe["object_states"][0]["position_world_m"]["harmonic_center_world_m"][0] = 0.06
        else:
            recipe["physics"] = copy.deepcopy(document["recipes"]["test_id"][name]["physics"])
            recipe["physics"]["bodies"][0]["diagonal_inertia_kg_m2"][0] *= 1.01
    path = tmp_path / "external_xyz.yaml"
    path.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    recipe = _select_recipe(document, partition="ood", factor=factor, recipe_name="e7_agentview")
    expected = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(17)))
    baseline = _proposal(task.task_id)
    if factor == "spatial":
        assert expected.motion[0].translation.center_world_m[0] == 0.06
    else:
        assert expected.physics.bodies[0].mass_kg == baseline.physics.bodies[0].mass_kg
        assert expected.physics.bodies[0].diagonal_inertia_kg_m2[0] == (
            1.01 * baseline.physics.bodies[0].diagonal_inertia_kg_m2[0]
        )
    outcomes = []

    def observe_oracle(environment: DrivenInterceptionEnv) -> dict[str, Any]:
        model = environment.sim.model._model
        assert model.body_mass[environment._target_body_id] == expected.physics.bodies[0].mass_kg
        np.testing.assert_array_equal(
            model.body_inertia[environment._target_body_id],
            expected.physics.bodies[0].diagonal_inertia_kg_m2,
        )
        for geom_id in environment._target_geom_ids:
            contact = expected.physics.contacts[0]
            np.testing.assert_array_equal(
                model.geom_friction[geom_id], contact.friction_slide_spin_roll
            )
            np.testing.assert_array_equal(model.geom_solref[geom_id], contact.solref)
            np.testing.assert_array_equal(model.geom_solimp[geom_id], contact.solimp)
        np.testing.assert_array_equal(model.opt.gravity, expected.physics.gravity_world_m_s2)
        outcome = _run_native_oracle(environment)
        outcomes.append(outcome)
        return outcome

    monkeypatch.setattr(
        "se3_wam_benchmark.scenarios._feasibility._run_native_oracle", observe_oracle
    )
    generated = generate_scenario(
        task, path, 17, partition="ood", factor=factor, recipe_name="e7_agentview"
    )
    assert generated == expected
    assert len(outcomes) == 1
    assert outcomes[0]["success"] and outcomes[0]["failure_code"] is None
    assert 0.0 < outcomes[0]["terminal_time_s"] < 8.0
    assert "stable_dwell" in outcomes[0]["events"]


@pytest.mark.parametrize("task_id", TASKS)
def test_matched_initial_pose_and_twist_use_one_declared_harmonic_motion(task_id: str) -> None:
    task = load_task(task_id)
    recipe = copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_recipe_path(task_id)),
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        )
    )
    center = (0.025, -0.22, 0.8180000000000001)
    target = recipe["object_states"][0]
    target["position_world_m"] = {"harmonic_center_world_m": list(center)}
    target["quaternion_world_xyzw"] = {"yaw_rad": 0.0}
    target["linear_velocity_world_m_s"] = {"from_motion": True}
    target["angular_velocity_world_rad_s"] = {"from_motion": True}
    yaw_speed = 0.0 if task_id == "t1_xyz" else 0.8
    recipe["motion"] = [
        {
            "entity_id": "target",
            "translation": {
                "type": "harmonic",
                "drift_velocity_world_m_s": [0.0, 0.065, 0.0],
                "amplitude_m": [0.03, 0.0, 0.0],
                "frequency_hz": [0.4, 0.0, 0.0],
                "phase_rad": [math.pi / 2.0, 0.0, 0.0],
            },
            "rotation": {
                "type": "constant_angular_velocity",
                "axis_world": [0.0, 0.0, 1.0],
                "angular_speed_rad_s": yaw_speed,
            },
        }
    ]
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(17)))
    target_state = scenario.object_states[0]
    assert scenario.motion[0].translation.center_world_m == center
    np.testing.assert_array_equal(target_state.position_world_m, (0.055, *center[1:]))
    np.testing.assert_allclose(
        target_state.linear_velocity_world_m_s,
        (0.03 * 2.0 * math.pi * 0.4 * math.cos(math.pi / 2.0), 0.065, 0.0),
        rtol=0.0,
        atol=1e-15,
    )
    np.testing.assert_array_equal(target_state.angular_velocity_world_rad_s, (0.0, 0.0, yaw_speed))
    # The original ID bound is on the sampled center, so actual t0 x=0.055 is valid.
    _validate_matched_declarative_scenario(
        task,
        scenario,
        partition="test_id",
        factor=None,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )


@pytest.mark.parametrize("task_id,yaw_speed", [("t1_xyz", 0.0), ("t1_so3", 1.4)])
def test_matched_ood_yaw_axis_keeps_unspun_xyz_counterfactual(
    task_id: str, yaw_speed: float
) -> None:
    # Original dataset_manifest pairs a yaw-only OOD SO3 case with yaw-zero XYZ;
    # its translation and initial pose remain in the shared ID support.
    task = load_task(task_id)
    scenario = _materialize_recipe(
        task,
        _select_recipe(
            load_yaml_strict(_recipe_path(task_id)),
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview",
        ),
        np.random.Generator(np.random.PCG64(17)),
    )
    position = (0.0, -0.22, 0.8180000000000001)
    target = replace(
        scenario.object_states[0],
        position_world_m=position,
        quaternion_world_xyzw=(0.0, 0.0, 0.0, 1.0),
        linear_velocity_world_m_s=(0.015 * 2.0 * math.pi * 0.4, 0.065, 0.0),
        angular_velocity_world_rad_s=(0.0, 0.0, yaw_speed),
    )
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            position, (0.0, 0.065, 0.0), (0.015, 0.0, 0.0), (0.4, 0.0, 0.0), (0.0, 0.0, 0.0)
        ),
        ConstantAngularVelocityRotation((0.0, 0.0, 1.0), yaw_speed),
    )
    _validate_matched_declarative_scenario(
        task,
        replace(scenario, object_states=(target,), motion=(motion,)),
        partition="ood",
        factor="motion_parameters",
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )


@pytest.mark.parametrize(
    (
        "position",
        "yaw",
        "forward",
        "amplitude",
        "frequency",
        "yaw_speed",
        "source_pair_separation_m",
    ),
    [
        ((-0.025, -0.24, 0.8180000000000001), -0.35, 0.04, 0.0, 0.25, -0.4, 0.01204811505904615),
        ((0.0, -0.22, 0.8180000000000001), 0.0, 0.065, 0.015, 0.4, 0.8, 0.015137160512849595),
        ((0.025, -0.20, 0.8180000000000001), 0.35, 0.09, 0.03, 0.65, 1.2, 0.012879305296594007),
    ],
    ids=["id_low", "id_midpoint", "id_high"],
)
def test_matched_reference_body_origin_ttc_and_measured_500hz_tracking_are_distinct_facts(
    position: tuple[float, float, float],
    yaw: float,
    forward: float,
    amplitude: float,
    frequency: float,
    yaw_speed: float,
    source_pair_separation_m: float,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    traces = []
    for task_id in TASKS:
        # This probe supplies explicit correlated initial states below; validate
        # the completed fixture after replacing its pose and motion.
        scenario = _materialize_recipe(
            load_task(task_id),
            _select_recipe(
                load_yaml_strict(_recipe_path(task_id)),
                partition="test_id",
                factor=None,
                recipe_name="e7_agentview",
            ),
            np.random.Generator(np.random.PCG64(17)),
        )
        target = replace(
            scenario.object_states[0],
            position_world_m=position,
            quaternion_world_xyzw=(0.0, 0.0, math.sin(yaw / 2), math.cos(yaw / 2)),
            linear_velocity_world_m_s=(amplitude * 2.0 * math.pi * frequency, forward, 0.0),
            angular_velocity_world_rad_s=(
                0.0,
                0.0,
                0.0 if task_id == "t1_xyz" else yaw_speed,
            ),
        )
        motion = DrivenMotionSpec(
            "target",
            HarmonicTranslation(
                position,
                (0.0, forward, 0.0),
                (amplitude, 0.0, 0.0),
                (frequency, 0.0, 0.0),
                (0.0, 0.0, 0.0),
            ),
            ConstantAngularVelocityRotation(
                (0.0, 0.0, 1.0), 0.0 if task_id == "t1_xyz" else yaw_speed
            ),
        )
        scenario = replace(scenario, object_states=(target,), motion=(motion,))
        _validate_matched_declarative_scenario(
            load_task(task_id),
            scenario,
            partition="test_id",
            factor=None,
            catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
        )
        environment = make_env(task_id, scenario)
        try:
            environment.reset()
            model, data = environment.sim.model._model, environment.sim.data._data
            times, positions, references, yaw_errors, forces, support = [], [], [], [], [], []
            original_update = environment._capture.update

            def observe(**state: Any) -> None:
                reference = _motion_state_at_time(
                    motion,
                    initial_position_world_m=target.position_world_m,
                    initial_quaternion_world_xyzw=target.quaternion_world_xyzw,
                    simulator_time_s=float(data.time),
                )
                times.append(float(data.time))
                positions.append(state["position"].copy())
                references.append(reference.position_world_m)
                # The old monitor samples the cached body frame after mj_step.
                np.testing.assert_array_equal(
                    state["position"], data.xpos[environment._target_body_id]
                )
                rotation = data.xmat[environment._target_body_id].reshape(3, 3)
                reference_yaw = yaw + (0.0 if task_id == "t1_xyz" else yaw_speed) * data.time
                yaw_errors.append(
                    (math.atan2(rotation[1, 0], rotation[0, 0]) - reference_yaw + math.pi)
                    % (2 * math.pi)
                    - math.pi
                )
                _assert_wrench(environment)
                forces.append(np.linalg.norm(environment._last_wrench[:2]))
                total = 0.0
                for index in range(data.ncon):
                    contact = data.contact[index]
                    pair = {int(contact.geom1), int(contact.geom2)}
                    if pair & set(environment._target_geom_ids) and pair & set(
                        environment._support_geom_ids
                    ):
                        force = np.empty(6)
                        mujoco.mj_contactForce(model, data, index, force)
                        total += float(force[0])
                support.append(total)
                original_update(**state)

            monkeypatch.setattr(environment._capture, "update", observe)
            for _ in range(160):
                _, _, done, outcome = environment.step(_action(environment))
                if done:
                    break
            assert done and outcome["failure_code"] in ("timeout", "downstream_exit")
            assert len(times) == environment._episode_tick * 25
            assert not any(warning.number for warning in data.warning)
            assert max(support) > 0.0
            positions_array, references_array = np.asarray(positions), np.asarray(references)
            error = np.linalg.norm((positions_array - references_array)[:, :2], axis=1)
            # Original DB0 measurements of these six open-gripper probes reach
            # 17.60 mm XY and 0.04477 rad yaw error under physical contact dynamics.
            # These bounds are regression checks, not proposal-admission criteria.
            assert np.max(error) < 0.020
            assert np.max(np.abs(yaw_errors)) < 0.050
            crossings = [t for t, p in zip(times, positions, strict=True) if p[1] > 0.0]
            exit_crossings = [t for t, p in zip(times, positions, strict=True) if p[1] > 0.39]
            assert crossings
            if outcome["failure_code"] == "downstream_exit":
                assert outcome["terminal_time_s"] == min(exit_crossings)
            else:
                assert not exit_crossings
            traces.append(
                {
                    "times": times,
                    "positions": positions_array,
                    "references": references_array,
                    "max_xy_reference_error_mm": float(np.max(error) * 1000),
                    "rms_xy_reference_error_mm": float(np.sqrt(np.mean(error**2)) * 1000),
                    "max_z_reference_error_mm": float(
                        np.max(np.abs(positions_array[:, 2] - references_array[:, 2])) * 1000
                    ),
                    "max_yaw_error_rad": float(np.max(np.abs(yaw_errors))),
                    "max_force_n": float(max(forces)),
                    "crossing_zero_s": min(crossings),
                    "exit_s": min(exit_crossings) if exit_crossings else None,
                }
            )
        finally:
            environment.close()
    common = min(len(trace["times"]) for trace in traces)
    np.testing.assert_array_equal(traces[0]["times"][:common], traces[1]["times"][:common])
    np.testing.assert_array_equal(
        traces[0]["references"][:common], traces[1]["references"][:common]
    )
    separation = np.linalg.norm(
        traces[0]["positions"][:common] - traces[1]["positions"][:common], axis=1
    )
    # The original six probes produce these measured body-origin separations;
    # rotating the asymmetric body changes its contacts with the support.
    assert np.max(separation) == pytest.approx(source_pair_separation_m, rel=0.0, abs=1e-8)
    report = {
        "forward_m_s": forward,
        "reference_zero_s": -position[1] / forward,
        "reference_exit_s": (0.39 - position[1]) / forward,
        "max_pair_body_origin_separation_mm": float(np.max(separation) * 1000),
        "actual": [
            {k: v for k, v in trace.items() if k not in ("times", "positions", "references")}
            for trace in traces
        ],
    }
    print("matched_tracking " + json.dumps(report, sort_keys=True))


@pytest.mark.parametrize("task_id", TASKS)
@pytest.mark.parametrize(
    ("name", "representation", "partition", "factor"),
    [
        ("e7_agentview", "delta", "test_id", None),
        ("j8_agentview_wrist", "absolute", "ood", "action_delay"),
    ],
)
def test_real_matched_export_manifest_and_exact_fixed_action_replay(
    task_id: str,
    name: str,
    representation: str,
    partition: Partition,
    factor: str | None,
    tmp_path: Path,
) -> None:
    scenario = _proposal(task_id, name=name, partition=partition, factor=factor)
    assert (scenario.action_delay_steps > 0) == (factor == "action_delay")
    first, second = make_env(task_id, scenario), None
    try:
        raw_first = first.reset()
        exported = first.export_scenario()
        identity = f"v1:{partition}:{factor + ':' if factor else ''}{task_id}:000000"
        manifest = ScenarioManifest(
            (ScenarioManifestRow(1, "v1", identity, task_id, partition, factor, 17, exported),)
        )
        path = tmp_path / "scenario.jsonl"
        write_manifest(manifest, path)
        loaded = load_manifest(path)
        assert loaded == manifest
        second = make_env(task_id, loaded.rows[0].scenario)
        raw_second = second.reset()
        assert second.export_scenario() == exported
        first_model, second_model = first.sim.model._model, second.sim.model._model
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "body_pos",
            "body_quat",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_condim",
            "geom_contype",
            "geom_conaffinity",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "geom_surfacevel",
            "jnt_type",
            "jnt_range",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_pos",
            "light_dir",
            "light_ambient",
            "light_diffuse",
            "light_specular",
            "light_attenuation",
            "light_cutoff",
            "light_active",
        ):
            np.testing.assert_array_equal(getattr(first_model, field), getattr(second_model, field))
        assert first_model.opt.timestep == second_model.opt.timestep == 0.002
        np.testing.assert_array_equal(first_model.opt.gravity, second_model.opt.gravity)
        for tick in range(9):
            data1, data2 = first.sim.data._data, second.sim.data._data
            assert data1.time == data2.time == pytest.approx(tick / 20.0, abs=1e-12)
            for field in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xipos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            ):
                np.testing.assert_array_equal(getattr(data1, field), getattr(data2, field))
            observation1, observation2 = (
                first._benchmark_observation(raw_first),
                second._benchmark_observation(raw_second),
            )
            for field in fields(observation1):
                if field.name != "rgb":
                    np.testing.assert_array_equal(
                        getattr(observation1, field.name),
                        getattr(observation2, field.name),
                        strict=True,
                        err_msg=field.name,
                    )
            # Keep physical replay exact and report the small EGL RGB differences.
            rgb1, rgb2 = observation1.rgb, observation2.rgb
            assert rgb1.shape == rgb2.shape
            assert rgb1.dtype == rgb2.dtype == np.uint8
            difference = np.abs(rgb1.astype(np.int16) - rgb2.astype(np.int16))
            max_abs = int(difference.max())
            report = {
                "probe": f"{task_id}_{name}_{representation}_tick_{tick}",
                "different_channels": int(np.count_nonzero(difference)),
                "total_channels": int(difference.size),
                "max_abs": max_abs,
                "max_different_channels_per_view_frame": int(
                    np.count_nonzero(difference, axis=(-3, -2, -1)).max()
                ),
            }
            print("replay_rgb " + json.dumps(report, sort_keys=True))
            assert max_abs <= 1, report
            if tick < 8:
                action = _action(first, representation, displacement=0.001 * ((tick % 3) - 1))
                raw_first, reward1, done1, info1 = first.step(action)
                raw_second, reward2, done2, info2 = second.step(action)
                assert (reward1, done1, info1) == (reward2, done2, info2)
    finally:
        if second is not None:
            second.close()
        first.close()


@pytest.mark.parametrize("task_id", TASKS)
def test_matched_moving_target_exit_uses_cached_body_origin_and_first_physics_time(
    task_id: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    scenario = _proposal(task_id)
    target = replace(scenario.object_states[0], position_world_m=(0.0, 0.3895, 0.8180000000000001))
    law = scenario.motion[0].translation
    center = np.asarray(target.position_world_m) - np.asarray(law.amplitude_m) * np.sin(
        law.phase_rad
    )
    motion = replace(scenario.motion[0], translation=replace(law, center_world_m=tuple(center)))
    environment = make_env(task_id, replace(scenario, object_states=(target,), motion=(motion,)))
    try:
        environment.reset()
        samples = []
        original_update = environment._capture.update

        def observe(**state: Any) -> None:
            data = environment.sim.data._data
            samples.append(
                (
                    float(data.time),
                    state["position"].copy(),
                    data.xpos[environment._target_body_id].copy(),
                )
            )
            _assert_wrench(environment)
            original_update(**state)

        monkeypatch.setattr(environment._capture, "update", observe)
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "downstream_exit"
        assert len(samples) == 25
        for index, (time_s, position, cached_body_position) in enumerate(samples, 1):
            assert time_s == pytest.approx(index * 0.002, abs=1e-12)
            np.testing.assert_array_equal(position, cached_body_position)
        crossings = [time_s for time_s, position, _ in samples if position[1] > 0.39]
        assert info["terminal_time_s"] == min(crossings)
        assert 0.0 < info["terminal_time_s"] < environment.sim.data.time
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


@pytest.mark.parametrize("task_id", TASKS)
def test_matched_native_bad_qpos_is_invalid_not_a_recovered_drop(
    task_id: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment = make_env(task_id, _proposal(task_id))
    try:
        environment.reset()
        action = _action(environment)
        data = environment.sim.data._data
        monkeypatch.chdir(tmp_path)
        data.qpos[environment._target_qpos_address] = np.nan
        _, reward, done, info = environment.step(action)
        assert done and reward == 0.0 and not info["success"]
        assert info["failure_code"] == "invalid_state" and info["terminal_time_s"] == 0.0
        assert data.warning[mujoco.mjtWarning.mjWARN_BADQPOS].number > 0
        assert np.isfinite(data.qpos).all()
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


@pytest.mark.parametrize("task_id", TASKS)
@pytest.mark.parametrize(
    "kind", ["joint_out_of_range", "target_collision_outside_support", "target_not_visible"]
)
def test_matched_reset_rejections_remain_real_and_structured(task_id: str, kind: str) -> None:
    scenario = _proposal(task_id)
    if kind == "target_not_visible":
        view = replace(scenario.cameras.views[0], position_parent_m=(3.0, 0.0, 2.0))
        scenario = replace(scenario, cameras=replace(scenario.cameras, views=(view,)))
    environment = make_env(task_id, scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        if kind == "joint_out_of_range":
            joint = model.joint(environment.robots[0].robot_model.joints[0])
            data.qpos[model.jnt_qposadr[joint.id]] = model.jnt_range[joint.id, 1] + 0.1
            environment.sim.forward()
        elif kind == "target_collision_outside_support":
            address = environment._target_qpos_address
            data.qpos[address : address + 3] = data.geom_xpos[min(environment._left_pad_ids)]
            environment.sim.forward()
        with pytest.raises(_CaptureProposalRejected) as rejected:
            _validate_capture_reset(environment)
        assert rejected.value.stage == "reset" and rejected.value.failure_code == kind
    finally:
        environment.close()


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
def test_matched_complete_case_rejects_unselected_bad_branch_before_rng(task_id: str) -> None:
    task = load_task(task_id)
    base = copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_recipe_path(task_id)),
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview_wrist",
        )
    )
    alternatives = [copy.deepcopy(base), copy.deepcopy(base)]
    rng = np.random.default_rng(17)
    untouched = copy.deepcopy(rng.bit_generator.state)
    selected = int(np.random.default_rng(17).integers(2))
    # The bad branch would not be selected; all complete cases must validate first.
    alternatives[1 - selected]["object_states"][0]["asset_id"] = "obj.cube_44_v1"
    with pytest.raises(ValueError):
        _materialize_recipe(task, {"choices": alternatives}, rng)
    assert rng.bit_generator.state == untouched


@pytest.mark.parametrize("task_id", ["t1_xyz", "t1_so3"])
def test_matched_complete_case_samples_one_whole_branch(task_id: str) -> None:
    task = load_task(task_id)
    base = copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_recipe_path(task_id)),
            partition="test_id",
            factor=None,
            recipe_name="e7_agentview_wrist",
        )
    )
    alternatives = [copy.deepcopy(base), copy.deepcopy(base)]
    for recipe, x, speed in zip(alternatives, (-0.025, 0.025), (0.04, 0.09)):
        recipe["object_states"][0]["position_world_m"]["harmonic_center_world_m"][0] = x
        recipe["motion"][0]["translation"]["drift_velocity_world_m_s"][1] = speed
    for seed in (0, 1):
        expected_rng = np.random.default_rng(seed)
        selected = int(expected_rng.integers(2))
        expected = _materialize_recipe(task, alternatives[selected], expected_rng)
        rng = np.random.default_rng(seed)
        actual = _materialize_recipe(task, {"choices": alternatives}, rng)
        assert actual == expected
        assert rng.bit_generator.state == expected_rng.bit_generator.state


@pytest.mark.parametrize("yaw", [-0.35, 0.35, 0.1])
def test_matched_scalar_reference_yaw_preserves_declared_quaternion_ratio(yaw: float) -> None:
    # The old +/-0.35 QA quaternion has norm 1-1 ULP. Normalizing both components
    # before atan2 changes the reconstructed angle and the first planar wrench.
    quaternion = (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))
    position = (0.0, -0.22, 0.8180000000000001)
    motion = DrivenMotionSpec(
        "target",
        HarmonicTranslation(
            position, (0.0, 0.065, 0.0), (0.015, 0.0, 0.0), (0.45, 0.0, 0.0), (0.3, 0.0, 0.0)
        ),
        ConstantAngularVelocityRotation((0.0, 0.0, 1.0), 1.2),
    )
    for time_s in (0.0, 0.024, 0.25):
        state = _motion_state_at_time(
            motion,
            initial_position_world_m=position,
            initial_quaternion_world_xyzw=quaternion,
            simulator_time_s=time_s,
        )
        assert state.yaw_world_rad == yaw + 1.2 * time_s


@pytest.mark.parametrize(
    "name", ["e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist"]
)
def test_xyz_stress_preserves_complete_legacy_qa_cases(name: str) -> None:
    from se3_wam_benchmark.scenarios._validation import _validate_declarative_scenario

    task = load_task("t1_xyz")
    document = load_yaml_strict(_recipe_path("t1_xyz"))
    recipe = _select_recipe(document, partition="stress", factor=None, recipe_name=name)
    assert set(recipe) == {"choices"} and len(recipe["choices"]) == 3
    # Fixed stress.py endpoints and suite.py cross-seed nominal; no published row identity.
    expected = [
        (-0.025, -0.24, -0.35, 0.04, 0.0, 0.25, -math.pi),
        (0.025, -0.20, 0.35, 0.09, 0.03, 0.65, math.pi),
        (0.0, -0.22, 0.10, 0.065, 0.015, 0.45, 0.30),
    ]
    for leaf, values in zip(recipe["choices"], expected, strict=True):
        target = leaf["object_states"][0]
        law = leaf["motion"][0]
        translation = law["translation"]
        assert (
            *target["position_world_m"]["harmonic_center_world_m"][:2],
            target["quaternion_world_xyzw"]["yaw_rad"],
            translation["drift_velocity_world_m_s"][1],
            translation["amplitude_m"][0],
            translation["frequency_hz"][0],
            translation["phase_rad"][0],
        ) == values
        assert law["rotation"]["angular_speed_rad_s"] == 0.0
        scenario = _materialize_recipe(task, leaf, np.random.default_rng(0))
        _validate_declarative_scenario(
            task, scenario, partition="stress", factor=None, document=document, recipe_name=name
        )
    for seed in (0, 1):
        expected_rng = np.random.default_rng(seed)
        index = int(expected_rng.integers(len(recipe["choices"])))
        expected_scenario = _materialize_recipe(task, recipe["choices"][index], expected_rng)
        rng = np.random.default_rng(seed)
        assert _materialize_recipe(task, recipe, rng) == expected_scenario
        assert rng.bit_generator.state == expected_rng.bit_generator.state


@pytest.mark.parametrize(
    "name", ["e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist"]
)
@pytest.mark.parametrize("kind", ["asset", "negative_speed", "missing_field"])
def test_xyz_stress_rejects_unselected_invalid_case_before_rng(name: str, kind: str) -> None:
    recipe = copy.deepcopy(
        _select_recipe(
            load_yaml_strict(_recipe_path("t1_xyz")),
            partition="stress",
            factor=None,
            recipe_name=name,
        )
    )
    rng = np.random.default_rng(17)
    untouched = copy.deepcopy(rng.bit_generator.state)
    index = (1 + int(np.random.default_rng(17).integers(len(recipe["choices"])))) % len(
        recipe["choices"]
    )
    leaf = recipe["choices"][index]
    if kind == "asset":
        leaf["object_states"][0]["asset_id"] = "obj.cube_44_v1"
    elif kind == "negative_speed":
        leaf["motion"][0]["translation"]["drift_velocity_world_m_s"][1] = -0.04
    else:
        del leaf["physics"]
    with pytest.raises(ValueError):
        _materialize_recipe(load_task("t1_xyz"), recipe, rng)
    assert rng.bit_generator.state == untouched
