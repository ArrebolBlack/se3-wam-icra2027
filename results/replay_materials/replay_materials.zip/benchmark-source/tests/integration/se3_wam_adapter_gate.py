"""Explicit Model integration gate; intentionally outside default test discovery."""

from __future__ import annotations

import json
import logging
import math
import os
import time
from dataclasses import replace
from pathlib import Path
from typing import cast

import numpy as np
import numpy.typing as npt
import pytest
import torch
from se3_wam.api import ActionChunk, PolicyObservation, load_policy
from se3_wam.api import ActionSpec as SE3WAMActionSpec
from torch import Tensor

from se3_wam_benchmark.api import evaluate
from se3_wam_benchmark.control.action import (
    ActionMode,
    ActionRepresentation,
    BenchmarkAction,
    _quaternion_xyzw_to_principal_rotvec,
)
from se3_wam_benchmark.data.recorder import _read_episode_file
from se3_wam_benchmark.data.schema import _episode_id
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.integrations.se3_wam import bind_policy
from se3_wam_benchmark.scenarios.manifest import load_manifest
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task

ROOT = Path(__file__).resolve().parents[2]
_E7_LIMITS = (0.05, 0.05, 0.05, 0.5, 0.5, 0.5)
_J8_LIMITS = (0.05,) * 7


def _readonly(value: npt.NDArray[np.generic]) -> npt.NDArray[np.generic]:
    result = np.ascontiguousarray(value)
    result.setflags(write=False)
    return result


def _observation(*, views: int = 2) -> BenchmarkObservation:
    view_names = ("agentview",) if views == 1 else ("agentview", "wrist")
    rgb = np.arange(views * 224 * 224 * 3, dtype=np.uint8).reshape(views, 224, 224, 3)
    depth = np.full((views, 224, 224), 1.25, dtype=np.float32)
    depth[0, 0, 0] = 0.0
    intrinsics = np.repeat(np.eye(3, dtype=np.float64)[None, ...], views, axis=0)
    intrinsics[:, 0, 0] = 160.0
    intrinsics[:, 1, 1] = 161.0
    world_from_camera = np.repeat(np.eye(4, dtype=np.float64)[None, ...], views, axis=0)
    world_from_camera[:, 0, 3] = np.arange(views, dtype=np.float64) + 0.2
    base_from_world = np.eye(4, dtype=np.float64)
    base_from_world[:2, :2] = ((0.0, -1.0), (1.0, 0.0))
    base_from_world[:3, 3] = (0.1, -0.2, 0.3)
    return BenchmarkObservation(
        tick=3,
        timestamp_s=0.15,
        view_names=view_names,
        rgb=cast(npt.NDArray[np.uint8], _readonly(rgb)),
        depth_m=cast(npt.NDArray[np.float32], _readonly(depth)),
        camera_intrinsics=cast(npt.NDArray[np.float64], _readonly(intrinsics)),
        world_from_camera_cv=cast(npt.NDArray[np.float64], _readonly(world_from_camera)),
        T_robot_base_from_world=cast(npt.NDArray[np.float64], _readonly(base_from_world)),
        joint_position=cast(
            npt.NDArray[np.float32],
            _readonly(np.linspace(-0.3, 0.3, 7, dtype=np.float32)),
        ),
        joint_velocity=cast(npt.NDArray[np.float32], _readonly(np.zeros(7, dtype=np.float32))),
        eef_position=cast(
            npt.NDArray[np.float32],
            _readonly(np.asarray((0.4, -0.1, 0.8), dtype=np.float32)),
        ),
        eef_quaternion_xyzw=cast(
            npt.NDArray[np.float32],
            _readonly(np.asarray((0.0, 0.0, 0.0, 1.0), dtype=np.float32)),
        ),
        gripper_position=cast(
            npt.NDArray[np.float32],
            _readonly(np.asarray((0.021, -0.019), dtype=np.float32)),
        ),
        gripper_velocity=cast(npt.NDArray[np.float32], _readonly(np.zeros(2, dtype=np.float32))),
    )


class _ContractPolicy:
    def __init__(self, action_spec: SE3WAMActionSpec, action: object) -> None:
        self._action_spec = action_spec
        self.action = action
        self.reset_calls = 0
        self.select_observations: list[PolicyObservation] = []
        self.predict_calls = 0

    @property
    def action_spec(self) -> SE3WAMActionSpec:
        return self._action_spec

    def predict_action_chunk(self, observation: PolicyObservation) -> ActionChunk:
        self.predict_calls += 1
        raise AssertionError(observation)

    def select_action(self, observation: PolicyObservation) -> Tensor:
        self.select_observations.append(observation)
        return cast(Tensor, self.action)

    def reset(self) -> None:
        self.reset_calls += 1


def _bind(
    policy: _ContractPolicy,
    *,
    camera: bool = True,
    depth: bool = True,
) -> object:
    return bind_policy(
        policy,
        camera_geometry_enabled=camera,
        observation_depth_enabled=depth,
        observation_flow_enabled=False,
        observation_anchor_enabled=False,
    )


@pytest.mark.parametrize(
    ("mode", "representation", "limits", "dimension"),
    [
        ("E7", "delta", _E7_LIMITS, 7),
        ("E7", "absolute", _E7_LIMITS, 7),
        ("J8", "delta", _J8_LIMITS, 8),
        ("J8", "absolute", _J8_LIMITS, 8),
    ],
)
def test_adapter_maps_one_observation_to_one_same_representation_action(
    mode: ActionMode,
    representation: ActionRepresentation,
    limits: tuple[float, ...],
    dimension: int,
) -> None:
    selected = torch.zeros(dimension, dtype=torch.float32)
    selected[0] = 0.01
    selected[-1] = 1.0
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode=mode, representation=representation, motion_limits=limits),
        selected,
    )
    adapter = _bind(policy)
    observation = _observation()

    adapter.reset()
    action = adapter.act(observation)

    assert policy.reset_calls == 1
    assert policy.predict_calls == 0
    assert len(policy.select_observations) == 1
    assert action.mode == mode
    assert action.representation == representation
    np.testing.assert_array_equal(action.value, selected.numpy())
    assert action.value.dtype == np.float64
    assert action.value.flags.c_contiguous
    assert action.value.flags.writeable is False
    with pytest.raises(ValueError, match="read-only"):
        action.value[0] = 0.0
    selected[0] = 0.02
    assert float(action.value[0]) == pytest.approx(0.01)

    mapped = policy.select_observations[0]
    assert mapped.view_names == observation.view_names
    assert mapped.rgb.dtype == torch.uint8
    assert mapped.rgb.device.type == "cpu"
    assert mapped.rgb.is_contiguous()
    assert mapped.rgb.requires_grad is False
    np.testing.assert_array_equal(mapped.rgb.numpy(), observation.rgb.transpose(0, 3, 1, 2))
    assert mapped.timestamp_s.dtype == torch.float64
    assert float(mapped.timestamp_s.item()) == observation.timestamp_s
    np.testing.assert_array_equal(mapped.joint_position_rad.numpy(), observation.joint_position)
    np.testing.assert_array_equal(
        mapped.eef_position_robot_base_m.numpy(), observation.eef_position
    )
    np.testing.assert_array_equal(
        mapped.eef_quaternion_robot_base_xyzw.numpy(), observation.eef_quaternion_xyzw
    )
    assert float(mapped.gripper_open_fraction.item()) == pytest.approx(0.5, abs=1e-7)

    assert mapped.camera_intrinsics is not None
    assert mapped.T_robot_base_from_camera is not None
    assert mapped.depth_m is not None
    assert mapped.depth_valid is not None
    np.testing.assert_allclose(
        mapped.camera_intrinsics.numpy(), observation.camera_intrinsics, rtol=0.0, atol=0.0
    )
    expected_transform = np.matmul(
        observation.T_robot_base_from_world[None, ...], observation.world_from_camera_cv
    ).astype(np.float32)
    np.testing.assert_allclose(
        mapped.T_robot_base_from_camera.numpy(), expected_transform, rtol=0.0, atol=0.0
    )
    np.testing.assert_array_equal(mapped.depth_m.numpy()[:, 0], observation.depth_m)
    np.testing.assert_array_equal(mapped.depth_valid.numpy(), mapped.depth_m.numpy() > 0)
    assert mapped.past_flow_px is None
    assert mapped.past_flow_valid is None
    assert mapped.anchor_position_m is None
    assert mapped.anchor_quaternion_xyzw is None
    assert mapped.anchor_valid is None
    mapped.joint_position_rad[0] = 1.0
    assert float(observation.joint_position[0]) == pytest.approx(-0.3)


@pytest.mark.parametrize(
    ("camera_enabled", "depth_enabled"),
    [(False, False), (False, True), (True, False), (True, True)],
)
def test_camera_geometry_and_upstream_depth_are_independent_resolved_choices(
    camera_enabled: bool, depth_enabled: bool
) -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode="E7", representation="delta", motion_limits=_E7_LIMITS),
        torch.zeros(7, dtype=torch.float32),
    )
    policy.action[-1] = 0.0
    adapter = _bind(policy, camera=camera_enabled, depth=depth_enabled)
    adapter.act(_observation(views=1))
    mapped = policy.select_observations[-1]
    assert (mapped.camera_intrinsics is not None) is camera_enabled
    assert (mapped.T_robot_base_from_camera is not None) is camera_enabled
    assert (mapped.depth_m is not None) is depth_enabled
    assert (mapped.depth_valid is not None) is depth_enabled


def test_scalar_carriers_remain_cpu_under_a_non_cpu_default_device() -> None:
    selected = torch.zeros(7, dtype=torch.float32)
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode="E7", representation="delta", motion_limits=_E7_LIMITS),
        selected,
    )
    adapter = _bind(policy)
    observation = _observation(views=1)

    with torch.device("meta"):
        action = adapter.act(observation)

    mapped = policy.select_observations[-1]
    carriers = (
        mapped.rgb,
        mapped.timestamp_s,
        mapped.joint_position_rad,
        mapped.eef_position_robot_base_m,
        mapped.eef_quaternion_robot_base_xyzw,
        mapped.gripper_open_fraction,
        mapped.camera_intrinsics,
        mapped.T_robot_base_from_camera,
        mapped.depth_m,
        mapped.depth_valid,
    )
    assert all(value is not None and value.device.type == "cpu" for value in carriers)
    assert float(mapped.timestamp_s.item()) == observation.timestamp_s
    assert float(mapped.gripper_open_fraction.item()) == pytest.approx(0.5, abs=1e-7)
    np.testing.assert_array_equal(action.value, selected.numpy())


@pytest.mark.parametrize(
    "option",
    [
        "camera_geometry_enabled",
        "observation_depth_enabled",
        "observation_flow_enabled",
        "observation_anchor_enabled",
    ],
)
def test_binding_requires_explicit_strict_bool_configuration(option: str) -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode="E7", representation="delta", motion_limits=_E7_LIMITS),
        torch.zeros(7, dtype=torch.float32),
    )
    values: dict[str, object] = {
        "camera_geometry_enabled": False,
        "observation_depth_enabled": False,
        "observation_flow_enabled": False,
        "observation_anchor_enabled": False,
    }
    values[option] = 1
    with pytest.raises(ValueError, match=option):
        bind_policy(policy, **cast(dict[str, bool], values))


@pytest.mark.parametrize(
    ("flow", "anchor", "message"),
    [(True, False, "past Flow"), (False, True, "Anchor")],
)
def test_binding_fails_when_resolved_config_requires_unavailable_upstream_fields(
    flow: bool, anchor: bool, message: str
) -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode="E7", representation="delta", motion_limits=_E7_LIMITS),
        torch.zeros(7, dtype=torch.float32),
    )
    with pytest.raises(ValueError, match=message):
        bind_policy(
            policy,
            camera_geometry_enabled=False,
            observation_depth_enabled=False,
            observation_flow_enabled=flow,
            observation_anchor_enabled=anchor,
        )
    assert policy.select_observations == []


@pytest.mark.parametrize("representation", ["delta", "absolute"])
def test_binding_rejects_continuous_gripper_even_with_benchmark_motion_limits(
    representation: str,
) -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(
            mode="J8",
            representation=representation,
            motion_limits=(0.05,) * 7,
            gripper_mode="continuous",
        ),
        torch.zeros(8, dtype=torch.float32),
    )
    with pytest.raises(ValueError, match="requires the discrete gripper contract"):
        _bind(policy)
    assert policy.select_observations == []


def test_binding_rejects_motion_limits_that_differ_from_the_benchmark_profile() -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(
            mode="E7",
            representation="delta",
            motion_limits=(0.051, 0.05, 0.05, 0.5, 0.5, 0.5),
        ),
        torch.zeros(7, dtype=torch.float32),
    )
    with pytest.raises(ValueError, match="default profile"):
        _bind(policy)


@pytest.mark.parametrize(
    ("action", "message"),
    [
        (np.zeros(7, dtype=np.float32), "torch.Tensor"),
        (torch.zeros(7, dtype=torch.float64), "float32"),
        (torch.zeros(8, dtype=torch.float32), "float32\\[7\\]"),
        (torch.zeros((7, 2), dtype=torch.float32)[:, 0], "contiguous"),
        (torch.zeros(7, dtype=torch.float32, requires_grad=True), "detached"),
        (torch.tensor([math.nan, 0, 0, 0, 0, 0, 0], dtype=torch.float32), "finite"),
    ],
)
def test_adapter_rejects_invalid_model_action_carriers(action: object, message: str) -> None:
    policy = _ContractPolicy(
        SE3WAMActionSpec(mode="E7", representation="delta", motion_limits=_E7_LIMITS),
        action,
    )
    with pytest.raises(ValueError, match=message):
        _bind(policy).act(_observation(views=1))


class _NeutralPhysicalPolicy(_ContractPolicy):
    def __init__(self, mode: ActionMode, representation: ActionRepresentation) -> None:
        limits = _E7_LIMITS if mode == "E7" else _J8_LIMITS
        super().__init__(
            SE3WAMActionSpec(
                mode=mode,
                representation=representation,
                motion_limits=limits,
            ),
            object(),
        )
        self.selected_actions: list[Tensor] = []

    def select_action(self, observation: PolicyObservation) -> Tensor:
        self.select_observations.append(observation)
        if self.action_spec.mode == "E7":
            motion = torch.zeros(6, dtype=torch.float32)
            if self.action_spec.representation == "absolute":
                motion[:3] = observation.eef_position_robot_base_m
                quaternion = observation.eef_quaternion_robot_base_xyzw.numpy().astype(np.float64)
                motion[3:] = torch.from_numpy(
                    _quaternion_xyzw_to_principal_rotvec(quaternion).astype(np.float32)
                )
        else:
            motion = torch.zeros(7, dtype=torch.float32)
            if self.action_spec.representation == "absolute":
                motion[:] = observation.joint_position_rad
        selected = torch.cat((motion, torch.zeros(1, dtype=torch.float32)))
        self.selected_actions.append(selected)
        return selected


class _ProjectedExecutionPolicy(_ContractPolicy):
    """Controlled raw rows through the real Model projection and executor."""

    def __init__(self) -> None:
        from se3_wam.config.schema import SynchronousExecutionConfig
        from se3_wam.inference.executor import _ChunkExecutor

        super().__init__(
            SE3WAMActionSpec(
                mode="E7", representation="delta", motion_limits=(0.1,) * 3 + (0.5,) * 3
            ),
            object(),
        )
        self.raw = torch.tensor(
            [[0.2, -0.2, 0.2, 0, 0, 0, 0.7], [-0.2, 0.2, -0.2, 0, 0, 0, -0.7]], dtype=torch.float32
        )
        self.executor = _ChunkExecutor(
            SynchronousExecutionConfig(profile="synchronous_receding_horizon", steps_per_replan=2),
            action_horizon=2,
            action_dimension=7,
            guidance_device=torch.device("cpu"),
        )

    def reset(self) -> None:
        super().reset()
        self.executor.reset()

    def select_action(self, observation: PolicyObservation) -> Tensor:
        from se3_wam.inference.policy import _physical_action_chunk

        self.select_observations.append(observation)

        def plan(
            guidance: Tensor | None, consumed: int, delay: int
        ) -> tuple[Tensor, Tensor, Tensor]:
            del guidance, consumed, delay
            return (
                _physical_action_chunk(self.action_spec, self.raw, action_horizon=2).actions,
                self.raw.clone(),
                self.raw.clone(),
            )

        return self.executor.select_action(plan)


def test_model_projection_reaches_native_osc_and_default_env_rejects_it() -> None:
    from se3_wam_benchmark.envs.factory import make_env
    from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
    from se3_wam_benchmark.tasks.registry import load_yaml_strict

    task = load_task("grasp")
    recipe = _select_recipe(
        load_yaml_strict(ROOT / "configs/scenarios/grasp.yaml"),
        partition="test_id",
        factor=None,
        recipe_name="e7_agentview",
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(2)))
    model = _ProjectedExecutionPolicy()
    adapter = _bind(model)
    default = make_env("grasp", scenario)
    expanded = make_env("grasp", scenario, execution_translation_limit_m=0.1)
    try:
        default.reset()
        raw = expanded.reset()
        adapter.reset()
        for tick in range(2):
            action = adapter.act(expanded._benchmark_observation(raw))
            np.testing.assert_array_equal(
                action.value[:3],
                np.asarray([1, -1, 1]) * (-1) ** tick * np.float64(np.float32(0.1)),
            )
            with pytest.raises(ValueError, match="execution-delta"):
                default.step(action)
            assert default._action_spec is None and default._episode_tick == 0
            part = expanded.robots[0].composite_controller.part_controllers["right"]
            expanded._achieved_controller_state()
            before = part.ref_pos.copy()
            raw, _, _, _ = expanded.step(action)
            np.testing.assert_allclose(
                part.goal_pos - before,
                np.asarray([1, -1, 1]) * (-1) ** tick * 0.1,
                rtol=0,
                atol=1e-12,
            )
            assert expanded._last_action_application_fact() == (tick, tick, action)
    finally:
        adapter.reset()
        expanded.close()
        default.close()


def test_model_selected_log_matches_formal_record_and_delayed_application(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
    from se3_wam_benchmark.tasks.registry import load_yaml_strict

    task = load_task("grasp")
    recipe = _select_recipe(
        load_yaml_strict(ROOT / "configs/scenarios/grasp.yaml"),
        partition="test_id",
        factor=None,
        recipe_name="e7_agentview",
    )
    scenario = replace(
        _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(2))),
        action_delay_steps=2,
    )
    selected_dir, replay_dir = tmp_path / "selected", tmp_path / "replay"
    selected_dir.mkdir()
    replay_dir.mkdir()
    model = _ProjectedExecutionPolicy()
    adapter = _bind(model)
    scenario_id = "v1:test_id:grasp:000000"
    with (
        caplog.at_level(logging.INFO, logger="se3_wam.inference.executor"),
        caplog.at_level(logging.INFO, logger="se3_wam_benchmark.evaluation.rollout"),
    ):
        trace = _rollout_episode(
            task,
            scenario,
            adapter,
            scenario_id=scenario_id,
            partition="test_id",
            factor=None,
            repeat_index=0,
            record_directory=selected_dir,
            execution_translation_limit_m=0.1,
        )
    entries = [
        json.loads(record.message)
        for record in caplog.records
        if record.name == "se3_wam.inference.executor"
        and '"event":"model_action_selected"' in record.message
    ]
    adapter.reset()
    assert 2 < len(entries) == len(trace.steps) <= task.episode_horizon_steps
    assert (
        len({(entry["process_id"], entry["thread_id"], entry["episode"]) for entry in entries}) == 1
    )
    assert [entry["tick"] for entry in entries] == list(range(len(entries)))
    assert [entry["cursor"] for entry in entries] == [tick % 2 for tick in range(len(entries))]
    path = selected_dir / f"{_episode_id(scenario_id, 0)}.hdf5"
    metadata, arrays = _read_episode_file(path)
    assert metadata["action_spec"] == {
        "mode": "E7",
        "representation": "delta",
        "motion_limits": [0.1, 0.1, 0.1, 0.5, 0.5, 0.5],
    }
    np.testing.assert_array_equal(
        arrays.action_value,
        np.asarray([entry["command"] for entry in entries], dtype=np.float32).astype(np.float64),
    )
    np.testing.assert_array_equal(arrays.issued_tick, np.arange(len(entries)))
    np.testing.assert_array_equal(arrays.applied_tick[:-2], arrays.issued_tick[:-2] + 2)
    np.testing.assert_array_equal(arrays.applied_tick[-2:], [-1, -1])
    benchmark_entries = [
        json.loads(record.message)
        for record in caplog.records
        if record.name == "se3_wam_benchmark.evaluation.rollout"
    ]
    reset, *applications = benchmark_entries
    assert reset["event"] == "benchmark_episode_reset"
    assert reset["scenario_id"] == scenario_id and reset["repeat_index"] == 0
    assert (reset["process_id"], reset["thread_id"]) == (
        entries[0]["process_id"],
        entries[0]["thread_id"],
    )
    np.testing.assert_array_equal([entry["command"] for entry in applications], arrays.action_value)
    np.testing.assert_array_equal(
        [entry["issued_tick"] for entry in applications], arrays.issued_tick
    )
    assert [entry["applied_tick"] for entry in applications] == [
        int(tick) if tick >= 0 else None for tick in arrays.applied_tick
    ]
    for tick, entry in enumerate(entries):
        np.testing.assert_array_equal(entry["raw_prediction"], model.raw[tick % 2].numpy())
    replay = _rollout_episode(
        task,
        scenario,
        _RecordedActionPolicy("E7", "delta", arrays.action_value),
        scenario_id=scenario_id,
        partition="test_id",
        factor=None,
        repeat_index=0,
        record_directory=replay_dir,
        execution_translation_limit_m=0.1,
    )
    replay_metadata, replay_arrays = _read_episode_file(replay_dir / path.name)
    assert replay_metadata == metadata and replay.failure_code == trace.failure_code
    for field in arrays.__dataclass_fields__:
        np.testing.assert_array_equal(getattr(replay_arrays, field), getattr(arrays, field))
    (tmp_path / "model-selected.jsonl").write_text(
        "".join(json.dumps(entry) + "\n" for entry in entries), encoding="utf-8"
    )
    (tmp_path / "benchmark-application.jsonl").write_text(
        "".join(json.dumps(entry) + "\n" for entry in benchmark_entries), encoding="utf-8"
    )


@pytest.mark.parametrize(
    ("mode", "representation", "recipe_name", "source_seed"),
    [
        ("E7", "delta", "e7_agentview", 2),
        ("E7", "absolute", "e7_agentview_wrist", 2),
        ("J8", "delta", "j8_agentview_wrist", 36),
        ("J8", "absolute", "j8_agentview", 36),
    ],
)
def test_adapter_drives_three_real_registered_robosuite_steps_without_reinterpreting_action(
    mode: ActionMode,
    representation: ActionRepresentation,
    recipe_name: str,
    source_seed: int,
) -> None:
    from se3_wam_benchmark.envs.factory import make_env
    from se3_wam_benchmark.scenarios.generator import generate_scenario
    from se3_wam_benchmark.tasks.registry import load_task

    task = load_task("grasp")
    scenario = generate_scenario(
        task,
        ROOT / "configs/scenarios/grasp.yaml",
        source_seed,
        partition="test_id",
        recipe_name=recipe_name,
    )
    environment = make_env("grasp", scenario)
    model_policy = _NeutralPhysicalPolicy(mode, representation)
    adapter = _bind(model_policy)
    try:
        raw = environment.reset()
        adapter.reset()
        for expected_tick in range(3):
            observation = environment._benchmark_observation(raw)
            assert observation.tick == expected_tick
            action = adapter.act(observation)
            assert action.mode == mode
            assert action.representation == representation
            np.testing.assert_array_equal(action.value, model_policy.selected_actions[-1].numpy())
            raw, _, done, _ = environment.step(action)
            assert done is False
            application = environment._last_action_application_fact()
            assert application is not None
            assert application[:2] == (expected_tick, expected_tick)
            assert application[2] is action
            assert float(
                model_policy.select_observations[-1].gripper_open_fraction.item()
            ) == pytest.approx(
                float(observation.gripper_position[0] - observation.gripper_position[1]) / 0.08,
                abs=1e-7,
            )
        assert len(model_policy.select_observations) == 3
        assert model_policy.predict_calls == 0
    finally:
        environment.close()


def _required_gate_path(variable: str, *, directory: bool = False) -> Path:
    try:
        path = Path(os.environ[variable])
    except KeyError as exc:
        raise RuntimeError(f"{variable} is required for the explicit learned-Policy gate") from exc
    if directory:
        if not path.is_dir():
            raise FileNotFoundError(path)
    elif not path.is_file():
        raise FileNotFoundError(path)
    return path


def test_loaded_execution_010_policy_runs_three_native_steps(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Explicit CUDA gate for the existing DB0/Farneback execution-010 bundle."""
    from se3_wam_benchmark.envs.factory import make_env
    from se3_wam_benchmark.scenarios.generator import generate_scenario

    bundle = _required_gate_path("SE3_WAM_EXECUTION_010_BUNDLE")
    policy = load_policy(bundle)
    assert policy.action_spec.gripper_mode == "discrete"
    assert policy.action_spec.motion_limits == (0.1, 0.1, 0.1, 0.5, 0.5, 0.5)
    adapter = bind_policy(
        policy,
        camera_geometry_enabled=True,
        observation_depth_enabled=True,
        observation_flow_enabled=False,
        observation_anchor_enabled=False,
    )
    task = load_task("grasp")
    scenario = replace(
        generate_scenario(
            task,
            ROOT / "configs/scenarios/grasp.yaml",
            2,
            partition="test_id",
            recipe_name="e7_agentview_wrist",
        ),
        action_delay_steps=1,
    )
    environment = make_env("grasp", scenario, execution_translation_limit_m=0.10)
    actions = []
    try:
        raw = environment.reset()
        adapter.reset()
        with caplog.at_level(logging.INFO, logger="se3_wam.inference.executor"):
            for tick in range(3):
                action = adapter.act(environment._benchmark_observation(raw))
                actions.append(action)
                raw, _, done, _ = environment.step(action)
                assert not done
                application = environment._last_action_application_fact()
                if tick == 0:
                    assert application is None
                else:
                    assert application == (tick - 1, tick, actions[tick - 1])
        entries = [
            json.loads(record.message)
            for record in caplog.records
            if record.name == "se3_wam.inference.executor"
            and '"event":"model_action_selected"' in record.message
        ]
        assert len(entries) == 3
        assert [entry["tick"] for entry in entries] == [0, 1, 2]
        for action, entry in zip(actions, entries, strict=True):
            np.testing.assert_array_equal(
                action.value, np.asarray(entry["command"], dtype=np.float32).astype(np.float64)
            )
        (tmp_path / "model-selected.jsonl").write_text(
            "".join(json.dumps(entry) + "\n" for entry in entries), encoding="utf-8"
        )
    finally:
        adapter.reset()
        environment.close()


def _assert_physical_terminal_time(elapsed_s: float, control_steps: int) -> None:
    assert control_steps > 0
    physics_steps = round(elapsed_s / 0.002)
    assert elapsed_s == pytest.approx(physics_steps * 0.002, rel=0.0, abs=3e-12)
    final_tick_start_s = (control_steps - 1) * 0.05
    assert elapsed_s >= final_tick_start_s - 3e-12
    assert elapsed_s <= control_steps * 0.05 + 3e-12


def test_physical_terminal_time_covers_the_closed_final_control_tick() -> None:
    for elapsed_s in (0.15, 0.174, 0.2):
        _assert_physical_terminal_time(elapsed_s, 4)
    for elapsed_s in (0.148, 0.175, 0.202):
        with pytest.raises(AssertionError):
            _assert_physical_terminal_time(elapsed_s, 4)


class _RecordedActionPolicy:
    def __init__(
        self,
        mode: ActionMode,
        representation: ActionRepresentation,
        values: npt.NDArray[np.float64],
    ) -> None:
        self._mode = mode
        self._representation = representation
        self._values = values
        self._index = 0

    def reset(self) -> None:
        self._index = 0

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
        assert observation.tick == self._index
        value = np.ascontiguousarray(self._values[self._index], dtype=np.float64)
        value = np.ascontiguousarray(value, dtype=np.float64)
        value.setflags(write=False)
        self._index += 1
        return BenchmarkAction(self._mode, self._representation, value)


@pytest.mark.parametrize(
    ("label", "mode", "representation", "profile", "views", "limits"),
    [
        ("E7", "E7", "delta", "agentview", ("agentview",), _E7_LIMITS),
        (
            "J8",
            "J8",
            "absolute",
            "agentview_wrist",
            ("agentview", "wrist"),
            _J8_LIMITS,
        ),
    ],
)
def test_loaded_action_only_policy_runs_and_replays_one_native_recorded_episode(
    request: pytest.FixtureRequest,
    label: str,
    mode: ActionMode,
    representation: ActionRepresentation,
    profile: str,
    views: tuple[str, ...],
    limits: tuple[float, ...],
) -> None:
    """Gate Model-to-Env wiring; native EGL RGB replay is not a bit-exact claim."""
    _run_loaded_policy_episode_and_replay(
        bundle_variable=f"SE3_WAM_TEST_{label}_BUNDLE",
        manifest_variable=f"SE3_WAM_TEST_{label}_MANIFEST",
        output_root_variable="SE3_WAM_TEST_OUTPUT_ROOT",
        output_label=label.lower(),
        mode=mode,
        representation=representation,
        profile=profile,
        views=views,
        limits=limits,
        camera_geometry_enabled=False,
        observation_depth_enabled=False,
        expected_source_seed=None,
        expected_scenario_id=None,
        verify_physical_clock=False,
        run_public_evaluate=False,
        wall_control_period_s=None,
        request=request,
    )


def test_loaded_full_fta_j8_policy_runs_to_terminal_and_replays_native_episode(
    request: pytest.FixtureRequest,
) -> None:
    """Gate the full FTA composition; task success and EGL RGB bit identity are not claims."""
    _run_loaded_policy_episode_and_replay(
        bundle_variable="SE3_WAM_TEST_FULL_J8_BUNDLE",
        manifest_variable="SE3_WAM_TEST_FULL_J8_MANIFEST",
        output_root_variable="SE3_WAM_TEST_FULL_OUTPUT_ROOT",
        output_label="j8-full-fta",
        mode="J8",
        representation="absolute",
        profile="agentview_wrist",
        views=("agentview", "wrist"),
        limits=_J8_LIMITS,
        camera_geometry_enabled=True,
        observation_depth_enabled=True,
        expected_source_seed=36,
        expected_scenario_id="v1:validation:grasp:000000",
        verify_physical_clock=True,
        run_public_evaluate=True,
        wall_control_period_s=None,
        request=request,
    )


def test_loaded_full_fta_j8_policy_runs_at_half_second_native_wall_period(
    request: pytest.FixtureRequest,
) -> None:
    """Gate native RTC pacing; task success and default-scale model quality are not claims."""
    _run_loaded_policy_episode_and_replay(
        bundle_variable="SE3_WAM_TEST_FULL_J8_BUNDLE",
        manifest_variable="SE3_WAM_TEST_FULL_J8_MANIFEST",
        output_root_variable="SE3_WAM_TEST_FULL_OUTPUT_ROOT",
        output_label="j8-full-fta-rtc",
        mode="J8",
        representation="absolute",
        profile="agentview_wrist",
        views=("agentview", "wrist"),
        limits=_J8_LIMITS,
        camera_geometry_enabled=True,
        observation_depth_enabled=True,
        expected_source_seed=36,
        expected_scenario_id="v1:validation:grasp:000000",
        verify_physical_clock=True,
        run_public_evaluate=True,
        wall_control_period_s=0.5,
        request=request,
    )


def _run_loaded_policy_episode_and_replay(
    *,
    bundle_variable: str,
    manifest_variable: str,
    output_root_variable: str,
    output_label: str,
    mode: ActionMode,
    representation: ActionRepresentation,
    profile: str,
    views: tuple[str, ...],
    limits: tuple[float, ...],
    camera_geometry_enabled: bool,
    observation_depth_enabled: bool,
    expected_source_seed: int | None,
    expected_scenario_id: str | None,
    verify_physical_clock: bool,
    run_public_evaluate: bool,
    wall_control_period_s: float | None,
    request: pytest.FixtureRequest,
) -> None:
    bundle = _required_gate_path(bundle_variable)
    manifest_path = _required_gate_path(manifest_variable)
    output_root = _required_gate_path(output_root_variable, directory=True)
    manifest = load_manifest(manifest_path)
    assert len(manifest.rows) == 1
    row = manifest.rows[0]
    assert row.task_id == "grasp"
    assert row.partition == "validation"
    assert row.factor is None
    assert row.scenario.action_mode == mode
    assert row.scenario.action_delay_steps == 0
    assert row.scenario.observation_profile == profile
    assert tuple(view.view_name for view in row.scenario.cameras.views) == views
    if expected_source_seed is not None:
        assert row.source_seed == expected_source_seed
    if expected_scenario_id is not None:
        assert row.scenario_id == expected_scenario_id
    task = load_task(row.task_id)

    learned_directory = output_root / f"{output_label}-learned"
    replay_directory = output_root / f"{output_label}-replay"
    learned_directory.mkdir()
    replay_directory.mkdir()
    model_policy = load_policy(bundle)
    request.addfinalizer(model_policy.reset)
    assert model_policy.action_spec.mode == mode
    assert model_policy.action_spec.representation == representation
    assert model_policy.action_spec.motion_limits == limits
    adapter = bind_policy(
        model_policy,
        camera_geometry_enabled=camera_geometry_enabled,
        observation_depth_enabled=observation_depth_enabled,
        observation_flow_enabled=False,
        observation_anchor_enabled=False,
    )
    learned_started_s = time.monotonic()
    learned_trace = _rollout_episode(
        task,
        row.scenario,
        adapter,
        scenario_id=row.scenario_id,
        partition=row.partition,
        factor=row.factor,
        repeat_index=0,
        record_directory=learned_directory,
        wall_control_period_s=wall_control_period_s,
    )
    learned_wall_elapsed_s = time.monotonic() - learned_started_s
    model_policy.reset()

    assert learned_trace.action_spec.mode == mode
    assert learned_trace.action_spec.representation == representation
    assert learned_trace.observation_profile == profile
    assert 0 < len(learned_trace.steps) <= task.episode_horizon_steps
    assert learned_trace.success == (learned_trace.failure_code is None)
    assert learned_trace.steps[-1].done
    assert all(step.tick == index for index, step in enumerate(learned_trace.steps))
    assert all(step.issued_tick == step.tick for step in learned_trace.steps)
    assert all(step.applied_tick == step.tick for step in learned_trace.steps)
    assert all(
        (step.action.mode, step.action.representation) == (mode, representation)
        and step.action.value.dtype == np.float64
        and step.action.value.flags.c_contiguous
        and not step.action.value.flags.writeable
        and np.isfinite(step.action.value).all()
        for step in learned_trace.steps
    )

    episode_name = f"{_episode_id(row.scenario_id, 0)}.hdf5"
    learned_metadata, learned_arrays = _read_episode_file(learned_directory / episode_name)
    transitions = len(learned_trace.steps)
    if wall_control_period_s is not None:
        assert transitions > 8
        assert learned_wall_elapsed_s >= (transitions - 1) * wall_control_period_s
        print(
            json.dumps(
                {
                    "learned_episode_steps": transitions,
                    "learned_wall_elapsed_s_including_cold_start": learned_wall_elapsed_s,
                    "nominal_wall_control_period_s": wall_control_period_s,
                },
                sort_keys=True,
            )
        )
    assert learned_arrays.tick.shape == (transitions + 1,)
    np.testing.assert_array_equal(learned_arrays.tick, np.arange(transitions + 1))
    np.testing.assert_array_equal(
        learned_arrays.timestamp_s[:-1],
        np.asarray([step.timestamp_s for step in learned_trace.steps], dtype=np.float64),
    )
    if verify_physical_clock:
        np.testing.assert_allclose(
            learned_arrays.timestamp_s,
            np.arange(transitions + 1, dtype=np.float64) * 0.05,
            rtol=0.0,
            atol=1e-12,
        )
        _assert_physical_terminal_time(learned_trace.elapsed_s, transitions)
    np.testing.assert_array_equal(learned_arrays.issued_tick, np.arange(transitions))
    np.testing.assert_array_equal(learned_arrays.applied_tick, learned_arrays.issued_tick)
    np.testing.assert_array_equal(
        learned_arrays.action_value,
        np.stack([step.action.value for step in learned_trace.steps]),
    )
    assert bool(learned_arrays.done[-1])
    assert bool(learned_arrays.success[-1]) == learned_trace.success
    assert learned_metadata["view_names"] == list(views)
    assert learned_metadata["action_spec"] == {
        "mode": mode,
        "representation": representation,
        "motion_limits": list(limits),
    }
    assert learned_metadata["outcome"]["success"] == learned_trace.success
    assert learned_metadata["outcome"]["failure_code"] == learned_trace.failure_code

    replay_trace = _rollout_episode(
        task,
        row.scenario,
        _RecordedActionPolicy(
            mode,
            representation,
            learned_arrays.action_value,
        ),
        scenario_id=row.scenario_id,
        partition=row.partition,
        factor=row.factor,
        repeat_index=0,
        record_directory=replay_directory,
        wall_control_period_s=None,
    )
    replay_metadata, replay_arrays = _read_episode_file(replay_directory / episode_name)
    assert replay_trace.success == learned_trace.success
    assert replay_trace.failure_code == learned_trace.failure_code
    assert replay_metadata == learned_metadata
    non_rgb_fields = tuple(field for field in learned_arrays.__dataclass_fields__ if field != "rgb")
    assert len(non_rgb_fields) == 25
    for field in non_rgb_fields:
        np.testing.assert_array_equal(
            getattr(replay_arrays, field),
            getattr(learned_arrays, field),
        )
    assert replay_arrays.rgb.shape == learned_arrays.rgb.shape
    assert replay_arrays.rgb.dtype == learned_arrays.rgb.dtype == np.uint8
    if run_public_evaluate:
        suite_directory = output_root / f"{output_label}-suite"
        suite_directory.mkdir()
        suite_path = suite_directory / "validation.yaml"
        suite_path.write_text(
            json.dumps(
                {
                    "schema_version": 1,
                    "suite_id": "validation",
                    "protocol_version": "v1",
                    "repeats": 1,
                    "members": [
                        {
                            "manifest": str(manifest_path.resolve()),
                            "task_ids": ["grasp"],
                        }
                    ],
                    "report": {
                        "group_by": [
                            "task_id",
                            "partition",
                            "factor",
                            "action_mode",
                            "action_representation",
                            "observation_profile",
                        ]
                    },
                },
                separators=(",", ":"),
            )
            + "\n",
            encoding="utf-8",
        )
        evaluate_started_s = time.monotonic()
        summary = evaluate(
            adapter,
            suite_path,
            wall_control_period_s=wall_control_period_s,
        )
        evaluate_wall_elapsed_s = time.monotonic() - evaluate_started_s
        assert len(summary.results) == 1
        result = summary.results[0]
        assert (
            result.scenario_id,
            result.task_id,
            result.partition,
            result.factor,
            result.repeat_index,
        ) == (row.scenario_id, "grasp", "validation", None, 0)
        assert (
            result.action_mode,
            result.action_representation,
            result.observation_profile,
        ) == (mode, representation, profile)
        assert 0 < result.episode_steps <= task.episode_horizon_steps
        if wall_control_period_s is not None:
            assert result.episode_steps > 8
            assert evaluate_wall_elapsed_s >= (result.episode_steps - 1) * wall_control_period_s
            print(
                json.dumps(
                    {
                        "nominal_wall_control_period_s": wall_control_period_s,
                        "public_evaluate_episode_steps": result.episode_steps,
                        "public_evaluate_wall_elapsed_s_including_cold_start": (
                            evaluate_wall_elapsed_s
                        ),
                    },
                    sort_keys=True,
                )
            )
        _assert_physical_terminal_time(result.elapsed_s, result.episode_steps)
        assert result.success == (result.failure_code is None)
        assert len(summary.groups) == 2
        assert {group.key.task_id for group in summary.groups} == {"grasp", None}
        for group in summary.groups:
            assert (
                group.key.partition,
                group.key.factor,
                group.key.action_mode,
                group.key.action_representation,
                group.key.observation_profile,
            ) == ("validation", None, mode, representation, profile)
            assert group.paired_test_id_difference is None
            assert (group.metrics.n_success, group.metrics.n_failure) == (
                int(result.success),
                int(not result.success),
            )
            assert group.metrics.success_rate.n_total == 1
            assert group.metrics.success_rate.n_valid == 1
            assert group.metrics.success_rate.mean == float(result.success)
