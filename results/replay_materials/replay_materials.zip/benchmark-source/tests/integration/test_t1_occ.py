from __future__ import annotations

import copy
from dataclasses import fields, replace
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest
import yaml

from se3_wam_benchmark.control.action import BenchmarkAction, _so3_log
from se3_wam_benchmark.envs.base import DynamicManipulationEnv, _load_asset_catalog
from se3_wam_benchmark.envs.components.occlusion import (
    _OcclusionVisibilityAudit,
    _target_visibility,
    _validate_compiled_occlusion,
)
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.driven_interception import (
    DrivenInterceptionEnv,
    _DrivenCapture,
)
from se3_wam_benchmark.scenarios._feasibility import _validate_capture_reset
from se3_wam_benchmark.scenarios._native_oracle import _CaptureOracle, _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_surface_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import ScenarioSpec, scenario_to_dict
from se3_wam_benchmark.sensing.camera import _camera_intrinsics, _world_from_camera_cv
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
RECIPE = ROOT / "configs/scenarios/t1_occ.yaml"


@pytest.mark.parametrize("samples", (0, 4))
def test_compiled_camera_samples_preserve_depth_and_real_occlusion(samples: int) -> None:
    outside = "".join(
        f'<geom name="outside{i}" type="sphere" size=".01" pos="{100 + i} 100 100"/>'
        for i in range(98)
    )
    xml = (
        '<mujoco><asset/><statistic extent="2" center="0 0 .8"/>'
        '<visual><global offwidth="224" offheight="224"/>'
        f'<quality offsamples="{samples}" shadowsize="512"/></visual><worldbody>'
        '<camera name="agentview" mode="fixed" pos=".68 -.58 1.62" '
        'quat=".82155868 .384027088 .1784387 .38173834"/>'
        '<geom name="floor" type="box" size="1 1 .01" pos="0 0 .78"/>'
        f'{outside}<geom name="target" type="box" size=".022 .022 .022" '
        'pos="0 -.22 .812"/>'
        '<geom name="buried" type="box" size=".01 .01 .01" pos="0 -.22 .75"/>'
        "</worldbody></mujoco>"
    )
    environment = make_env("t1_occ", _proposal())
    try:
        xml = DynamicManipulationEnv.edit_model_xml(environment, xml)
    finally:
        environment.close()
    model = mujoco.MjModel.from_xml_string(xml)
    assert model.vis.quality.offsamples == 4
    assert model.vis.quality.shadowsize == 512
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    state = data.geom_xpos.copy()
    with mujoco.Renderer(model, height=224, width=224) as renderer:
        renderer.update_scene(data, camera="agentview")
        rgb_before = renderer.render().copy()
        renderer.enable_depth_rendering()
        depth_before = renderer.render().copy()
        renderer.disable_depth_rendering()
        renderer.enable_segmentation_rendering()
        elements = renderer.render().copy()
        renderer.disable_segmentation_rendering()
        labels = elements[:, :, 0]
        # The floor hides the buried box, even though that box is drawn last.
        # Intermediate colour averages would identify one of the distant spheres.
        target_id = model.geom("target").id
        assert np.count_nonzero(labels == target_id) > 0
        assert set(np.unique(labels)) <= {-1, model.geom("floor").id, target_id}
        camera_id = model.camera("agentview").id
        intrinsic = _camera_intrinsics(float(model.cam_fovy[camera_id]), 224, 224)
        world_from_camera = _world_from_camera_cv(
            data.cam_xpos[camera_id], data.cam_xmat[camera_id].reshape(3, 3)
        )
        u, v = np.meshgrid(np.arange(224), np.arange(224))
        points = np.stack(
            (
                (u - intrinsic[0, 2]) * depth_before / intrinsic[0, 0],
                (v - intrinsic[1, 2]) * depth_before / intrinsic[1, 1],
                depth_before,
            ),
            axis=-1,
        )
        points = points @ world_from_camera[:3, :3].T + world_from_camera[:3, 3]
        valid = labels >= 0
        distance = np.linalg.norm(points[valid] - data.geom_xpos[labels[valid]], axis=1)
        assert np.all(distance <= model.geom_rbound[labels[valid]] + 0.05)
        assert np.array_equal(renderer.render(), rgb_before)
        renderer.enable_depth_rendering()
        assert np.array_equal(renderer.render(), depth_before)
        renderer.disable_depth_rendering()

    assert np.array_equal(data.geom_xpos, state)


def _proposal(
    seed: int = 2,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task("t1_occ")
    selected = _select_recipe(
        load_yaml_strict(RECIPE), partition=partition, factor=factor, recipe_name=name
    )
    scenario = _materialize_recipe(task, selected, np.random.Generator(np.random.PCG64(seed)))
    _validate_surface_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    return scenario


def _action(
    environment: DrivenInterceptionEnv, representation: str = "delta", value: float = 0.0
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.r_[position, _so3_log(rotation)] if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += value
    values = np.ascontiguousarray(np.r_[motion, -1.0], dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _source_proposal() -> ScenarioSpec:
    # Fixed DB0 episode d0-train-t1_occ-00000-s931593392.
    scenario = _proposal(seed=931593392, partition="train")
    return replace(
        scenario,
        object_states=(
            replace(
                scenario.object_states[0],
                position_world_m=(0.07034196577201272, -0.23794974631928603, 0.8220000000000001),
            ),
        ),
        motion=(
            replace(
                scenario.motion[0],
                translation=replace(
                    scenario.motion[0].translation,
                    velocity_world_m_s=(0.0, 0.07824411639122328, 0.0),
                ),
            ),
        ),
    )


def _parked(scenario: ScenarioSpec) -> ScenarioSpec:
    return replace(
        scenario,
        fixture_states=tuple(
            replace(fixture, position_world_m=(0.6, 0.0, -2.0))
            if fixture.instance_id == "occluder"
            else fixture
            for fixture in scenario.fixture_states
        ),
    )


@pytest.mark.parametrize(
    ("name", "representation", "delay"),
    [
        ("e7_agentview", "delta", 0),
        ("e7_agentview_wrist", "absolute", 1),
        ("j8_agentview", "absolute", 0),
        ("j8_agentview_wrist", "delta", 2),
    ],
)
def test_registered_occ_runs_real_actions_rgbd_and_exact_compiled_reset_export(
    name: str,
    representation: str,
    delay: int,
) -> None:
    scenario = replace(_proposal(name=name), action_delay_steps=delay)
    environment = make_env("t1_occ", scenario)
    try:
        assert isinstance(environment, DrivenInterceptionEnv)
        raw = environment.reset()
        assert environment.export_scenario() == scenario
        model, data = environment.sim.model._model, environment.sim.data._data
        assert model.nv == 15 and model.nq == 16
        assert model.body_dofnum[environment._canopy_body_id] == 0
        # These are the compiled values in the fixed old DB0 source episode.
        assert data.qpos[environment._target_qpos_address + 2] == 0.8220000000000001
        np.testing.assert_array_equal(model.site_size, np.full((model.nsite, 3), 1.0e-8))
        for geom_id in environment._canopy_geom_ids:
            np.testing.assert_array_equal(model.geom_friction[geom_id], (0.8, 0.005, 0.0001))
        assert model.light_type[0] == mujoco.mjtLightType.mjLIGHT_DIRECTIONAL
        assert not model.light_castshadow[0]
        segmentation = environment.sim.render(
            camera_name="agentview", width=224, height=224, segmentation=True
        )
        target_pixels = (segmentation[:, :, 0] == mujoco.mjtObj.mjOBJ_GEOM) & np.isin(
            segmentation[:, :, 1], np.flatnonzero(model.geom_bodyid == environment._target_body_id)
        )
        native_rgb = environment.sim.render(camera_name="agentview", width=224, height=224)
        np.testing.assert_array_equal(raw["agentview_image"], native_rgb)
        assert target_pixels.sum() > 200
        assert np.percentile(native_rgb[target_pixels].max(axis=1), 75) > 64
        facts = environment._compiled_occlusion_facts()
        assert facts.lift_envelope_clearance_m == pytest.approx(0.300, abs=1e-12)
        assert _validate_compiled_occlusion(facts).safe
        for tick in range(5):
            observation = environment._benchmark_observation(raw)
            views = 2 if name.endswith("_wrist") else 1
            assert observation.rgb.shape == (views, 224, 224, 3)
            assert observation.depth_m.shape == (views, 224, 224)
            assert observation.rgb.dtype == np.uint8
            assert observation.depth_m.dtype == np.float32
            assert observation.camera_intrinsics.dtype == np.float64
            assert observation.world_from_camera_cv.shape == (views, 4, 4)
            assert observation.timestamp_s == tick / 20 and observation.tick == tick
            for field in fields(observation):
                value = getattr(observation, field.name)
                if isinstance(value, np.ndarray):
                    assert value.flags.c_contiguous and not value.flags.writeable
                    assert np.isfinite(value).all()
            assert np.all(data.xfrc_applied == 0.0) and np.all(data.qfrc_applied == 0.0)
            if tick != 4:
                raw, reward, done, info = environment.step(
                    _action(environment, representation, 0.001)
                )
                assert np.isfinite(reward) and not done and info["failure_code"] is None
        environment.reset()
        assert environment._episode_tick == 0 and environment._capture.physics_step == 0
        assert environment._capture.events == {"target_enters_observation_region": 0.0}
        assert not environment._capture.success
        environment.step(_action(environment, "absolute" if representation == "delta" else "delta"))
        assert environment._episode_tick == 1
    finally:
        environment.close()


def test_real_panda_active_parked_pair_changes_only_occluder_pose_and_visible_raster() -> None:
    active = _proposal()
    parked = _parked(active)
    a, b = scenario_to_dict(active), scenario_to_dict(parked)
    assert a["fixture_states"] != b["fixture_states"]
    a.pop("fixture_states")
    b.pop("fixture_states")
    assert a == b
    traces = []
    visibility_traces = []
    final_audits = []
    images = []
    calibration = []
    for scenario in (active, parked):
        environment = make_env("t1_occ", scenario)
        try:
            raw = environment.reset()
            assert environment.export_scenario() == scenario
            if scenario == active:
                assert _validate_compiled_occlusion(environment._compiled_occlusion_facts()).safe
            audit = _OcclusionVisibilityAudit()
            physical, observed, frames = [], [], []
            model, data = environment.sim.model._model, environment.sim.data._data
            for frame in range(121):
                before = (data.qpos.copy(), data.qvel.copy(), model.geom_pos.copy())
                visibility = _target_visibility(
                    environment.sim,
                    target_body_id=environment._target_body_id,
                    occluder_body_id=environment._canopy_body_id,
                )
                for old, new in zip(before, (data.qpos, data.qvel, model.geom_pos), strict=True):
                    np.testing.assert_array_equal(old, new)
                assert 0 <= visibility.visible_pixels <= visibility.silhouette_pixels
                observed.append(visibility.ratio)
                address = environment._target_qpos_address
                audit_state = audit.observe(
                    sensor_time_s=float(data.time),
                    target_visible_ratio=visibility.ratio,
                    target_position_world_m=tuple(
                        float(v) for v in data.qpos[address : address + 3]
                    ),
                    fingerpad_contact_event="fingerpad_contact" in environment._capture.events,
                    bilateral_hold_event="bilateral_hold" in environment._capture.events,
                )
                physical.append(
                    np.r_[data.time, data.qpos.copy(), data.qvel.copy(), data.ctrl.copy()]
                )
                facts = environment._compiled_occlusion_facts()
                assert not facts.robot_canopy_contact and not facts.target_canopy_contact
                assert (
                    model.flg_surfacevel
                    and not np.any(data.xfrc_applied)
                    and not np.any(data.qfrc_applied)
                )
                if frame in (0, 35, 90):
                    observation = environment._benchmark_observation(raw)
                    frames.append(observation.rgb.copy())
                if frame == 0:
                    calibration.append(
                        (
                            model.stat.extent,
                            observation.camera_intrinsics,
                            observation.world_from_camera_cv,
                        )
                    )
                if frame != 120:
                    raw, _, done, info = environment.step(_action(environment))
                    assert not done, info
            traces.append(np.asarray(physical))
            visibility_traces.append(np.asarray(observed))
            final_audits.append(audit_state)
            images.append(frames)
            assert not {"fingerpad_contact", "bilateral_hold"} & environment._capture.events.keys()
        finally:
            environment.close()
    np.testing.assert_array_equal(traces[0], traces[1])
    for first, second in zip(calibration[0], calibration[1], strict=True):
        np.testing.assert_array_equal(first, second)
    assert any(
        not np.array_equal(first, second)
        for first, second in zip(images[0], images[1], strict=True)
    )
    # This passive pair establishes the physical raster sequence. DB0 acceptance
    # additionally requires actual first-contact and hold events inside its hidden run.
    active_visibility, parked_visibility = visibility_traces
    hidden = np.flatnonzero(active_visibility <= 0.05)
    assert 10 <= len(hidden) <= 60
    assert np.all(np.diff(hidden) == 1)
    assert np.all(active_visibility[:8] >= 0.95)
    assert np.all(active_visibility[-3:] >= 0.80)
    assert np.min(parked_visibility) > 0.80
    assert not final_audits[0].complete and not final_audits[1].complete
    assert {"fingerpad_contact_event_missing", "bilateral_hold_event_missing"} <= set(
        final_audits[0].failure_codes
    )


@pytest.mark.parametrize(
    ("name", "expected_time", "ticks"),
    [
        ("e7_agentview", 3.480, 70),
        ("j8_agentview", 3.462, 70),
    ],
)
def test_real_occ_oracle_completes_visibility_and_capture_with_continuous_contact_drive(
    name: str,
    expected_time: float,
    ticks: int,
) -> None:
    scenario = _source_proposal() if name == "e7_agentview" else _proposal(name=name)
    environment = make_env("t1_occ", scenario)
    try:
        environment.reset()
        _validate_capture_reset(environment)
        model, data = environment.sim.model._model, environment.sim.data._data
        surface = model.geom_surfacevel.copy()
        update = environment._capture.update
        physics_times = []
        terminal_tail = []
        phases = set()

        def observe_physics(**kwargs: Any) -> None:
            np.testing.assert_array_equal(model.geom_surfacevel, surface)
            assert model.flg_surfacevel
            assert not np.any(data.xfrc_applied) and not np.any(data.qfrc_applied)
            assert not kwargs["unsafe_canopy_contact"]
            physics_times.append(float(data.time))
            if environment._capture.terminal_time_s is not None:
                terminal_tail.append(float(data.time))
            update(**kwargs)
            phases.update(environment._capture.events)

        environment._capture.update = observe_physics
        oracle = _CaptureOracle(environment)
        visibility_states = [oracle._visibility_state]
        oracle._require_valid_visibility(environment, terminal=False)
        for tick in range(1, 161):
            _, _, done, info = environment.step(oracle.action(environment))
            oracle._observe_visibility(environment)
            visibility_states.append(oracle._visibility_state)
            oracle._require_valid_visibility(environment, terminal=done)
            if done:
                break
        assert info["success"] and info["failure_code"] is None
        assert info["terminal_time_s"] == pytest.approx(expected_time, abs=1e-9)
        assert tick == ticks and len(physics_times) == ticks * 25 and terminal_tail
        np.testing.assert_allclose(
            physics_times, np.arange(1, len(physics_times) + 1) * 0.002, rtol=0, atol=1e-12
        )
        assert {"fingerpad_contact", "bilateral_hold", "clearance", "stable_dwell"} <= phases
        assert environment._capture.stable_steps == 250
        assert oracle._visibility_state.complete
        assert 0.50 <= oracle._visibility_state.selected_hidden_duration_s <= 3.0
        assert all(state.target_visible_ratio >= 0.95 for state in visibility_states[:8])
        completed_at = next(
            index for index, state in enumerate(visibility_states) if state.complete
        )
        assert all(
            state.target_visible_ratio >= 0.80
            for state in visibility_states[completed_at - 2 : completed_at + 1]
        )
        hidden = [state for state in visibility_states if state.phase == "hidden"]
        assert 10 <= len(hidden) <= 60
        assert all(state.target_visible_ratio <= 0.05 for state in hidden)
        if name == "e7_agentview":
            assert environment._capture.events == pytest.approx(
                {
                    "target_enters_observation_region": 0.0,
                    "approach": 1.186,
                    "fingerpad_contact": 2.676,
                    "bilateral_hold": 2.726,
                    "clearance": 2.982,
                    "stable_dwell": 3.480,
                    "success": 3.480,
                },
                abs=1e-9,
            )
        with pytest.raises(ValueError, match="terminated"):
            environment.step(_action(environment))
    finally:
        environment.close()


@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_public_occ_generator_really_validates_reset_visibility_and_oracle(name: str) -> None:
    scenario = generate_scenario(
        load_task("t1_occ"), RECIPE, 2, partition="test_id", recipe_name=name
    )
    assert scenario == _proposal(name=name)


def test_real_canopy_contact_is_unsafe_and_beats_downstream_exit_on_the_same_physics_step() -> None:
    scenario = _proposal()
    target = replace(scenario.object_states[0], position_world_m=(0.0, 0.391, 0.822))
    scenario = replace(
        scenario,
        object_states=(target,),
        fixture_states=(
            scenario.fixture_states[0],
            replace(scenario.fixture_states[1], position_world_m=(0.0, 0.391, 0.849)),
        ),
    )
    environment = make_env("t1_occ", scenario)
    try:
        environment.reset()
        assert environment._compiled_occlusion_facts().target_canopy_contact
        _, _, done, info = environment.step(_action(environment))
        assert done and not info["success"] and info["failure_code"] == "unsafe_contact"
        assert info["terminal_time_s"] == pytest.approx(0.002, abs=1e-12)
        assert environment.sim.data.time == pytest.approx(0.05)
        assert environment.sim.model.flg_surfacevel
        assert not np.any(environment.sim.data.xfrc_applied)
    finally:
        environment.close()


@pytest.mark.parametrize("finite", [True, False])
def test_occ_safety_priority_precedes_success_timeout_and_exit_but_not_invalid_state(
    finite: bool,
) -> None:
    task = load_task("t1_occ")
    capture = _DrivenCapture(task, _proposal().geometry, 0.002)
    capture.begin(eef_distance_m=0.30)
    capture.physics_step = 3999
    capture.stable_steps = 249
    capture.bilateral_steps = 250
    capture.events = {
        "approach": 1.0,
        "fingerpad_contact": 2.0,
        "bilateral_hold": 3.0,
        "clearance": 4.0,
    }
    capture.update(
        time_s=8.0,
        finite=finite,
        position=np.array([0.0, 0.391, 0.90]),
        bottom_z_m=0.878,
        eef_distance_m=0.0,
        left=True,
        right=True,
        opposing=True,
        unsafe_canopy_contact=True,
    )
    assert not capture.success and capture.terminal_time_s == 8.0
    assert capture.failure_code == ("unsafe_contact" if finite else "invalid_state")


@pytest.mark.parametrize(
    ("name", "representation", "partition", "factor"),
    [
        ("e7_agentview", "delta", "test_id", None),
        ("e7_agentview", "delta", "ood", "physics"),
        ("j8_agentview_wrist", "absolute", "ood", "action_delay"),
    ],
)
def test_occ_real_export_manifest_and_fixed_action_replay_are_exact(
    name: str,
    representation: str,
    partition: Partition,
    factor: str | None,
    tmp_path: Path,
) -> None:
    scenario = _proposal(name=name, partition=partition, factor=factor)
    assert (scenario.action_delay_steps > 0) is (factor == "action_delay")
    first = make_env("t1_occ", scenario)
    second = None
    try:
        first_raw = first.reset()
        exported = first.export_scenario()
        identity = f"v1:{partition}:{factor + ':' if factor else ''}t1_occ:000000"
        manifest = ScenarioManifest(
            (ScenarioManifestRow(1, "v1", identity, "t1_occ", partition, factor, 2, exported),)
        )
        path = tmp_path / "scenario.jsonl"
        write_manifest(manifest, path)
        loaded = load_manifest(path)
        assert loaded == manifest
        second = make_env("t1_occ", loaded.rows[0].scenario)
        second_raw = second.reset()
        assert second.export_scenario() == exported
        model1, model2 = first.sim.model._model, second.sim.model._model
        if factor == "physics":
            for geom_id in first._target_geom_ids:
                # The source factor scales sliding friction only.
                assert model1.geom_friction[geom_id, 0] in (0.7, 1.3)
                np.testing.assert_array_equal(model1.geom_friction[geom_id, 1:], (0.005, 0.0001))
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "body_pos",
            "body_quat",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_condim",
            "geom_contype",
            "geom_conaffinity",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "geom_surfacevel",
            "jnt_type",
            "jnt_range",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_type",
            "light_castshadow",
            "light_pos",
            "light_dir",
            "light_diffuse",
            "light_ambient",
            "light_specular",
            "light_attenuation",
            "light_cutoff",
            "light_active",
        ):
            np.testing.assert_array_equal(getattr(model1, field), getattr(model2, field))
        assert model1.flg_surfacevel == model2.flg_surfacevel == 1
        assert first._canopy_clearance_m == second._canopy_clearance_m
        assert first._geometry.occlusion_target_clearance_m == 0.20
        for tick in range(9):
            data1, data2 = first.sim.data._data, second.sim.data._data
            assert data1.time == data2.time == pytest.approx(tick / 20.0, abs=1e-12)
            for field in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            ):
                np.testing.assert_array_equal(getattr(data1, field), getattr(data2, field))
            observation1 = first._benchmark_observation(first_raw)
            observation2 = second._benchmark_observation(second_raw)
            for field in fields(observation1):
                np.testing.assert_array_equal(
                    getattr(observation1, field.name), getattr(observation2, field.name)
                )
            assert _target_visibility(
                first.sim,
                target_body_id=first._target_body_id,
                occluder_body_id=first._canopy_body_id,
            ) == _target_visibility(
                second.sim,
                target_body_id=second._target_body_id,
                occluder_body_id=second._canopy_body_id,
            )
            if tick != 8:
                action = _action(first, representation, 0.001 if tick % 2 else -0.001)
                first_raw, _, done1, info1 = first.step(action)
                second_raw, _, done2, info2 = second.step(action)
                assert not done1 and not done2 and info1 == info2
    finally:
        first.close()
        if second is not None:
            second.close()


@pytest.mark.parametrize(
    ("partition", "factor", "seed"),
    [("test_id", None, 2), ("ood", "spatial", 0), ("ood", "spatial", 1)],
)
def test_parked_occ_and_belt_share_actual_reset_and_contact_dynamics(
    partition: Partition,
    factor: str | None,
    seed: int,
) -> None:
    parked = _parked(_proposal(seed, partition=partition, factor=factor))
    belt_recipe = _select_recipe(
        load_yaml_strict(ROOT / "configs/scenarios/t1_belt.yaml"),
        partition=partition,
        factor=factor,
        recipe_name="e7_agentview",
    )
    belt = _materialize_recipe(
        load_task("t1_belt"), belt_recipe, np.random.Generator(np.random.PCG64(seed))
    )
    traces = []
    for task_id, scenario in (("t1_belt", belt), ("t1_occ", parked)):
        environment = make_env(task_id, scenario)
        try:
            environment.reset()
            assert environment.export_scenario() == scenario
            data = environment.sim.data._data
            states = [np.r_[data.time, data.qpos.copy(), data.qvel.copy()]]
            for _ in range(12):
                environment.step(_action(environment))
                states.append(np.r_[data.time, data.qpos.copy(), data.qvel.copy()])
            traces.append(np.asarray(states))
        finally:
            environment.close()
    np.testing.assert_array_equal(traces[0], traces[1])


@pytest.mark.parametrize(
    "name", ["e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist"]
)
def test_occ_spatial_ood_excludes_id_overlap_and_joint_xy_interventions(name: str) -> None:
    belt_recipe = _select_recipe(
        load_yaml_strict(ROOT / "configs/scenarios/t1_belt.yaml"),
        partition="ood",
        factor="spatial",
        recipe_name=name,
    )
    for seed in range(8):
        scenario = _proposal(seed, name, partition="ood", factor="spatial")
        x, y, z = scenario.object_states[0].position_world_m
        # Fixed old dataset_manifest.py changes exactly one of speed / X / Y.
        # The spatial partition contains only X-only and Y-only interventions.
        assert (not -0.08 <= x <= 0.08) != (not -0.26 <= y <= -0.18)
        assert -0.12 <= x <= 0.12 and -0.30 <= y <= -0.16
        assert z == 0.8220000000000001
        belt = _materialize_recipe(
            load_task("t1_belt"), belt_recipe, np.random.Generator(np.random.PCG64(seed))
        )
        assert scenario.object_states == belt.object_states
        assert scenario.motion == belt.motion


@pytest.mark.parametrize(
    ("name", "stage", "failure_code", "terminal_time_s"),
    [
        ("e7_agentview", "visibility", "reappearance_frames_insufficient", 5.25),
        ("j8_agentview", "visibility", "reappearance_frames_insufficient", 5.35),
    ],
)
def test_public_occ_keeps_fixed_seed_zero_as_a_structured_real_rejection(
    name: str, stage: str, failure_code: str, terminal_time_s: float
) -> None:
    with pytest.raises(_CaptureProposalRejected) as rejected:
        generate_scenario(load_task("t1_occ"), RECIPE, 0, partition="test_id", recipe_name=name)
    assert rejected.value.stage == stage
    assert rejected.value.failure_code == failure_code
    assert rejected.value.terminal_time_s == pytest.approx(terminal_time_s, abs=1e-9)
    assert "stable_dwell" in rejected.value.events
    assert rejected.value.visibility_state.reappearance_frames == 0
    assert not rejected.value.visibility_state.complete


@pytest.mark.parametrize(
    ("kind", "stage", "reason"),
    [
        ("initial_hidden", "reset", "target_not_visible"),
        ("initial_partial", "visibility", "initial_visible_frames_insufficient"),
        ("too_low", "reset", "lift_envelope_clearance_insufficient"),
    ],
)
def test_public_occ_rejects_real_visibility_or_compiled_clearance_without_resampling(
    kind: str,
    stage: str,
    reason: str,
    tmp_path: Path,
) -> None:
    document = copy.deepcopy(load_yaml_strict(RECIPE))
    for recipe in document["recipes"]["test_id"].values():
        position = recipe["fixture_states"][1]["position_world_m"]
        if kind == "initial_hidden":
            position[1] = -0.40
        elif kind == "initial_partial":
            position[1] = -0.44
        else:
            position[2] = 1.090
    external = tmp_path / "external.yaml"
    external.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    with pytest.raises(_CaptureProposalRejected) as rejected:
        generate_scenario(
            load_task("t1_occ"), external, 2, partition="test_id", recipe_name="e7_agentview"
        )
    assert rejected.value.stage == stage and rejected.value.failure_code == reason
    if stage == "visibility":
        assert rejected.value.visibility_state.frame_index == 0
        assert 0.05 < rejected.value.visibility_state.target_visible_ratio < 0.95


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_occ"])
def test_public_surface_generator_applies_independent_inertia_via_real_native_reset_and_oracle(
    task_id: str,
    tmp_path: Path,
) -> None:
    source = ROOT / f"configs/scenarios/{task_id}.yaml"
    document = copy.deepcopy(load_yaml_strict(source))
    recipes = copy.deepcopy(document["recipes"]["test_id"])
    for recipe in recipes.values():
        recipe["physics"]["bodies"][0]["diagonal_inertia_kg_m2"][0] *= 1.01
    document["recipes"]["ood"]["physics"] = recipes
    external = tmp_path / "physical.yaml"
    external.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    scenario = generate_scenario(
        load_task(task_id),
        external,
        2,
        partition="ood",
        factor="physics",
        recipe_name="e7_agentview",
    )
    original = _materialize_recipe(
        load_task(task_id),
        _select_recipe(
            load_yaml_strict(source), partition="test_id", factor=None, recipe_name="e7_agentview"
        ),
        np.random.Generator(np.random.PCG64(2)),
    )
    assert scenario.physics.bodies[0].mass_kg == original.physics.bodies[0].mass_kg
    assert (
        scenario.physics.bodies[0].diagonal_inertia_kg_m2[0]
        == original.physics.bodies[0].diagonal_inertia_kg_m2[0] * 1.01
    )
    assert (
        scenario.physics.bodies[0].diagonal_inertia_kg_m2[1:]
        == original.physics.bodies[0].diagonal_inertia_kg_m2[1:]
    )


def test_real_robot_canopy_contact_is_terminal_without_inventing_other_forbidden_contacts() -> None:
    scenario = _proposal()
    probe = make_env("t1_occ", scenario)
    try:
        probe.reset()
        eef = tuple(
            float(x) for x in probe.sim.data.site_xpos[probe.robots[0].eef_site_id["right"]]
        )
    finally:
        probe.close()
    altered = replace(
        scenario,
        fixture_states=(
            scenario.fixture_states[0],
            replace(scenario.fixture_states[1], position_world_m=eef),
        ),
    )
    environment = make_env("t1_occ", altered)
    try:
        environment.reset()
        assert environment._compiled_occlusion_facts().robot_canopy_contact
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "unsafe_contact" and not info["success"]
        assert info["terminal_time_s"] == pytest.approx(0.002, abs=1e-12)
    finally:
        environment.close()


def test_occ_native_bad_state_cannot_hide_behind_canopy_safety_or_auto_reset(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    environment = make_env("t1_occ", _proposal())
    try:
        environment.reset()
        monkeypatch.chdir(tmp_path)
        environment.sim.data.qpos[environment._target_qpos_address] = np.nan
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "invalid_state" and not info["success"]
        assert info["terminal_time_s"] <= 0.002
    finally:
        environment.close()


def test_occ_native_terminal_failure_is_not_masked_by_an_empty_last_frame_silhouette(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    environment = make_env("t1_occ", _proposal())
    try:
        environment.reset()
        native_step = environment.step

        def exit_camera_and_workspace(action: BenchmarkAction) -> Any:
            # Failure-path injection only; the real native step must classify the bad state.
            environment.sim.data.qpos[environment._target_qpos_address] = 100.0
            return native_step(action)

        monkeypatch.setattr(environment, "step", exit_camera_and_workspace)
        info = _run_native_oracle(environment)
        assert info["failure_code"] == "workspace_exit" and not info["success"]
        assert info["terminal_time_s"] == pytest.approx(0.002, abs=1e-12)
        assert environment.sim.data.time == pytest.approx(0.05)
        visibility = _target_visibility(
            environment.sim,
            target_body_id=environment._target_body_id,
            occluder_body_id=environment._canopy_body_id,
        )
        assert visibility.visible_pixels == visibility.silhouette_pixels == 0
        with pytest.raises(ValueError, match="silhouette is empty"):
            _ = visibility.ratio
    finally:
        environment.close()


@pytest.mark.parametrize("finished", [False, True])
def test_occ_visibility_is_strict_until_complete_but_does_not_require_permanent_visibility(
    finished: bool,
) -> None:
    environment = make_env("t1_occ", _proposal())
    try:
        environment.reset()
        oracle = _CaptureOracle(environment)
        if finished:
            for _ in range(environment._task_spec.episode_horizon_steps):
                _, _, done, info = environment.step(oracle.action(environment))
                assert not done, info
                oracle._observe_visibility(environment)
                oracle._require_valid_visibility(environment, terminal=False)
                if oracle._visibility_state.complete:
                    break
            assert oracle._visibility_state.complete
        previous = oracle._visibility_state
        if not finished:
            _, _, done, info = environment.step(oracle.action(environment))
            assert not done, info
        assert environment._capture.terminal_time_s is None

        # Camera-only test perturbation: physical state remains valid and unterminated.
        model, data = environment.sim.model._model, environment.sim.data._data
        state = (data.qpos.copy(), data.qvel.copy())
        model.cam_pos[model.camera("agentview").id, 0] += 100.0
        environment.sim.forward()
        for before, after in zip(state, (data.qpos, data.qvel), strict=True):
            np.testing.assert_array_equal(before, after)
        if finished:
            _, _, done, info = environment.step(oracle.action(environment))
            assert not done, info
            assert data.time > previous.sensor_time_s
        visibility = _target_visibility(
            environment.sim,
            target_body_id=environment._target_body_id,
            occluder_body_id=environment._canopy_body_id,
        )
        assert visibility.visible_pixels == visibility.silhouette_pixels == 0
        if finished:
            oracle._observe_visibility(environment)
            oracle._require_valid_visibility(environment, terminal=False)
        else:
            with pytest.raises(_CaptureProposalRejected) as rejected:
                oracle._observe_visibility(environment)
            assert rejected.value.stage == "visibility"
            assert rejected.value.failure_code == "target_silhouette_empty"
            assert rejected.value.terminal_time_s == pytest.approx(0.05)
        assert oracle._visibility_state is previous
        assert environment._capture.terminal_time_s is None
    finally:
        environment.close()


def test_public_occ_generator_structures_real_raster_exit_before_visibility_completion(
    tmp_path: Path,
) -> None:
    document = copy.deepcopy(load_yaml_strict(RECIPE))
    recipes = copy.deepcopy(document["recipes"]["test_id"])
    for recipe in recipes.values():
        # One native physics intervention makes the free target rise out of the image.
        recipe["physics"]["gravity_world_m_s2"] = [0.0, 0.0, 0.4]
    document["recipes"]["ood"]["physics"] = recipes
    external = tmp_path / "raster_exit.yaml"
    external.write_text(yaml.safe_dump(document, sort_keys=False), encoding="utf-8")
    with pytest.raises(_CaptureProposalRejected) as rejected:
        generate_scenario(
            load_task("t1_occ"),
            external,
            2,
            partition="ood",
            factor="physics",
            recipe_name="e7_agentview",
        )
    assert rejected.value.stage == "visibility"
    assert rejected.value.failure_code == "target_silhouette_empty"
    assert rejected.value.terminal_time_s == pytest.approx(1.9, abs=1e-9)
    assert rejected.value.visibility_state.initial_visible_frames == 38
    assert not rejected.value.visibility_state.complete
    assert "stable_dwell" not in rejected.value.events
