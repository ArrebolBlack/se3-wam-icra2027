from __future__ import annotations

import json
import math
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import fields, replace
from importlib.metadata import entry_points
from pathlib import Path
from types import ModuleType
from typing import Any, cast

import mujoco
import numpy as np
import numpy.typing as npt
import pytest

from se3_wam_benchmark.control.action import (
    ActionMode,
    ActionRepresentation,
    BenchmarkAction,
    _controller_action,
    _so3_log,
)
from se3_wam_benchmark.data.recorder import _read_episode_file
from se3_wam_benchmark.data.schema import _episode_id
from se3_wam_benchmark.envs.base import (
    _collision_bottom_z,
    _distance_stage_progress,
    _duration_stage_progress,
    _fingerpad_contacts,
    _load_asset_catalog,
    _ordered_stage_facts,
    _resolve_joint_physics,
)
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.grasp import GraspEnv, _GraspCapture
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation import suite as suite_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.policy import BenchmarkPolicy
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.evaluation.suite import (
    GROUP_FIELDS,
    SuiteMember,
    SuiteSpec,
    _EvaluatedEpisode,
    _load_declared_jobs,
    _prepare_suite_jobs,
    _standalone_ood_reference_jobs,
    _SuiteJob,
    evaluate,
)
from se3_wam_benchmark.scenarios._feasibility import _validate_capture_reset
from se3_wam_benchmark.scenarios._native_oracle import _CaptureOracle, _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_grasp_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import (
    CircularTranslation,
    ConstantAngularVelocityRotation,
    ConstantVelocityTranslation,
    FixedTranslation,
    GraspGeometrySpec,
    HarmonicTranslation,
    JointPhysicsSpec,
    ScenarioSpec,
)
from se3_wam_benchmark.sensing.observation import (
    BenchmarkObservation,
    _quaternion_xyzw_to_matrix,
)
from se3_wam_benchmark.supervision.optical_flow import _exact_dense_optical_flow
from se3_wam_benchmark.supervision.snapshot import (
    SupervisionSnapshot,
    _assemble_supervision_snapshot,
)
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
RECIPE = ROOT / "configs/scenarios/grasp.yaml"


def _registered_cli(name: str) -> Callable[[Sequence[str] | None], None]:
    matches = tuple(entry_points(group="console_scripts", name=name))
    assert len(matches) == 1
    return cast(Callable[[Sequence[str] | None], None], matches[0].load())


def _proposal(
    seed: int,
    recipe_name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task("grasp")
    recipe = _select_recipe(
        load_yaml_strict(RECIPE), partition=partition, factor=factor, recipe_name=recipe_name
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_grasp_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    return scenario


def _motion_recipe_fixture(recipe_name: str, law_type: type[object]) -> dict[str, Any]:
    """Declare the law under test independently of the production seed schedule."""
    recipe = dict(
        _select_recipe(
            load_yaml_strict(RECIPE), partition="test_id", factor=None, recipe_name=recipe_name
        )
    )
    target = recipe["object_states"][0]
    target["position_world_m"] = [0.0, -0.22, 0.8220000000000001]
    target["quaternion_world_xyzw"] = {"yaw_rad": 0.0}
    translation: dict[str, Any]
    if law_type is FixedTranslation:
        translation = {"type": "fixed"}
    elif law_type is ConstantVelocityTranslation:
        translation = {"type": "constant_velocity", "velocity_world_m_s": [0.0, 0.06, 0.0]}
    elif law_type is CircularTranslation:
        translation = {
            "type": "circular",
            "axis_world": [0.0, 0.0, 1.0],
            "radial_direction_world": [1.0, 0.0, 0.0],
            "radius_m": 0.025,
            "angular_speed_rad_s": 0.5,
            "phase_rad": 0.0,
        }
    else:
        raise ValueError("motion fixture requires an explicit non-harmonic law")
    recipe["motion"][0]["translation"] = translation
    recipe["motion"][0]["rotation"] = {"type": "fixed"}
    return recipe


def _motion_fixture(seed: int, recipe_name: str, law_type: type[object]) -> ScenarioSpec:
    task = load_task("grasp")
    scenario = _materialize_recipe(
        task,
        _motion_recipe_fixture(recipe_name, law_type),
        np.random.Generator(np.random.PCG64(seed)),
    )
    _validate_grasp_declarative_scenario(
        task,
        scenario,
        partition="stress",
        factor=None,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    return scenario


@pytest.mark.parametrize("partition", ["train", "validation", "test_id"])
def test_grasp_id_recipe_preserves_db0_motion_distribution(partition: Partition) -> None:
    recipes = load_yaml_strict(RECIPE)
    for recipe_name in ("e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist"):
        for seed in (0, 7):
            scenario = _proposal(seed, recipe_name, partition=partition)
            translation = scenario.motion[0].translation
            rotation = scenario.motion[0].rotation
            assert isinstance(translation, HarmonicTranslation)
            assert isinstance(rotation, ConstantAngularVelocityRotation)
            assert -0.08 <= translation.center_world_m[0] <= 0.08
            assert -0.26 <= translation.center_world_m[1] <= -0.19
            assert 0.025 <= translation.drift_velocity_world_m_s[1] <= 0.125
            assert 0.015 <= translation.amplitude_m[0] <= 0.035
            assert 0.30 <= translation.frequency_hz[0] <= 0.70
            assert -math.pi <= translation.phase_rad[0] <= math.pi
            assert rotation.axis_world == (0.0, 0.0, 1.0)
            assert -1.2 <= rotation.angular_speed_rad_s <= 1.2
        recipe = _select_recipe(recipes, partition=partition, factor=None, recipe_name=recipe_name)
        assert recipe["motion"][0]["translation"]["drift_velocity_world_m_s"][1] == {
            "min": 0.025,
            "max": 0.125,
        }
        assert recipe["motion"][0]["translation"]["amplitude_m"][0] == {
            "min": 0.015,
            "max": 0.035,
        }
        assert recipe["motion"][0]["translation"]["frequency_hz"][0] == {
            "min": 0.30,
            "max": 0.70,
        }


@pytest.mark.parametrize("phase", [0.0, math.pi / 2.0])
def test_grasp_recipe_derives_actual_start_and_initial_twist_from_one_motion(phase: float) -> None:
    task = load_task("grasp")
    recipe = _select_recipe(
        load_yaml_strict(RECIPE), partition="test_id", factor=None, recipe_name="e7_agentview"
    )
    recipe["object_states"][0]["position_world_m"] = {
        "harmonic_center_world_m": [0.08, -0.22, 0.8220000000000001]
    }
    translation = recipe["motion"][0]["translation"]
    translation["drift_velocity_world_m_s"] = [0.0, 0.1, 0.0]
    translation["amplitude_m"] = [0.035, 0.0, 0.0]
    translation["frequency_hz"] = [0.5, 0.0, 0.0]
    translation["phase_rad"] = [phase, 0.0, 0.0]
    recipe["motion"][0]["rotation"]["angular_speed_rad_s"] = 0.6
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(0)))
    _validate_grasp_declarative_scenario(
        task,
        scenario,
        partition="test_id",
        factor=None,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    target = scenario.object_states[0]
    expected_x = 0.08 if phase == 0.0 else 0.115
    expected_vx = 0.035 * math.pi if phase == 0.0 else 0.0
    np.testing.assert_allclose(
        target.position_world_m, [expected_x, -0.22, 0.8220000000000001], rtol=0.0, atol=1e-15
    )
    np.testing.assert_allclose(
        target.linear_velocity_world_m_s, [expected_vx, 0.1, 0.0], rtol=0.0, atol=1e-15
    )
    np.testing.assert_array_equal(target.angular_velocity_world_rad_s, [0.0, 0.0, 0.6])


def test_grasp_reset_keeps_db0_yaw_rate_without_a_world_body_roundtrip() -> None:
    scenario = _proposal(5)
    environment = make_env("grasp", scenario)
    try:
        environment.reset()
        velocity = environment._target_qvel_address
        expected = (
            *scenario.object_states[0].linear_velocity_world_m_s,
            *scenario.object_states[0].angular_velocity_world_rad_s,
        )
        np.testing.assert_array_equal(environment.sim.data.qvel[velocity : velocity + 6], expected)
        assert environment.export_scenario() == scenario
    finally:
        environment.close()


class _RecordedActions:
    def __init__(self, mode: ActionMode, actions: npt.NDArray[np.float64]) -> None:
        self._mode = mode
        self._actions = actions
        self._index = 0

    def reset(self) -> None:
        self._index = 0

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
        assert observation.tick == self._index
        values = np.ascontiguousarray(self._actions[self._index], dtype=np.float64)
        values = np.ascontiguousarray(values, dtype=np.float64)
        values.setflags(write=False)
        self._index += 1
        return BenchmarkAction(self._mode, "delta", values)


@pytest.mark.parametrize("task_id", ["t1_so3", "t1_occ", "t4_slider", "t5_replan"])
def test_native_oracle_cli_preserves_acceptance_or_structured_rejection(
    task_id: str, tmp_path: Path
) -> None:
    manifest_path = tmp_path / "train.jsonl"
    if task_id == "t5_replan":
        with pytest.raises(_CaptureProposalRejected) as caught:
            _registered_cli("se3-wam-generate-scenarios")(
                (
                    "--task-id",
                    task_id,
                    "--recipe",
                    str(ROOT / "configs" / "scenarios" / f"{task_id}.yaml"),
                    "--partition",
                    "train",
                    "--recipe-name",
                    "e7_agentview_wrist",
                    "--seed",
                    "2",
                    "--count",
                    "1",
                    "--output",
                    str(manifest_path),
                )
            )
        rejection = caught.value
        assert rejection.stage == "oracle" and rejection.failure_code == "downstream_exit"
        assert rejection.terminal_time_s is not None
        assert rejection.events["downstream_exit"] == rejection.terminal_time_s
        assert "success" not in rejection.events
        assert rejection.__notes__ == ["selected branch: right; counterfactual index: 1"]
        assert not manifest_path.exists()
        assert not tuple(tmp_path.iterdir())
        assert list(rejection.events) == [
            "keyed_puck_enters_observation_lane",
            "side_strike_triggered",
            "striker_impact_onset",
            "striker_impact_end",
            "postevent_state_validated",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "verified_rigid_grasp_engaged",
            "downstream_exit",
        ]
        return
    _registered_cli("se3-wam-generate-scenarios")(
        (
            "--task-id",
            task_id,
            "--recipe",
            str(ROOT / "configs" / "scenarios" / f"{task_id}.yaml"),
            "--partition",
            "train",
            "--recipe-name",
            "e7_agentview_wrist",
            "--seed",
            "2",
            "--count",
            "1",
            "--output",
            str(manifest_path),
        )
    )
    row = load_manifest(manifest_path).rows[0]
    directory = tmp_path / "episodes"
    directory.mkdir()
    _registered_cli("se3-wam-record")(
        (
            "--manifest",
            str(manifest_path),
            "--policy",
            "native-oracle",
            "--output",
            str(directory),
        )
    )
    filename = f"{_episode_id(row.scenario_id, 0)}.hdf5"
    metadata, arrays = _read_episode_file(directory / filename)
    assert metadata["outcome"] == {
        "success": True,
        "termination_reason": "success",
        "failure_code": None,
    }
    assert not tuple(directory.glob("*.partial.hdf5"))
    transitions = len(arrays.action_value)
    assert len(arrays.tick) == transitions + 1
    assert arrays.rgb.shape == (transitions + 1, 2, 224, 224, 3)
    assert arrays.flow_2d_px.shape == (transitions, 2, 224, 224, 2)
    np.testing.assert_array_equal(arrays.issued_tick, np.arange(transitions))
    expected_applied = arrays.issued_tick + row.scenario.action_delay_steps
    expected_applied[expected_applied >= transitions] = -1
    np.testing.assert_array_equal(arrays.applied_tick, expected_applied)
    assert not np.any(arrays.success[:-1]) and arrays.success[-1]
    assert not np.any(arrays.done[:-1]) and arrays.done[-1]
    assert np.all(arrays.event_flags[-1])
    assert np.any(arrays.flow_valid) and np.any(arrays.flow_future_visible)
    assert np.all(arrays.flow_2d_px[~arrays.flow_valid] == 0.0)
    assert np.all(np.abs(arrays.action_value[:, :3]) <= 0.05)
    assert np.all(np.abs(arrays.action_value[:, 3:6]) <= 0.5)
    assert np.all(np.abs(arrays.action_value[:, 6]) <= 1.0)

    replay_directory = tmp_path / "replay"
    replay_directory.mkdir()
    replay = _rollout_episode(
        load_task(task_id),
        row.scenario,
        _RecordedActions(row.scenario.action_mode, arrays.action_value),
        scenario_id=row.scenario_id,
        partition=row.partition,
        factor=row.factor,
        repeat_index=0,
        record_directory=replay_directory,
    )
    assert replay.success and replay.failure_code is None
    replay_metadata, replay_arrays = _read_episode_file(replay_directory / filename)
    assert replay_metadata == metadata
    for field in arrays.__dataclass_fields__:
        if field != "rgb":
            np.testing.assert_array_equal(getattr(replay_arrays, field), getattr(arrays, field))
    _assert_replay_rgb(replay_arrays.rgb, arrays.rgb, probe=f"native_oracle_{task_id}")


def test_grasp_applies_free_joint_physics_by_compiled_dof_without_robot_drift() -> None:
    baseline = _proposal(2)
    native_environment = make_env("grasp", baseline)
    try:
        assert isinstance(native_environment, GraspEnv)
        native_environment.reset()
        address = native_environment._target_qvel_address
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_damping[address : address + 6],
            np.zeros(6),
        )
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_frictionloss[address : address + 6],
            np.zeros(6),
        )
    finally:
        native_environment.close()
    damping = (0.001, 0.002, 0.003, 0.004, 0.005, 0.006)
    friction = (0.0001, 0.0002, 0.0003, 0.0004, 0.0005, 0.0006)
    joint = JointPhysicsSpec("target", "target_joint0", damping, friction)
    scenario = replace(baseline, physics=replace(baseline.physics, joints=(joint,)))
    environment = make_env("grasp", scenario)
    try:
        assert isinstance(environment, GraspEnv)
        model = environment.sim.model._model
        robot = environment.robots[0]
        robot_dofs = np.asarray(
            [
                *robot._ref_joint_vel_indexes,
                *robot._ref_gripper_joint_vel_indexes["right"],
            ],
            dtype=np.int64,
        )
        robot_damping = model.dof_damping[robot_dofs].copy()
        robot_friction = model.dof_frictionloss[robot_dofs].copy()
        for _ in range(2):
            environment.reset()
            binding = environment._compiled_joint_physics[0]
            assert binding.dof_address == environment._target_qvel_address
            assert binding.dof_count == 6
            np.testing.assert_array_equal(
                model.dof_damping[binding.dof_address : binding.dof_address + 6], damping
            )
            np.testing.assert_array_equal(
                model.dof_frictionloss[binding.dof_address : binding.dof_address + 6], friction
            )
            np.testing.assert_array_equal(model.dof_damping[robot_dofs], robot_damping)
            np.testing.assert_array_equal(model.dof_frictionloss[robot_dofs], robot_friction)

        entity_bodies = {"target": environment._target_body_id}
        with pytest.raises(ValueError, match="entity does not resolve"):
            _resolve_joint_physics(
                model,
                (JointPhysicsSpec("robot", "target_joint0", damping, friction),),
                entity_body_ids=entity_bodies,
            )
        with pytest.raises(ValueError, match="element does not resolve"):
            _resolve_joint_physics(
                model,
                (JointPhysicsSpec("target", "missing_joint", damping, friction),),
                entity_body_ids=entity_bodies,
            )
        with pytest.raises(ValueError, match="does not belong to its declared entity"):
            _resolve_joint_physics(
                model,
                (JointPhysicsSpec("target", robot.robot_model.joints[0], damping, friction),),
                entity_body_ids=entity_bodies,
            )
        with pytest.raises(ValueError, match="exactly 6 per-DOF values"):
            _resolve_joint_physics(
                model,
                (JointPhysicsSpec("target", "target_joint0", (0.0,), (0.0,)),),
                entity_body_ids=entity_bodies,
            )
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _action(
    environment: GraspEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = -1.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        if mode == "E7":
            motion = np.concatenate((position, _so3_log(rotation)))
        else:
            motion = joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    value = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    value = np.ascontiguousarray(value, dtype=np.float64)
    value.setflags(write=False)
    return BenchmarkAction(mode, representation, value)


class _PolicyVisibleStaticGrasp:
    """A deterministic test policy using only ScenarioSpec and policy-visible state."""

    def __init__(self, scenario: ScenarioSpec) -> None:
        if scenario.action_mode != "E7" or not isinstance(
            scenario.motion[0].translation, FixedTranslation
        ):
            raise ValueError("static Grasp test policy requires one fixed E7 scenario")
        self._scenario = scenario
        self.reset()

    def reset(self) -> None:
        self._phase = "approach"
        self._close_ticks = 0
        self.observation_ids: list[int] = []

    def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
        self.observation_ids.append(id(observation))
        target_state = self._scenario.object_states[0]
        target_position_world = np.asarray(target_state.position_world_m, dtype=np.float64)
        target_rotation_world = _quaternion_xyzw_to_matrix(
            np.asarray(target_state.quaternion_world_xyzw, dtype=np.float64)
        )
        yaw = math.atan2(float(target_rotation_world[1, 0]), float(target_rotation_world[0, 0]))
        cosine, sine = math.cos(yaw), math.sin(yaw)
        goal_rotation_world = np.asarray(
            ((cosine, sine, 0.0), (sine, -cosine, 0.0), (0.0, 0.0, -1.0)),
            dtype=np.float64,
        )
        base_from_world = observation.T_robot_base_from_world
        target_position = (base_from_world @ np.append(target_position_world, 1.0))[:3]
        goal_rotation = base_from_world[:3, :3] @ goal_rotation_world
        eef_position = np.asarray(observation.eef_position, dtype=np.float64)
        eef_rotation = _quaternion_xyzw_to_matrix(
            np.asarray(observation.eef_quaternion_xyzw, dtype=np.float64)
        )
        rotation_error = _so3_log(goal_rotation @ eef_rotation.T)

        desired = target_position.copy()
        if self._phase == "approach":
            desired[2] += 0.10
            if (
                np.linalg.norm(desired - eef_position) < 0.025
                and np.linalg.norm(rotation_error) < 0.20
            ):
                self._phase = "descend"
        if self._phase == "descend":
            desired = target_position.copy()
            desired[2] += 0.005
            if (
                np.linalg.norm(desired[:2] - eef_position[:2]) < 0.012
                and abs(desired[2] - eef_position[2]) < 0.010
            ):
                self._phase = "close"
        if self._phase == "close":
            desired = target_position.copy()
            desired[2] += 0.005
            self._close_ticks += 1
            if self._close_ticks >= 10:
                self._phase = "lift"
        if self._phase == "lift":
            desired[2] = target_position[2] + 0.11

        position_error = desired - eef_position
        position_norm = float(np.linalg.norm(position_error))
        if position_norm > 0.03:
            position_error *= 0.03 / position_norm
        rotation_norm = float(np.linalg.norm(rotation_error))
        if rotation_norm > 0.20:
            rotation_error *= 0.20 / rotation_norm
        gripper = 1.0 if self._phase in ("close", "lift") else -1.0
        value = np.ascontiguousarray(
            np.concatenate((position_error, rotation_error, (gripper,))), dtype=np.float32
        )
        value = np.ascontiguousarray(value, dtype=np.float64)
        value.setflags(write=False)
        return BenchmarkAction("E7", "delta", value)


def _assert_observation(observation: BenchmarkObservation, tick: int, views: int) -> None:
    assert observation.tick == tick
    assert observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.rgb.dtype == np.uint8
    assert observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.dtype == np.float64
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    assert observation.T_robot_base_from_world.dtype == np.float64
    assert np.all(observation.depth_m > 0.0)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert value.flags.c_contiguous and not value.flags.writeable
            assert np.isfinite(value).all()
    assert not {"task", "events", "target_pose", "future"} & {
        field.name for field in fields(observation)
    }


def _assert_replay_rgb(
    actual: npt.NDArray[np.uint8], expected: npt.NDArray[np.uint8], *, probe: str
) -> None:
    """Report small EGL RGB differences separately from exact replay state."""
    assert actual.shape == expected.shape
    assert actual.dtype == expected.dtype == np.uint8
    difference = np.abs(actual.astype(np.int16) - expected.astype(np.int16))
    max_abs = int(difference.max())
    report = {
        "probe": probe,
        "different_channels": int(np.count_nonzero(difference)),
        "total_channels": int(difference.size),
        "max_abs": max_abs,
        "max_different_channels_per_view_frame": int(
            np.count_nonzero(difference, axis=(-3, -2, -1)).max()
        ),
    }
    print("replay_rgb " + json.dumps(report, sort_keys=True))
    assert max_abs <= 1, report


@pytest.mark.parametrize(
    ("seed", "name", "representation", "delay", "law_type"),
    [
        (0, "e7_agentview", "delta", 0, FixedTranslation),
        (2, "j8_agentview_wrist", "delta", 1, ConstantVelocityTranslation),
        (5, "e7_agentview", "absolute", 0, HarmonicTranslation),
        (1, "j8_agentview_wrist", "absolute", 1, CircularTranslation),
    ],
)
def test_registered_grasp_runs_real_motion_action_and_rgbd_chain(
    seed: int, name: str, representation: str, delay: int, law_type: type[object]
) -> None:
    scenario = replace(
        _proposal(seed, name)
        if law_type is HarmonicTranslation
        else _motion_fixture(seed, name, law_type),
        action_delay_steps=delay,
    )
    assert isinstance(scenario.motion[0].translation, law_type)
    environment = make_env("grasp", scenario)
    assert isinstance(environment, GraspEnv)
    try:
        raw = environment.reset()
        assert isinstance(raw, Mapping)
        assert environment.get_ep_meta() == scenario
        initial = environment._benchmark_observation(raw)
        views = len(scenario.cameras.views)
        _assert_observation(initial, 0, views)
        first = _action(environment, representation, displacement=0.002, gripper=1.0)
        raw, reward, done, _ = environment.step(first)
        assert math.isfinite(reward) and not done
        if delay:
            np.testing.assert_array_equal(environment.robots[0].recent_actions.current, 0.0)
        previous = environment._benchmark_observation(raw)
        _assert_observation(previous, 1, views)
        position, rotation, joints = environment._achieved_controller_state()
        second = _action(environment, representation)
        expected = _controller_action(
            first if delay else second,
            environment._action_spec,
            achieved_eef_position=position,
            achieved_eef_rotation=rotation,
            achieved_joint_position=joints,
        )
        raw, _, done, _ = environment.step(second)
        assert not done
        np.testing.assert_allclose(
            environment.robots[0].recent_actions.current, expected, rtol=0.0, atol=1e-7
        )
        current = environment._benchmark_observation(raw)
        _assert_observation(current, 2, views)
        assert environment.sim.data.time == pytest.approx(0.10, abs=1e-12)
        assert environment._capture.physics_step == 50
        assert np.dot(previous.eef_quaternion_xyzw, current.eef_quaternion_xyzw) >= 0.0
        np.testing.assert_array_equal(
            raw["robot0_eef_pos"],
            environment.sim.data._data.site_xpos[environment.robots[0].eef_site_id["right"]],
        )
        np.testing.assert_array_equal(
            initial.world_from_camera_cv[0], current.world_from_camera_cv[0]
        )
        if views == 2:
            assert not np.array_equal(
                initial.world_from_camera_cv[1], current.world_from_camera_cv[1]
            )
            wrist_id = environment.sim.model._model.camera("robot0_eye_in_hand").id
            np.testing.assert_array_equal(
                current.world_from_camera_cv[1, :3, 3],
                environment.sim.data._data.cam_xpos[wrist_id],
            )
        raw = environment.reset()
        assert environment._episode_tick == environment._capture.physics_step == 0
        assert environment._action_spec is environment._action_delay_queue is None
        assert environment._previous_eef_quaternion_xyzw is None
        assert environment._capture.events == {"target_enters_observation_region": 0.0}
        assert not environment.done
        reset_observation = environment._benchmark_observation(raw)
        for field in fields(initial):
            if field.name != "rgb":
                np.testing.assert_array_equal(
                    getattr(initial, field.name),
                    getattr(reset_observation, field.name),
                    strict=True,
                )
        _assert_replay_rgb(
            initial.rgb,
            reset_observation.rgb,
            probe=f"grasp_reset_{seed}_{name}_{representation}_{delay}",
        )
        opposite = "absolute" if representation == "delta" else "delta"
        environment.step(_action(environment, opposite))
        assert environment._action_spec.representation == opposite
    finally:
        environment.close()


def test_single_sample_depth_labels_preserve_rgb_state_and_context_lifetime(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    environment = make_env("grasp", _proposal(10000, "e7_agentview_wrist", partition="train"))
    try:
        raw = environment.reset()
        context = environment.sim._render_context_offscreen
        original = context.con
        qpos = environment.sim.data.qpos.copy()
        qvel = environment.sim.data.qvel.copy()
        images = [
            environment.sim.render(camera_name=name, width=224, height=224).copy()
            for name in environment._camera_sensor_names
        ]
        observation = environment._benchmark_observation(raw)
        single = environment._single_sample_context
        assert single is not None and single is not original
        assert single.offSamples == 0 and original.offSamples == 4
        assert environment.sim.model.vis.quality.offsamples == 4
        for view, name in enumerate(environment._camera_sensor_names):
            segmentation, depth = environment._render_single_sample(name, segmentation=True)
            assert segmentation.shape == (224, 224, 2) and depth.shape == (224, 224)
            _assert_replay_rgb(
                images[view],
                environment.sim.render(camera_name=name, width=224, height=224),
                probe=f"single_sample_context_{name}",
            )
            np.testing.assert_array_equal(observation.rgb[view], raw[f"{name}_image"][::-1])
            assert context.con is original
            if view == 0:
                model, data = environment.sim.model._model, environment.sim.data._data
                target_geoms = np.flatnonzero(model.geom_bodyid == environment._target_body_id)
                cv_segmentation = segmentation[::-1]
                pixels = np.argwhere(
                    (cv_segmentation[..., 0] == int(mujoco.mjtObj.mjOBJ_GEOM))
                    & np.isin(cv_segmentation[..., 1], target_geoms)
                )
                assert len(pixels) >= 6
                intrinsic = observation.camera_intrinsics[view]
                transform = observation.world_from_camera_cv[view]
                for y, x in pixels[np.linspace(0, len(pixels) - 1, 6, dtype=int)]:
                    cv_ray = np.linalg.solve(intrinsic, np.array([x, y, 1.0]))
                    world_ray = transform[:3, :3] @ cv_ray
                    world_ray /= np.linalg.norm(world_ray)
                    ray_geom = np.array([-1], dtype=np.int32)
                    distance = mujoco.mj_ray(
                        model,
                        data,
                        transform[:3, 3].copy(),
                        world_ray,
                        context.vopt.geomgroup,
                        1,
                        -1,
                        ray_geom,
                    )
                    assert ray_geom[0] == cv_segmentation[y, x, 1]
                    np.testing.assert_allclose(
                        observation.depth_m[view, y, x],
                        distance / np.linalg.norm(cv_ray),
                        rtol=0.0,
                        atol=1e-4,
                    )
        np.testing.assert_array_equal(qpos, environment.sim.data.qpos)
        np.testing.assert_array_equal(qvel, environment.sim.data.qvel)

        flags = context.scn.flags.copy()
        buffer = original.currentBuffer

        def interrupted_render(**kwargs: object) -> None:
            context.scn.flags[mujoco.mjtRndFlag.mjRND_SEGMENT] = 1
            raise RuntimeError("interrupted categorical render")

        with monkeypatch.context() as patch:
            patch.setattr(environment.sim, "render", interrupted_render)
            with pytest.raises(RuntimeError, match="interrupted categorical render"):
                environment._render_single_sample("agentview", segmentation=True)
        assert context.con is original and original.currentBuffer == buffer
        np.testing.assert_array_equal(flags, context.scn.flags)
        _assert_replay_rgb(
            images[0],
            environment.sim.render(camera_name="agentview", width=224, height=224),
            probe="single_sample_context_after_exception",
        )
        raw = environment.reset()
        assert environment._single_sample_context is None
        assert environment.sim._render_context_offscreen.con is not original
        environment._benchmark_observation(raw)
        assert environment._single_sample_context is not single
    finally:
        environment.close()
    assert environment._single_sample_context is None


def test_real_grasp_snapshot_aligns_cv_segmentation_pose_and_adjacent_flow() -> None:
    environment = make_env("grasp", _proposal(0, "e7_agentview"))
    try:
        raw = environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        identities = tuple(
            f"body:{int(model.geom_bodyid[geom_id])}" for geom_id in range(model.ngeom)
        )

        def capture(
            previous: npt.NDArray[np.float64] | None = None,
        ) -> tuple[SupervisionSnapshot, npt.NDArray[np.int32]]:
            observation = environment._benchmark_observation(raw)
            segmentation = np.stack(
                [
                    environment.sim.render(
                        camera_name="agentview",
                        width=224,
                        height=224,
                        segmentation=True,
                    )
                ]
            ).astype(np.int32, copy=False)
            snapshot = _assemble_supervision_snapshot(
                observation,
                model,
                data,
                element_segmentation_opengl=segmentation,
                target_body_id=environment._target_body_id,
                geom_semantic_identity=identities,
                previous_target_quaternion_xyzw=previous,
            )
            return snapshot, segmentation

        first, native_first = capture()
        expected = native_first[:, ::-1]
        is_geom = expected[..., 0] == int(mujoco.mjtObj.mjOBJ_GEOM)
        np.testing.assert_array_equal(first.geom_id[is_geom], expected[..., 1][is_geom])
        assert np.all(first.geom_id[~is_geom] == -1)
        np.testing.assert_array_equal(
            first.target_object_pose_world[:3], data.xpos[environment._target_body_id]
        )
        assert len(set(first.geom_semantic_identity)) < model.ngeom

        raw, _, done, info = environment.step(_action(environment))
        assert not done, info
        second, _ = capture(first.target_object_pose_world[3:])
        flow, valid, future_visible = _exact_dense_optical_flow(first, second)
        assert flow.shape == (1, 224, 224, 2)
        assert valid.shape == future_visible.shape == (1, 224, 224)
        assert np.any(valid) and np.any(future_visible)
        assert np.all(flow[~valid] == 0.0)
        assert (
            float(np.dot(first.target_object_pose_world[3:], second.target_object_pose_world[3:]))
            >= 0.0
        )
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("seed", "factor", "asset_id"),
    [
        (0, None, "obj.cuboid_grasp_v1"),
        (14, "object", "obj.bottle_v1"),
        (12, "object", "obj.rod_v1"),
        (0, "object", "obj.asym_t_t1_v1"),
    ],
)
def test_four_assets_have_real_support_and_exact_compiled_reset(
    seed: int, factor: str | None, asset_id: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    scenario = _proposal(seed, partition="ood" if factor else "test_id", factor=factor)
    assert scenario.object_states[0].asset_id == asset_id
    environment = make_env("grasp", scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        body = environment._target_body_id
        exported = environment.export_scenario()
        assert exported == scenario and exported is not scenario
        velocity = environment._target_qvel_address
        np.testing.assert_array_equal(data.qvel[:velocity], 0.0)
        np.testing.assert_array_equal(
            data.qvel[velocity : velocity + 3],
            scenario.object_states[0].linear_velocity_world_m_s,
        )
        np.testing.assert_allclose(
            data.xmat[body].reshape(3, 3) @ data.qvel[velocity + 3 : velocity + 6],
            scenario.object_states[0].angular_velocity_world_rad_s,
            rtol=0.0,
            atol=1e-15,
        )
        np.testing.assert_array_equal(
            data.qpos[environment.robots[0]._ref_joint_pos_indexes],
            scenario.robot_initial_state.joint_position_rad,
        )
        np.testing.assert_array_equal(data.xpos[body], scenario.object_states[0].position_world_m)
        assert _collision_bottom_z(model, data, environment._target_geom_ids) == pytest.approx(0.8)
        assert model.body_mass[body] == scenario.physics.bodies[0].mass_kg
        np.testing.assert_array_equal(
            model.body_inertia[body], scenario.physics.bodies[0].diagonal_inertia_kg_m2
        )
        assert np.all(model.body_inertia[body] > 0.0)
        if asset_id == "obj.asym_t_t1_v1":
            assert not np.array_equal(model.body_iquat[body], [1.0, 0.0, 0.0, 0.0])
        for geom_id in environment._target_geom_ids:
            assert model.geom_bodyid[geom_id] == body
            np.testing.assert_array_equal(
                model.geom_friction[geom_id], scenario.physics.contacts[0].friction_slide_spin_roll
            )
            np.testing.assert_array_equal(
                model.geom_solref[geom_id], scenario.physics.contacts[0].solref
            )
            np.testing.assert_array_equal(
                model.geom_solimp[geom_id], scenario.physics.contacts[0].solimp
            )
        assert model.nlight == 1 and model.light(0).name == "table_key"
        assert model.vis.headlight.active == 1
        assert model.vis.quality.offsamples == 4
        np.testing.assert_array_equal(
            model.light_pos[0], scenario.lighting.lights[0].position_world_m
        )
        np.testing.assert_array_equal(
            model.light_diffuse[0],
            np.asarray(scenario.lighting.lights[0].diffuse_rgb, dtype=np.float32),
        )
        np.testing.assert_array_equal(model.opt.gravity, scenario.physics.gravity_world_m_s2)
        _validate_capture_reset(environment)
        support_forces: list[float] = []
        original_update = environment._capture.update

        def observe_support(**state: Any) -> None:
            for index in range(data.ncon):
                contact = data.contact[index]
                pair = {int(contact.geom1), int(contact.geom2)}
                if environment._table_geom_id in pair and pair & set(environment._target_geom_ids):
                    force = np.empty(6)
                    mujoco.mj_contactForce(model, data, index, force)
                    support_forces.append(float(force[0]))
            original_update(**state)

        monkeypatch.setattr(environment._capture, "update", observe_support)
        environment.step(_action(environment))
        assert support_forces and max(support_forces) > 0.0
        assert np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
        assert environment.export_scenario() == exported
    finally:
        environment.close()


@pytest.mark.parametrize(
    "seed,name",
    [(2, "e7_agentview"), (5, "e7_agentview"), (35, "j8_agentview"), (36, "j8_agentview")],
)
def test_real_oracle_capture_keeps_driver_and_unique_terminal_facts(seed: int, name: str) -> None:
    environment = make_env("grasp", _proposal(seed, name))
    try:
        environment.reset()
        outcome = _run_native_oracle(environment)
        assert outcome["success"] is True and outcome["failure_code"] is None
        stage_names = (
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
        )
        assert tuple(outcome["events"]) == (
            "target_enters_observation_region",
            *stage_names,
            "success",
        )
        assert outcome["events"]["target_enters_observation_region"] == 0.0
        assert outcome["events"]["success"] == outcome["terminal_time_s"]
        assert tuple(item[0] for item in outcome["stage_facts"]) == stage_names
        assert all(item[1] and item[2] == 1.0 for item in outcome["stage_facts"])
        assert list(outcome["events"].values()) == sorted(outcome["events"].values())
        assert outcome["terminal_time_s"] == outcome["events"]["stable_dwell"]
        assert environment._capture.stable_steps == 250
        assert environment._capture.bilateral_steps >= 25
        assert _fingerpad_contacts(
            environment.sim.model._model,
            environment.sim.data._data,
            environment._target_geom_ids,
            environment._left_pad_ids,
            environment._right_pad_ids,
        ) == (True, True, True)
        assert environment.sim.data.time >= outcome["terminal_time_s"]
        assert environment.sim.data.time - outcome["terminal_time_s"] < 0.05
        assert environment._episode_tick < 160
        wrench = environment.sim.data._data.xfrc_applied[environment._target_body_id]
        np.testing.assert_array_equal(wrench, environment._last_wrench)
        assert wrench[2] == 0.0
        assert np.linalg.norm(wrench[:2]) <= 3.0 + 1e-12
        assert np.linalg.norm(wrench[3:5]) <= 0.15 + 1e-12
        assert abs(wrench[5]) <= 0.12 + 1e-12
        if seed != 35:
            assert np.linalg.norm(wrench) > 0.01
        assert not environment._action_delay_queue._pending
        time_before = float(environment.sim.data.time)
        with pytest.raises(ValueError, match="terminated episode"):
            environment.step(_action(environment))
        assert environment.sim.data.time == time_before
    finally:
        environment.close()


def test_grasp_real_oracle_runs_through_the_single_formal_rollout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("grasp")
    scenario = _proposal(2, "e7_agentview")
    environment = make_env(task.task_id, scenario)

    class OraclePolicy:
        oracle: _CaptureOracle | None = None

        def reset(self) -> None:
            self.oracle = _CaptureOracle(environment)

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            assert self.oracle is not None
            return self.oracle.action(environment)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> GraspEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        assert isinstance(environment, GraspEnv)
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        OraclePolicy(),
        scenario_id="v1:test_id:grasp:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert trace.success and trace.failure_code is None
    assert trace.event_names == tuple(stage.stage_name for stage in trace.steps[-1].stage_progress)
    assert trace.steps[-1].event_flags == (True,) * len(trace.event_names)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(range(len(trace.steps)))
    result = _evaluate_episode(trace)
    assert result.success and result.episode_steps == len(trace.steps)


def test_real_success_episode_records_frozen_hdf5_from_policy_visible_state(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    task = load_task("grasp")
    scenario = _motion_fixture(0, "e7_agentview", FixedTranslation)
    scenario_id = "v1:stress:grasp:000000"
    environment = cast(GraspEnv, make_env(task.task_id, scenario))
    original_observation = environment._benchmark_observation
    converted_observations: list[BenchmarkObservation] = []

    def counted_observation(raw: Mapping[str, object]) -> BenchmarkObservation:
        observation = original_observation(raw)
        converted_observations.append(observation)
        return observation

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> GraspEnv:
        assert execution_translation_limit_m == 0.05
        assert (task_id, compiled) == (task.task_id, scenario)
        return environment

    monkeypatch.setattr(environment, "_benchmark_observation", counted_observation)
    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    policy = _PolicyVisibleStaticGrasp(scenario)
    trace = _rollout_episode(
        task,
        scenario,
        policy,
        scenario_id=scenario_id,
        partition="stress",
        factor=None,
        repeat_index=0,
        record_directory=tmp_path,
    )
    destination = tmp_path / f"{_episode_id(scenario_id, 0)}.hdf5"
    assert destination.is_file()
    assert not tuple(tmp_path.glob("*.partial.hdf5"))
    metadata, arrays = _read_episode_file(destination)
    transitions = len(trace.steps)
    assert trace.success and trace.failure_code is None
    assert len(converted_observations) == transitions + 1
    assert policy.observation_ids == [id(item) for item in converted_observations[:-1]]
    assert arrays.tick.shape == (transitions + 1,)
    assert arrays.action_value.shape == (transitions, 7)
    assert arrays.flow_2d_px.shape == (transitions, 1, 224, 224, 2)
    np.testing.assert_array_equal(arrays.issued_tick, np.arange(transitions))
    np.testing.assert_array_equal(arrays.applied_tick, arrays.issued_tick)
    np.testing.assert_array_equal(
        arrays.action_value, np.stack([step.action.value for step in trace.steps])
    )
    np.testing.assert_array_equal(
        arrays.event_flags[0], np.zeros(len(trace.event_names), dtype=np.bool_)
    )
    np.testing.assert_array_equal(
        arrays.event_flags[-1], np.ones(len(trace.event_names), dtype=np.bool_)
    )
    assert not np.any(arrays.success[:-1]) and bool(arrays.success[-1])
    assert not np.any(arrays.done[:-1]) and bool(arrays.done[-1])
    assert np.any(arrays.flow_valid) and np.any(arrays.flow_future_visible)
    assert np.all(arrays.flow_2d_px[~arrays.flow_valid] == 0.0)
    assert metadata["episode_id"] == _episode_id(scenario_id, 0)
    assert metadata["outcome"] == {
        "success": True,
        "termination_reason": "success",
        "failure_code": None,
    }

    class RecordedActionPolicy:
        def reset(self) -> None:
            self._index = 0

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == self._index
            value = np.ascontiguousarray(arrays.action_value[self._index], dtype=np.float64)
            value = np.ascontiguousarray(value, dtype=np.float64)
            value.setflags(write=False)
            self._index += 1
            return BenchmarkAction(
                trace.action_spec.mode,
                trace.action_spec.representation,
                value,
            )

    replay_directory = tmp_path / "replay"
    replay_directory.mkdir()
    monkeypatch.setattr(rollout_module, "make_env", make_env)
    replay_trace = _rollout_episode(
        task,
        scenario,
        RecordedActionPolicy(),
        scenario_id=scenario_id,
        partition="stress",
        factor=None,
        repeat_index=0,
        record_directory=replay_directory,
    )
    replay_metadata, replay_arrays = _read_episode_file(
        replay_directory / f"{_episode_id(scenario_id, 0)}.hdf5"
    )
    assert replay_trace.success and replay_trace.failure_code is None
    assert replay_metadata == metadata
    for field in arrays.__dataclass_fields__:
        if field != "rgb":
            np.testing.assert_array_equal(
                getattr(replay_arrays, field), getattr(arrays, field), strict=True, err_msg=field
            )
    _assert_replay_rgb(replay_arrays.rgb, arrays.rgb, probe="grasp_success_recording")


def test_registered_cli_generate_evaluate_record_and_replay_real_episodes(
    tmp_path: Path,
) -> None:
    manifest_directory = tmp_path / "manifests" / "v1"
    failure_manifest_directory = tmp_path / "failure_manifests" / "v1"
    suite_directory = tmp_path / "configs" / "suites"
    manifest_directory.mkdir(parents=True)
    failure_manifest_directory.mkdir(parents=True)
    suite_directory.mkdir(parents=True)
    test_id_path = manifest_directory / "stress.jsonl"
    failure_manifest_path = failure_manifest_directory / "test_id.jsonl"
    static_recipe = tmp_path / "static-grasp.json"
    document = load_yaml_strict(RECIPE)
    document["recipes"]["stress"]["e7_agentview"] = _motion_recipe_fixture(
        "e7_agentview", FixedTranslation
    )
    static_recipe.write_text(json.dumps(document), encoding="utf-8")
    generate = _registered_cli("se3-wam-generate-scenarios")
    generate(
        (
            "--task-id",
            "grasp",
            "--recipe",
            str(static_recipe),
            "--partition",
            "stress",
            "--recipe-name",
            "e7_agentview",
            "--seed",
            "0",
            "--count",
            "1",
            "--output",
            str(test_id_path),
        )
    )
    generate(
        (
            "--task-id",
            "t5_replan",
            "--recipe",
            str(ROOT / "configs/scenarios/t5_replan.yaml"),
            "--partition",
            "test_id",
            "--recipe-name",
            "j8_agentview_wrist",
            "--seed",
            "0",
            "--count",
            "1",
            "--output",
            str(failure_manifest_path),
        )
    )
    success_manifest = load_manifest(test_id_path)
    failure_manifest = load_manifest(failure_manifest_path)
    assert tuple(row.source_seed for row in success_manifest) == (0,)
    assert tuple(row.source_seed for row in failure_manifest) == (0,)
    assert failure_manifest.rows[0].scenario.action_delay_steps == 1

    policy_module = ModuleType("b36_explicit_test_policy")
    sys.modules[policy_module.__name__] = policy_module
    try:
        setattr(
            policy_module,
            "build",
            lambda: _PolicyVisibleStaticGrasp(success_manifest.rows[0].scenario),
        )
        suite_path = suite_directory / "test_id.yaml"
        suite_path.write_text(
            """schema_version: 1
suite_id: test_id
protocol_version: v1
repeats: 1
members:
  - manifest: ../../manifests/v1/stress.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
            encoding="utf-8",
        )
        summary_path = tmp_path / "summary.json"
        evaluate_cli = _registered_cli("se3-wam-evaluate")
        evaluate_cli(
            (
                "--suite",
                str(suite_path),
                "--policy",
                f"{policy_module.__name__}:build",
                "--output",
                str(summary_path),
            )
        )
        summary = load_yaml_strict(summary_path)
        assert summary["results"][0]["success"] is True
        assert len(summary["groups"]) == 2

        record = _registered_cli("se3-wam-record")
        success_directory = tmp_path / "success"
        success_directory.mkdir()
        record(
            (
                "--manifest",
                str(test_id_path),
                "--policy",
                f"{policy_module.__name__}:build",
                "--output",
                str(success_directory),
            )
        )
        success_row = success_manifest.rows[0]
        success_path = success_directory / f"{_episode_id(success_row.scenario_id, 0)}.hdf5"
        success_metadata, success_arrays = _read_episode_file(success_path)
        assert success_metadata["outcome"] == {
            "success": True,
            "termination_reason": "success",
            "failure_code": None,
        }

        class ReplayPolicy:
            def __init__(self, metadata: Mapping[str, object], actions: npt.NDArray[np.float32]):
                action_spec = cast(Mapping[str, object], metadata["action_spec"])
                self.mode = cast(ActionMode, action_spec["mode"])
                self.representation = cast(ActionRepresentation, action_spec["representation"])
                self.actions = actions

            def reset(self) -> None:
                self.index = 0

            def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
                assert observation.tick == self.index
                value = np.ascontiguousarray(self.actions[self.index], dtype=np.float32)
                value = np.ascontiguousarray(value, dtype=np.float64)
                value.setflags(write=False)
                self.index += 1
                return BenchmarkAction(self.mode, self.representation, value)

        setattr(
            policy_module,
            "build",
            lambda: ReplayPolicy(success_metadata, success_arrays.action_value),
        )
        success_replay_directory = tmp_path / "success_replay"
        success_replay_directory.mkdir()
        record(
            (
                "--manifest",
                str(test_id_path),
                "--policy",
                f"{policy_module.__name__}:build",
                "--output",
                str(success_replay_directory),
            )
        )
        replay_metadata, replay_arrays = _read_episode_file(
            success_replay_directory / success_path.name
        )
        assert replay_metadata == success_metadata
        for field in success_arrays.__dataclass_fields__:
            if field != "rgb":
                np.testing.assert_array_equal(
                    getattr(replay_arrays, field),
                    getattr(success_arrays, field),
                    strict=True,
                    err_msg=field,
                )
        _assert_replay_rgb(
            replay_arrays.rgb, success_arrays.rgb, probe="grasp_cli_success_recording"
        )

        class HoldJ8Policy:
            def reset(self) -> None:
                self.ticks = 0

            def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
                assert observation.tick == self.ticks
                self.ticks += 1
                value = np.ascontiguousarray(
                    np.concatenate((observation.joint_position, [-1.0])), dtype=np.float32
                )
                value = np.ascontiguousarray(value, dtype=np.float64)
                value.setflags(write=False)
                return BenchmarkAction("J8", "absolute", value)

        setattr(policy_module, "build", HoldJ8Policy)
        failure_directory = tmp_path / "failure"
        failure_directory.mkdir()
        record(
            (
                "--manifest",
                str(failure_manifest_path),
                "--policy",
                f"{policy_module.__name__}:build",
                "--output",
                str(failure_directory),
            )
        )
        failure_row = failure_manifest.rows[0]
        failure_episode_path = failure_directory / f"{_episode_id(failure_row.scenario_id, 0)}.hdf5"
        failure_metadata, failure_arrays = _read_episode_file(failure_episode_path)
        failure_outcome = cast(Mapping[str, object], failure_metadata["outcome"])
        assert failure_outcome["success"] is False
        assert failure_outcome["failure_code"] is not None
        np.testing.assert_array_equal(
            failure_arrays.applied_tick[:-1], failure_arrays.issued_tick[:-1] + 1
        )
        assert failure_arrays.applied_tick[-1] == -1

        setattr(
            policy_module,
            "build",
            lambda: ReplayPolicy(failure_metadata, failure_arrays.action_value),
        )
        failure_replay_directory = tmp_path / "failure_replay"
        failure_replay_directory.mkdir()
        record(
            (
                "--manifest",
                str(failure_manifest_path),
                "--policy",
                f"{policy_module.__name__}:build",
                "--output",
                str(failure_replay_directory),
            )
        )
        replay_metadata, replay_arrays = _read_episode_file(
            failure_replay_directory / failure_episode_path.name
        )
        assert replay_metadata == failure_metadata
        for field in failure_arrays.__dataclass_fields__:
            if field != "rgb":
                np.testing.assert_array_equal(
                    getattr(replay_arrays, field),
                    getattr(failure_arrays, field),
                    strict=True,
                    err_msg=field,
                )
        _assert_replay_rgb(
            replay_arrays.rgb, failure_arrays.rgb, probe="grasp_cli_failure_recording"
        )
    finally:
        del sys.modules[policy_module.__name__]


def test_recording_rejects_native_time_regression_and_leaves_only_an_invalid_partial(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    task = load_task("grasp")
    scenario = _motion_fixture(0, "e7_agentview", FixedTranslation)
    scenario_id = "v1:stress:grasp:000099"
    environment = cast(GraspEnv, make_env(task.task_id, scenario))
    original_step = environment.step

    def time_regressing_step(
        action: BenchmarkAction,
    ) -> tuple[Mapping[str, object], float, bool, dict[str, object]]:
        raw, reward, done, info = original_step(action)
        environment.sim.data.time -= scenario.physics_timestep_s
        return raw, reward, done, info

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> GraspEnv:
        assert execution_translation_limit_m == 0.05
        assert (task_id, compiled) == (task.task_id, scenario)
        return environment

    monkeypatch.setattr(environment, "step", time_regressing_step)
    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    with pytest.raises(RuntimeError, match="simulator time is not aligned"):
        _rollout_episode(
            task,
            scenario,
            _PolicyVisibleStaticGrasp(scenario),
            scenario_id=scenario_id,
            partition="stress",
            factor=None,
            repeat_index=0,
            record_directory=tmp_path,
        )
    partial = tmp_path / f"{_episode_id(scenario_id, 0)}.partial.hdf5"
    assert partial.is_file()
    assert not (tmp_path / f"{_episode_id(scenario_id, 0)}.hdf5").exists()
    with pytest.raises(ValueError, match="partial episode files"):
        _read_episode_file(partial)
    with pytest.raises(ValueError, match="frozen dataset set"):
        _read_episode_file(partial, allow_partial=True)


def test_suite_jobs_keep_all_repeats_together_and_preserve_declared_order(
    tmp_path: Path,
) -> None:
    manifest_path = tmp_path / "test_id.jsonl"
    manifest = ScenarioManifest(
        tuple(
            ScenarioManifestRow(
                1,
                "v1",
                f"v1:test_id:grasp:{ordinal:06d}",
                "grasp",
                "test_id",
                None,
                seed,
                _proposal(seed),
            )
            for ordinal, seed in enumerate((2, 3))
        )
    )
    write_manifest(manifest, manifest_path)
    suite = SuiteSpec(
        "research",
        "v1",
        2,
        (SuiteMember(manifest_path, ("grasp",)),),
        GROUP_FIELDS,
    )
    shards = tuple(
        _prepare_suite_jobs(suite, shard_index=index, shard_count=3)[0] for index in range(3)
    )
    assert tuple(
        tuple((job.row.scenario_id, job.repeat_index) for job in shard) for shard in shards
    ) == (
        (
            ("v1:test_id:grasp:000000", 0),
            ("v1:test_id:grasp:000000", 1),
        ),
        (
            ("v1:test_id:grasp:000001", 0),
            ("v1:test_id:grasp:000001", 1),
        ),
        (),
    )
    with pytest.raises(ValueError, match="no rows for declared task_ids"):
        _prepare_suite_jobs(
            replace(
                suite,
                members=(SuiteMember(manifest_path, ("grasp", "t1_belt")),),
            ),
            shard_index=0,
            shard_count=1,
        )


def test_pairing_groups_colocate_baseline_all_ood_factors_and_repeats(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def row(
        *,
        partition: Partition,
        factor: str | None,
        ordinal: int,
        seed: int,
    ) -> ScenarioManifestRow:
        identity = (
            f"v1:ood:{factor}:grasp:{ordinal:06d}"
            if partition == "ood"
            else f"v1:{partition}:grasp:{ordinal:06d}"
        )
        return ScenarioManifestRow(
            1,
            "v1",
            identity,
            "grasp",
            partition,
            factor,
            seed,
            _proposal(2, partition=partition, factor=factor),
        )

    reference_path = tmp_path / "baseline.jsonl"
    object_path = tmp_path / "object_cases.jsonl"
    physics_path = tmp_path / "physics_cases.jsonl"
    write_manifest(
        ScenarioManifest(
            (
                row(partition="test_id", factor=None, ordinal=0, seed=2),
                row(partition="test_id", factor=None, ordinal=1, seed=2),
                row(partition="test_id", factor=None, ordinal=2, seed=3),
            )
        ),
        reference_path,
    )
    write_manifest(
        ScenarioManifest(
            (
                row(partition="ood", factor="object", ordinal=0, seed=2),
                row(partition="ood", factor="object", ordinal=1, seed=3),
            )
        ),
        object_path,
    )
    write_manifest(
        ScenarioManifest((row(partition="ood", factor="physics", ordinal=0, seed=2),)),
        physics_path,
    )
    suite = SuiteSpec(
        "research_pairs",
        "v1",
        2,
        (
            SuiteMember(reference_path, ("grasp",)),
            SuiteMember(object_path, ("grasp",)),
            SuiteMember(physics_path, ("grasp",)),
        ),
        GROUP_FIELDS,
    )
    shards = tuple(
        _prepare_suite_jobs(suite, shard_index=index, shard_count=3)[0] for index in range(3)
    )
    assert tuple(
        tuple(
            (job.row.partition, job.row.factor, job.row.source_seed, job.repeat_index)
            for job in shard
        )
        for shard in shards
    ) == (
        (
            ("test_id", None, 2, 0),
            ("test_id", None, 2, 1),
            ("test_id", None, 2, 0),
            ("test_id", None, 2, 1),
            ("ood", "object", 2, 0),
            ("ood", "object", 2, 1),
            ("ood", "physics", 2, 0),
            ("ood", "physics", 2, 1),
        ),
        (
            ("test_id", None, 3, 0),
            ("test_id", None, 3, 1),
            ("ood", "object", 3, 0),
            ("ood", "object", 3, 1),
        ),
        (),
    )

    suite_path = tmp_path / "research_pairs.yaml"
    suite_path.write_text(
        """schema_version: 1
suite_id: research_pairs
protocol_version: v1
repeats: 2
members:
  - manifest: baseline.jsonl
    task_ids: [grasp]
  - manifest: object_cases.jsonl
    task_ids: [grasp]
  - manifest: physics_cases.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    calls: list[tuple[tuple[str, int], ...]] = []

    def observe_jobs(
        _policy: BenchmarkPolicy,
        selected: Sequence[_SuiteJob],
        *,
        wall_control_period_s: float | None,
        execution_translation_limit_m: float,
    ) -> tuple[_EvaluatedEpisode, ...]:
        assert execution_translation_limit_m == 0.05
        assert wall_control_period_s is None
        calls.append(tuple((job.row.scenario_id, job.repeat_index) for job in selected))
        return ()

    class NoRolloutPolicy:
        def reset(self) -> None:
            raise AssertionError("shard scheduling probe must not reset the policy")

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            raise AssertionError(f"shard scheduling probe must not act at tick {observation.tick}")

    monkeypatch.setattr(suite_module, "_evaluate_jobs", observe_jobs)
    policy = NoRolloutPolicy()
    for shard_index in range(3):
        evaluate(policy, suite_path, shard_index=shard_index, shard_count=3)
    assert calls == [
        tuple((job.row.scenario_id, job.repeat_index) for job in shards[0]),
        tuple((job.row.scenario_id, job.repeat_index) for job in shards[1]),
        (),
    ]
    flattened = tuple(identity for shard in calls for identity in shard)
    assert len(flattened) == len(set(flattened)) == 12


def test_standalone_ood_suite_loads_only_the_exact_test_id_reference_on_its_owner_shard(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manifest_dir = tmp_path / "manifests" / "v1"
    manifest_dir.mkdir(parents=True)
    ood_path = manifest_dir / "ood_object.jsonl"
    reference_path = manifest_dir / "test_id.jsonl"
    ood = ScenarioManifest(
        (
            ScenarioManifestRow(
                1,
                "v1",
                "v1:ood:object:grasp:000000",
                "grasp",
                "ood",
                "object",
                2,
                _proposal(2, partition="ood", factor="object"),
            ),
            ScenarioManifestRow(
                1,
                "v1",
                "v1:ood:object:grasp:000001",
                "grasp",
                "ood",
                "object",
                3,
                _proposal(2, partition="ood", factor="object"),
            ),
        )
    )
    reference = ScenarioManifest(
        (
            ScenarioManifestRow(
                1,
                "v1",
                "v1:test_id:grasp:000000",
                "grasp",
                "test_id",
                None,
                2,
                _proposal(2),
            ),
            ScenarioManifestRow(
                1,
                "v1",
                "v1:test_id:grasp:000001",
                "grasp",
                "test_id",
                None,
                3,
                _proposal(2),
            ),
        )
    )
    write_manifest(ood, ood_path)
    write_manifest(reference, reference_path)
    suite = SuiteSpec(
        "ood_object",
        "v1",
        1,
        (SuiteMember(ood_path, ("grasp",)),),
        GROUP_FIELDS,
    )
    jobs, manifests = _load_declared_jobs(suite)
    reference_jobs = _standalone_ood_reference_jobs(suite, manifests, jobs)
    assert tuple(job.row.scenario_id for job in jobs) == (
        "v1:ood:object:grasp:000000",
        "v1:ood:object:grasp:000001",
    )
    assert tuple(job.row.scenario_id for job in reference_jobs) == (
        "v1:test_id:grasp:000000",
        "v1:test_id:grasp:000001",
    )
    assert (
        _standalone_ood_reference_jobs(replace(suite, suite_id="research"), manifests, jobs) == ()
    )
    benchmark = SuiteSpec(
        "benchmark_v1",
        "v1",
        1,
        (
            SuiteMember(reference_path, ("grasp",)),
            SuiteMember(ood_path, ("grasp",)),
        ),
        GROUP_FIELDS,
    )
    assert _standalone_ood_reference_jobs(benchmark, (reference, ood), jobs) == ()
    nonprotocol_dir = tmp_path / "other" / "v1"
    nonprotocol_dir.mkdir(parents=True)
    nonprotocol_path = nonprotocol_dir / "ood_object.jsonl"
    write_manifest(ood, nonprotocol_path)
    nonprotocol_suite = replace(
        suite,
        members=(SuiteMember(nonprotocol_path, ("grasp",)),),
    )
    nonprotocol_jobs, nonprotocol_manifests = _load_declared_jobs(nonprotocol_suite)
    assert (
        _standalone_ood_reference_jobs(
            nonprotocol_suite,
            nonprotocol_manifests,
            nonprotocol_jobs,
        )
        == ()
    )
    missing_dir = tmp_path / "missing" / "manifests" / "v1"
    missing_dir.mkdir(parents=True)
    missing_ood_path = missing_dir / "ood_object.jsonl"
    write_manifest(ood, missing_ood_path)
    missing_suite = replace(
        suite,
        members=(SuiteMember(missing_ood_path, ("grasp",)),),
    )
    missing_jobs, missing_manifests = _load_declared_jobs(missing_suite)
    with pytest.raises(FileNotFoundError, match="test_id.jsonl"):
        _standalone_ood_reference_jobs(
            missing_suite,
            missing_manifests,
            missing_jobs,
        )

    suite_path = manifest_dir / "ood_object.yaml"
    suite_path.write_text(
        """schema_version: 1
suite_id: ood_object
protocol_version: v1
repeats: 1
members:
  - manifest: ood_object.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    calls: list[tuple[float | None, tuple[str, ...]]] = []

    def observe_jobs(
        _policy: BenchmarkPolicy,
        selected: Sequence[_SuiteJob],
        *,
        wall_control_period_s: float | None,
        execution_translation_limit_m: float,
    ) -> tuple[_EvaluatedEpisode, ...]:
        assert execution_translation_limit_m == 0.05
        calls.append((wall_control_period_s, tuple(job.row.scenario_id for job in selected)))
        return ()

    class NoRolloutPolicy:
        def reset(self) -> None:
            raise AssertionError("known-invalid Suite must not reset the policy")

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            raise AssertionError(f"known-invalid Suite must not act at tick {observation.tick}")

    policy = NoRolloutPolicy()
    monkeypatch.setattr(suite_module, "_evaluate_jobs", observe_jobs)
    missing_suite_path = missing_dir / "ood_object.yaml"
    missing_suite_path.write_text(
        """schema_version: 1
suite_id: ood_object
protocol_version: v1
repeats: 1
members:
  - manifest: ood_object.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    with pytest.raises(FileNotFoundError, match="test_id.jsonl"):
        evaluate(policy, missing_suite_path)
    assert calls == []

    evaluate(
        policy,
        suite_path,
        shard_index=0,
        shard_count=3,
        wall_control_period_s=0.1,
    )
    assert calls == [
        (0.1, ("v1:ood:object:grasp:000000",)),
        (0.1, ("v1:test_id:grasp:000000",)),
    ]
    calls.clear()
    evaluate(
        policy,
        suite_path,
        shard_index=1,
        shard_count=3,
        wall_control_period_s=0.1,
    )
    assert calls == [
        (0.1, ("v1:ood:object:grasp:000001",)),
        (0.1, ("v1:test_id:grasp:000001",)),
    ]
    calls.clear()
    evaluate(
        policy,
        suite_path,
        shard_index=2,
        shard_count=3,
        wall_control_period_s=0.1,
    )
    assert calls == [(0.1, ())]


def test_suite_known_manifest_errors_fail_before_any_rollout(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal(2)
    first_path = tmp_path / "first.jsonl"
    second_path = tmp_path / "second.jsonl"
    duplicate_row = ScenarioManifestRow(
        1,
        "v1",
        "v1:test_id:grasp:000000",
        "grasp",
        "test_id",
        None,
        2,
        scenario,
    )
    write_manifest(ScenarioManifest((duplicate_row,)), first_path)
    write_manifest(ScenarioManifest((duplicate_row,)), second_path)
    duplicate_suite = tmp_path / "duplicate.yaml"
    duplicate_suite.write_text(
        """schema_version: 1
suite_id: duplicate
protocol_version: v1
repeats: 1
members:
  - manifest: first.jsonl
    task_ids: [grasp]
  - manifest: second.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    calls = 0

    def reject_rollout(
        _policy: BenchmarkPolicy,
        _jobs: Sequence[_SuiteJob],
        *,
        wall_control_period_s: float | None,
        execution_translation_limit_m: float,
    ) -> tuple[_EvaluatedEpisode, ...]:
        assert execution_translation_limit_m == 0.05
        nonlocal calls
        assert wall_control_period_s is None
        calls += 1
        return ()

    class NoRolloutPolicy:
        def reset(self) -> None:
            raise AssertionError("known-invalid Suite must not reset the policy")

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            raise AssertionError(f"known-invalid Suite must not act at tick {observation.tick}")

    policy = NoRolloutPolicy()
    monkeypatch.setattr(suite_module, "_evaluate_jobs", reject_rollout)
    with pytest.raises(ValueError, match="duplicate declared scenario/repeat"):
        evaluate(policy, duplicate_suite)
    assert calls == 0

    ood_path = tmp_path / "research_ood.jsonl"
    write_manifest(
        ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    "v1:ood:object:grasp:000000",
                    "grasp",
                    "ood",
                    "object",
                    2,
                    _proposal(2, partition="ood", factor="object"),
                ),
            )
        ),
        ood_path,
    )
    missing_reference_suite = tmp_path / "research_missing_reference.yaml"
    missing_reference_suite.write_text(
        """schema_version: 1
suite_id: research_missing_reference
protocol_version: v1
repeats: 1
members:
  - manifest: research_ood.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="missing test-ID reference for known paired identity"):
        evaluate(policy, missing_reference_suite)
    assert calls == 0


def test_public_evaluate_runs_a_real_manifest_episode_and_builds_task_and_macro_groups(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal(2)
    manifest_dir = tmp_path / "manifests" / "v1"
    suite_dir = tmp_path / "configs" / "suites"
    manifest_dir.mkdir(parents=True)
    suite_dir.mkdir(parents=True)
    manifest_path = manifest_dir / "test_id.jsonl"
    write_manifest(
        ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    "v1:test_id:grasp:000000",
                    "grasp",
                    "test_id",
                    None,
                    2,
                    scenario,
                ),
            )
        ),
        manifest_path,
    )
    suite_path = suite_dir / "test_id.yaml"
    suite_path.write_text(
        """schema_version: 1
suite_id: test_id
protocol_version: v1
repeats: 1
members:
  - manifest: ../../manifests/v1/test_id.jsonl
    task_ids: [grasp]
report:
  group_by: [task_id, partition, factor, action_mode, action_representation, observation_profile]
""",
        encoding="utf-8",
    )

    class OraclePolicy:
        environment: GraspEnv | None = None
        oracle: _CaptureOracle | None = None
        reset_count = 0
        action_count = 0
        observation_times_s: list[float]

        def reset(self) -> None:
            assert self.environment is not None
            self.oracle = _CaptureOracle(self.environment)
            self.reset_count += 1
            self.observation_times_s = []

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert self.environment is not None and self.oracle is not None
            assert observation.tick == self.environment._episode_tick
            self.action_count += 1
            self.observation_times_s.append(observation.timestamp_s)
            return self.oracle.action(self.environment)

    policy = OraclePolicy()

    def fresh_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> GraspEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == "grasp" and compiled == scenario
        environment = make_env(task_id, compiled)
        assert isinstance(environment, GraspEnv)
        policy.environment = environment
        return environment

    monkeypatch.setattr(rollout_module, "make_env", fresh_environment)
    summary = evaluate(policy, suite_path)
    assert policy.reset_count == 1
    assert policy.action_count == summary.results[0].episode_steps
    assert len(summary.results) == 1 and summary.results[0].success
    assert tuple(group.key.task_id for group in summary.groups) == ("grasp", None)
    assert all(group.metrics.success_rate.mean == 1.0 for group in summary.groups)
    assert all(group.paired_test_id_difference is None for group in summary.groups)
    np.testing.assert_allclose(
        np.diff(policy.observation_times_s),
        0.05,
        rtol=0.0,
        atol=1e-10,
    )
    assert policy.observation_times_s[-1] <= summary.results[0].elapsed_s
    assert summary.results[0].elapsed_s <= policy.observation_times_s[-1] + 0.05


@pytest.mark.parametrize("seed,name", [(2, "e7_agentview"), (36, "j8_agentview")])
def test_public_generator_returns_only_a_real_oracle_accepted_reset(seed: int, name: str) -> None:
    assert generate_scenario(
        load_task("grasp"), RECIPE, seed, partition="test_id", recipe_name=name
    ) == _proposal(seed, name)


def test_public_generator_accepts_original_j8_timeout_regression() -> None:
    assert generate_scenario(
        load_task("grasp"), RECIPE, 0, partition="test_id", recipe_name="j8_agentview"
    ) == _proposal(0, "j8_agentview")


@pytest.mark.parametrize(
    "kind", ["joint_out_of_range", "target_collision_outside_support", "target_not_visible"]
)
def test_real_reset_validation_has_explicit_rejection_facts(kind: str) -> None:
    scenario = _proposal(0)
    if kind == "target_not_visible":
        view = replace(scenario.cameras.views[0], position_parent_m=(3.0, 0.0, 2.0))
        scenario = replace(scenario, cameras=replace(scenario.cameras, views=(view,)))
    environment = make_env("grasp", scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        if kind == "joint_out_of_range":
            joint_id = model.joint(environment.robots[0].robot_model.joints[0]).id
            data.qpos[model.jnt_qposadr[joint_id]] = model.jnt_range[joint_id, 1] + 0.1
            environment.sim.forward()
        elif kind == "target_collision_outside_support":
            pad = min(environment._left_pad_ids)
            address = environment._target_qpos_address
            data.qpos[address : address + 3] = data.geom_xpos[pad]
            environment.sim.forward()
        with pytest.raises(_CaptureProposalRejected) as rejected:
            _validate_capture_reset(environment)
        assert rejected.value.stage == "reset" and rejected.value.failure_code == kind
    finally:
        environment.close()


@pytest.mark.parametrize("bad_position", [float("nan"), 1e11])
def test_native_bad_qpos_reset_cannot_disguise_invalid_state(
    bad_position: float, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment = make_env("grasp", _proposal(0))
    try:
        environment.reset()
        action = _action(environment)
        monkeypatch.chdir(tmp_path)
        data = environment.sim.data._data
        data.qpos[environment._target_qpos_address] = bad_position
        _, reward, done, info = environment.step(action)
        assert done and reward == 0.0
        assert info["failure_code"] == "invalid_state" and not info["success"]
        # Nonfinite input is visible before physics; a finite oversized qpos first
        # raises MuJoCo's warning at the first completed physics boundary.
        expected_invalid_time = environment.model_timestep if math.isfinite(bad_position) else 0.0
        assert info["terminal_time_s"] == expected_invalid_time
        assert info["events"]["invalid_state"] == expected_invalid_time
        assert data.warning[mujoco.mjtWarning.mjWARN_BADQPOS].number > 0
        assert np.isfinite(data.qpos).all()  # MuJoCo's reset must not erase the failure fact.
        assert environment._episode_tick == 1
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


def test_moving_target_boundary_uses_db0_physics_geometry_sample(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal(2)
    target = scenario.object_states[0]
    before_exit_y = math.nextafter(0.39, -math.inf)
    target = replace(
        target,
        position_world_m=(target.position_world_m[0], before_exit_y, target.position_world_m[2]),
    )
    motion = scenario.motion[0]
    assert isinstance(motion.translation, HarmonicTranslation)
    center = motion.translation.center_world_m
    motion = replace(
        motion,
        translation=replace(
            motion.translation, center_world_m=(center[0], before_exit_y, center[2])
        ),
    )
    environment = make_env("grasp", replace(scenario, object_states=(target,), motion=(motion,)))
    try:
        environment.reset()
        address = environment._target_qpos_address
        previous_qpos = environment.sim.data.qpos[address : address + 3].copy()
        samples: list[tuple[float, np.ndarray, np.ndarray]] = []
        original = environment._capture.update

        def observe(**state: Any) -> None:
            data = environment.sim.data._data
            address = environment._target_qpos_address
            samples.append(
                (
                    float(data.time),
                    state["position"].copy(),
                    data.qpos[address : address + 3].copy(),
                )
            )
            original(**state)

        monkeypatch.setattr(environment._capture, "update", observe)
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "downstream_exit"
        assert len(samples) == 25
        assert not np.array_equal(samples[0][1], samples[0][2])
        for index, (time_s, position, qpos) in enumerate(samples, start=1):
            assert time_s == pytest.approx(index * 0.002, abs=1e-12)
            # DB0 samples body_xpos after mj_step, before another forward pass.
            np.testing.assert_array_equal(position, previous_qpos)
            previous_qpos = qpos
        crossings = [time_s for time_s, position, _ in samples if position[1] > 0.39]
        assert info["terminal_time_s"] == min(crossings)
        assert 0.0 < info["terminal_time_s"] < environment.sim.data.time
    finally:
        environment.close()


def _capture_sample(capture: _GraspCapture, **changes: Any) -> None:
    sample = {
        "time_s": (capture.physics_step + 1) * 0.002,
        "finite": True,
        "position": np.asarray([0.0, 0.0, 0.822]),
        "bottom_z_m": 0.8,
        "eef_distance_m": 0.01,
        "left": True,
        "right": True,
        "opposing": True,
    }
    sample.update(changes)
    capture.update(**sample)


def _capture() -> _GraspCapture:
    capture = _GraspCapture(
        load_task("grasp"), GraspGeometrySpec(0.8, ((-0.31, -0.40), (0.31, 0.40)), 0.39), 0.002
    )
    capture.begin(eef_distance_m=0.30)
    return capture


def test_capture_requires_explicit_scored_start_initialization() -> None:
    capture = _GraspCapture(
        load_task("grasp"), GraspGeometrySpec(0.8, ((-0.31, -0.40), (0.31, 0.40)), 0.39), 0.002
    )
    for invalid_distance in (math.nan, math.inf, math.nextafter(0.0, -math.inf)):
        with pytest.raises(ValueError, match="finite non-negative"):
            capture.begin(eef_distance_m=invalid_distance)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        _capture_sample(capture)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        capture.invalidate(0.0)
    capture.begin(eef_distance_m=0.30)
    assert capture.events == {"target_enters_observation_region": 0.0}
    capture.invalidate(0.002)
    assert capture.events == {"target_enters_observation_region": 0.0, "invalid_state": 0.002}
    capture.invalidate(0.004)
    assert capture.events["invalid_state"] == 0.002


def test_capture_counts_bilateral_contact_before_approach_like_db0() -> None:
    capture = _capture()
    outside_approach = math.nextafter(0.10, math.inf)
    for _ in range(3):
        _capture_sample(capture, eef_distance_m=outside_approach)
    assert "approach" not in capture.events
    assert "fingerpad_contact" not in capture.events
    assert capture.bilateral_steps == 3

    _capture_sample(capture, eef_distance_m=0.10)
    assert "approach" in capture.events and "fingerpad_contact" in capture.events
    assert capture.bilateral_steps == 4


def test_capture_requires_exact_consecutive_bilateral_contact_and_dwell_counts() -> None:
    capture = _capture()
    for _ in range(24):
        _capture_sample(capture)
    assert "bilateral_hold" not in capture.events
    _capture_sample(capture, right=False, opposing=False)
    assert capture.bilateral_steps == 0
    for _ in range(25):
        _capture_sample(capture)
    assert capture.events["bilateral_hold"] == pytest.approx(0.10)
    for _ in range(249):
        _capture_sample(capture, bottom_z_m=0.851)
    assert not capture.success and capture.stable_steps == 249
    _capture_sample(capture, left=False, bottom_z_m=0.851)
    assert capture.stable_steps == 0
    for _ in range(249):
        _capture_sample(capture, bottom_z_m=0.851)
    assert not capture.success
    _capture_sample(capture, bottom_z_m=0.851)
    assert capture.success and capture.stable_steps == 250
    assert capture.events["success"] == capture.events["stable_dwell"] == capture.terminal_time_s
    capture.reset()
    assert capture.physics_step == capture.stable_steps == capture.bilateral_steps == 0
    assert not capture.events and capture.terminal_time_s is None and not capture.success


def test_capture_stage_facts_use_current_distance_and_resettable_duration_counts() -> None:
    capture = _capture()
    capture.begin(eef_distance_m=0.40)
    _capture_sample(
        capture,
        eef_distance_m=0.20,
        left=False,
        right=False,
        opposing=False,
    )
    assert capture._stage_facts()[0] == ("approach", False, pytest.approx(0.5), 0)
    _capture_sample(
        capture,
        eef_distance_m=0.25,
        left=False,
        right=False,
        opposing=False,
    )
    assert capture._stage_facts()[0] == ("approach", False, pytest.approx(0.25), 0)
    _capture_sample(
        capture,
        eef_distance_m=0.10,
        left=True,
        right=False,
        opposing=False,
    )
    for _ in range(12):
        _capture_sample(capture)
    assert capture._stage_facts()[2] == (
        "bilateral_hold",
        False,
        pytest.approx(12 / 25),
        12,
    )
    _capture_sample(capture, right=False, opposing=False)
    assert capture._stage_facts()[2] == ("bilateral_hold", False, 0.0, 0)
    for _ in range(25):
        _capture_sample(capture)
    _capture_sample(capture, bottom_z_m=0.825)
    assert capture._stage_facts()[3] == ("clearance", False, pytest.approx(0.5), 0)
    _capture_sample(capture, bottom_z_m=0.81)
    assert capture._stage_facts()[3] == ("clearance", False, pytest.approx(0.2), 0)
    _capture_sample(capture, right=False, bottom_z_m=0.825)
    assert not capture.post_hold_contact_valid
    assert capture._stage_facts()[3] == ("clearance", False, 0.0, 0)
    for _ in range(24):
        _capture_sample(capture, bottom_z_m=0.825)
    assert capture._stage_facts()[3] == ("clearance", False, 0.0, 0)
    _capture_sample(capture, bottom_z_m=0.825)
    assert capture.post_hold_contact_valid
    assert capture._stage_facts()[3] == ("clearance", False, pytest.approx(0.5), 0)
    minimum_clearance_bottom = (
        capture.geometry.support_surface_z_m + capture.success_spec.minimum_lift_or_clearance_m
    )
    _capture_sample(capture, bottom_z_m=minimum_clearance_bottom)
    assert capture._stage_facts()[4] == (
        "stable_dwell",
        False,
        pytest.approx(1 / 250),
        1,
    )
    _capture_sample(capture, bottom_z_m=0.849)
    assert capture._stage_facts()[4] == ("stable_dwell", False, 0.0, 0)


def test_capture_progress_stays_zero_until_first_physics_sample() -> None:
    capture = _capture()
    capture.begin(eef_distance_m=0.20)
    assert capture._stage_facts()[0] == ("approach", False, 0.0, 0)
    _capture_sample(capture, eef_distance_m=0.20, left=False, right=False)
    assert capture._stage_facts()[0] == ("approach", False, pytest.approx(0.5), 0)


def test_capture_valid_failure_uses_terminal_sample_progress_without_new_stage_events() -> None:
    capture = _capture()
    _capture_sample(capture, eef_distance_m=0.20, left=False, right=False)
    _capture_sample(
        capture,
        eef_distance_m=0.25,
        left=False,
        right=False,
        position=np.asarray([0.32, 0.0, 0.822]),
    )
    assert capture.failure_code == "workspace_exit"
    assert capture.events == {"target_enters_observation_region": 0.0, "workspace_exit": 0.004}
    assert capture._stage_facts()[0] == ("approach", False, pytest.approx(0.25), 0)
    capture = _capture()
    _capture_sample(capture, eef_distance_m=0.10, left=False, right=False)
    _capture_sample(capture, position=np.asarray([0.32, 0.0, 0.822]))
    assert capture.failure_code == "workspace_exit"
    assert set(capture.events) == {"target_enters_observation_region", "approach", "workspace_exit"}
    assert capture._stage_facts()[1] == ("fingerpad_contact", False, pytest.approx(1.0), 0)


def test_private_stage_fact_mechanics_reject_invalid_state_machine_values() -> None:
    assert _distance_stage_progress(0.30, 0.20, 0.10, completed=False) == pytest.approx(0.5)
    assert _duration_stage_progress(12, 25, completed=False) == pytest.approx(12 / 25)
    with pytest.raises(RuntimeError, match="finite"):
        _distance_stage_progress(math.nan, math.nan, 0.10, completed=False)
    with pytest.raises(RuntimeError, match="non-negative integer"):
        _duration_stage_progress(-1, 25, completed=False)
    with pytest.raises(RuntimeError, match="incomplete prerequisite"):
        _ordered_stage_facts((("approach", False, 0.5, 0), ("fingerpad_contact", True, 1.0, 0)))


@pytest.mark.parametrize(
    ("failure", "changes"),
    [
        ("invalid_state", {"finite": False, "position": np.asarray([0.32, 0.0, 0.7])}),
        ("invalid_state", {"eef_distance_m": math.nan}),
        ("invalid_state", {"eef_distance_m": math.inf}),
        ("workspace_exit", {"position": np.asarray([0.32, 0.0, 0.7]), "bottom_z_m": 0.7}),
        ("drop", {"position": np.asarray([0.0, 0.39, 0.7]), "bottom_z_m": 0.7}),
        ("downstream_exit", {"position": np.asarray([0.0, 0.40, 0.7]), "bottom_z_m": 0.7}),
    ],
)
def test_failure_priority_beats_same_physics_step_success(
    failure: str, changes: dict[str, Any]
) -> None:
    capture = _capture()
    for _ in range(25):
        _capture_sample(capture)
    for _ in range(249):
        _capture_sample(capture, bottom_z_m=0.851)
    before = capture._stage_facts()
    state = {"bottom_z_m": 0.851, **changes}
    _capture_sample(capture, **state)
    assert capture.failure_code == failure and not capture.success
    assert capture.events[failure] == capture.terminal_time_s
    assert "success" not in capture.events
    assert "stable_dwell" not in capture.events
    assert capture._stage_facts() == before
    terminal_time = capture.terminal_time_s
    _capture_sample(capture, bottom_z_m=0.851)
    assert capture.terminal_time_s == terminal_time


def test_db0_capture_accepts_x_boundary_and_has_no_upstream_y_failure() -> None:
    for x in (-0.31, 0.31):
        capture = _capture()
        _capture_sample(capture, position=np.asarray([x, -0.41, 0.822]), opposing=False)
        assert capture.failure_code is None
        assert capture.bilateral_steps == 1
    for x in (math.nextafter(-0.31, -math.inf), math.nextafter(0.31, math.inf)):
        capture = _capture()
        _capture_sample(capture, position=np.asarray([x, 0.0, 0.822]))
        assert capture.failure_code == "workspace_exit"


def test_db0_capture_success_on_exact_horizon_precedes_timeout() -> None:
    capture = _capture()
    for index in range(1, 4000):
        _capture_sample(capture, bottom_z_m=0.851 if index >= 3751 else 0.8)
    assert capture.stable_steps == 249 and not capture.success
    _capture_sample(capture, bottom_z_m=0.851)
    assert capture.failure_code is None and capture.terminal_time_s == 8.0
    assert capture.success
    assert capture.events["success"] == capture.events["stable_dwell"] == 8.0
    assert "timeout" not in capture.events


def test_db0_capture_timeout_preserves_final_physics_step_events() -> None:
    capture = _capture()
    for _ in range(3999):
        _capture_sample(capture, eef_distance_m=0.20, left=False, right=False)
    _capture_sample(capture, eef_distance_m=0.10, left=True, right=False)
    assert capture.failure_code == "timeout" and capture.terminal_time_s == 8.0
    assert capture.events == {
        "target_enters_observation_region": 0.0,
        "approach": 8.0,
        "fingerpad_contact": 8.0,
        "timeout": 8.0,
    }
    assert not capture.success


def test_real_export_manifest_round_trip_and_fixed_action_replay(tmp_path: Path) -> None:
    declared_delay_steps = 1
    scenario = replace(
        _proposal(2, "j8_agentview", partition="ood", factor="action_delay"),
        action_delay_steps=declared_delay_steps,
    )
    assert scenario.action_delay_steps == declared_delay_steps
    first = make_env("grasp", scenario)
    second = None
    try:
        raw_first = first.reset()
        exported = first.export_scenario()
        path = tmp_path / "ood_action_delay.jsonl"
        manifest = ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    "v1:ood:action_delay:grasp:000000",
                    "grasp",
                    "ood",
                    "action_delay",
                    2,
                    exported,
                ),
            )
        )
        write_manifest(manifest, path)
        loaded = load_manifest(path)
        assert loaded == manifest
        second = make_env("grasp", loaded.rows[0].scenario)
        raw_second = second.reset()
        assert second.export_scenario() == exported
        first_model, second_model = first.sim.model._model, second.sim.model._model
        for name in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "jnt_range",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_pos",
            "light_dir",
            "light_ambient",
            "light_diffuse",
            "light_specular",
            "light_attenuation",
            "light_cutoff",
            "light_active",
        ):
            np.testing.assert_array_equal(getattr(first_model, name), getattr(second_model, name))
        for tick in range(9):
            for name in ("qpos", "qvel", "ctrl", "xpos", "xmat"):
                np.testing.assert_array_equal(
                    getattr(first.sim.data, name), getattr(second.sim.data, name)
                )
            assert (
                first.sim.data.time == second.sim.data.time == pytest.approx(tick / 20.0, abs=1e-12)
            )
            one, two = (
                first._benchmark_observation(raw_first),
                second._benchmark_observation(raw_second),
            )
            for field in fields(one):
                if field.name != "rgb":
                    np.testing.assert_array_equal(
                        getattr(one, field.name),
                        getattr(two, field.name),
                        strict=True,
                        err_msg=field.name,
                    )
            _assert_replay_rgb(two.rgb, one.rgb, probe=f"grasp_fixed_action_tick_{tick}")
            if tick < 8:
                action = _action(first, displacement=0.002 if tick % 2 else -0.001)
                raw_first, reward_one, done_one, info_one = first.step(action)
                raw_second, reward_two, done_two, info_two = second.step(action)
                assert (reward_one, done_one, info_one) == (reward_two, done_two, info_two)
    finally:
        if second is not None:
            second.close()
        first.close()
