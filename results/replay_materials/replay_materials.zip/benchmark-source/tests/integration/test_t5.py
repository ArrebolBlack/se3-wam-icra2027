from __future__ import annotations

import ast
import inspect
import math
from collections.abc import Mapping
from dataclasses import fields, replace
from functools import lru_cache
from pathlib import Path
from typing import Any, cast

import mujoco
import numpy as np
import pytest

import se3_wam_benchmark.scenarios._feasibility as scenario_feasibility
from se3_wam_benchmark.control.action import BenchmarkAction, _so3_log
from se3_wam_benchmark.data.recorder import _read_episode_file
from se3_wam_benchmark.data.schema import _episode_id
from se3_wam_benchmark.envs.base import _load_asset_catalog
from se3_wam_benchmark.envs.components.events import _StrikerPulseSnapshot
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.replanning import ReplanningEnv, _ReplanningOutcome
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.result import failure_class_for
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios._feasibility import (
    _opposite_replanning_branch,
    _validate_replanning_reset,
)
from se3_wam_benchmark.scenarios._native_oracle import _ReplanningOracle, _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_replanning_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import JointPhysicsSpec, ScenarioSpec, StrikerPulseEffectSpec
from se3_wam_benchmark.sensing.observation import (
    BenchmarkObservation,
    _quaternion_xyzw_to_matrix,
)
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
RECIPE = ROOT / "configs/scenarios/t5_replan.yaml"


@lru_cache(maxsize=1)
def _document() -> Any:
    return load_yaml_strict(RECIPE)


def _proposal(
    seed: int = 0,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task("t5_replan")
    recipe = _select_recipe(_document(), partition=partition, factor=factor, recipe_name=name)
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_replanning_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
        id_recipe=_select_recipe(_document(), partition="test_id", factor=None, recipe_name=name),
    )
    return scenario


def test_t5_applies_optional_target_joint_physics_with_required_striker_joints() -> None:
    baseline = _proposal()
    native_environment = make_env("t5_replan", baseline)
    try:
        assert isinstance(native_environment, ReplanningEnv)
        native_environment.reset()
        address = native_environment._target_qvel_address
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_damping[address : address + 6],
            np.zeros(6),
        )
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_frictionloss[address : address + 6],
            np.zeros(6),
        )
    finally:
        native_environment.close()
    target_id = baseline.object_states[0].instance_id
    target_joint = JointPhysicsSpec(
        target_id,
        f"{target_id}_joint0",
        tuple((index + 1) * 1e-6 for index in range(6)),
        tuple((index + 1) * 1e-7 for index in range(6)),
    )
    scenario = replace(
        baseline,
        physics=replace(baseline.physics, joints=(*baseline.physics.joints, target_joint)),
    )
    environment = make_env("t5_replan", scenario)
    try:
        assert isinstance(environment, ReplanningEnv)
        expected_addresses = {
            "left_slide": environment._joint_qvel_addresses["left"],
            "right_slide": environment._joint_qvel_addresses["right"],
            f"{target_id}_joint0": environment._target_qvel_address,
        }
        for _ in range(2):
            environment.reset()
            assert {
                binding.spec.joint_name: binding.dof_address
                for binding in environment._compiled_joint_physics
            } == expected_addresses
            for binding in environment._compiled_joint_physics:
                stop = binding.dof_address + binding.dof_count
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_damping[binding.dof_address : stop],
                    binding.spec.damping_per_dof,
                )
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_frictionloss[binding.dof_address : stop],
                    binding.spec.friction_loss_per_dof,
                )
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _action(
    environment: ReplanningEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = -1.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    values = np.ascontiguousarray(np.concatenate((motion, (gripper,))), dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _state(environment: ReplanningEnv) -> dict[str, Any]:
    data = environment.sim.data._data
    return {
        "time": float(data.time),
        **{
            name: np.asarray(getattr(data, name)).copy()
            for name in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            )
        },
    }


def _assert_state_equal(first: Mapping[str, Any], second: Mapping[str, Any]) -> None:
    assert first.keys() == second.keys()
    for name in first:
        np.testing.assert_array_equal(first[name], second[name], err_msg=name)


def _assert_observation(observation: BenchmarkObservation, *, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.rgb.dtype == np.uint8 and not observation.rgb.flags.writeable
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.depth_m.dtype == np.float32 and not observation.depth_m.flags.writeable
    assert np.isfinite(observation.depth_m).all() and np.all(observation.depth_m > 0.0)
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    assert observation.T_robot_base_from_world.shape == (4, 4)
    assert not observation.camera_intrinsics.flags.writeable
    assert not observation.world_from_camera_cv.flags.writeable
    assert not observation.T_robot_base_from_world.flags.writeable
    assert observation.eef_position.shape == (3,)
    assert observation.eef_quaternion_xyzw.shape == (4,)
    assert observation.joint_position.shape == (7,)
    assert all(
        np.isfinite(value).all()
        for value in (
            observation.eef_position,
            observation.eef_quaternion_xyzw,
            observation.joint_position,
        )
    )


def _snapshot(
    *,
    count: int = 1,
    active: bool = True,
    separation_s: float = 0.0,
    trapped: bool = False,
    trigger_s: float = 0.002,
) -> _StrikerPulseSnapshot:
    return _StrikerPulseSnapshot(
        "selected_strike",
        trigger_s,
        False,
        count,
        active,
        0.002,
        separation_s,
        trapped,
    )


def _outcome(*, branch: str = "left") -> _ReplanningOutcome:
    scenario = _proposal()
    effect = scenario.events[0].effect
    assert isinstance(effect, StrikerPulseEffectSpec)
    return _ReplanningOutcome(
        load_task("t5_replan"), scenario.geometry, effect, selected_branch=branch
    )


def _outcome_sample(outcome: _ReplanningOutcome, **changes: Any) -> None:
    sample: dict[str, Any] = {
        "time_s": (outcome.physics_step + 1) * 0.002,
        "finite": True,
        "position": np.asarray((0.0, 0.0, 0.812), dtype=np.float64),
        "bottom_z_m": 0.8,
        "twist_world": np.zeros(6, dtype=np.float64),
        "eef_distance_m": 0.20,
        "event_fired": False,
        "striker_state": None,
        "selected_contact": False,
        "nonselected_contact": False,
        "robot_target_contact": False,
        "unsafe_contact": False,
        "left": False,
        "right": False,
        "opposing": False,
        "grasp_axis_error_rad": 0.0,
    }
    sample.update(changes)
    snapshot = sample["striker_state"]
    if snapshot is not None and "selected_contact" not in changes:
        sample["selected_contact"] = snapshot.impact_active and snapshot.separation_duration_s == 0
    outcome.update(**sample)


def test_t5_failure_frame_freezes_the_last_preterminal_stage_facts() -> None:
    outcome = _outcome(branch="left")
    outgoing = np.asarray((0.0, 0.0, 0.5, 0.10, 0.0, 0.0), dtype=np.float64)
    _outcome_sample(
        outcome,
        event_fired=True,
        striker_state=_snapshot(active=True),
        eef_distance_m=0.30,
    )
    _outcome_sample(
        outcome,
        event_fired=True,
        striker_state=_snapshot(active=False),
        twist_world=outgoing,
        eef_distance_m=0.30,
    )
    while outcome.outgoing_validation_time_s is None:
        assert outcome.terminal_time_s is None, outcome.failure_code
        _outcome_sample(
            outcome,
            event_fired=True,
            striker_state=_snapshot(active=False),
            twist_world=outgoing,
            eef_distance_m=0.30,
        )
    _outcome_sample(
        outcome,
        event_fired=True,
        striker_state=_snapshot(active=False),
        twist_world=outgoing,
        eef_distance_m=0.20,
    )
    before_failure = outcome._stage_facts()
    assert before_failure[0] == ("valid_selected_impact", True, 1.0, 0)
    assert before_failure[1] == ("approach", False, pytest.approx(0.5), 0)
    _outcome_sample(
        outcome,
        event_fired=True,
        striker_state=_snapshot(active=False),
        twist_world=outgoing,
        eef_distance_m=0.10,
        unsafe_contact=True,
    )
    assert outcome.failure_code == "unsafe_contact"
    assert outcome._stage_facts() == before_failure


@pytest.mark.parametrize(
    ("name", "views", "action_dim"),
    [
        ("e7_agentview", 1, 7),
        ("e7_agentview_wrist", 2, 7),
        ("j8_agentview", 1, 8),
        ("j8_agentview_wrist", 2, 8),
    ],
)
def test_t5_native_reset_exports_compiled_two_striker_scene_and_policy_observation(
    name: str, views: int, action_dim: int
) -> None:
    scenario = _proposal(name=name)
    environment = cast(ReplanningEnv, make_env("t5_replan", scenario))
    try:
        raw = environment.reset()
        assert environment.export_scenario() == scenario
        assert environment.action_dim == action_dim
        observed = environment._benchmark_observation(raw)
        _assert_observation(observed, tick=0, views=views)
        assert not hasattr(observed, "events") and not hasattr(observed, "selected_branch")
        model, data = environment.sim.model._model, environment.sim.data._data
        assert model.flg_surfacevel
        np.testing.assert_allclose(
            data.geom_xmat[environment._belt_geom_id].reshape(3, 3)
            @ model.geom_surfacevel[environment._belt_geom_id, :3],
            scenario.motion[0].translation.velocity_world_m_s,
            rtol=0.0,
            atol=1e-12,
        )
        assert set(environment._joint_ids) == {"left", "right"}
        assert all(
            data.qpos[address] == 0.0 for address in environment._joint_qpos_addresses.values()
        )
        assert all(
            data.qfrc_applied[index] == 0.0 for index in environment._joint_qvel_addresses.values()
        )
        assert not environment._event_fired and environment._last_striker_state is None
        _validate_replanning_reset(environment)
        _, _, done, info = environment.step(_action(environment))
        assert not done
        assert tuple(item[0] for item in info["stage_facts"]) == (
            "valid_selected_impact",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
        )
        assert info["stage_facts"][0][1:3] == (False, 0.0)
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("changes", "failure"),
    [
        ({"finite": False, "unsafe_contact": True}, "invalid_state"),
        ({"unsafe_contact": True}, "unsafe_contact"),
        ({"nonselected_contact": True}, "wrong_striker_contact"),
        ({"robot_target_contact": True}, "early_robot_contact"),
        (
            {"position": np.asarray((math.nextafter(0.270, math.inf), 0.0, 0.812))},
            "workspace_exit",
        ),
        (
            {"position": np.asarray((0.0, math.nextafter(-0.350, -math.inf), 0.812))},
            "workspace_exit",
        ),
        (
            {"position": np.asarray((0.0, math.nextafter(0.340, math.inf), 0.812))},
            "downstream_exit",
        ),
        ({"position": np.asarray((0.0, 0.0, math.nextafter(0.760, -math.inf)))}, "drop"),
    ],
)
def test_t5_outcome_immediate_failure_priority_and_exact_boundaries(
    changes: dict[str, Any], failure: str
) -> None:
    outcome = _outcome()
    _outcome_sample(outcome, **changes)
    assert outcome.failure_code == failure
    assert not outcome.success and outcome.terminal_time_s == 0.002


@pytest.mark.parametrize(
    ("changes", "failure"),
    [
        (
            {
                "unsafe_contact": True,
                "nonselected_contact": True,
                "striker_state": _snapshot(count=2, trapped=True),
            },
            "unsafe_contact",
        ),
        (
            {
                "robot_target_contact": True,
                "nonselected_contact": True,
                "striker_state": _snapshot(count=2, trapped=True),
            },
            "early_robot_contact",
        ),
        (
            {
                "nonselected_contact": True,
                "striker_state": _snapshot(count=2, trapped=True),
            },
            "wrong_striker_contact",
        ),
    ],
)
def test_t5_safety_failures_precede_wrong_and_extra_impact(
    changes: dict[str, Any], failure: str
) -> None:
    outcome = _outcome()
    _outcome_sample(outcome, **changes)
    assert outcome.failure_code == failure
    assert failure_class_for(failure) == (
        "task_violation" if failure == "wrong_striker_contact" else "safety"
    )


def _finish_impact(outcome: _ReplanningOutcome, *, outgoing: np.ndarray) -> None:
    _outcome_sample(
        outcome,
        event_fired=True,
        striker_state=_snapshot(),
        selected_contact=True,
        twist_world=np.asarray((0.0, 0.0, 0.1, 0.0, 0.13, 0.0)),
    )
    for separation_step in range(1, 6):
        _outcome_sample(
            outcome,
            striker_state=_snapshot(active=True, separation_s=separation_step * 0.002),
        )
    _outcome_sample(outcome, striker_state=_snapshot(active=False, separation_s=0.012))
    while (outcome.physics_step + 1) * 0.002 < 0.032:
        assert outcome.terminal_time_s is None, outcome.failure_code
        _outcome_sample(outcome, striker_state=_snapshot(active=False))
    _outcome_sample(outcome, striker_state=_snapshot(active=False), twist_world=outgoing)


def test_t5_impact_groups_and_trapping_follow_physical_contact_history() -> None:
    trapped = _outcome()
    for _ in range(50):
        _outcome_sample(trapped, selected_contact=True)
    assert trapped.failure_code is None
    _outcome_sample(trapped, selected_contact=True)
    assert trapped.failure_code == "striker_trap"

    repeated = _outcome()
    _outcome_sample(repeated, selected_contact=True)
    for _ in range(5):
        _outcome_sample(repeated)
    assert repeated.impact_end_time_s is None
    _outcome_sample(repeated)
    assert repeated.impact_end_time_s == pytest.approx(0.002, abs=1e-12)
    _outcome_sample(repeated, selected_contact=True)
    assert repeated.failure_code == "extra_impact"


def test_t5_bilateral_duration_records_physical_contact_before_approach() -> None:
    outcome = _outcome()
    outgoing = np.asarray((0.0, 0.0, 0.35, 0.035, 0.13, 0.0))
    _finish_impact(outcome, outgoing=outgoing)
    outside_approach = {
        "striker_state": _snapshot(active=False),
        "twist_world": outgoing,
        "left": True,
        "right": True,
        "opposing": True,
        "grasp_axis_error_rad": 0.0,
        "eef_distance_m": math.nextafter(0.10, math.inf),
    }
    for _ in range(3):
        _outcome_sample(outcome, **outside_approach)
    assert "approach" not in outcome.events
    assert "fingerpad_contact" not in outcome.events
    assert outcome.bilateral_steps == 3

    _outcome_sample(outcome, **{**outside_approach, "eef_distance_m": 0.10})
    assert "approach" in outcome.events and "fingerpad_contact" in outcome.events
    assert outcome.bilateral_steps == 4


def test_t5_outgoing_validation_uses_physics_steps_across_clock_roundoff() -> None:
    outcome = _outcome()
    time_s = 0.0
    for _ in range(985):
        time_s += 0.002
        _outcome_sample(outcome, time_s=time_s)
    time_s += 0.002
    _outcome_sample(outcome, time_s=time_s, selected_contact=True)
    outgoing = np.asarray((0.0, 0.0, 0.35, 0.035, 0.13, 0.0))
    for _ in range(14):
        time_s += 0.002
        _outcome_sample(outcome, time_s=time_s, twist_world=outgoing)
        assert outcome.outgoing_validation_time_s is None
    time_s += 0.002
    _outcome_sample(outcome, time_s=time_s, twist_world=outgoing)
    assert outcome.failure_code is None
    assert outcome.physics_step == 1001
    assert outcome.outgoing_validation_time_s == time_s


def test_t5_outcome_impact_validation_counters_and_success_boundaries() -> None:
    outcome = _outcome()
    exact_outgoing = np.asarray((0.0, 0.0, 0.35, 0.035, 0.13, 0.0))
    _finish_impact(outcome, outgoing=exact_outgoing)
    assert outcome.outgoing_validation_time_s == 0.032
    assert outcome.failure_code is None
    assert outcome.events["valid_selected_impact"] == 0.032

    oriented = {
        "striker_state": _snapshot(active=False),
        "twist_world": exact_outgoing,
        "left": True,
        "right": True,
        "opposing": True,
        "grasp_axis_error_rad": math.radians(18.0),
        "eef_distance_m": 0.10,
    }
    for _ in range(outcome.hold_steps - 1):
        _outcome_sample(outcome, **oriented)
    assert "bilateral_hold" not in outcome.events
    _outcome_sample(
        outcome,
        **{
            **oriented,
            "grasp_axis_error_rad": math.nextafter(math.radians(18.0), math.inf),
        },
    )
    assert outcome.bilateral_steps == 0
    for _ in range(outcome.hold_steps - 1):
        _outcome_sample(outcome, **oriented)
    _outcome_sample(outcome, **{**oriented, "opposing": False})
    assert outcome.bilateral_steps == outcome.hold_steps
    assert "bilateral_hold" in outcome.events

    minimum_height = (
        outcome._capture_reference_z_m + outcome.success_spec.minimum_lift_or_clearance_m
    )
    lifted = {**oriented, "position": np.asarray((0.0, 0.0, minimum_height))}
    for _ in range(outcome.dwell_steps - 1):
        _outcome_sample(outcome, **lifted)
    assert not outcome.success
    _outcome_sample(
        outcome,
        **{**lifted, "position": np.asarray((0.0, 0.0, math.nextafter(minimum_height, -math.inf)))},
    )
    assert outcome.stable_steps == 0
    for _ in range(outcome.dwell_steps):
        _outcome_sample(outcome, **lifted)
    assert outcome.success and outcome.failure_code is None
    assert outcome.events["stable_dwell"] == outcome.terminal_time_s


def test_t5_outcome_no_impact_outgoing_timeout_and_failure_before_success() -> None:
    no_impact = _outcome()
    for _ in range(round(no_impact.horizon_s / no_impact.timestep_s)):
        _outcome_sample(
            no_impact,
            event_fired=True,
            striker_state=_snapshot(count=0, active=False),
        )
        if no_impact.terminal_time_s is not None:
            break
    assert no_impact.failure_code == "no_selected_impact"
    assert failure_class_for(no_impact.failure_code) == "task_violation"
    assert no_impact.terminal_time_s == pytest.approx(no_impact.horizon_s, abs=1e-12)

    weak = _outcome()
    _finish_impact(weak, outgoing=np.zeros(6, dtype=np.float64))
    assert weak.failure_code == "insufficient_outgoing_change"
    assert weak.terminal_time_s == pytest.approx(0.032, abs=1e-12)

    timeout = _outcome()
    _finish_impact(timeout, outgoing=np.asarray((0.0, 0.0, 0.35, 0.035, 0.13, 0.0)))
    timeout.physics_step = 2999
    _outcome_sample(timeout)
    assert timeout.failure_code == "timeout" and timeout.terminal_time_s == 6.0

    priority = _outcome()
    priority._maximum_impact_group_count = 1
    priority.impact_end_time_s = 0.0
    priority.outgoing_validation_time_s = 0.0
    priority.events["valid_selected_impact"] = 0.0
    priority.events["approach"] = 0.0
    priority.events["fingerpad_contact"] = 0.0
    priority.events["bilateral_hold"] = 0.0
    priority.events["clearance"] = 0.0
    priority.stable_steps = priority.dwell_steps - 1
    _outcome_sample(
        priority,
        unsafe_contact=True,
        left=True,
        right=True,
        opposing=True,
        bottom_z_m=0.85,
    )
    assert priority.failure_code == "unsafe_contact" and not priority.success


@pytest.mark.parametrize(
    ("branch", "exact_lateral", "exact_yaw"),
    [("left", 0.035, 0.35), ("right", -0.035, -0.35)],
)
def test_t5_outgoing_thresholds_are_signed_and_inclusive(
    branch: str, exact_lateral: float, exact_yaw: float
) -> None:
    exact = _outcome(branch=branch)
    _finish_impact(
        exact,
        outgoing=np.asarray((0.0, 0.0, exact_yaw, exact_lateral, 0.13, 0.0)),
    )
    assert exact.failure_code is None and exact.outgoing_validation_time_s == 0.032

    below = _outcome(branch=branch)
    below_lateral = math.nextafter(exact_lateral, 0.0)
    _finish_impact(
        below,
        outgoing=np.asarray((0.0, 0.0, exact_yaw, below_lateral, 0.13, 0.0)),
    )
    assert below.failure_code == "insufficient_outgoing_change"


@pytest.mark.parametrize(
    "position",
    [
        (0.270, 0.0, 0.812),
        (-0.270, 0.0, 0.812),
        (0.0, -0.350, 0.812),
        (0.0, 0.340, 0.812),
        (0.0, 0.0, 0.760),
    ],
)
def test_t5_workspace_downstream_and_drop_boundaries_are_inclusive(
    position: tuple[float, float, float],
) -> None:
    outcome = _outcome()
    _outcome_sample(outcome, position=np.asarray(position, dtype=np.float64))
    assert outcome.failure_code is None and outcome.terminal_time_s is None


@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_public_t5_generator_preserves_native_branch_acceptance(
    name: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured: dict[str, dict[str, Any]] = {}
    native_oracle = scenario_feasibility._run_native_oracle

    def observe_oracle(environment: ReplanningEnv) -> dict[str, Any]:
        samples: list[dict[str, Any]] = []
        native_update = environment._outcome.update

        def observe_update(**sample: Any) -> None:
            native_update(**sample)
            samples.append(
                {
                    "time_s": sample["time_s"],
                    "selected": sample["selected_contact"],
                    "nonselected": sample["nonselected_contact"],
                    "robot": sample["robot_target_contact"],
                    "left": sample["left"],
                    "right": sample["right"],
                    "opposing": sample["opposing"],
                    "axis_error": sample["grasp_axis_error_rad"],
                    "impact_count": environment._outcome._maximum_impact_group_count,
                    "bilateral_steps": environment._outcome.bilateral_steps,
                    "stable_steps": environment._outcome.stable_steps,
                }
            )

        environment._outcome.update = observe_update
        reset_qpos = environment.sim.data.qpos.copy()
        reset_qvel = environment.sim.data.qvel.copy()
        result = native_oracle(environment)
        captured[environment._selected_branch] = {
            "result": result,
            "samples": samples,
            "reset_qpos": reset_qpos,
            "reset_qvel": reset_qvel,
            "tick": environment.timestep,
            "physics_step": environment._outcome.physics_step,
            "pending": tuple(environment._action_delay_queue._pending),
        }
        return result

    monkeypatch.setattr(scenario_feasibility, "_run_native_oracle", observe_oracle)
    if name == "e7_agentview":
        # The fixed old planner also exits the workspace on seed-zero's left branch.
        with pytest.raises(_CaptureProposalRejected) as caught:
            generate_scenario(
                load_task("t5_replan"), RECIPE, 0, partition="test_id", recipe_name=name
            )
        assert caught.value.stage == "oracle"
        assert caught.value.failure_code == "workspace_exit"
        assert caught.value.terminal_time_s == pytest.approx(2091 * 0.002, abs=1e-12)
        assert caught.value.__notes__ == ["selected branch: left; counterfactual index: 0"]
        assert set(captured) == {"left"}
        assert captured["left"]["physics_step"] == 2091
        assert captured["left"]["pending"] == ()
        assert not captured["left"]["result"]["success"]
        return
    generated = generate_scenario(
        load_task("t5_replan"), RECIPE, 0, partition="test_id", recipe_name=name
    )
    assert generated == _proposal(name=name)
    assert set(captured) == {"left", "right"}
    np.testing.assert_array_equal(captured["left"]["reset_qpos"], captured["right"]["reset_qpos"])
    np.testing.assert_array_equal(captured["left"]["reset_qvel"], captured["right"]["reset_qvel"])

    outgoing: dict[str, tuple[float, ...]] = {}
    for branch, evidence in captured.items():
        result = evidence["result"]
        samples = evidence["samples"]
        assert result["success"] is True and result["failure_code"] is None
        assert result["impact_group_count"] == 1
        assert result["terminal_time_s"] <= 6.0
        assert evidence["tick"] <= 120 and evidence["physics_step"] <= evidence["tick"] * 25
        assert evidence["pending"] == ()
        assert list(result["events"]) == [
            "keyed_puck_enters_observation_lane",
            "side_strike_triggered",
            "striker_impact_onset",
            "striker_impact_end",
            "postevent_state_validated",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "verified_rigid_grasp_engaged",
            "clearance",
            "stable_dwell",
            "success",
        ]
        assert tuple(item[0] for item in result["stage_facts"]) == (
            "valid_selected_impact",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
        )
        assert all(item[1] and item[2] == 1.0 for item in result["stage_facts"])
        robot_samples = [sample for sample in samples if sample["robot"]]
        assert robot_samples
        assert robot_samples[0]["impact_count"] == 1
        assert robot_samples[0]["time_s"] > result["events"]["striker_impact_onset"]
        assert not any(sample["nonselected"] for sample in samples)
        qualifying = [
            sample
            for sample in samples
            if sample["bilateral_steps"] >= 25 and sample["left"] and sample["right"]
        ]
        assert qualifying
        assert qualifying[0]["axis_error"] <= math.radians(18.0)
        assert max(sample["stable_steps"] for sample in samples) == 250
        outgoing[branch] = result["outgoing_twist_world"]
        sign = 1.0 if branch == "left" else -1.0
        assert sign * outgoing[branch][3] >= 0.035
        assert sign * outgoing[branch][2] >= 0.35
    assert outgoing["left"] != outgoing["right"]
    assert (
        captured["left"]["result"]["events"]["side_strike_triggered"]
        == captured["right"]["result"]["events"]["side_strike_triggered"]
    )


def test_replanning_real_oracle_runs_through_the_single_formal_rollout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("t5_replan")
    scenario = _proposal(0, "e7_agentview")
    environment = cast(ReplanningEnv, make_env(task.task_id, scenario))

    class OraclePolicy:
        oracle: _ReplanningOracle | None = None

        def reset(self) -> None:
            self.oracle = _ReplanningOracle(environment)

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            assert self.oracle is not None
            return self.oracle.action(environment)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> ReplanningEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        OraclePolicy(),
        scenario_id="v1:test_id:t5_replan:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert not trace.success and trace.failure_code == "workspace_exit"
    assert trace.elapsed_s == pytest.approx(2091 * 0.002, abs=1e-12)
    assert len(trace.steps) == 84
    assert trace.steps[-1].event_flags == (True, True, True, False, False, False)
    delay = scenario.action_delay_steps
    assert tuple(step.applied_tick for step in trace.steps) == tuple(
        tick + delay if tick + delay < len(trace.steps) else None
        for tick in range(len(trace.steps))
    )
    result = _evaluate_episode(trace)
    assert not result.success and result.failure_code == "workspace_exit"


@pytest.mark.parametrize(
    ("recipe_name", "representation", "ordinal", "approach_reached"),
    [
        ("e7_agentview", "delta", 1, False),
        ("e7_agentview_wrist", "absolute", 2, False),
        ("j8_agentview", "delta", 3, False),
        ("j8_agentview_wrist", "absolute", 4, False),
    ],
)
def test_replanning_real_failure_trace_keeps_unreached_formal_events_false(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    recipe_name: str,
    representation: str,
    ordinal: int,
    approach_reached: bool,
) -> None:
    task = load_task("t5_replan")
    scenario = _proposal(0, recipe_name)
    environment = cast(ReplanningEnv, make_env(task.task_id, scenario))
    scenario_id = f"v1:test_id:t5_replan:{ordinal:06d}"

    class NeutralPolicy:
        def reset(self) -> None:
            pass

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            if representation == "absolute":
                if scenario.action_mode == "E7":
                    motion = np.concatenate(
                        (
                            observation.eef_position,
                            _so3_log(
                                _quaternion_xyzw_to_matrix(
                                    observation.eef_quaternion_xyzw.astype(np.float64)
                                )
                            ),
                        )
                    )
                else:
                    motion = observation.joint_position
            else:
                motion = np.zeros(6 if scenario.action_mode == "E7" else 7)
            values = np.ascontiguousarray(np.concatenate((motion, (-1.0,))), dtype=np.float32)
            values = np.ascontiguousarray(values, dtype=np.float64)
            values.setflags(write=False)
            return BenchmarkAction(scenario.action_mode, representation, values)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> ReplanningEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        NeutralPolicy(),
        scenario_id=scenario_id,
        partition="test_id",
        factor=None,
        repeat_index=0,
        record_directory=tmp_path,
    )
    assert trace.event_names == (
        "valid_selected_impact",
        "approach",
        "fingerpad_contact",
        "bilateral_hold",
        "clearance",
        "stable_dwell",
    )
    assert not {
        "keyed_puck_enters_observation_lane",
        "side_strike_triggered",
        "striker_impact_onset",
        "striker_impact_end",
        "postevent_state_validated",
        "verified_rigid_grasp_engaged",
        "success",
    }.intersection(trace.event_names)
    assert trace.failure_code == "downstream_exit" and not trace.success
    # The original OSC staging leaves the neutral open-gripper policy above
    # the approach radius for both action interfaces.
    assert trace.steps[-1].event_flags == (True, approach_reached, False, False, False, False)
    assert trace.steps[-1].applied_tick is None
    result = _evaluate_episode(trace)
    assert result.failure_code == "downstream_exit" and result.failure_class == "boundary"
    destination = tmp_path / f"{_episode_id(scenario_id, 0)}.hdf5"
    metadata, arrays = _read_episode_file(destination)
    assert not tuple(tmp_path.glob("*.partial.hdf5"))
    assert arrays.tick.shape[0] == len(trace.steps) + 1
    assert arrays.action_value.shape[0] == len(trace.steps)
    assert arrays.flow_2d_px.shape[0] == len(trace.steps)
    np.testing.assert_array_equal(arrays.event_flags[-1], trace.steps[-1].event_flags)
    assert arrays.applied_tick[-1] == -1
    assert metadata["action_spec"] == {
        "mode": scenario.action_mode,
        "representation": representation,
        "motion_limits": list(trace.action_spec.motion_limits),
    }
    np.testing.assert_array_equal(
        arrays.action_value,
        np.stack([step.action.value for step in trace.steps]),
    )
    assert metadata["outcome"] == {
        "success": False,
        "termination_reason": "terminal_failure",
        "failure_code": "downstream_exit",
    }


def test_t5_j8_right_oracle_is_exactly_repeatable_from_the_same_native_reset() -> None:
    scenario = _opposite_replanning_branch(_proposal(name="j8_agentview"))
    environment = cast(ReplanningEnv, make_env("t5_replan", scenario))
    try:
        environment.reset()
        first = _run_native_oracle(environment)
        first_state = _state(environment)
        environment.reset()
        second = _run_native_oracle(environment)
        assert second == first
        _assert_state_equal(_state(environment), first_state)
        assert first["success"] and first["failure_code"] is None
    finally:
        environment.close()


@pytest.mark.parametrize("branch", ["left", "right"])
def test_t5_native_selected_impact_without_robot_capture_fails_honestly(branch: str) -> None:
    scenario = _proposal()
    if branch == "right":
        scenario = _opposite_replanning_branch(scenario)
    environment = cast(ReplanningEnv, make_env("t5_replan", scenario))
    try:
        environment.reset()
        terminal: dict[str, Any] | None = None
        target_qpos = slice(environment._target_qpos_address, environment._target_qpos_address + 7)
        target_dofs = slice(environment._target_qvel_address, environment._target_qvel_address + 6)
        for _ in range(environment._task_spec.episode_horizon_steps):
            assert (
                np.count_nonzero(environment.sim.data.xfrc_applied[environment._target_body_id])
                == 0
            )
            assert np.count_nonzero(environment.sim.data.qfrc_applied[target_dofs]) == 0
            _, _, done, info = environment.step(_action(environment))
            assert (
                np.count_nonzero(environment.sim.data.xfrc_applied[environment._target_body_id])
                == 0
            )
            assert np.count_nonzero(environment.sim.data.qfrc_applied[target_dofs]) == 0
            assert np.isfinite(environment.sim.data.qpos[target_qpos]).all()
            if done:
                terminal = info
                break
        assert terminal is not None and not terminal["success"]
        assert terminal["failure_code"] in {"downstream_exit", "timeout"}
        assert terminal["impact_group_count"] == 1
        assert list(terminal["events"])[:5] == [
            "keyed_puck_enters_observation_lane",
            "side_strike_triggered",
            "striker_impact_onset",
            "striker_impact_end",
            "postevent_state_validated",
        ]
        assert "fingerpad_contact" not in terminal["events"]
    finally:
        environment.close()


def test_public_t5_generator_preserves_a_deterministic_structured_rejection() -> None:
    facts = []
    for _ in range(2):
        with pytest.raises(_CaptureProposalRejected) as caught:
            generate_scenario(
                load_task("t5_replan"),
                RECIPE,
                0,
                partition="ood",
                factor="motion_parameters",
                recipe_name="e7_agentview",
            )
        rejection = caught.value
        assert rejection.stage == "oracle" and rejection.failure_code == "workspace_exit"
        assert rejection.terminal_time_s is not None
        assert rejection.events["workspace_exit"] == rejection.terminal_time_s
        assert "success" not in rejection.events
        facts.append((rejection.terminal_time_s, rejection.events, rejection.__notes__))
    assert facts[0] == facts[1]
    assert list(facts[0][1]) == [
        "keyed_puck_enters_observation_lane",
        "side_strike_triggered",
        "striker_impact_onset",
        "striker_impact_end",
        "postevent_state_validated",
        "approach",
        "fingerpad_contact",
        "workspace_exit",
    ]
    assert facts[0][2] == ["selected branch: left; counterfactual index: 0"]


@pytest.mark.parametrize(
    ("partition", "seed"),
    [("test_id", 200000), ("test_id", 200003), ("validation", 3)],
)
def test_public_t5_oracle_captures_fixed_delayed_e7_regressions(partition: str, seed: int) -> None:
    generated = generate_scenario(
        load_task("t5_replan"),
        RECIPE,
        seed,
        partition=partition,
        recipe_name="e7_agentview_wrist",
    )
    assert generated == _proposal(seed, partition=partition, name="e7_agentview_wrist")
    assert generated.action_delay_steps == 1


def test_public_t5_motion_parameter_ood_has_a_real_accepted_e7_proposal() -> None:
    generated = generate_scenario(
        load_task("t5_replan"),
        RECIPE,
        10,
        partition="ood",
        factor="motion_parameters",
        recipe_name="e7_agentview",
    )
    assert generated == _proposal(
        10,
        partition="ood",
        factor="motion_parameters",
        name="e7_agentview",
    )
    assert generated.motion[0].translation.velocity_world_m_s == (0.0, 0.09, 0.0)
    assert generated.events[0].effect.actuator_scale == 1.2


def test_t5_stress_physics_and_delay_are_applied_and_exported_from_native_reset() -> None:
    scenario = _proposal(3, partition="stress")
    assert scenario.action_delay_steps == 1
    assert scenario.physics == _proposal().physics
    environment = cast(ReplanningEnv, make_env("t5_replan", scenario))
    try:
        environment.reset()
        assert environment.export_scenario() == scenario
        body = scenario.physics.bodies[0]
        model = environment.sim.model._model
        assert model.body_mass[environment._target_body_id] == body.mass_kg
        np.testing.assert_array_equal(
            model.body_inertia[environment._target_body_id], body.diagonal_inertia_kg_m2
        )
    finally:
        environment.close()


def test_public_t5_stress_preserves_fixed_seed_structured_rejection() -> None:
    facts = []
    for _ in range(2):
        with pytest.raises(_CaptureProposalRejected) as caught:
            generate_scenario(
                load_task("t5_replan"),
                RECIPE,
                0,
                partition="stress",
                factor=None,
                recipe_name="e7_agentview",
            )
        rejection = caught.value
        assert rejection.stage == "oracle" and rejection.failure_code == "downstream_exit"
        assert rejection.terminal_time_s is not None
        assert rejection.events["downstream_exit"] == rejection.terminal_time_s
        assert "success" not in rejection.events
        facts.append((rejection.terminal_time_s, rejection.events, rejection.__notes__))
    assert facts[0] == facts[1]
    assert list(facts[0][1]) == [
        "keyed_puck_enters_observation_lane",
        "side_strike_triggered",
        "striker_impact_onset",
        "striker_impact_end",
        "postevent_state_validated",
        "approach",
        "fingerpad_contact",
        "downstream_exit",
    ]
    assert facts[0][2] == ["selected branch: left; counterfactual index: 1"]


@pytest.mark.parametrize(
    ("name", "representation", "views"),
    [
        ("e7_agentview_wrist", "absolute", 2),
        ("j8_agentview", "delta", 1),
    ],
)
def test_t5_public_manifest_repeat_reset_and_fixed_action_replay_are_exact(
    name: str, representation: str, views: int, tmp_path: Path
) -> None:
    # Manifest and action replay also cover proposals rejected by the native oracle.
    scenario = _proposal(name=name)
    assert scenario.action_delay_steps == 1
    first = cast(ReplanningEnv, make_env("t5_replan", scenario))
    second: ReplanningEnv | None = None
    try:
        raw = first.reset()
        initial_state = _state(first)
        initial_observation = first._benchmark_observation(raw)
        _assert_observation(initial_observation, tick=0, views=views)
        for _ in range(3):
            first.step(_action(first, representation, displacement=0.0001))
        raw = first.reset()
        _assert_state_equal(initial_state, _state(first))
        assert first._action_spec is first._action_delay_queue is None
        assert first._previous_eef_quaternion_xyzw is None
        assert first._outcome.events == {"keyed_puck_enters_observation_lane": 0.0}
        assert first._outcome.physics_step == 0
        assert not first._event_fired and first._last_striker_state is None
        reset_observation = first._benchmark_observation(raw)
        for field in fields(reset_observation):
            np.testing.assert_array_equal(
                getattr(reset_observation, field.name), getattr(initial_observation, field.name)
            )

        manifest = ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    "v1:test_id:t5_replan:000000",
                    "t5_replan",
                    "test_id",
                    None,
                    0,
                    first.export_scenario(),
                ),
            )
        )
        path = tmp_path / "replanning.jsonl"
        write_manifest(manifest, path)
        assert load_manifest(path) == manifest
        second = cast(ReplanningEnv, make_env("t5_replan", load_manifest(path).rows[0].scenario))
        second_raw = second.reset()
        second_observation = second._benchmark_observation(second_raw)
        assert second.export_scenario() == scenario
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "jnt_type",
            "jnt_axis",
            "jnt_range",
            "dof_damping",
            "dof_frictionloss",
            "actuator_gear",
            "actuator_ctrlrange",
            "geom_surfacevel",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_type",
            "light_pos",
            "light_dir",
            "light_diffuse",
            "light_specular",
        ):
            np.testing.assert_array_equal(
                getattr(first.sim.model._model, field),
                getattr(second.sim.model._model, field),
                err_msg=field,
            )
        replayed_valid_impact = False
        replayed_selected_actuation = False
        for tick in range(61):
            _assert_state_equal(_state(first), _state(second))
            selected_dof = first._joint_qvel_addresses[first._selected_branch]
            if first.sim.data.qfrc_applied[selected_dof] != 0.0:
                replayed_selected_actuation = True
            left = reset_observation if tick == 0 else first._benchmark_observation(raw)
            right = second_observation if tick == 0 else second._benchmark_observation(second_raw)
            for field in fields(left):
                np.testing.assert_array_equal(
                    getattr(left, field.name), getattr(right, field.name), err_msg=field.name
                )
            if "valid_selected_impact" in first._outcome.events:
                assert first._outcome.events == second._outcome.events
                assert list(first._outcome.events)[:6] == [
                    "keyed_puck_enters_observation_lane",
                    "selected_strike_triggered",
                    "selected_impact",
                    "selected_impact_end",
                    "valid_selected_impact",
                    "outgoing_change_validated",
                ]
                assert first._outcome._maximum_impact_group_count == 1
                assert second._outcome._maximum_impact_group_count == 1
                replayed_valid_impact = True
                break
            action = _action(
                first,
                representation,
                displacement=0.0001 * ((tick % 3) - 1),
            )
            raw, first_reward, first_done, first_info = first.step(action)
            second_raw, second_reward, second_done, second_info = second.step(action)
            assert (first_reward, first_done, first_info) == (
                second_reward,
                second_done,
                second_info,
            )
            assert not first_done
        assert replayed_selected_actuation and replayed_valid_impact
    finally:
        first.close()
        if second is not None:
            second.close()


def test_t5_real_bad_qpos_is_invalid_before_mujoco_recovery(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    environment = cast(ReplanningEnv, make_env("t5_replan", _proposal()))
    try:
        environment.reset()
        data = environment.sim.data._data
        data.qpos[environment._target_qpos_address] = math.nan
        _, reward, done, info = environment.step(_action(environment))
        assert done and reward == 0.0 and not info["success"]
        assert info["failure_code"] == "invalid_state" and info["terminal_time_s"] == 0.0
        assert data.warning[mujoco.mjtWarning.mjWARN_BADQPOS].number > 0
        assert np.isfinite(data.qpos).all()
    finally:
        environment.close()


def test_t5_malformed_or_contacting_reset_is_rejected_explicitly() -> None:
    scenario = _proposal()
    with pytest.raises(ValueError, match="exactly"):
        make_env("t5_replan", replace(scenario, events=()))

    target = replace(scenario.object_states[0], position_world_m=(-0.13, -0.15, 0.812))
    environment = cast(
        ReplanningEnv,
        make_env("t5_replan", replace(scenario, object_states=(target,))),
    )
    try:
        environment.reset()
        with pytest.raises(_CaptureProposalRejected) as caught:
            _validate_replanning_reset(environment)
        assert caught.value.stage == "reset"
        assert caught.value.failure_code == "striker_contact_at_reset"
    finally:
        environment.close()


def test_t5_target_native_state_writes_are_confined_to_reset() -> None:
    module = inspect.getmodule(ReplanningEnv)
    assert module is not None
    tree = ast.parse(inspect.getsource(module))
    for function in ast.walk(tree):
        if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)) or function.name in {
            "_reset_internal",
            "reset",
        }:
            continue
        for node in ast.walk(function):
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Attribute):
                # Striker generalized forces are allowed; the real no-capture
                # trace above checks that they never drive the target DOFs.
                if node.value.attr in {"qpos", "qvel", "xfrc_applied"}:
                    assert not isinstance(node.ctx, ast.Store), function.name


def test_t5_oracle_emits_actions_only_from_current_native_state() -> None:
    environment = cast(ReplanningEnv, make_env("t5_replan", _proposal(name="j8_agentview")))
    try:
        environment.reset()
        oracle = _ReplanningOracle(environment)
        before = _state(environment)
        action = oracle.action(environment)
        _assert_state_equal(before, _state(environment))
        assert action.mode == "J8" and action.representation == "delta"
        assert action.value.shape == (8,) and not action.value.flags.writeable
    finally:
        environment.close()
