from __future__ import annotations

import ast
import inspect
import math
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import fields, replace
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest

from se3_wam_benchmark.control.action import BenchmarkAction, _controller_action, _so3_log
from se3_wam_benchmark.envs.base import (
    _collision_bottom_z,
    _fingerpad_contacts,
    _load_asset_catalog,
)
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.driven_interception import (
    DrivenInterceptionEnv,
    _DrivenCapture,
)
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios._feasibility import _validate_capture_reset
from se3_wam_benchmark.scenarios._native_oracle import _CaptureOracle, _run_native_oracle
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_surface_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import (
    ConstantVelocityTranslation,
    JointPhysicsSpec,
    ScenarioSpec,
)
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
RECIPE = ROOT / "configs/scenarios/t1_belt.yaml"


def _proposal(
    seed: int,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    recipe = _select_recipe(
        load_yaml_strict(RECIPE), partition=partition, factor=factor, recipe_name=name
    )
    scenario = _materialize_recipe(
        load_task("t1_belt"), recipe, np.random.Generator(np.random.PCG64(seed))
    )
    _validate_surface_declarative_scenario(
        load_task("t1_belt"),
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
    )
    return scenario


@pytest.mark.parametrize(
    "name", ["e7_agentview", "e7_agentview_wrist", "j8_agentview", "j8_agentview_wrist"]
)
def test_belt_spatial_ood_excludes_closed_id_on_exactly_one_selected_axis(name: str) -> None:
    # Fixed DB0 source: se3_wam/benchmark/dataset_manifest.py:104-156, 283-345;
    # se3_wam/benchmark/configs/t1_belt_v0_2.yaml:43-58. Spatial OOD conditions
    # the speed/X/Y cycle on X or Y, then weights the exterior intervals by length.
    source_id = np.asarray([[-0.08, 0.08], [-0.26, -0.18]])
    source_ood = np.asarray([[-0.12, 0.12], [-0.30, -0.16]])
    task = load_task("t1_belt")
    recipe: dict[str, Any] = dict(
        _select_recipe(
            load_yaml_strict(RECIPE),
            partition="ood",
            factor="spatial",
            recipe_name=name,
        )
    )
    selector = recipe["object_states"][0]["position_world_m"]
    assert set(selector) == {"choices"} and len(selector["choices"]) == 2
    catalog = _load_asset_catalog(ROOT / "assets/catalog.yaml")
    for axis, position in enumerate(selector["choices"]):
        assert len(position) == 3 and position[2] == 0.8 + 0.022
        assert set(position[axis]) == {"uniform_intervals"}
        intervals = np.asarray(position[axis]["uniform_intervals"])
        expected = np.asarray(
            [
                [source_ood[axis, 0], np.nextafter(source_id[axis, 0], -np.inf)],
                [np.nextafter(source_id[axis, 1], np.inf), source_ood[axis, 1]],
            ]
        )
        np.testing.assert_array_equal(intervals, expected)
        widths = intervals[:, 1] - intervals[:, 0]
        np.testing.assert_array_equal(
            widths / widths.sum(), [0.5, 0.5] if axis == 0 else [2.0 / 3.0, 1.0 / 3.0]
        )
        assert position[1 - axis] == {
            "min": source_id[1 - axis, 0],
            "max": source_id[1 - axis, 1],
        }
        # Check both declared endpoints of each exterior interval through the
        # ordinary concrete recipe and scenario validators, without widening them.
        for endpoint in intervals.flat:
            xy = source_id.mean(axis=1)
            xy[axis] = endpoint
            concrete = deepcopy(recipe)
            concrete["object_states"][0]["position_world_m"] = [*xy, position[2]]
            scenario = _materialize_recipe(task, concrete, np.random.default_rng(0))
            _validate_surface_declarative_scenario(
                task,
                scenario,
                partition="ood",
                factor="spatial",
                catalog=catalog,
            )
            realized = np.asarray(scenario.object_states[0].position_world_m)
            np.testing.assert_array_equal(realized, [*xy, position[2]])
            outside = (realized[:2] < source_id[:, 0]) | (realized[:2] > source_id[:, 1])
            assert int(outside.sum()) == 1 and outside[axis]


def test_t1_applies_optional_target_free_joint_physics_on_every_reset() -> None:
    baseline = _proposal(2)
    native_environment = make_env("t1_belt", baseline)
    try:
        assert isinstance(native_environment, DrivenInterceptionEnv)
        native_environment.reset()
        address = native_environment._target_qvel_address
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_damping[address : address + 6],
            np.zeros(6),
        )
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_frictionloss[address : address + 6],
            np.zeros(6),
        )
    finally:
        native_environment.close()
    damping = tuple((index + 1) * 1e-6 for index in range(6))
    friction = tuple((index + 1) * 1e-7 for index in range(6))
    scenario = replace(
        baseline,
        physics=replace(
            baseline.physics,
            joints=(JointPhysicsSpec("target", "target_joint0", damping, friction),),
        ),
    )
    environment = make_env("t1_belt", scenario)
    try:
        assert isinstance(environment, DrivenInterceptionEnv)
        for _ in range(2):
            environment.reset()
            binding = environment._compiled_joint_physics[0]
            assert binding.dof_address == environment._target_qvel_address
            assert binding.dof_count == 6
            np.testing.assert_array_equal(
                environment.sim.model._model.dof_damping[
                    binding.dof_address : binding.dof_address + binding.dof_count
                ],
                damping,
            )
            np.testing.assert_array_equal(
                environment.sim.model._model.dof_frictionloss[
                    binding.dof_address : binding.dof_address + binding.dof_count
                ],
                friction,
            )
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _action(
    environment: DrivenInterceptionEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = -1.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    values = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _assert_observation(observation: BenchmarkObservation, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.rgb.dtype == np.uint8
    assert observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    assert observation.camera_intrinsics.dtype == np.float64
    assert observation.T_robot_base_from_world.dtype == np.float64
    assert np.all(observation.depth_m > 0.0)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert value.flags.c_contiguous and not value.flags.writeable
            assert np.isfinite(value).all()
    assert not {"task", "events", "target_pose", "future"} & {
        field.name for field in fields(observation)
    }


@pytest.mark.parametrize(
    ("name", "representation", "delay"),
    [
        ("e7_agentview", "delta", 0),
        ("e7_agentview_wrist", "absolute", 1),
        ("j8_agentview", "absolute", 0),
        ("j8_agentview_wrist", "delta", 2),
    ],
)
def test_registered_belt_runs_real_actions_current_rgbd_and_exact_reset_export(
    name: str, representation: str, delay: int
) -> None:
    scenario = replace(_proposal(2, name), action_delay_steps=delay)
    environment = make_env("t1_belt", scenario)
    assert isinstance(environment, DrivenInterceptionEnv)
    try:
        raw = environment.reset()
        assert isinstance(raw, Mapping)
        assert environment.get_ep_meta() == scenario
        assert environment.export_scenario() == scenario
        _assert_observation(environment._benchmark_observation(raw), 0, len(scenario.cameras.views))
        model = environment.sim.model._model
        assert model.light_type[0] == mujoco.mjtLightType.mjLIGHT_DIRECTIONAL
        assert not model.light_castshadow[0]
        segmentation = environment.sim.render(
            camera_name="agentview", width=224, height=224, segmentation=True
        )
        target_pixels = (segmentation[:, :, 0] == mujoco.mjtObj.mjOBJ_GEOM) & np.isin(
            segmentation[:, :, 1], np.flatnonzero(model.geom_bodyid == environment._target_body_id)
        )
        native_rgb = environment.sim.render(camera_name="agentview", width=224, height=224)
        np.testing.assert_array_equal(raw["agentview_image"], native_rgb)
        assert target_pixels.sum() > 200
        assert np.percentile(native_rgb[target_pixels].max(axis=1), 75) > 64
        first = _action(environment, representation, displacement=0.002, gripper=1.0)
        for tick in range(1, delay + 2):
            action = first if tick == 1 else _action(environment, representation)
            position, rotation, joints = environment._achieved_controller_state()
            raw, reward, done, _ = environment.step(action)
            assert math.isfinite(reward) and not done
            if tick <= delay:
                np.testing.assert_array_equal(environment.robots[0].recent_actions.current, 0.0)
            else:
                assert environment._action_spec is not None
                expected = _controller_action(
                    first,
                    environment._action_spec,
                    achieved_eef_position=position,
                    achieved_eef_rotation=rotation,
                    achieved_joint_position=joints,
                )
                np.testing.assert_allclose(
                    environment.robots[0].recent_actions.current, expected, rtol=0.0, atol=1e-7
                )
            _assert_observation(
                environment._benchmark_observation(raw), tick, len(scenario.cameras.views)
            )
            np.testing.assert_array_equal(
                raw["robot0_eef_pos"],
                environment.sim.data._data.site_xpos[environment.robots[0].eef_site_id["right"]],
            )
            assert environment._capture.physics_step == tick * 25
            assert environment.sim.data.time == pytest.approx(tick / 20.0, abs=1e-12)
    finally:
        environment.close()


def test_contact_records_bind_by_entity_id_and_preserve_reverse_order_in_real_export() -> None:
    scenario = _proposal(2)
    scenario = replace(
        scenario,
        physics=replace(scenario.physics, contacts=tuple(reversed(scenario.physics.contacts))),
    )
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        assert environment.export_scenario() == scenario
        assert tuple(item.entity_id for item in environment.export_scenario().physics.contacts) == (
            "belt",
            "target",
        )
        environment.step(_action(environment))
        assert environment.sim.data._data.qvel[environment._target_qvel_address + 1] > 0.0
    finally:
        environment.close()


@pytest.mark.parametrize("yaw", [0.0, math.pi / 4.0, math.pi / 2.0])
def test_real_belt_uses_only_native_surface_contact_even_with_rotated_fixture(yaw: float) -> None:
    scenario = _proposal(2)
    fixture = replace(
        scenario.fixture_states[0],
        quaternion_world_xyzw=(0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)),
    )
    scenario = replace(scenario, fixture_states=(fixture,))
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        assert environment.export_scenario() == scenario
        model, data = environment.sim.model._model, environment.sim.data._data
        assert model.flg_surfacevel and model.body_dofnum[environment._belt_body_id] == 0
        motion = scenario.motion[0].translation
        assert isinstance(motion, ConstantVelocityTranslation)
        world_velocity = np.asarray(motion.velocity_world_m_s)
        compiled_field = model.geom_surfacevel[environment._belt_geom_id].copy()
        rotation = data.geom_xmat[environment._belt_geom_id].reshape(3, 3)
        np.testing.assert_allclose(compiled_field[:3], rotation.T @ world_velocity, atol=1e-14)
        initial_y = float(data.xpos[environment._target_body_id, 1])
        normal_forces = []
        force = np.empty(6)
        for _ in range(20):
            _, _, done, _ = environment.step(_action(environment))
            assert not done
            np.testing.assert_array_equal(
                model.geom_surfacevel[environment._belt_geom_id], compiled_field
            )
            np.testing.assert_array_equal(data.xfrc_applied, 0.0)
            np.testing.assert_array_equal(data.qfrc_applied, 0.0)
            total = 0.0
            for index in range(data.ncon):
                contact = data.contact[index]
                pair = {int(contact.geom1), int(contact.geom2)}
                if environment._belt_geom_id in pair and pair & set(environment._target_geom_ids):
                    mujoco.mj_contactForce(model, data, index, force)
                    total += force[0]
            normal_forces.append(total)
        assert min(normal_forces) > 0.0
        assert data.xpos[environment._target_body_id, 1] - initial_y > 0.95 * world_velocity[1]
        assert data.qvel[environment._target_qvel_address + 1] == pytest.approx(
            world_velocity[1], abs=1e-6
        )
        assert abs(data.qvel[environment._target_qvel_address]) < 1e-7
        assert environment._capture.physics_step == 500
        assert not any(warning.number for warning in data.warning)
    finally:
        environment.close()


def test_driven_hooks_keep_target_state_reset_only_and_wrench_outside_belt_branch() -> None:
    module = inspect.getmodule(DrivenInterceptionEnv)
    assert module is not None
    tree = ast.parse(inspect.getsource(module))
    native_fields = {"qpos", "qvel", "qfrc_applied"}
    for method in ast.walk(tree):
        if isinstance(method, ast.FunctionDef) and method.name != "_reset_internal":
            for node in ast.walk(method):
                if isinstance(node, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                    targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                    for target in targets:
                        assert not any(
                            isinstance(child, ast.Attribute) and child.attr in native_fields
                            for child in ast.walk(target)
                        ), method.name
    pre_action = next(
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.FunctionDef) and node.name == "_pre_action"
    )
    guarded_calls = [
        node
        for node in ast.walk(pre_action)
        if isinstance(node, ast.If)
        and ast.unparse(node.test) == "not self._is_surface_driven"
        and any(
            isinstance(child, ast.Call) and ast.unparse(child.func) == "self._apply_target_wrench"
            for child in ast.walk(node)
        )
    ]
    assert len(guarded_calls) == 1


@pytest.mark.parametrize("sign", [1.0, -1.0])
def test_rounded_unit_quaternion_uses_compiler_semantics_and_exports_original_values(
    sign: float,
) -> None:
    scenario = _proposal(2)
    rounded = (0.0, 0.0, sign * 0.707106781, sign * 0.707106781)
    fixture = replace(scenario.fixture_states[0], quaternion_world_xyzw=rounded)
    scenario = replace(scenario, fixture_states=(fixture,))
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        assert environment.export_scenario() == scenario
        assert environment.export_scenario().fixture_states[0].quaternion_world_xyzw == rounded
        model, data = environment.sim.model._model, environment.sim.data._data
        rotation = data.geom_xmat[environment._belt_geom_id].reshape(3, 3)
        np.testing.assert_allclose(rotation.T @ rotation, np.eye(3), rtol=0.0, atol=1e-12)
        np.testing.assert_allclose(
            rotation @ model.geom_surfacevel[environment._belt_geom_id, :3],
            scenario.motion[0].translation.velocity_world_m_s,
            rtol=0.0,
            atol=1e-12,
        )
        for _ in range(3):
            _, _, done, _ = environment.step(_action(environment))
            assert not done
        assert data.qvel[environment._target_qvel_address + 1] > 0.0
    finally:
        environment.close()


def test_occ_requires_canopy_fixture_and_contact_bindings() -> None:
    with pytest.raises(ValueError, match="physical bindings"):
        DrivenInterceptionEnv(task_spec=load_task("t1_occ"), scenario_spec=_proposal(2))


@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_real_belt_oracle_succeeds_without_stopping_surface_or_writing_target(
    name: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    scenario = _proposal(2, name)
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        initial_surface = model.geom_surfacevel.copy()
        observed_stages = set()
        physics_calls = 0
        terminal_tail_calls = 0
        original_update = environment._capture.update

        def observed_update(**state: object) -> None:
            nonlocal physics_calls, terminal_tail_calls
            physics_calls += 1
            if environment._capture.terminal_time_s is not None:
                terminal_tail_calls += 1
            np.testing.assert_array_equal(model.geom_surfacevel, initial_surface)
            assert model.flg_surfacevel
            np.testing.assert_array_equal(data.xfrc_applied, 0.0)
            np.testing.assert_array_equal(data.qfrc_applied, 0.0)
            original_update(**state)
            observed_stages.update(environment._capture.events)

        monkeypatch.setattr(environment._capture, "update", observed_update)
        outcome = _run_native_oracle(environment)
        assert outcome["success"] is True and outcome["failure_code"] is None
        terminal_s = outcome["terminal_time_s"]
        assert math.isfinite(terminal_s) and 0.0 < terminal_s <= 8.0
        assert tuple(outcome["events"]) == (
            "target_enters_observation_region",
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
            "success",
        )
        assert tuple(item[0] for item in outcome["stage_facts"]) == tuple(outcome["events"])[1:-1]
        assert outcome["events"]["target_enters_observation_region"] == 0.0
        assert outcome["events"]["success"] == outcome["terminal_time_s"]
        assert all(item[1] and item[2] == 1.0 for item in outcome["stage_facts"])
        assert outcome["terminal_time_s"] == outcome["events"]["stable_dwell"]
        assert environment._capture.bilateral_steps >= 25
        assert environment._capture.stable_steps == 250
        assert outcome["events"]["stable_dwell"] - outcome["events"]["clearance"] == pytest.approx(
            249 * scenario.physics_timestep_s, abs=1e-9
        )
        assert _fingerpad_contacts(
            model,
            data,
            environment._target_geom_ids,
            environment._left_pad_ids,
            environment._right_pad_ids,
        ) == (True, True, True)
        assert _collision_bottom_z(model, data, environment._target_geom_ids) >= (
            scenario.geometry.support_surface_z_m
            + environment._task_spec.success.minimum_lift_or_clearance_m
        )
        np.testing.assert_array_equal(model.geom_surfacevel, initial_surface)
        np.testing.assert_array_equal(data.xfrc_applied, 0.0)
        np.testing.assert_array_equal(data.qfrc_applied, 0.0)
        assert model.flg_surfacevel
        assert environment.sim.data.time >= outcome["terminal_time_s"]
        assert environment.sim.data.time < outcome["terminal_time_s"] + 0.05
        assert environment._episode_tick == math.ceil(terminal_s * 20)
        assert physics_calls == environment._episode_tick * 25
        assert terminal_tail_calls > 0
        assert observed_stages == set(outcome["events"])
        assert environment._action_delay_queue is not None
        assert not environment._action_delay_queue._pending
        with pytest.raises(ValueError, match="terminated episode"):
            environment.step(_action(environment))
    finally:
        environment.close()


def test_belt_real_oracle_runs_through_the_single_formal_rollout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("t1_belt")
    scenario = _proposal(2, "e7_agentview")
    environment = make_env(task.task_id, scenario)

    class OraclePolicy:
        oracle: _CaptureOracle | None = None

        def reset(self) -> None:
            self.oracle = _CaptureOracle(environment)

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            assert self.oracle is not None
            return self.oracle.action(environment)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> DrivenInterceptionEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        assert isinstance(environment, DrivenInterceptionEnv)
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        OraclePolicy(),
        scenario_id="v1:test_id:t1_belt:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert trace.success and trace.failure_code is None
    assert trace.steps[-1].event_flags == (True,) * len(trace.event_names)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(range(len(trace.steps)))
    assert _evaluate_episode(trace).success


@pytest.mark.parametrize(
    ("seed", "name"), [(2, "e7_agentview"), (2, "j8_agentview"), (0, "j8_agentview")]
)
def test_public_belt_generator_runs_real_reset_and_oracle_before_returning_exact_export(
    seed: int,
    name: str,
) -> None:
    generated = generate_scenario(
        load_task("t1_belt"), RECIPE, seed, partition="test_id", recipe_name=name
    )
    assert generated == _proposal(seed, name)


@pytest.mark.parametrize("task_id", ["grasp", "t1_belt"])
def test_external_recipe_location_does_not_change_the_canonical_asset_owner(
    task_id: str, tmp_path: Path
) -> None:
    source = ROOT / "configs/scenarios" / f"{task_id}.yaml"
    external = tmp_path / "external_recipe.yaml"
    external.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    task = load_task(task_id)
    expected = _materialize_recipe(
        task,
        _select_recipe(
            load_yaml_strict(source), partition="test_id", factor=None, recipe_name="e7_agentview"
        ),
        np.random.Generator(np.random.PCG64(2)),
    )
    assert (
        generate_scenario(task, external, 2, partition="test_id", recipe_name="e7_agentview")
        == expected
    )


@pytest.mark.parametrize(
    ("name", "representation", "partition", "factor"),
    [
        ("e7_agentview", "delta", "test_id", None),
        ("j8_agentview_wrist", "absolute", "ood", "action_delay"),
    ],
)
def test_real_belt_export_manifest_round_trip_and_fixed_action_replay(
    name: str, representation: str, partition: Partition, factor: str | None, tmp_path: Path
) -> None:
    scenario = _proposal(2, name, partition=partition, factor=factor)
    assert (scenario.action_delay_steps > 0) == (factor == "action_delay")
    first = make_env("t1_belt", scenario)
    second = None
    try:
        first_raw = first.reset()
        exported = first.export_scenario()
        identity = f"v1:{partition}:{factor + ':' if factor is not None else ''}t1_belt:000000"
        manifest = ScenarioManifest(
            (ScenarioManifestRow(1, "v1", identity, "t1_belt", partition, factor, 2, exported),)
        )
        path = tmp_path / "scenario.jsonl"
        write_manifest(manifest, path)
        loaded = load_manifest(path)
        assert loaded == manifest
        second = make_env("t1_belt", loaded.rows[0].scenario)
        second_raw = second.reset()
        assert second.export_scenario() == exported
        model1, model2 = first.sim.model._model, second.sim.model._model
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "body_pos",
            "body_quat",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_condim",
            "geom_contype",
            "geom_conaffinity",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "geom_surfacevel",
            "jnt_type",
            "jnt_range",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_pos",
            "light_dir",
            "light_ambient",
            "light_diffuse",
            "light_specular",
            "light_attenuation",
            "light_cutoff",
            "light_active",
        ):
            np.testing.assert_array_equal(getattr(model1, field), getattr(model2, field))
        assert model1.flg_surfacevel == model2.flg_surfacevel == 1
        assert model1.opt.timestep == model2.opt.timestep == 0.002
        np.testing.assert_array_equal(model1.opt.gravity, model2.opt.gravity)
        for tick in range(9):
            data1, data2 = first.sim.data._data, second.sim.data._data
            assert data1.time == data2.time == pytest.approx(tick / 20.0, abs=1e-12)
            for field in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            ):
                np.testing.assert_array_equal(getattr(data1, field), getattr(data2, field))
            observation1 = first._benchmark_observation(first_raw)
            observation2 = second._benchmark_observation(second_raw)
            for field in fields(observation1):
                left, right = getattr(observation1, field.name), getattr(observation2, field.name)
                if isinstance(left, np.ndarray):
                    np.testing.assert_array_equal(left, right)
                else:
                    assert left == right
            if tick < 8:
                # Replay the identical issued BenchmarkAction, including absolute targets.
                action = _action(first, representation, displacement=0.001 * ((tick % 3) - 1))
                first_raw, reward1, done1, info1 = first.step(action)
                second_raw, reward2, done2, info2 = second.step(action)
                assert reward1 == reward2 and done1 == done2 and info1 == info2
    finally:
        first.close()
        if second is not None:
            second.close()


def test_real_moving_belt_target_boundary_uses_db0_cached_pose_and_exact_physics_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal(2)
    target = replace(scenario.object_states[0], position_world_m=(0.0, 0.3895, 0.822))
    environment = make_env("t1_belt", replace(scenario, object_states=(target,)))
    try:
        environment.reset()
        previous_qpos = environment.sim.data._data.qpos[
            environment._target_qpos_address : environment._target_qpos_address + 3
        ].copy()
        samples = []
        original_update = environment._capture.update

        def observe(**state: Any) -> None:
            data = environment.sim.data._data
            address = environment._target_qpos_address
            samples.append(
                (
                    float(data.time),
                    state["position"].copy(),
                    data.qpos[address : address + 3].copy(),
                )
            )
            original_update(**state)

        monkeypatch.setattr(environment._capture, "update", observe)
        _, _, done, info = environment.step(_action(environment))
        assert done and info["failure_code"] == "downstream_exit"
        assert len(samples) == 25
        for index, (time_s, position, qpos) in enumerate(samples, start=1):
            assert time_s == pytest.approx(index * 0.002, abs=1e-12)
            np.testing.assert_array_equal(position, previous_qpos)
            previous_qpos = qpos
        crossings = [time_s for time_s, position, _ in samples if position[1] > 0.39]
        assert info["terminal_time_s"] == min(crossings)
        assert 0.0 < info["terminal_time_s"] < environment.sim.data.time
        assert not environment._action_delay_queue._pending
    finally:
        environment.close()


@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview"])
def test_real_belt_reset_clears_capture_clock_action_latch_queue_and_quaternion(name: str) -> None:
    scenario = replace(_proposal(2, name), action_delay_steps=2)
    environment = make_env("t1_belt", scenario)
    try:
        initial = environment.reset()
        initial_qpos = environment.sim.data._data.qpos.copy()
        environment._benchmark_observation(initial)
        for _ in range(2):
            raw, _, done, _ = environment.step(_action(environment, gripper=1.0))
            assert not done
            environment._benchmark_observation(raw)
        assert len(environment._action_delay_queue._pending) == 2
        assert environment._capture.physics_step == 50
        assert environment._previous_eef_quaternion_xyzw is not None
        environment.reset()
        assert environment._episode_tick == 0 and environment.sim.data.time == 0.0
        assert environment._capture.physics_step == environment._capture.bilateral_steps == 0
        assert environment._capture.stable_steps == 0
        assert environment._capture.events == {"target_enters_observation_region": 0.0}
        assert (
            environment._capture.terminal_time_s is None
            and environment._capture.failure_code is None
        )
        assert environment._action_spec is None and environment._action_delay_queue is None
        assert environment._previous_eef_quaternion_xyzw is None
        np.testing.assert_array_equal(environment.sim.data._data.qpos, initial_qpos)
        assert environment.export_scenario() == scenario
        environment.step(_action(environment, "absolute"))
        assert environment._action_spec.representation == "absolute"
        np.testing.assert_array_equal(environment.robots[0].recent_actions.current, 0.0)
    finally:
        environment.close()


@pytest.mark.parametrize("bad_qpos", [float("nan"), 1e11])
def test_real_belt_native_auto_reset_does_not_disguise_invalid_state(
    bad_qpos: float, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    scenario = _proposal(2)
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        action = _action(environment)
        data = environment.sim.data._data
        monkeypatch.chdir(tmp_path)
        data.qpos[environment._target_qpos_address] = bad_qpos
        _, reward, done, info = environment.step(action)
        assert done and reward == 0.0 and not info["success"]
        assert info["failure_code"] == "invalid_state"
        # NaN is visible before mj_step; a huge finite value is detected when
        # mj_step raises BADQPOS. The source has no t0 magnitude precheck.
        first_detection_s = scenario.physics_timestep_s if math.isfinite(bad_qpos) else 0.0
        assert info["terminal_time_s"] == first_detection_s
        assert data.warning[mujoco.mjtWarning.mjWARN_BADQPOS].number > 0
        assert np.isfinite(data.qpos).all()
        assert environment._episode_tick == 1 and not environment._action_delay_queue._pending
        terminal_qpos = data.qpos.copy()
        terminal_time_s = float(data.time)
        with pytest.raises(ValueError, match="terminated episode"):
            environment.step(action)
        np.testing.assert_array_equal(data.qpos, terminal_qpos)
        assert float(data.time) == terminal_time_s and environment._episode_tick == 1
    finally:
        environment.close()


@pytest.mark.parametrize(
    "kind", ["joint_out_of_range", "target_collision_outside_support", "target_not_visible"]
)
def test_belt_real_reset_rejection_records_the_explicit_stage_and_reason(kind: str) -> None:
    scenario = _proposal(2)
    if kind == "target_not_visible":
        view = replace(scenario.cameras.views[0], position_parent_m=(3.0, 0.0, 2.0))
        scenario = replace(scenario, cameras=replace(scenario.cameras, views=(view,)))
    environment = make_env("t1_belt", scenario)
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        if kind == "joint_out_of_range":
            joint = model.joint(environment.robots[0].robot_model.joints[0])
            data.qpos[model.jnt_qposadr[joint.id]] = model.jnt_range[joint.id, 1] + 0.1
            environment.sim.forward()
        elif kind == "target_collision_outside_support":
            address = environment._target_qpos_address
            data.qpos[address : address + 3] = data.geom_xpos[min(environment._left_pad_ids)]
            environment.sim.forward()
        with pytest.raises(_CaptureProposalRejected) as rejected:
            _validate_capture_reset(environment)
        assert rejected.value.stage == "reset" and rejected.value.failure_code == kind
    finally:
        environment.close()


def _capture_sample(capture: _DrivenCapture, **changes: Any) -> None:
    state = {
        "time_s": (capture.physics_step + 1) * 0.002,
        "finite": True,
        "position": np.asarray([0.0, 0.0, 0.822]),
        "bottom_z_m": 0.8,
        "eef_distance_m": 0.01,
        "left": True,
        "right": True,
        "opposing": True,
        **changes,
    }
    capture.update(**state)


def _capture_for_task(task_id: str) -> _DrivenCapture:
    capture = _DrivenCapture(load_task(task_id), _proposal(2).geometry, 0.002)
    capture.begin(eef_distance_m=0.30)
    return capture


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
@pytest.mark.parametrize(
    "failure", ["invalid_state", "workspace_exit", "downstream_exit", "drop", "timeout"]
)
def test_driven_raw_terminal_history_keeps_db0_names_and_scored_times(
    task_id: str, failure: str
) -> None:
    # Fixed registry.py defaults target_enters_observation_region for all T1;
    # capture.py _fail emits the registered reason unchanged.
    capture = _capture_for_task(task_id)
    if failure == "invalid_state":
        capture.invalidate(0.0)
        terminal_s = 0.0
    elif failure == "timeout":
        for _ in range(round(capture.horizon_s / 0.002)):
            _capture_sample(capture, eef_distance_m=0.30, left=False, right=False)
        terminal_s = capture.horizon_s
    else:
        change: dict[str, Any] = {
            "workspace_exit": {"position": np.asarray([0.32, 0.0, 0.822])},
            "downstream_exit": {"position": np.asarray([0.0, 0.40, 0.822])},
            "drop": {"bottom_z_m": 0.71},
        }[failure]
        _capture_sample(capture, eef_distance_m=0.30, left=False, right=False, **change)
        terminal_s = 0.002
    assert capture.events == {"target_enters_observation_region": 0.0, failure: terminal_s}
    assert capture.failure_code == failure and capture.terminal_time_s == terminal_s
    assert all(not completed for _, completed, _, _ in capture._stage_facts())
    frozen = capture._stage_facts()
    capture.invalidate(99.0)
    _capture_sample(capture)
    assert capture.events == {"target_enters_observation_region": 0.0, failure: terminal_s}
    assert capture._stage_facts() == frozen


def test_driven_capture_requires_explicit_scored_start_initialization() -> None:
    capture = _DrivenCapture(load_task("t1_belt"), _proposal(2).geometry, 0.002)
    for invalid_distance in (math.nan, math.inf, math.nextafter(0.0, -math.inf)):
        with pytest.raises(ValueError, match="finite non-negative"):
            capture.begin(eef_distance_m=invalid_distance)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        _capture_sample(capture)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        capture.invalidate(0.0)


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_approach_progress_uses_db0_current_distance_and_fixed_span(task_id: str) -> None:
    capture = _capture_for_task(task_id)
    capture.begin(eef_distance_m=0.50)
    assert capture._stage_facts()[0][2] == 0.0
    _capture_sample(capture, eef_distance_m=0.20, left=False, right=False)
    assert capture._stage_facts()[0][2] == pytest.approx(0.50)
    _capture_sample(capture, eef_distance_m=0.28, left=False, right=False)
    assert capture._stage_facts()[0][2] == pytest.approx(0.10)
    assert capture.events == {"target_enters_observation_region": 0.0}


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_clearance_progress_tracks_current_height_and_requires_valid_hold(
    task_id: str,
) -> None:
    capture = _capture_for_task(task_id)
    for _ in range(25):
        _capture_sample(capture)
    assert capture.post_hold_contact_valid and "bilateral_hold" in capture.events
    _capture_sample(capture, bottom_z_m=0.825)
    assert capture._stage_facts()[3][2] == pytest.approx(0.50)
    _capture_sample(capture, bottom_z_m=0.81)
    assert capture._stage_facts()[3][2] == pytest.approx(0.20)
    _capture_sample(capture, bottom_z_m=0.84, right=False)
    assert not capture.post_hold_contact_valid and capture._stage_facts()[3][2] == 0.0
    for _ in range(24):
        _capture_sample(capture, bottom_z_m=0.84)
        assert capture._stage_facts()[3][2] == 0.0
    _capture_sample(capture, bottom_z_m=0.84)
    assert capture.post_hold_contact_valid
    assert capture._stage_facts()[3][2] == pytest.approx(0.80)
    assert "clearance" not in capture.events


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_finite_failure_scores_current_sample_without_completing_events(
    task_id: str,
) -> None:
    capture = _capture_for_task(task_id)
    _capture_sample(capture, eef_distance_m=0.20, left=False, right=False)
    _capture_sample(
        capture,
        position=np.asarray([0.32, 0.0, 0.822]),
        eef_distance_m=0.28,
        left=False,
        right=False,
    )
    assert capture.failure_code == "workspace_exit"
    assert capture.events == {"target_enters_observation_region": 0.0, "workspace_exit": 0.004}
    assert capture._stage_facts()[0][2] == pytest.approx(0.10)


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_bilateral_duration_counts_physical_contact_before_approach(task_id: str) -> None:
    capture = _capture_for_task(task_id)
    outside_approach = math.nextafter(0.10, math.inf)
    for _ in range(3):
        _capture_sample(capture, eef_distance_m=outside_approach)
    assert "approach" not in capture.events
    assert "fingerpad_contact" not in capture.events
    assert capture.bilateral_steps == 3

    _capture_sample(capture, eef_distance_m=0.10)
    assert "approach" in capture.events and "fingerpad_contact" in capture.events
    assert capture.bilateral_steps == 4


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3"])
def test_driven_capture_core_requires_consecutive_bilateral_contact_then_consecutive_dwell(
    task_id: str,
) -> None:
    capture = _capture_for_task(task_id)
    for _ in range(24):
        _capture_sample(capture)
    assert "bilateral_hold" not in capture.events
    _capture_sample(capture, right=False)
    assert capture.bilateral_steps == 0
    for _ in range(25):
        _capture_sample(capture, opposing=False)
    assert capture.events["bilateral_hold"] == pytest.approx(0.10)
    for _ in range(249):
        _capture_sample(capture, bottom_z_m=0.851)
    assert not capture.success and capture.stable_steps == 249
    _capture_sample(capture, left=False, bottom_z_m=0.851)
    assert capture.stable_steps == 0
    for _ in range(250):
        _capture_sample(capture, bottom_z_m=0.851)
    assert capture.success and capture.stable_steps == 250


@pytest.mark.parametrize(
    ("failure", "changes"),
    [
        ("invalid_state", {"finite": False, "position": np.asarray([0.32, 0.40, 0.70])}),
        ("invalid_state", {"eef_distance_m": math.nan}),
        ("invalid_state", {"eef_distance_m": math.inf}),
        ("workspace_exit", {"position": np.asarray([0.32, 0.40, 0.70]), "bottom_z_m": 0.70}),
        ("downstream_exit", {"position": np.asarray([0.0, 0.40, 0.70]), "bottom_z_m": 0.70}),
        ("drop", {"position": np.asarray([0.0, 0.30, 0.70]), "bottom_z_m": 0.70}),
        ("downstream_exit", {"position": np.asarray([0.0, 0.40, 0.90])}),
    ],
)
@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_capture_core_latches_failure_before_same_physics_step_success(
    task_id: str, failure: str, changes: dict[str, Any]
) -> None:
    capture = _capture_for_task(task_id)
    for _ in range(25):
        _capture_sample(capture)
    for _ in range(249):
        _capture_sample(capture, bottom_z_m=0.851)
    before = capture._stage_facts()
    _capture_sample(capture, **{"bottom_z_m": 0.851, **changes})
    assert capture.failure_code == failure and not capture.success
    terminal = capture.terminal_time_s
    assert "stable_dwell" not in capture.events
    assert capture._stage_facts() == before
    _capture_sample(capture, bottom_z_m=0.851)
    assert capture.terminal_time_s == terminal


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3"])
def test_driven_capture_core_scores_success_on_the_last_horizon_physics_step(
    task_id: str,
) -> None:
    capture = _capture_for_task(task_id)
    for index in range(1, 4000):
        _capture_sample(capture, bottom_z_m=0.851 if index >= 3751 else 0.8)
    assert capture.stable_steps == 249 and not capture.success
    _capture_sample(capture, bottom_z_m=0.851)
    assert capture.failure_code is None and capture.terminal_time_s == 8.0
    assert capture.success


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_capture_core_keeps_upstream_y_out_of_the_failure_rule(task_id: str) -> None:
    capture = _capture_for_task(task_id)
    _capture_sample(capture, position=np.asarray([0.0, -0.41, 0.822]))
    assert capture.failure_code is None and capture.terminal_time_s is None


@pytest.mark.parametrize("task_id", ["t1_belt", "t1_xyz", "t1_so3", "t1_occ"])
def test_driven_capture_core_times_out_after_the_last_nonterminal_sample(task_id: str) -> None:
    capture = _capture_for_task(task_id)
    simulator_time_s = 0.0
    for _ in range(4000):
        simulator_time_s += 0.002
        _capture_sample(capture, time_s=simulator_time_s)
    assert simulator_time_s != 8.0
    assert capture.failure_code == "timeout" and capture.terminal_time_s == 8.0
    assert capture.bilateral_steps == 4000 and not capture.success
