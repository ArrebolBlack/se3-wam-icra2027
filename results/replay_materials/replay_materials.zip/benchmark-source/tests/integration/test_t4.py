from __future__ import annotations

import ast
import inspect
import math
from collections.abc import Mapping
from dataclasses import fields, replace
from functools import lru_cache
from pathlib import Path
from typing import Any

import mujoco
import numpy as np
import pytest
from robosuite.environments.manipulation.manipulation_env import ManipulationEnv

from se3_wam_benchmark.control.action import BenchmarkAction, _so3_log
from se3_wam_benchmark.envs.base import _load_asset_catalog
from se3_wam_benchmark.envs.factory import make_env
from se3_wam_benchmark.envs.families.free_dynamics_interception import (
    FreeDynamicsInterceptionEnv,
    _contact_impulse_between,
    _FreeDynamicsOutcome,
    _has_contact_between,
)
from se3_wam_benchmark.evaluation import rollout as rollout_module
from se3_wam_benchmark.evaluation.evaluator import _evaluate_episode
from se3_wam_benchmark.evaluation.rollout import _rollout_episode
from se3_wam_benchmark.scenarios import _feasibility as feasibility_module
from se3_wam_benchmark.scenarios._native_oracle import (
    _FreeDynamicsOracle,
    _mujoco_twist_to_spatial,
)
from se3_wam_benchmark.scenarios._recipes import _materialize_recipe, _select_recipe
from se3_wam_benchmark.scenarios._rejection import _CaptureProposalRejected
from se3_wam_benchmark.scenarios._validation import _validate_free_dynamics_declarative_scenario
from se3_wam_benchmark.scenarios.generator import generate_scenario
from se3_wam_benchmark.scenarios.manifest import (
    Partition,
    ScenarioManifest,
    ScenarioManifestRow,
    load_manifest,
    write_manifest,
)
from se3_wam_benchmark.scenarios.spec import JointPhysicsSpec, ScenarioSpec, TimeTriggerSpec
from se3_wam_benchmark.sensing.observation import BenchmarkObservation
from se3_wam_benchmark.tasks.registry import load_task, load_yaml_strict

ROOT = Path(__file__).resolve().parents[2]
TASKS = ("t4_sphere", "t4_sphere_tabletop", "t4_slider", "t4_can")


@lru_cache(maxsize=4)
def _document(task_id: str) -> Any:
    return load_yaml_strict(ROOT / f"configs/scenarios/{task_id}.yaml")


def _proposal(
    task_id: str,
    seed: int = 0,
    name: str = "e7_agentview",
    *,
    partition: Partition = "test_id",
    factor: str | None = None,
) -> ScenarioSpec:
    task = load_task(task_id)
    recipe = _select_recipe(
        _document(task_id), partition=partition, factor=factor, recipe_name=name
    )
    scenario = _materialize_recipe(task, recipe, np.random.Generator(np.random.PCG64(seed)))
    _validate_free_dynamics_declarative_scenario(
        task,
        scenario,
        partition=partition,
        factor=factor,
        catalog=_load_asset_catalog(ROOT / "assets/catalog.yaml"),
        id_recipe=_select_recipe(
            _document(task_id),
            partition="test_id",
            factor=None,
            recipe_name=name,
        ),
    )
    return scenario


def test_t4_applies_optional_target_joint_physics_with_static_gate() -> None:
    baseline = _proposal("t4_slider")
    native_environment = make_env("t4_slider", baseline)
    try:
        assert isinstance(native_environment, FreeDynamicsInterceptionEnv)
        native_environment.reset()
        address = native_environment._target_qvel_address
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_damping[address : address + 6],
            np.zeros(6),
        )
        np.testing.assert_array_equal(
            native_environment.sim.model._model.dof_frictionloss[address : address + 6],
            np.zeros(6),
        )
    finally:
        native_environment.close()
    target_id = baseline.object_states[0].instance_id
    target_joint = JointPhysicsSpec(
        target_id,
        f"{target_id}_joint0",
        tuple((index + 1) * 1e-6 for index in range(6)),
        tuple((index + 1) * 1e-7 for index in range(6)),
    )
    scenario = replace(
        baseline,
        physics=replace(baseline.physics, joints=(*baseline.physics.joints, target_joint)),
    )
    environment = make_env("t4_slider", scenario)
    try:
        assert isinstance(environment, FreeDynamicsInterceptionEnv)
        expected_addresses = {
            f"{target_id}_joint0": environment._target_qvel_address,
        }
        for _ in range(2):
            environment.reset()
            assert {
                binding.spec.joint_name: binding.dof_address
                for binding in environment._compiled_joint_physics
            } == expected_addresses
            for binding in environment._compiled_joint_physics:
                stop = binding.dof_address + binding.dof_count
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_damping[binding.dof_address : stop],
                    binding.spec.damping_per_dof,
                )
                np.testing.assert_array_equal(
                    environment.sim.model._model.dof_frictionloss[binding.dof_address : stop],
                    binding.spec.friction_loss_per_dof,
                )
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
    finally:
        environment.close()


def _action(
    environment: FreeDynamicsInterceptionEnv,
    representation: str = "delta",
    *,
    displacement: float = 0.0,
    gripper: float = 0.0,
) -> BenchmarkAction:
    mode = environment._scenario_spec.action_mode
    if representation == "absolute":
        position, rotation, joints = environment._achieved_controller_state()
        motion = np.concatenate((position, _so3_log(rotation))) if mode == "E7" else joints.copy()
    else:
        motion = np.zeros(6 if mode == "E7" else 7)
    motion[0] += displacement
    values = np.ascontiguousarray(np.concatenate((motion, [gripper])), dtype=np.float32)
    values = np.ascontiguousarray(values, dtype=np.float64)
    values.setflags(write=False)
    return BenchmarkAction(mode, representation, values)


def _state(environment: FreeDynamicsInterceptionEnv) -> dict[str, Any]:
    data = environment.sim.data._data
    return {
        "time": float(data.time),
        **{
            name: np.asarray(getattr(data, name)).copy()
            for name in (
                "qpos",
                "qvel",
                "qacc",
                "ctrl",
                "xpos",
                "xmat",
                "geom_xpos",
                "geom_xmat",
                "cam_xpos",
                "cam_xmat",
                "xfrc_applied",
                "qfrc_applied",
            )
        },
    }


def _assert_state_equal(first: Mapping[str, Any], second: Mapping[str, Any]) -> None:
    assert first.keys() == second.keys()
    for name in first:
        np.testing.assert_array_equal(first[name], second[name], err_msg=name)


def _target_ramp_contact_friction(
    environment: FreeDynamicsInterceptionEnv,
) -> np.ndarray:
    data = environment.sim.data._data
    target_ids = frozenset(environment._target_geom_ids)
    ramp_ids = frozenset(environment._ramp_geom_ids)
    samples = [
        np.asarray(data.contact[index].friction, dtype=np.float64).copy()
        for index in range(data.ncon)
        if (
            int(data.contact[index].geom1) in target_ids
            and int(data.contact[index].geom2) in ramp_ids
        )
        or (
            int(data.contact[index].geom2) in target_ids
            and int(data.contact[index].geom1) in ramp_ids
        )
    ]
    assert samples
    for sample in samples[1:]:
        np.testing.assert_array_equal(sample, samples[0])
    return samples[0]


def _assert_observation(observation: BenchmarkObservation, *, tick: int, views: int) -> None:
    assert observation.tick == tick and observation.timestamp_s == tick / 20.0
    assert observation.rgb.shape == (views, 224, 224, 3)
    assert observation.rgb.dtype == np.uint8
    assert observation.depth_m.shape == (views, 224, 224)
    assert observation.depth_m.dtype == np.float32
    assert observation.camera_intrinsics.shape == (views, 3, 3)
    assert observation.world_from_camera_cv.shape == (views, 4, 4)
    for field in fields(observation):
        value = getattr(observation, field.name)
        if isinstance(value, np.ndarray):
            assert np.isfinite(value).all()
            assert value.flags.c_contiguous and not value.flags.writeable


@pytest.mark.parametrize("task_id", TASKS)
@pytest.mark.parametrize("name", ["e7_agentview", "j8_agentview_wrist"])
def test_t4_real_reset_is_hidden_supported_verified_and_starts_a_clean_scored_clock(
    task_id: str,
    name: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    scenario = _proposal(task_id, name=name)
    environment = make_env(task_id, scenario)
    try:
        assert isinstance(environment, FreeDynamicsInterceptionEnv)
        staging_end: dict[str, Any] = {}
        preposition = environment._preposition_robot_for_release
        native_step = ManipulationEnv.step

        def observe_preposition() -> None:
            model, data = environment.sim.model._model, environment.sim.data._data
            preparation = scenario.preparation_object_states[0]
            x, y, z, w = preparation.quaternion_world_xyzw
            address = environment._target_qpos_address
            np.testing.assert_array_equal(
                data.qpos[address : address + 7],
                (*preparation.position_world_m, w, x, y, z),
            )
            surface_mu = {
                "t4_sphere": 0.8,
                "t4_sphere_tabletop": 0.8,
                "t4_slider": 0.035,
                "t4_can": 0.35,
            }[task_id]
            for geom in (
                *environment._target_geom_ids,
                *environment._ramp_geom_ids,
                *environment._gate_geom_ids,
            ):
                np.testing.assert_array_equal(
                    model.geom_friction[geom], (surface_mu, 0.005, 0.0001)
                )
            for geom in environment._downstream_geom_ids:
                np.testing.assert_array_equal(model.geom_friction[geom], (1.0, 0.005, 0.0001))
            for geom in (*environment._ramp_geom_ids, *environment._gate_geom_ids):
                np.testing.assert_array_equal(data.xpos[model.geom_bodyid[geom]], (0.0, 0.0, -1.0))
            preposition()
            staging_end["qacc_warmstart"] = data.qacc_warmstart.copy()
            staging_end["robot_qvel"] = data.qvel[:9].copy()
            staging_end["ctrl"] = data.ctrl.copy()

        def observe_settle(self: Any, action: Any) -> Any:
            if self is environment and self._settling and "settle_checked" not in staging_end:
                model, data = self.sim.model._model, self.sim.data._data
                np.testing.assert_array_equal(data.qacc_warmstart, staging_end["qacc_warmstart"])
                np.testing.assert_array_equal(data.qvel[:9], staging_end["robot_qvel"])
                np.testing.assert_array_equal(data.ctrl, staging_end["ctrl"])
                address = self._target_qpos_address
                released = scenario.object_states[0]
                x, y, z, w = released.quaternion_world_xyzw
                np.testing.assert_array_equal(
                    data.qpos[address : address + 7], (*released.position_world_m, w, x, y, z)
                )
                np.testing.assert_array_equal(data.qvel[self._target_qvel_address :], 0.0)
                for entity, geoms in {
                    self._bindings.target_object_id: self._target_geom_ids,
                    **self._fixture_geom_ids,
                }.items():
                    for geom in geoms:
                        np.testing.assert_array_equal(
                            model.geom_friction[geom],
                            self._contact_specs[entity].friction_slide_spin_roll,
                        )
                staging_end["settle_checked"] = True
            return native_step(self, action)

        monkeypatch.setattr(environment, "_preposition_robot_for_release", observe_preposition)
        monkeypatch.setattr(ManipulationEnv, "step", observe_settle)
        raw = environment.reset()
        assert staging_end["settle_checked"]
        assert environment.export_scenario() == scenario
        assert environment._preparation_steps == 12 * 25
        assert environment._ramp_support_steps >= 25
        assert environment.sim.data.time == 0.0
        assert environment._episode_tick == 0 and environment.timestep == 0
        assert environment._release_command is not None
        assert environment._event_runtime._fired == [True]
        assert environment._release_event_time_s == 0.0
        assert environment._outcome.events["release_gate_opens"] == 0.0
        np.testing.assert_array_equal(
            environment.sim.model.body_pos[environment._gate_body_id], (0.0, -0.25, 0.55)
        )
        np.testing.assert_array_equal(
            environment.sim.data.qvel[
                environment._target_qvel_address : environment._target_qvel_address + 6
            ],
            0.0,
        )
        assert np.isfinite(environment.sim.data.xipos[environment._target_body_id]).all()
        assert environment.sim.model.body_jntnum[environment._gate_body_id] == 0
        assert environment.sim.model.nq == 16 and environment.sim.model.nv == 15
        assert set(environment._fixture_geom_ids) == set(
            (
                environment._bindings.ramp_fixture_id,
                environment._bindings.release_gate_fixture_id,
                environment._bindings.downstream_surface_fixture_id,
            )
        )
        observed = environment._benchmark_observation(raw)
        _assert_observation(observed, tick=0, views=2 if name.endswith("wrist") else 1)
    finally:
        environment.close()


def test_tick_zero_static_release_precedes_observation_and_records_native_impulse() -> None:
    environment = make_env("t4_sphere", _proposal("t4_sphere"))
    try:
        environment.reset()
        model, data = environment.sim.model._model, environment.sim.data._data
        impulses: list[float] = []
        times: list[float] = []
        native_update = environment._outcome.update
        first_command = environment._release_command
        assert first_command is not None
        assert environment._release_event_time_s == 0.0
        assert environment._release_linear_speed_m_s == 0.0
        assert environment._release_angular_speed_rad_s == 0.0
        assert model.body_jntnum[environment._gate_body_id] == 0
        np.testing.assert_array_equal(model.body_pos[environment._gate_body_id], (0.0, -0.25, 0.55))

        def observe_update(**sample: Any) -> None:
            direct = _contact_impulse_between(
                model,
                data,
                frozenset(environment._target_geom_ids),
                frozenset(environment._gate_geom_ids),
                timestep_s=environment.model_timestep,
            )
            assert sample["target_gate_impulse_n_s"] == pytest.approx(direct, rel=0.0, abs=1e-12)
            impulses.append(direct)
            times.append(float(data.time))
            native_update(**sample)

        environment._outcome.update = observe_update
        _, _, done, info = environment.step(_action(environment))
        assert not done and info["failure_code"] is None
        assert tuple(item[0] for item in info["stage_facts"]) == (
            "approach",
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
        )
        assert info["stage_facts"][0][1] is False
        assert 0.0 < info["stage_facts"][0][2] < 1.0
        assert len(impulses) == 25
        np.testing.assert_allclose(times, np.arange(1, 26) * 0.002, rtol=0.0, atol=1e-12)
        assert all(value == 0.0 for value in impulses)
        assert info["release_impulse_n_s"] == max(impulses)
        assert max(impulses) <= 0.002
        assert environment._release_event_time_s == 0.0
        assert environment._event_runtime._fired == [True]
        assert environment._release_command is not None
        assert environment._release_command == first_command
        environment.step(_action(environment))
        assert environment._event_runtime._fired == [True]
        assert environment._release_command == first_command
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "seed"),
    [
        ("t4_sphere", 0),
        ("t4_sphere_tabletop", 0),
        ("t4_slider", 10),
        ("t4_can", 9),
    ],
)
def test_t4_release_event_twist_is_native_reset_state_and_repeatable(
    task_id: str,
    seed: int,
) -> None:
    scenario = _proposal(task_id, seed)
    environment = make_env(task_id, scenario)
    records = []
    try:
        for _ in range(2):
            environment.reset()
            assert environment._release_event_time_s == 0.0
            environment.step(_action(environment))
            assert environment._release_event_fired
            assert environment._release_event_time_s == 0.0
            assert environment._release_linear_speed_m_s is not None
            assert environment._release_angular_speed_rad_s is not None
            assert environment._release_linear_speed_m_s <= 0.005
            assert environment._release_angular_speed_rad_s <= 0.05
            assert environment._outcome.release_impulse_n_s <= 0.002
            if task_id in ("t4_slider", "t4_can"):
                for _ in range(environment._task_spec.episode_horizon_steps - 1):
                    if environment._release_pre_robot_physics_steps == 25 or environment.done:
                        break
                    environment.step(_action(environment))
                assert environment._release_pre_robot_physics_steps == 25
                assert environment._release_interval_first_time_s is not None
                assert environment._release_interval_last_time_s == pytest.approx(
                    environment._release_interval_first_time_s + 24 * 0.002,
                    rel=0.0,
                    abs=1e-12,
                )
                assert environment._release_along_slope_velocity_gain_m_s is not None
                assert environment._release_mean_along_slope_acceleration_m_s2 is not None
                assert environment._release_along_slope_velocity_gain_m_s > 0.0
                assert environment._release_mean_along_slope_acceleration_m_s2 > 0.0
            assert environment._release_dynamics_rejection() is None
            records.append(
                (
                    environment._release_event_time_s,
                    environment._release_linear_speed_m_s,
                    environment._release_angular_speed_rad_s,
                    environment._outcome.release_impulse_n_s,
                    environment._release_interval_first_time_s,
                    environment._release_interval_last_time_s,
                    environment._release_along_slope_velocity_gain_m_s,
                    environment._release_mean_along_slope_acceleration_m_s2,
                )
            )
        assert records[0] == records[1]
    finally:
        environment.close()


def test_t4_post_release_native_twist_does_not_redefine_the_tick_zero_event_fact() -> None:
    environment = make_env("t4_sphere", _proposal("t4_sphere"))
    try:
        environment.reset()
        environment.step(_action(environment))
        event_fact = (
            environment._release_event_time_s,
            environment._release_linear_speed_m_s,
            environment._release_angular_speed_rad_s,
        )
        target_ids = frozenset(environment._target_geom_ids)
        gate_ids = frozenset(environment._gate_geom_ids)
        for _ in range(environment._task_spec.episode_horizon_steps - 1):
            if not _has_contact_between(environment.sim.data._data, target_ids, gate_ids):
                break
            assert not environment.done
            environment.step(_action(environment))
        assert not _has_contact_between(environment.sim.data._data, target_ids, gate_ids)
        velocity = np.empty(6, dtype=np.float64)
        mujoco.mj_objectVelocity(
            environment.sim.model._model,
            environment.sim.data._data,
            mujoco.mjtObj.mjOBJ_XBODY,
            environment._target_body_id,
            velocity,
            0,
        )
        assert np.linalg.norm(velocity[3:]) > 0.005 or np.linalg.norm(velocity[:3]) > 0.05
        assert (
            environment._release_event_time_s,
            environment._release_linear_speed_m_s,
            environment._release_angular_speed_rad_s,
        ) == event_fact
        assert environment._release_dynamics_rejection() is None
    finally:
        environment.close()


def test_t4_release_twist_limits_are_exact_without_a_tolerance_extension() -> None:
    environment = make_env("t4_sphere", _proposal("t4_sphere"))
    try:
        environment.reset()
        environment._release_event_time_s = 0.0
        environment._release_linear_speed_m_s = 0.005
        environment._release_angular_speed_rad_s = 0.05
        assert environment._release_dynamics_rejection() is None
        environment._release_linear_speed_m_s = math.nextafter(0.005, math.inf)
        assert environment._release_dynamics_rejection() == "release_twist_exceeded"
        environment._release_linear_speed_m_s = 0.005
        environment._release_angular_speed_rad_s = math.nextafter(0.05, math.inf)
        assert environment._release_dynamics_rejection() == "release_twist_exceeded"
    finally:
        environment.close()


def test_t4_real_supported_motion_rejects_nonpositive_native_along_slope_gain() -> None:
    scenario = _proposal("t4_slider", 10)
    scenario = replace(
        scenario,
        physics=replace(scenario.physics, gravity_world_m_s2=(0.0, -3.0, -9.81)),
    )
    environment = make_env("t4_slider", scenario)
    try:
        environment.reset()
        environment.step(_action(environment))
        assert environment._release_pre_robot_physics_steps == 25
        assert environment._release_along_slope_velocity_gain_m_s is not None
        assert environment._release_mean_along_slope_acceleration_m_s2 is not None
        assert environment._release_along_slope_velocity_gain_m_s < 0.0
        assert environment._release_mean_along_slope_acceleration_m_s2 < 0.0
        assert environment._release_dynamics_rejection() == "nonpositive_along_slope_dynamics"
    finally:
        environment.close()


def _outcome_sample(outcome: _FreeDynamicsOutcome, **changes: Any) -> None:
    sample: dict[str, Any] = {
        "time_s": (outcome.physics_step + 1) * 0.002,
        "finite": True,
        "position": np.asarray((0.0, 0.0, 0.90), dtype=np.float64),
        "ramp_coordinate_m": np.asarray((0.0, 0.0, 0.0), dtype=np.float64),
        "planar_speed_m_s": 0.10,
        "eef_distance_m": 0.05,
        "ramp_exited": False,
        "target_gate_impulse_n_s": 0.0,
        "target_downstream_contact": False,
        "robot_target_contact": False,
        "robot_ramp_contact": False,
        "left": False,
        "right": False,
        "can_axis_vertical_alignment": 0.0,
    }
    sample.update(changes)
    outcome.update(**sample)


def _outcome(task_id: str) -> _FreeDynamicsOutcome:
    task = load_task(task_id)
    recipe = _select_recipe(
        _document(task_id), partition="test_id", factor=None, recipe_name="e7_agentview"
    )
    scenario = _materialize_recipe(task, recipe, np.random.default_rng(0))
    outcome = _FreeDynamicsOutcome(task, scenario.geometry)
    outcome.begin(eef_distance_m=0.30)
    return outcome


def test_t4_outcome_requires_explicit_scored_start_initialization() -> None:
    outcome = _outcome("t4_sphere")
    outcome.reset()
    for invalid_distance in (math.nan, math.inf, math.nextafter(0.0, -math.inf)):
        with pytest.raises(ValueError, match="finite non-negative"):
            outcome.begin(eef_distance_m=invalid_distance)
    with pytest.raises(RuntimeError, match=r"begin\(\) at scored t0"):
        _outcome_sample(outcome)


@pytest.mark.parametrize(
    ("task_id", "changes", "failure"),
    [
        ("t4_sphere", {"finite": False, "robot_ramp_contact": True}, "invalid_state"),
        (
            "t4_sphere",
            {"robot_ramp_contact": True, "target_gate_impulse_n_s": 1.0},
            "release_impulse",
        ),
        ("t4_sphere", {"robot_ramp_contact": True}, "unsafe_contact"),
        ("t4_sphere", {"left": True}, "early_robot_contact"),
        ("t4_sphere", {"target_downstream_contact": True}, "tray_contact"),
        (
            "t4_can",
            {"can_axis_vertical_alignment": math.nextafter(0.45, math.inf)},
            "unstable_tipping",
        ),
        (
            "t4_sphere",
            {"ramp_coordinate_m": np.asarray((math.nextafter(0.25, math.inf), 0.0, 0.0))},
            "workspace_exit",
        ),
        (
            "t4_sphere",
            {"ramp_coordinate_m": np.asarray((0.0, math.nextafter(0.48, math.inf), 0.0))},
            "downstream_exit",
        ),
        (
            "t4_sphere",
            {"position": np.asarray((0.0, 0.0, math.nextafter(0.805, -math.inf)))},
            "drop",
        ),
        (
            "t4_slider",
            {"position": np.asarray((math.nextafter(0.135, math.inf), 0.0, 0.9))},
            "workspace_exit",
        ),
        ("t4_slider", {"position": np.asarray((0.0, 0.20, 0.9))}, "downstream_exit"),
        (
            "t4_slider",
            {"position": np.asarray((0.0, 0.0, math.nextafter(0.785, -math.inf)))},
            "drop",
        ),
    ],
)
def test_t4_outcome_preserves_db0_failure_order_and_native_boundaries(
    task_id: str,
    changes: dict[str, Any],
    failure: str,
) -> None:
    outcome = _outcome(task_id)
    _outcome_sample(outcome, **changes)
    assert outcome.failure_code == failure and outcome.terminal_time_s == 0.002
    if failure == "invalid_state":
        assert failure not in outcome.events
    else:
        assert outcome.events[failure] == outcome.terminal_time_s


def test_t4_clearance_uses_com_at_bilateral_hold_and_consecutive_dwell() -> None:
    outcome = _outcome("t4_can")
    contact = {
        "ramp_exited": True,
        "target_downstream_contact": True,
        "position": np.asarray((0.0, 0.0, 0.823)),
        "planar_speed_m_s": 0.08,
        "left": True,
        "right": True,
    }
    for _ in range(24):
        _outcome_sample(outcome, **contact)
    assert "bilateral_hold" not in outcome.events
    _outcome_sample(outcome, **{**contact, "right": False})
    assert outcome.bilateral_steps == 0
    for _ in range(25):
        _outcome_sample(outcome, **contact)
    assert outcome.capture_reference_com_z_m == 0.823
    lift_z = 0.823 + outcome.success_spec.minimum_lift_or_clearance_m
    below = {**contact, "position": np.asarray((0.0, 0.0, math.nextafter(lift_z, -math.inf)))}
    for _ in range(250):
        _outcome_sample(outcome, **below)
    assert outcome.stable_steps == 0 and not outcome.success
    lifted = {**contact, "position": np.asarray((0.0, 0.0, math.nextafter(lift_z, math.inf)))}
    for _ in range(249):
        _outcome_sample(outcome, **lifted)
    assert not outcome.success
    _outcome_sample(outcome, **{**lifted, "left": False})
    assert outcome.stable_steps == 0
    for _ in range(250):
        _outcome_sample(outcome, **lifted)
    assert outcome.success and outcome.failure_code is None
    assert outcome.events["success"] == outcome.events["stable_dwell"] == outcome.terminal_time_s


def test_t4_raw_bilateral_counter_precedes_ordered_stages() -> None:
    outcome = _outcome("t4_can")
    contact = {"ramp_exited": True, "target_downstream_contact": True, "left": True, "right": True}
    _outcome_sample(outcome, **contact, eef_distance_m=0.20)
    assert "approach" not in outcome.events and outcome.bilateral_steps == 1
    _outcome_sample(outcome, **contact, eef_distance_m=0.10)
    assert "fingerpad_contact" in outcome.events and outcome.bilateral_steps == 2


@pytest.mark.parametrize(
    ("change", "failure"),
    [
        (
            {"position": np.asarray((math.nextafter(0.12, math.inf), 0.0, 0.90))},
            "early_robot_contact",
        ),
        ({"target_downstream_contact": False}, "early_robot_contact"),
        ({"ramp_exited": False}, "early_robot_contact"),
        ({"planar_speed_m_s": math.nextafter(0.08, -math.inf)}, "stop_or_deflect_only"),
    ],
)
def test_t4_supported_first_single_pad_contact_is_eligible_or_terminal(
    change: dict[str, Any],
    failure: str,
) -> None:
    outcome = _outcome("t4_can")
    contact = {"ramp_exited": True, "target_downstream_contact": True, "left": True}
    _outcome_sample(outcome, **{**contact, **change})
    assert outcome.failure_code == failure
    assert outcome.events[failure] == outcome.terminal_time_s
    assert "fingerpad_contact" not in outcome.events


def test_t4_can_tipping_gate_ends_when_capture_contact_begins() -> None:
    outcome = _outcome("t4_can")
    contact = {
        "ramp_exited": True,
        "target_downstream_contact": True,
        "left": True,
        "can_axis_vertical_alignment": 0.9,
    }
    _outcome_sample(outcome, **contact)
    assert outcome.failure_code is None and "fingerpad_contact" in outcome.events
    _outcome_sample(outcome, can_axis_vertical_alignment=0.9)
    assert outcome.failure_code is None


def test_t4_supported_exit_gate_ends_at_bilateral_hold() -> None:
    outcome = _outcome("t4_slider")
    contact = {"ramp_exited": True, "target_downstream_contact": True, "left": True, "right": True}
    for _ in range(outcome.hold_steps):
        _outcome_sample(outcome, **contact)
    assert "bilateral_hold" in outcome.events
    _outcome_sample(outcome, **contact, position=np.asarray((0.0, 0.22, 0.90)))
    assert outcome.failure_code is None


def test_t4_stop_gate_counts_supported_uncontacted_motion_only() -> None:
    outcome = _outcome("t4_slider")
    stopped = {"ramp_exited": True, "target_downstream_contact": True, "planar_speed_m_s": 0.03}
    for _ in range(124):
        _outcome_sample(outcome, **stopped)
    assert outcome.failure_code is None
    _outcome_sample(outcome, **{**stopped, "target_downstream_contact": False})
    assert outcome.stopped_steps == 0
    for _ in range(125):
        _outcome_sample(outcome, **stopped)
    assert outcome.failure_code == "stop_or_deflect_only"
    assert outcome.events["stop_or_deflect_only"] == outcome.terminal_time_s
    outcome.reset()
    outcome.begin(eef_distance_m=0.3)
    for _ in range(3000):
        _outcome_sample(outcome)
    assert outcome.failure_code == "timeout" and outcome.terminal_time_s == 6.0
    assert outcome.events["timeout"] == outcome.terminal_time_s


def test_t4_non_pad_robot_contact_is_not_unsupported_capture_eligibility() -> None:
    outcome = _outcome("t4_sphere")
    _outcome_sample(outcome, robot_target_contact=True)
    assert outcome.failure_code is None and "fingerpad_contact" not in outcome.events


def test_t4_oracle_spatial_twist_reorders_native_angular_linear_components() -> None:
    native = np.asarray((1.0, 2.0, 3.0, 4.0, 5.0, 6.0), dtype=np.float64)
    spatial = _mujoco_twist_to_spatial(native)
    np.testing.assert_array_equal(spatial, (4.0, 5.0, 6.0, 1.0, 2.0, 3.0))
    np.testing.assert_array_equal(native, (1.0, 2.0, 3.0, 4.0, 5.0, 6.0))


def test_t4_factory_rejects_malformed_release_event_shapes_as_value_errors() -> None:
    scenario = _proposal("t4_sphere")
    event = scenario.events[0]
    assert isinstance(event.trigger, TimeTriggerSpec)
    wrong_tick = replace(event, trigger=replace(event.trigger, control_tick=1))
    extra_event = replace(event, event_id="other_release_gate")
    for events in ((), (event, extra_event), (wrong_tick,)):
        with pytest.raises(ValueError, match="T4 .*requires"):
            make_env("t4_sphere", replace(scenario, events=events))


def test_t4_real_mujoco_bad_qpos_is_invalid_before_native_recovery(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    environment = make_env("t4_sphere", _proposal("t4_sphere"))
    try:
        environment.reset()
        monkeypatch.chdir(tmp_path)
        environment.sim.data.qpos[environment._target_qpos_address] = math.nan
        _, _, done, info = environment.step(_action(environment))
        assert done and not info["success"]
        assert info["failure_code"] == "invalid_state"
        assert info["terminal_time_s"] == 0.0
    finally:
        environment.close()


@pytest.mark.parametrize(
    ("task_id", "reason"),
    [
        ("t4_sphere", "target_release_twist_not_settled"),
        ("t4_sphere_tabletop", "target_not_supported_by_ramp"),
        ("t4_slider", "target_not_supported_by_ramp"),
        ("t4_can", "target_release_twist_not_settled"),
    ],
)
def test_t4_physical_feasibility_rejects_an_initial_target_outside_its_ramp(
    task_id: str,
    reason: str,
) -> None:
    scenario = _proposal(task_id)
    target = replace(scenario.object_states[0], position_world_m=(0.0, 0.30, 1.10))
    # Reset owns the original settled-twist gate; feasibility additionally checks support.
    with pytest.raises(feasibility_module._CaptureProposalRejected, match=reason):
        feasibility_module._validate_free_dynamics_physical_scenario(
            load_task(task_id), replace(scenario, object_states=(target,))
        )


@pytest.mark.parametrize(
    ("task_id", "name", "expected_failure"),
    [
        ("t4_sphere", "e7_agentview", None),
        ("t4_sphere_tabletop", "e7_agentview", None),
        ("t4_slider", "e7_agentview", None),
        ("t4_sphere", "j8_agentview", None),
        ("t4_sphere_tabletop", "j8_agentview", "downstream_exit"),
        ("t4_slider", "j8_agentview", None),
    ],
)
def test_public_t4_generator_preserves_seed_zero_oracle_acceptance_or_rejection(
    task_id: str,
    name: str,
    expected_failure: str | None,
) -> None:
    if expected_failure is None:
        generated = generate_scenario(
            load_task(task_id),
            ROOT / f"configs/scenarios/{task_id}.yaml",
            0,
            partition="test_id",
            recipe_name=name,
        )
        assert generated == _proposal(task_id, name=name)
    else:
        with pytest.raises(_CaptureProposalRejected) as caught:
            generate_scenario(
                load_task(task_id),
                ROOT / f"configs/scenarios/{task_id}.yaml",
                0,
                partition="test_id",
                recipe_name=name,
            )
        failure = caught.value
        assert failure.stage == "oracle"
        assert failure.failure_code == expected_failure
        assert failure.terminal_time_s is not None and failure.terminal_time_s > 0.0


def test_free_dynamics_real_oracle_runs_through_the_single_formal_rollout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    task = load_task("t4_sphere")
    scenario = _proposal(task.task_id, 0, "e7_agentview")
    environment = make_env(task.task_id, scenario)

    class OraclePolicy:
        oracle: _FreeDynamicsOracle | None = None

        def reset(self) -> None:
            self.oracle = _FreeDynamicsOracle(environment)

        def act(self, observation: BenchmarkObservation) -> BenchmarkAction:
            assert observation.tick == environment._episode_tick
            assert self.oracle is not None
            return self.oracle.action(environment)

    def existing_environment(
        task_id: str, compiled: ScenarioSpec, *, execution_translation_limit_m: float
    ) -> FreeDynamicsInterceptionEnv:
        assert execution_translation_limit_m == 0.05
        assert task_id == task.task_id and compiled == scenario
        assert isinstance(environment, FreeDynamicsInterceptionEnv)
        return environment

    monkeypatch.setattr(rollout_module, "make_env", existing_environment)
    trace = _rollout_episode(
        task,
        scenario,
        OraclePolicy(),
        scenario_id="v1:test_id:t4_sphere:000000",
        partition="test_id",
        factor=None,
        repeat_index=0,
    )
    assert trace.success and trace.failure_code is None
    assert trace.steps[-1].event_flags == (True,) * len(trace.event_names)
    assert tuple(step.applied_tick for step in trace.steps) == tuple(range(len(trace.steps)))
    assert _evaluate_episode(trace).success


@pytest.mark.parametrize(
    ("name", "seed", "angle_deg"),
    [
        ("e7_agentview", 9, 10),
        ("e7_agentview", 19, 10),
        ("e7_agentview", 18, 15),
        ("j8_agentview", 9, 10),
        ("j8_agentview", 19, 10),
        ("j8_agentview", 18, 15),
    ],
)
def test_public_can_oracle_screens_paired_scenarios_after_fast_bilateral_contact(
    seed: int,
    angle_deg: int,
    name: str,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    samples: list[tuple[float, bool, bool, bool, float]] = []
    native_update = _FreeDynamicsOutcome.update

    def observe_update(self: _FreeDynamicsOutcome, **sample: Any) -> None:
        if self.can:
            samples.append(
                (
                    sample["time_s"],
                    sample["left"],
                    sample["right"],
                    sample["target_downstream_contact"],
                    sample["planar_speed_m_s"],
                )
            )
        native_update(self, **sample)

    monkeypatch.setattr(_FreeDynamicsOutcome, "update", observe_update)
    if name == "j8_agentview" and seed == 19:
        # The native oracle rejects this fixed proposal before accepting a scenario.
        with pytest.raises(
            feasibility_module._CaptureProposalRejected, match="stop_or_deflect_only"
        ):
            generate_scenario(
                load_task("t4_can"),
                ROOT / "configs/scenarios/t4_can.yaml",
                seed,
                partition="test_id",
                recipe_name=name,
            )
        return
    generated = generate_scenario(
        load_task("t4_can"),
        ROOT / "configs/scenarios/t4_can.yaml",
        seed,
        partition="test_id",
        recipe_name=name,
    )
    assert generated == _proposal("t4_can", seed, name)
    assert math.degrees(generated.geometry.ramp_angle_rad) == pytest.approx(angle_deg)
    first = next(item for item in samples if item[1] or item[2])
    assert first[3]
    assert first[4] >= 0.08
    assert not any(item[1] and item[2] for item in samples if item[0] < first[0])


@pytest.mark.parametrize(
    ("seed", "name", "precontact_events"),
    [
        (4, "e7_agentview", ("approach", "ramp_exit")),
        (14, "j8_agentview", ("ramp_exit", "approach")),
    ],
)
def test_public_can_generator_preserves_restored_fixed_input_success(
    seed: int,
    name: str,
    precontact_events: tuple[str, str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    terminal_facts: list[tuple[float, int, bool, str | None]] = []
    terminal_infos: list[dict[str, Any]] = []
    native_update = _FreeDynamicsOutcome.update
    native_oracle = feasibility_module._run_native_oracle

    def observe_update(self: _FreeDynamicsOutcome, **sample: Any) -> None:
        before = self.terminal_time_s
        native_update(self, **sample)
        if before is None and self.terminal_time_s is not None:
            terminal_facts.append(
                (sample["time_s"], self.physics_step, self.success, self.failure_code)
            )

    def observe_oracle(environment: FreeDynamicsInterceptionEnv) -> dict[str, Any]:
        info = native_oracle(environment)
        terminal_infos.append(
            {key: info[key] for key in ("success", "failure_code", "terminal_time_s", "events")}
        )
        return info

    monkeypatch.setattr(_FreeDynamicsOutcome, "update", observe_update)
    monkeypatch.setattr(feasibility_module, "_run_native_oracle", observe_oracle)
    for repeat in range(2):
        generated = generate_scenario(
            load_task("t4_can"),
            ROOT / "configs/scenarios/t4_can.yaml",
            seed,
            partition="test_id",
            recipe_name=name,
        )
        assert generated == _proposal("t4_can", seed, name)
        assert len(terminal_facts) == len(terminal_infos) == repeat + 1
        fact_time_s, physics_step, success, failure_code = terminal_facts[-1]
        info = terminal_infos[-1]
        assert success and info["success"]
        assert failure_code is info["failure_code"] is None
        assert info["terminal_time_s"] == fact_time_s
        assert fact_time_s == pytest.approx(physics_step * 0.002, rel=0.0, abs=1e-12)
        assert tuple(info["events"]) == (
            "release_gate_opens",
            *precontact_events,
            "fingerpad_contact",
            "bilateral_hold",
            "clearance",
            "stable_dwell",
            "success",
        )
        assert info["events"]["success"] == info["events"]["stable_dwell"] == fact_time_s
    assert terminal_infos[0] == terminal_infos[1]


@pytest.mark.parametrize(
    ("task_id", "partition", "factor", "name", "representation", "seed", "delay_steps"),
    [
        ("t4_sphere", "ood", "action_delay", "e7_agentview", "delta", 2, 1),
        ("t4_sphere", "ood", "action_delay", "e7_agentview_wrist", "absolute", 2, 1),
        ("t4_sphere", "ood", "action_delay", "j8_agentview", "delta", 6, 2),
        ("t4_sphere", "ood", "action_delay", "j8_agentview_wrist", "absolute", 6, 2),
        ("t4_can", "test_id", None, "j8_agentview", "delta", 9, 0),
    ],
)
def test_t4_public_manifest_repeat_reset_and_fixed_action_replay_are_exact(
    task_id: str,
    partition: Partition,
    factor: str | None,
    name: str,
    representation: str,
    seed: int,
    delay_steps: int,
    tmp_path: Path,
) -> None:
    scenario = _proposal(task_id, seed, name, partition=partition, factor=factor)
    assert scenario.action_delay_steps == delay_steps
    first = make_env(task_id, scenario)
    second: FreeDynamicsInterceptionEnv | None = None
    try:
        raw = first.reset()
        initial_state = _state(first)
        initial_observation = first._benchmark_observation(raw)
        for _ in range(3):
            first.step(_action(first, representation, displacement=0.0001, gripper=-1.0))
        raw = first.reset()
        _assert_state_equal(initial_state, _state(first))
        assert first._action_spec is first._action_delay_queue is None
        assert first._previous_eef_quaternion_xyzw is None
        assert first._outcome.events == {"release_gate_opens": 0.0}
        assert first._outcome.physics_step == 0
        assert not first._outcome.capture_attempted
        reset_observation = first._benchmark_observation(raw)
        for field in fields(reset_observation):
            np.testing.assert_array_equal(
                getattr(reset_observation, field.name),
                getattr(initial_observation, field.name),
            )

        manifest = ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    f"v1:{partition}:{factor + ':' if factor is not None else ''}{task_id}:000000",
                    task_id,
                    partition,
                    factor,
                    seed,
                    first.export_scenario(),
                ),
            )
        )
        path = tmp_path / "free-dynamics.jsonl"
        write_manifest(manifest, path)
        assert load_manifest(path) == manifest
        second = make_env(task_id, load_manifest(path).rows[0].scenario)
        second_raw = second.reset()
        second_observation = second._benchmark_observation(second_raw)
        assert second.export_scenario() == scenario
        for field in (
            "body_mass",
            "body_inertia",
            "body_iquat",
            "body_ipos",
            "geom_type",
            "geom_size",
            "geom_pos",
            "geom_quat",
            "geom_bodyid",
            "geom_friction",
            "geom_solref",
            "geom_solimp",
            "jnt_type",
            "jnt_axis",
            "jnt_range",
            "dof_damping",
            "dof_frictionloss",
            "actuator_gear",
            "actuator_ctrlrange",
            "cam_pos",
            "cam_quat",
            "cam_fovy",
            "light_type",
            "light_pos",
            "light_dir",
            "light_diffuse",
            "light_specular",
        ):
            np.testing.assert_array_equal(
                getattr(first.sim.model._model, field),
                getattr(second.sim.model._model, field),
                err_msg=field,
            )
        for tick in range(7):
            _assert_state_equal(_state(first), _state(second))
            left = reset_observation if tick == 0 else first._benchmark_observation(raw)
            right = second_observation if tick == 0 else second._benchmark_observation(second_raw)
            for field in fields(left):
                np.testing.assert_array_equal(
                    getattr(left, field.name), getattr(right, field.name), err_msg=field.name
                )
            if tick < 6:
                action = _action(
                    first,
                    representation,
                    displacement=0.0001 * ((tick % 3) - 1),
                    gripper=-1.0,
                )
                raw, first_reward, first_done, first_info = first.step(action)
                second_raw, second_reward, second_done, second_info = second.step(action)
                assert (first_reward, first_done, first_info) == (
                    second_reward,
                    second_done,
                    second_info,
                )
    finally:
        first.close()
        if second is not None:
            second.close()


@pytest.mark.parametrize("task_id", TASKS)
def test_t4_physics_ood_changes_native_effective_contact_and_replays_exactly(
    task_id: str,
    tmp_path: Path,
) -> None:
    identity = _proposal(task_id)
    intervention = _proposal(task_id, partition="ood", factor="physics")
    identity_env = make_env(task_id, identity)
    intervention_env = make_env(task_id, intervention)
    replay_env: FreeDynamicsInterceptionEnv | None = None
    try:
        identity_env.reset()
        intervention_env.reset()
        identity_friction = _target_ramp_contact_friction(identity_env)
        intervention_friction = _target_ramp_contact_friction(intervention_env)
        assert intervention_friction[0] != identity_friction[0]
        assert intervention_env.export_scenario() == intervention

        manifest = ScenarioManifest(
            (
                ScenarioManifestRow(
                    1,
                    "v1",
                    f"v1:ood:physics:{task_id}:000000",
                    task_id,
                    "ood",
                    "physics",
                    0,
                    intervention_env.export_scenario(),
                ),
            )
        )
        path = tmp_path / f"{task_id}-physics.jsonl"
        write_manifest(manifest, path)
        loaded = load_manifest(path)
        assert loaded == manifest
        replay_env = make_env(task_id, loaded.rows[0].scenario)
        replay_env.reset()
        np.testing.assert_array_equal(
            _target_ramp_contact_friction(replay_env), intervention_friction
        )
        _assert_state_equal(_state(intervention_env), _state(replay_env))

        identity_env.step(_action(identity_env))
        intervention_env.step(_action(intervention_env))
        replay_env.step(_action(replay_env))
        intervention_velocity = intervention_env.sim.data._data.qvel[
            intervention_env._target_qvel_address : intervention_env._target_qvel_address + 6
        ]
        identity_velocity = identity_env.sim.data._data.qvel[
            identity_env._target_qvel_address : identity_env._target_qvel_address + 6
        ]
        assert not np.array_equal(intervention_velocity, identity_velocity)
        _assert_state_equal(_state(intervention_env), _state(replay_env))
    finally:
        identity_env.close()
        intervention_env.close()
        if replay_env is not None:
            replay_env.close()


def test_t4_target_native_state_writes_are_confined_to_reset_preparation() -> None:
    module = inspect.getmodule(FreeDynamicsInterceptionEnv)
    assert module is not None
    tree = ast.parse(inspect.getsource(module))
    for function in ast.walk(tree):
        if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)) or function.name in {
            "_reset_internal",
            "reset",
        }:
            continue
        for node in ast.walk(function):
            if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Attribute):
                if node.value.attr in {"qpos", "qvel", "xfrc_applied", "qfrc_applied"}:
                    assert not isinstance(node.ctx, ast.Store), function.name


def test_all_t4_recipe_names_use_one_explicit_robot_pose_per_task() -> None:
    for task_id in TASKS:
        states = []
        document = _document(task_id)
        for partition in ("train", "validation", "test_id", "stress"):
            states.extend(
                alternative["robot_initial_state"]
                for recipe in document["recipes"][partition].values()
                for alternative in (recipe["choices"] if partition == "stress" else [recipe])
            )
        for recipes in document["recipes"]["ood"].values():
            states.extend(recipe["robot_initial_state"] for recipe in recipes.values())
        assert len(states) == (48 if task_id == "t4_sphere" else 52)
        assert states and all(state == states[0] for state in states)
