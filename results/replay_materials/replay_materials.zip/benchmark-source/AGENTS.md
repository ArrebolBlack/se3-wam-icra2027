# Repository working rules

- The frozen Dynamic Benchmark architecture page is the sole TO-BE design authority.
- Structural changes proceed inventory, classification, target contract, contract tests,
  deletion-first rebuild, and boundary-by-boundary verification.
- Do not add packages, public concepts, compatibility paths, fallbacks, hashes, receipts,
  or governance layers without project-owner approval.
- Keep task declarations, scenario recipes, concrete manifests, action semantics,
  observation visibility, success facts, episode schema, metrics, and suite membership in
  their documented single owners.
- Fail explicitly on invalid input or missing implementation. Do not guess fields, coerce
  incompatible values, swallow exceptions, or preserve retired imports.
- Use one writer per branch/worktree. Integrate completed candidates serially through
  `main`; do not develop directly on `main`.
