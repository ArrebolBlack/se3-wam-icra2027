"""Application-owned instrumentation around the official evaluator CLI."""
import argparse
import json
import logging
import math
import os
from pathlib import Path
import time

import sys as _source_sys
_pro_root = Path('/public_fast_storage/se3wam/yjq/history-pro6000-20261011-a1')
for _source in (_pro_root / 'model-source-v2/src', _pro_root / 'openwam', _pro_root / 'deps'):
    _source_sys.path.insert(0, str(_source))
import se3_wam as _actual_model_source
if Path(_actual_model_source.__file__).resolve() != (_pro_root / 'model-source-v2/src/se3_wam/__init__.py').resolve():
    raise RuntimeError('PRO6000 worker imported the wrong accepted model source')

ROOT = Path(__file__).resolve().parent
_policy = None
_events = []
_phase = 'startup'
_episode_index = -1


class ProductActionFormatter(logging.Formatter):
    def format(self, record):
        row = json.loads(record.getMessage())
        row.update(measurement_phase=_phase, measurement_episode=_episode_index,
                   logged_at=record.created)
        return json.dumps(row, allow_nan=False)


def event(kind, **values):
    row = dict(kind=kind, phase=_phase, t=time.time(), **values)
    _events.append(row)
    if kind != 'act':
        print(json.dumps(row), flush=True)


class MeasuredPolicy:
    def __init__(self, model, adapter, out):
        self.model = model
        self.adapter = adapter
        self.out = out

    def reset(self):
        global _episode_index
        _episode_index += 1
        self.adapter.reset()
        event('reset', episode_index=_episode_index)

    def act(self, observation):
        start = time.time()
        try:
            action = self.adapter.act(observation)
        except Exception as error:
            # Read failed action values from the original traceback; never repair or retry.
            import torch
            diagnostic = dict(error=str(error), tick=observation.tick,
                              physical_s=observation.timestamp_s, frames=[])
            trace = error.__traceback__
            while trace is not None:
                frame = trace.tb_frame
                if frame.f_code.co_name in ('_physical_action_chunk', 'validate_physical_action'):
                    values = dict(function=frame.f_code.co_name, line=trace.tb_lineno)
                    for key in ('physical', 'execution', 'selected'):
                        value = frame.f_locals.get(key)
                        if isinstance(value, torch.Tensor):
                            values[key] = value.detach().cpu().tolist()
                    spec = frame.f_locals.get('action_spec')
                    values['action_spec'] = str(spec)
                    selected = frame.f_locals.get('selected')
                    if isinstance(selected, torch.Tensor) and spec.representation == 'delta':
                        motion = selected[:, :spec.gripper_index].detach().cpu()
                        limits = torch.tensor(spec.motion_limits, dtype=motion.dtype)
                        exceeded = motion.abs() > limits
                        values.update(limits=limits.tolist(), max_abs_per_axis=motion.abs().amax(dim=0).tolist(),
                                      exceeded_cells=int(exceeded.sum()), exceeded_rows=int(exceeded.any(dim=1).sum()),
                                      exceeded_cells_per_axis=exceeded.sum(dim=0).tolist(),
                                      first_action=selected[0].detach().cpu().tolist())
                    diagnostic['frames'].append(values)
                trace = trace.tb_next
            (self.out/'action-error.json').write_text(json.dumps(diagnostic, indent=2))
            raise
        event('act', start=start, tick=observation.tick, physical_s=observation.timestamp_s,
              episode_index=_episode_index)
        if observation.tick % 40 == 0:
            print(json.dumps(dict(kind='progress', phase=_phase, tick=observation.tick, t=time.time())), flush=True)
        return action


def make_policy():
    return _policy


def evaluate_with_terminal_risk(evaluate_cli, argv, task_id, output):
    """Capture existing terminal Env info after each step without changing rollout decisions."""
    from se3_wam_benchmark.evaluation import rollout

    original = rollout._step_outcome
    tick = 0
    terminal = None

    def observed(info, *, done):
        nonlocal tick, terminal
        outcome = original(info, done=done)
        current_tick = tick
        tick += 1
        if done:
            if terminal is not None:
                raise RuntimeError('multiple terminal steps in one scenario')
            stages = info['stage_facts']
            events = info['events']
            if not isinstance(stages, tuple) or not isinstance(events, dict):
                raise RuntimeError('terminal stage facts or events unavailable')
            completed = [name for name, reached, _, _ in stages if reached]
            active = next((name for name, reached, _, _ in stages if not reached), None)
            terminal = dict(
                task_id=task_id, terminal_tick=current_tick,
                terminal_time_s=outcome[2], success=outcome[0],
                failure_code=outcome[1], completed_stages=completed,
                active_stage=active,
                stage_facts=[dict(name=name, completed=reached, progress=progress,
                                  consecutive_steps=consecutive)
                             for name, reached, progress, consecutive in stages],
                events=dict(events),
            )
            if task_id in ('t3_full', 't3_phase'):
                for key in ('maximum_wire_impulse_n_s', 'maximum_penetration_m'):
                    value = info[key]
                    if not isinstance(value, (int, float)) or not math.isfinite(value):
                        raise RuntimeError(f'invalid terminal {key}')
                    terminal[key] = float(value)
        return outcome

    rollout._step_outcome = observed
    try:
        evaluate_cli(argv)
    finally:
        rollout._step_outcome = original
    if terminal is None:
        raise RuntimeError('evaluation ended without terminal Env info')
    result = json.loads(output.read_text())['results']
    if len(result) != 1:
        raise RuntimeError('terminal observation requires a single-scenario evaluation')
    row = result[0]
    if (row['task_id'] != task_id or row['success'] != terminal['success']
            or row['failure_code'] != terminal['failure_code']
            or row['episode_steps'] != terminal['terminal_tick'] + 1):
        raise RuntimeError('terminal observation disagrees with official result')
    terminal['scenario_id'] = row['scenario_id']
    output.with_suffix('.risk.json').write_text(json.dumps(terminal, allow_nan=False, sort_keys=True))


def main():
    global _policy, _phase
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--suite', type=Path, required=True)
    parser.add_argument('--shard-index', type=int, required=True)
    parser.add_argument('--shard-count', type=int, required=True)
    parser.add_argument('--start-file', type=Path, required=True)
    parser.add_argument('--bundle', required=True)
    parser.add_argument('--execution-translation-limit-m', type=float, choices=(0.05,0.10), default=0.05)
    parser.add_argument('--warmup-suite', type=Path, required=True)
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--terminal-risk-observation', action='store_true')
    args = parser.parse_args()
    assert args.threads>=1 and args.threads<=len(os.sched_getaffinity(0))
    action_log = args.out/'model-actions.jsonl'
    action_handler = logging.FileHandler(action_log, mode='w', encoding='utf-8')
    action_handler.setFormatter(ProductActionFormatter())
    action_logger = logging.getLogger('se3_wam.inference.executor')
    action_logger.setLevel(logging.INFO)
    action_logger.propagate = False
    action_logger.addHandler(action_handler)
    applied_log = args.out/'benchmark-actions.jsonl'
    applied_handler = logging.FileHandler(applied_log, mode='w', encoding='utf-8')
    applied_handler.setFormatter(ProductActionFormatter())
    applied_logger = logging.getLogger('se3_wam_benchmark.evaluation.rollout')
    applied_logger.setLevel(logging.INFO)
    applied_logger.propagate = False
    applied_logger.addHandler(applied_handler)
    started = time.time()
    event('process_start', pid=os.getpid(), affinity=sorted(os.sched_getaffinity(0)))
    import cv2
    import torch
    # Robosuite 1.5.2 validates EGLID as a numeric substring of CVD at import.
    # UUID CUDA binding and EGL device ordinals are distinct: preserve both for
    # actual execution, and omit EGLID only while that import-time check runs.
    saved_cuda_visible_devices = os.environ["CUDA_VISIBLE_DEVICES"]
    saved_egl_device_id = os.environ["MUJOCO_EGL_DEVICE_ID"]
    if not saved_cuda_visible_devices.isdigit() or not os.environ.get("SE3WAM_NVML_UUID", "").startswith("GPU-"):
        raise RuntimeError("one numeric CUDA device and its independently checked NVML UUID are required by this worker")
    if not saved_egl_device_id.isdigit() or torch.cuda.is_initialized():
        raise RuntimeError("explicit EGL ordinal and no initialized CUDA required before robosuite import")
    del os.environ["MUJOCO_EGL_DEVICE_ID"]
    try:
        import robosuite
    finally:
        os.environ["MUJOCO_EGL_DEVICE_ID"] = saved_egl_device_id
    from robosuite.renderers.context import egl_context
    if (os.environ["CUDA_VISIBLE_DEVICES"] != saved_cuda_visible_devices
            or os.environ["MUJOCO_EGL_DEVICE_ID"] != saved_egl_device_id
            or torch.cuda.is_initialized() or egl_context.EGL_DISPLAY is not None):
        raise RuntimeError("robosuite import changed device binding or initialized a GPU/context")
    event("robosuite_uuid_import_adapter", cuda_visible_device=saved_cuda_visible_devices, nvml_uuid=os.environ["SE3WAM_NVML_UUID"],
          egl_device_id=saved_egl_device_id, cuda_initialized=False, egl_display_created=False)
    from se3_wam.api import load_policy
    from se3_wam_benchmark.integrations.se3_wam import bind_policy
    from se3_wam_benchmark.cli.evaluate import main as evaluate_cli
    import sys
    sys.modules['rollout_capacity_policy'] = sys.modules[__name__]
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    cv2.setNumThreads(args.threads)
    torch.manual_seed(20260918)
    from device_binding_pro6000 import cuda_nvml_bindings
    bindings = cuda_nvml_bindings()
    if len(bindings) != 1 or bindings[0]["nvml_uuid"] != os.environ["SE3WAM_NVML_UUID"]:
        raise RuntimeError("worker CUDA/NVML PCI identity differs from the assigned GPU")
    torch.cuda.init()
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("one real CUDA device is required by this worker")
    load_start = time.time()
    model = load_policy(args.bundle)
    adapter = bind_policy(model, camera_geometry_enabled=True, observation_depth_enabled=True,
                          observation_flow_enabled=False, observation_anchor_enabled=False)
    _policy = MeasuredPolicy(model, adapter, args.out)
    event('model_loaded', load_s=time.time()-load_start, action_spec=str(model.action_spec),
          model_action_log=str(action_log), benchmark_action_log=str(applied_log))
    common = ['--policy', 'rollout_capacity_policy:make_policy']
    if args.execution_translation_limit_m != 0.05:
        common += ['--execution-translation-limit-m',str(args.execution_translation_limit_m)]
    report = dict(pid=os.getpid(), started=started, shard_index=args.shard_index,
                  shard_count=args.shard_count, bundle=args.bundle, threads=args.threads,
                  execution_translation_limit_m=args.execution_translation_limit_m,
                  affinity=sorted(os.sched_getaffinity(0)))
    try:
        _phase = 'warmup'
        warm_start = time.time()
        episodes = json.loads(args.suite.read_text())
        warmup = episodes[0]
        evaluate_cli(common + ['--suite', warmup['suite'], '--shard-index', str(warmup['shard_index']), '--shard-count', str(warmup['shard_count']),
                              '--output', str(args.out/'warmup.json')])
        report['warmup_wall_s'] = time.time()-warm_start
        report['startup_to_ready_s'] = time.time()-started
        event('ready')
        (args.out/'ready').write_text(str(time.time()))
        while not args.start_file.exists():
            time.sleep(0.1)
        target = float(args.start_file.read_text())
        while time.time() < target:
            time.sleep(min(0.05, target-time.time()))
        _phase = 'steady'
        report['steady_started'] = time.time()
        event('steady_start')
        episodes = json.loads(args.suite.read_text())
        assigned = [e for e in episodes if e['index'] % args.shard_count == args.shard_index]
        assert assigned
        files = []
        for episode in assigned:
            torch.manual_seed(episode['inference_seed'])
            output = args.out / f"episode-{episode['index']:03}.json"
            invocation = common + ['--suite', episode['suite'], '--shard-index', str(episode['shard_index']),
                                   '--shard-count', str(episode['shard_count']), '--output', str(output)]
            if args.terminal_risk_observation and episode['task_id'] in ('t2_se3', 't2_trans', 't3_full', 't3_phase'):
                evaluate_with_terminal_risk(evaluate_cli, invocation, episode['task_id'], output)
            else:
                evaluate_cli(invocation)
            files.append(dict(**episode, result=str(output)))
            (args.out/'completed-episodes.json').write_text(json.dumps(files, indent=2))
            event('episode_complete', scenario_id=episode['scenario_id'], result=str(output))
        (args.out/'evaluation.json').write_text(json.dumps(dict(episodes=files), indent=2))
        report['steady_ended'] = time.time()
        report['steady_wall_s'] = report['steady_ended']-report['steady_started']
        event('steady_end')
    finally:
        model.reset()
        report['total_wall_s'] = time.time()-started
        report['cuda_peak_allocated_bytes'] = torch.cuda.max_memory_allocated()
        report['cuda_peak_reserved_bytes'] = torch.cuda.max_memory_reserved()
        (args.out/'timing.json').write_text(json.dumps(report, indent=2))
        with (args.out/'events.jsonl').open('w') as stream:
            for row in _events:
                stream.write(json.dumps(row)+'\n')
        action_logger.removeHandler(action_handler)
        action_handler.close()
        applied_logger.removeHandler(applied_handler)
        applied_handler.close()


if __name__ == '__main__':
    main()
