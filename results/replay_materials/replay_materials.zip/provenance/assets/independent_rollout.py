"""Original independent1260 on each arm's accepted export, with new-only reports.

Allocation shards native inference only; checkpoint world/RNG identity remains the
accepted training source. No training, export, checkpoint GET, or DEV rerun occurs.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import io
import json
import math
import os
from pathlib import Path
import socket
import subprocess
import sys
import tarfile
import time
from types import SimpleNamespace

import archive_reports as reports
import checkpoint_storage as storage
import evaluate_final as evaluation
import unified_cost as sources

ARMS = ("P00", "P01", "P02", "P03", "P15")
TASKS = ("grasp", "t1_belt", "t1_occ", "t1_so3", "t1_xyz", "t2_se3", "t2_trans",
    "t3_full", "t3_phase", "t4_can", "t4_slider", "t4_sphere", "t4_sphere_tabletop", "t5_replan")
FIELDS = ("index", "task_id", "scenario_id", "source_seed", "inference_seed", "suite", "shard_index", "shard_count")
ROLLOUT_TIMEOUT = 43200
require, read, write = evaluation.require, evaluation.read, evaluation.write


def manifest(path, arm):
    value = read(path)
    require(set(value) == {"arms"} and [row["arm"] for row in value["arms"]] == list(ARMS),
        "exact five independent rollout sources required")
    for row in value["arms"]:
        require(set(row) == {"arm", "run_id", "world_size", "control_root", "evaluation_root"},
            "explicit own accepted source fields required")
        require(type(row["world_size"]) is int and row["world_size"] in evaluation.TRAINING_WORLD_SIZES
            and row["run_id"].endswith("-formal"), "original formal source world/run required")
        for key in ("control_root", "evaluation_root"):
            reports.root_path(Path(row[key]))
    for key in ("control_root", "evaluation_root"):
        require(len({row[key] for row in value["arms"]}) == len(ARMS), "source borrowed across arms")
    require(arm in ARMS, "arm outside authorized independent1260 scope")
    return next(row for row in value["arms"] if row["arm"] == arm)


def validate_selection(rows, fixed):
    """Exact original complement ordering; native manifest validates source seeds."""
    require(len(fixed) == 140 and [r["index"] for r in fixed] == list(range(140))
        and Counter(r["task_id"] for r in fixed) == Counter({task: 10 for task in TASKS})
        and [r["inference_seed"] for r in fixed] == list(range(20260918, 20261058)), "original fixed140 differs")
    require(len(rows) == 1260 and [r["index"] for r in rows] == list(range(1260))
        and Counter(r["task_id"] for r in rows) == Counter({task: 90 for task in TASKS})
        and [r["inference_seed"] for r in rows] == list(range(20261058, 20262318)),
        "original fourteen-by-ninety selection/seed ordering differs")
    require([(r["task_id"], r["shard_index"]) for r in rows]
        == sorted((r["task_id"], r["shard_index"]) for r in rows), "original task/shard order differs")
    combined = fixed + rows
    require(len({r["scenario_id"] for r in combined}) == 1400, "fixed140 overlap or duplicate scenario")
    for row in combined:
        require(set(row) == set(FIELDS) and type(row["source_seed"]) is int
            and type(row["shard_index"]) is int and 0 <= row["shard_index"] < 100
            and row["shard_count"] == 100 and row["task_id"] in TASKS
            and row["scenario_id"] == f"v1:validation:{row['task_id']}:{row['shard_index']:06d}"
            and Path(row["suite"]).name == f"sr_{row['task_id']}.yaml", "original scenario identity differs")
    for task in TASKS:
        require(sorted(r["shard_index"] for r in combined if r["task_id"] == task) == list(range(100)),
            "original full task shard pool differs")


def validate_live_scenes(rows, fixed, inputs):
    import yaml
    sys.path.insert(0, inputs["benchmark_source"])
    from se3_wam_benchmark.scenarios.manifest import load_manifest
    manifests, suites = {}, {}
    for row in fixed + rows:
        original = row["suite"]
        if original not in suites:
            suite = yaml.safe_load(Path(evaluation.mapped(original, inputs)).read_text())
            require(suite["repeats"] == 1 and len(suite["members"]) == 1
                and suite["members"][0]["task_ids"] == [row["task_id"]], "original single-task suite differs")
            path = Path(evaluation.mapped(suite["members"][0]["manifest"], inputs))
            require(path.is_absolute(), "explicit full native scenario manifest required")
            if path not in manifests:
                before = sources.file_stat(path)
                load_manifest(path)
                records = [json.loads(line) for line in path.read_text().splitlines() if line]
                require(sources.file_stat(path) == before, "scene manifest changed while reading")
                require(len(records) == 1400 and len({r["scenario_id"] for r in records}) == 1400,
                    "original full1400 native scenario manifest required")
                for task in TASKS:
                    require([r["scenario_id"] for r in records if r["task_id"] == task]
                        == [f"v1:validation:{task}:{i:06d}" for i in range(100)], "native shard ordinal changed")
                manifests[path] = ({r["scenario_id"]: r for r in records}, before)
            suites[original] = path
        record = manifests[suites[original]][0][row["scenario_id"]]
        require(record["task_id"] == row["task_id"] and record["source_seed"] == row["source_seed"]
            and record["partition"] == "validation" and record["scenario"]["action_mode"] == "E7",
            "native scene/task/source seed/action identity differs")
    return [{"path": str(path), "source_stat": value[1]} for path, value in manifests.items()]


def assigned(rows, world_size, gpus_per_node, node_rank):
    require(world_size in (4, 8, 16) and gpus_per_node == min(8, world_size)
        and node_rank in range(world_size // gpus_per_node), "explicit allocation topology differs")
    return [r for r in rows if node_rank * gpus_per_node <= r["index"] % world_size < (node_rank + 1) * gpus_per_node]


def stage(args, inputs, rows, fixed):
    """Reuse the accepted source adapter; change only independent selection/shards."""
    import yaml
    node = args.output / f"node-{args.node_rank}"
    evaluation.stage_rollout(SimpleNamespace(output=node), inputs)
    native = node / "native"
    old = read(native / "selection.json")
    suite_map = {row["task_id"]: row["suite"] for row in old}
    checked_suites = set()
    for row in rows:
        source, target = row["suite"], suite_map[row["task_id"]]
        if (source, target) not in checked_suites:
            original = yaml.safe_load(Path(evaluation.mapped(source, inputs)).read_text())
            accepted = yaml.safe_load(Path(target).read_text())
            require(evaluation.mapped(original, inputs) == accepted,
                "independent task suite contents differ from accepted full-pool suite")
            checked_suites.add((source, target))
    (native / "selection.json").rename(native / "fixed140-reference.json")
    (native / "one-scene.json").rename(native / "fixed140-one-scene-reference.json")
    selected = [{**r, "suite": suite_map[r["task_id"]]} for r in rows]
    write(native / "selection.json", selected)
    write(native / "one-scene.json", selected[:1])
    source = (native / "run_tier.py").read_text()
    source = evaluation.replace_once(source, "'--shard-index',str(rank)",
        f"'--shard-index',str(rank + {args.node_rank * args.gpus_per_node})")
    source = evaluation.replace_once(source, "'--shard-count',str(len(args.gpus)*args.per_gpu)",
        f"'--shard-count',str({args.world_size})")
    (native / "run_tier.py").write_text(source, encoding="utf-8")
    write(node / "independent-staging.json", {"selection": str(args.selection), "n": 1260,
        "allocation_world_size": args.world_size, "node_rank": args.node_rank,
        "scientific_fields_preserved": True, "suite_contents_exact_after_path_mapping": True,
        "warmup_excluded_from_1260": True,
        "formal_indices": [r["index"] for r in assigned(rows, args.world_size, args.gpus_per_node, args.node_rank)]})
    return native


def devices(native, workers, env):
    with (native / "egl-inventory.log").open("x") as log:
        subprocess.run([sys.executable, str(native / "egl_inventory.py")], cwd=native, env=env,
            stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    observed = json.loads(subprocess.check_output([sys.executable, "-c",
        "import json; from device_binding_pro6000 import cuda_nvml_bindings; print(json.dumps(cuda_nvml_bindings()))"],
        cwd=native, env=env, text=True))
    require(len(observed) == workers and {r["cuda_ordinal"] for r in observed} == set(range(workers)),
        "actual local CUDA allocation differs")
    inventory = read(native / "egl-inventory.json")
    bindings = []
    for row in sorted(observed, key=lambda r: r["cuda_ordinal"]):
        matching = [r for r in inventory if r.get("nvml_uuid") == row["nvml_uuid"] and "cuda_ordinal" in r]
        require(len(matching) == 1 and matching[0]["nvml_index"] == row["nvml_index"]
            and matching[0]["cuda_ordinal"] == row["cuda_ordinal"], "actual CUDA/NVML/EGL mapping differs")
        bindings.append({**matching[0], **row})
    require(len({r["nvml_uuid"] for r in bindings}) == workers
        and len({r["egl_index"] for r in bindings}) == workers, "local device identities not unique")
    return bindings


def tier_command(native, bindings, cpus, bundle):
    require(len(cpus) == 3 * len(bindings) and len(set(cpus)) == len(cpus), "three distinct CPU cores per GPU required")
    return [sys.executable, "-u", str(native / "run_tier.py"), "--name", "independent1260", "--gpus",
        *[str(r["nvml_index"]) for r in bindings], "--gpu-uuids", *[r["nvml_uuid"] for r in bindings],
        "--cuda-visible-devices", *[r["cuda_visible_device"] for r in bindings],
        "--egl-inventory", str(native / "egl-inventory.json"), "--per-gpu", "1", "--cpus", *map(str, cpus),
        "--threads-per-worker", "3", "--timeout", str(ROLLOUT_TIMEOUT),
        "--suite", str(native / "selection.json"), "--warmup-suite", str(native / "one-scene.json"),
        "--bundle", str(bundle), "--execution-translation-limit-m", "0.10"]


def accept_node(native, expected, workers, *, result_resolver=None):
    selected = {r["scenario_id"]: r for r in expected}
    supervisor = read(native / "independent1260/result.json")
    require(not supervisor["timeout"] and not supervisor["worker_failure"] and supervisor["supervisor_error"] is None
        and len(supervisor["workers"]) == workers and all(r["exit_code"] == 0 for r in supervisor["workers"]),
        "independent native workers failed")
    directories = sorted((native / "independent1260").glob("worker-*"))
    require(len(directories) == workers, "native worker evidence missing")
    episodes, seen, act_calls = [], set(), 0
    for directory in directories:
        completed = read(directory / "completed-episodes.json")
        groups = defaultdict(list)
        with (directory / "events.jsonl").open() as stream:
            for line in stream:
                event = json.loads(line)
                if event["kind"] == "act" and event["phase"] == "steady":
                    groups[event["episode_index"]].append(event)
        require(len(groups) == len(completed), "native tick coverage differs")
        for case, ticks in zip(completed, groups.values(), strict=True):
            key = case["scenario_id"]
            require(key in selected and key not in seen and all(case[k] == v for k, v in selected[key].items()),
                "duplicate/foreign independent scenario or seed")
            seen.add(key)
            result_path = Path(case["result"] if result_resolver is None else result_resolver(case["result"]))
            require(result_path.resolve().is_relative_to(directory.resolve()), "native result outside own worker")
            result = read(result_path)["results"]
            require(len(result) == 1 and result[0]["scenario_id"] == key and result[0]["task_id"] == case["task_id"]
                and type(result[0]["success"]) is bool and type(result[0]["episode_steps"]) is int
                and result[0]["episode_steps"] > 0, "complete native result identity missing")
            steps = result[0]["episode_steps"]
            require([t["tick"] for t in ticks] == list(range(steps)), "native ticks skipped/repeated")
            times = [t["physical_s"] for t in ticks]
            require(all(math.isfinite(t) for t in times)
                and all(abs(b - a - .05) < 1e-7 for a, b in zip(times, times[1:])), "native physical 50ms clock differs")
            # Result fields cannot replace original selection identity fields.
            episodes.append({**result[0], **selected[key], "result": case["result"]})
            act_calls += steps
    require(seen == selected.keys(), "independent node scenario coverage incomplete")
    return {"accepted": True, "episodes": sorted(episodes, key=lambda r: r["index"]), "act_calls": act_calls}


def merge_nodes(args, rows, source):
    episodes, act_calls, seen = [], 0, set()
    for node in range(args.world_size // args.gpus_per_node):
        value = read(args.output / f"node-{node}" / "accepted.json")
        require(value["accepted"] is True and value["arm"] == args.arm and value["source"] == source
            and value["node_rank"] == node and value["allocation_world_size"] == args.world_size,
            "foreign/incomplete node acceptance")
        for row in value["episodes"]:
            index = row["index"]
            require(index not in seen and index in range(1260)
                and all(row[k] == rows[index][k] for k in FIELDS if k != "suite")
                and node * args.gpus_per_node <= index % args.world_size < (node + 1) * args.gpus_per_node,
                "duplicate or changed cross-node scenario identity")
            seen.add(index)
            episodes.append(row)
        act_calls += value["act_calls"]
    require(seen == set(range(1260)), "all original1260 scenarios required")
    episodes.sort(key=lambda r: r["index"])
    tasks = {task: {"n": 90, "successes": sum(r["success"] for r in episodes if r["task_id"] == task)} for task in TASKS}
    for value in tasks.values():
        value["sr"] = value["successes"] / 90
    return {"accepted": True, "arm": args.arm, "source": source, "checkpoint": source["bundle"],
        "source_world_size": source["world_size"], "allocation_world_size": args.world_size,
        "optimizer_step": 40104, "completed_epochs": 4, "n": 1260,
        "successes": sum(r["success"] for r in episodes), "episodes": episodes, "tasks": tasks,
        "macro_sr": sum(t["sr"] for t in tasks.values()) / 14, "act_calls": act_calls,
        "period_s": .05, "complete_native_ticks": True, "original_scenario_and_seed_fields": True,
        "fixed140_overlap": 0, "training_seeds": 1, "infrastructure_errors": 0, "missing_scenarios": 0,
        "scope": "independent1260 only; no fresh training, DEV rerun, or cross-training-seed claim"}


def archive(args):
    target = args.archive_target
    parts = target.relative_to(storage.FUTURE_PREFIX).parts
    require(len(parts) == 4 and parts[1] == args.arm and parts[2] == args.output.name and parts[3] == "reports.tar"
        and ".." not in parts, "own new independent report target required")
    require(storage.filesystem(args.output) == "gpfs", "independent reports require GPFS")
    destination = args.output.with_name(args.output.name + "-archive")
    destination.mkdir()
    def inventory():
        files = []
        for directory, dirs, names in os.walk(args.output, followlinks=False):
            dirs[:] = [name for name in dirs if name not in ("tmp", "cache", "__pycache__")]
            require(not any((Path(directory) / name).is_symlink() for name in dirs), "report directory symlink")
            for name in names:
                path = Path(directory) / name
                info = reports.regular(path)
                require(path.suffix not in (".pt", ".pth"), "model bytes cannot enter report archive")
                files.append({"member": "independent1260/" + path.relative_to(args.output).as_posix(),
                    "source_path": str(path), "bytes": info.st_size, "mtime_ns": info.st_mtime_ns})
        return sorted(files, key=lambda r: r["member"])
    rows = inventory()
    value = {"kind": "FUTURE0_independent1260_reports", "version": 1, "arm": args.arm,
        "source_root": str(args.output), "files": rows, "scope": "native reports, action/tick traces and source identity; no model bytes or caches"}
    payload = (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()
    path = destination / "reports.tar"
    with path.open("xb") as stream:
        with tarfile.open(fileobj=stream, mode="w", format=tarfile.PAX_FORMAT) as tar:
            header = tarfile.TarInfo("manifest.json")
            header.size = len(payload)
            tar.addfile(header, io.BytesIO(payload))
            for row in rows:
                info = tar.gettarinfo(row["source_path"], arcname=row["member"])
                require(info.isfile() and info.size == row["bytes"], "archive source changed")
                with Path(row["source_path"]).open("rb") as data:
                    tar.addfile(info, data)
        stream.flush()
        os.fsync(stream.fileno())
    reports.check_archive(path, value, payload)
    require(inventory() == rows, "reports changed during packaging")
    copied = storage.publish_tos_copy(path, target, object_client_dir=args.object_client_dir,
        log_dir=destination / "object-api", readback_path=destination / "reports.tos-readback.tar", transfer_timeout=1800)
    reports.check_archive(destination / "reports.tos-readback.tar", value, payload)
    head = storage.confirm_object_head(target, path.stat().st_size,
        object_client_dir=args.object_client_dir, log_dir=destination / "object-api")
    require(inventory() == rows, "reports changed during publication")
    receipt = {"kind": "FUTURE0_independent1260_archive", "accepted": True, "arm": args.arm,
        "n": 1260, "file_count": len(rows), "tos_copy": copied, "object_api_head": head,
        "complete_member_set_and_source_bytes_exact": True, "model_bytes_archived": False}
    write(destination / "accepted.json", receipt)
    storage.publish_tos_copy(destination / "accepted.json", target.with_name("accepted.json"),
        object_client_dir=args.object_client_dir, log_dir=destination / "object-api",
        readback_path=destination / "accepted.tos-readback.json")
    storage.confirm_object_head(target.with_name("accepted.json"), (destination / "accepted.json").stat().st_size,
        object_client_dir=args.object_client_dir, log_dir=destination / "object-api")
    return receipt


def wait_for(args, paths, deadline):
    while True:
        check_peers(args)
        if all(path.is_file() for path in paths):
            return
        require(time.monotonic() < deadline, "independent node coordination deadline exhausted")
        time.sleep(1)


def check_peers(args):
    for node in range(args.world_size // args.gpus_per_node):
        failed = args.output / f"node-{node}" / "failure.json"
        if failed.is_file():
            raise RuntimeError("independent peer failed: " + str(failed))


def run(args):
    assigned([], args.world_size, args.gpus_per_node, args.node_rank)
    reports.root_path(args.output)
    require(args.output.parent.name == "independent1260" and args.output.parent.parent.name == args.arm,
        "own independent1260 output namespace required")
    # Each node claims its own new directory; no prior attempt can be reused.
    args.output.mkdir(parents=True, exist_ok=True)
    node = args.output / f"node-{args.node_rank}"
    node.mkdir()
    deadline = time.monotonic() + ROLLOUT_TIMEOUT + 7200
    child = None
    try:
        inputs = evaluation.load_inputs(args.inputs)
        row = manifest(args.manifest, args.arm)
        source = sources.source_identity(row, inputs)
        selected, fixed = read(args.selection), read(inputs["fixed140_selection"])
        validate_selection(selected, fixed)
        scene_sources = validate_live_scenes(selected, fixed, inputs)
        write(node / "execution.json", {"arm": args.arm, "source": source, "inputs": str(args.inputs),
            "node_rank": args.node_rank, "allocation_world_size": args.world_size,
            "gpus_per_node": args.gpus_per_node, "hostname": socket.gethostname(), "scenes": scene_sources})
        native = stage(args, inputs, selected, fixed)
        env = evaluation.environment()
        bindings = devices(native, args.gpus_per_node, env)
        cpus = sorted(os.sched_getaffinity(0))[:3 * args.gpus_per_node]
        command = tier_command(native, bindings, cpus, source["bundle"])
        write(node / "devices.json", {"bindings": bindings, "cpus": cpus})
        write(node / "command.json", {"argv": command, "source_world_size": row["world_size"], "started_at": time.time()})
        # The outer prepared console owns controller stdout/stderr. Native workers
        # keep their complete process/action/tick logs in their own report roots.
        child = subprocess.Popen(command, cwd=native, env=env, start_new_session=True)
        child_deadline = time.monotonic() + ROLLOUT_TIMEOUT + 300
        while child.poll() is None:
            check_peers(args)
            require(time.monotonic() < child_deadline, "native independent subprocess deadline exhausted")
            time.sleep(1)
        require(child.wait() == 0, "native independent subprocess failed")
        value = accept_node(native, assigned(read(native / "selection.json"), args.world_size,
            args.gpus_per_node, args.node_rank), args.gpus_per_node)
        require(sources.source_identity(row, inputs) == source, "accepted source changed during rollout")
        write(node / "accepted.json", {**value, "arm": args.arm, "source": source,
            "node_rank": args.node_rank, "allocation_world_size": args.world_size})
        # Publish readiness only after the complete JSON has been flushed/fsynced.
        (node / "ready").touch(exist_ok=False)
        if args.node_rank == 0:
            wait_for(args, [args.output / f"node-{n}" / "ready"
                for n in range(args.world_size // args.gpus_per_node)], deadline)
            value = merge_nodes(args, selected, source)
            write(args.output / "accepted.json", value)
            write(args.output / "selection.json", selected)
            write(args.output / "source.json", source)
            if os.environ.get("WANDB_NATIVE_ENABLE") == "1":
                sys.path.insert(0, str(Path(__file__).parent / "monitoring"))
                from wandb_native import accepted_rollout
                accepted_rollout("se3", value, expected_checkpoint=source["bundle"], checkpoint_step=40104,
                    world_size=source["world_size"])
            receipt = archive(args)
            write(args.output / "archive-complete.json", receipt)
            print("FUTURE0_INDEPENDENT1260=" + json.dumps({"arm": args.arm, "accepted": True,
                "n": 1260, "successes": value["successes"], "archive": receipt}), flush=True)
        else:
            wait_for(args, [args.output / "archive-complete.json"], deadline)
    except BaseException as error:
        try:
            write(node / "failure.json", {"arm": args.arm, "node_rank": args.node_rank, "error_type": type(error).__name__})
        except Exception as reporting_error:
            print("FUTURE0_INDEPENDENT_FAILURE_RECORD=" + type(reporting_error).__name__, flush=True)
        raise
    finally:
        if child is not None and child.poll() is None:
            import signal
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()


def main():
    import signal
    def interrupted(signum, frame):
        raise InterruptedError("independent controller received signal " + str(signum))
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, interrupted)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=ARMS, required=True)
    for name in ("manifest", "selection", "inputs", "output", "object-client-dir", "archive-target"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--world-size", type=int, choices=(16, 8, 4), required=True)
    parser.add_argument("--gpus-per-node", type=int, choices=(8, 4), required=True)
    parser.add_argument("--node-rank", type=int, required=True)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
